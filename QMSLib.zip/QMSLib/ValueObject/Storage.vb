Namespace VO
    Public Class Storage
        Property ComLocDivSubDivID As Integer
        Property CompanyID As String
        Property LocationID As String
        Property ProgramID As String
        Property StorageGroupID As String
        Property StorageID As String
        Property StorageGroupName As String
        Property StorageName As String
        Property IsBlackList As Boolean
    End Class
End Namespace

