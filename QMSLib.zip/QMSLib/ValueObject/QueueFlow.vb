Namespace VO
    Public Class QueueFlow
        Inherits Common
        Property ID As String
        Property Name As String
        Property Type As Byte
        Property TypeInfo As String
        Property IsDefault As Boolean
        Property IDStatus As Byte
        Property Remarks As String
    End Class 
End Namespace

