Namespace VO
    Public Class QueueDetStatus
        Inherits Common
        Property ID As String
        Property QueueDetID As String
        Property StationID As Integer
        Property SubStationID As Integer
        Property Status As String
        Property StatusBy As String
        Property StatusDate As DateTime
        Property Remarks As String

        Enum StatusAction
            Request = 1
            CancelRequest = 2
            Done = 3
            CancelDone = 4
            OnHold = 5
            CancelOnHold = 6
            Reject = 7
            CancelReject = 8
            Start = 9
            CancelStart = 10
        End Enum

        Public Function StatusToString(ByVal action As StatusAction) As String
            Dim strReturn As String = "-"
            Select Case action
                Case QueueDetStatus.StatusAction.Request : strReturn = "REQUEST"
                Case QueueDetStatus.StatusAction.CancelRequest : strReturn = "CANCEL REQUEST"

                Case QueueDetStatus.StatusAction.Done : strReturn = "DONE"
                Case QueueDetStatus.StatusAction.CancelDone : strReturn = "CANCEL DONE"

                Case QueueDetStatus.StatusAction.OnHold : strReturn = "ONHOLD"
                Case QueueDetStatus.StatusAction.CancelOnHold : strReturn = "CANCEL ONHOLD"

                Case QueueDetStatus.StatusAction.Reject : strReturn = "REJECT"
                Case QueueDetStatus.StatusAction.CancelReject : strReturn = "CANCEL REJECT"

                Case QueueDetStatus.StatusAction.Start : strReturn = "START"
                Case QueueDetStatus.StatusAction.CancelStart : strReturn = "CANCEL START"
            End Select
            Return strReturn
        End Function

    End Class
End Namespace

