Namespace VO
    Public Class Queue
        Inherits Common
        Property LocationID As String
        Property LocationName As String
        Property ID As String
        Property QueueNumber As Integer
        Property TicketParkingID As String
        Property QueueDate As DateTime
        Property PlatNumber As String
        Property DriverID As String
        Property DriverFullName As String
        Property SPBNumber As String
        Property RFID As String
        Property NewRFID As String
        Property ComLocDivSubDivIDStorage As Integer
        Property ProgramIDStorage As String = ""
        Property StorageGroupID As String
        Property StorageGroupName As String = ""
        Property StorageID As String
        Property StorageName As String = ""
        Property IsFreePass As Boolean = False
        Property WBNumber As String
        Property WBProgramID As String
        Property WBProgramName As String
        Property ContractNumber As String = ""
        Property QueueType As Type = Type.None
        Property QueueTypeName As String
        Property QueueFlowID As String = ""
        Property QueueFlowName As String = ""
        Property ItemCode As String = ""
        Property ItemName As String = ""
        Property IsRepeat As Boolean
        Property IsArrange As Boolean
        Property ReferencesID As String = ""
        Property IDStatus As Byte
        Property IsCompleted As Boolean
        Property CompletedBy As String
        Property CompletedDate As DateTime
        Property IsDeleted As Boolean
        Property Remarks As String
        Property IsHold As Boolean
        Property Position As String
        Property QueueDetail As VO.QueueDet

        Enum Action
            UpdateIsFreePass = 0
            UpdateIsRepeat = 1
        End Enum

        Enum Filter
            RFID = 0
            PlatNumber = 1
        End Enum

        Enum Type
            None = 0
            Incoming = 1
            Outgoing = 2
        End Enum

    End Class
End Namespace

