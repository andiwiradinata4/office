Namespace VO
    Public Class DriverImage
        Inherits Common
        Property ID As String
        Property DriverID As String
        Property ImagePath As String
        Property ImageTypeID As Byte
        Property ImageTypeName As String
        Property FileExtension As String
        Property ByteOfImage As Byte()
        Property IsNewFile As Boolean
    End Class 
End Namespace

