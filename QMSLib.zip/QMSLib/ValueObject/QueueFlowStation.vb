Namespace VO
    Public Class QueueFlowStation
        Inherits Common
        Property ID As String
        Property QueueFlowID As String
        Property Idx As Integer
        Property StationID As Integer
        Property StationName As String
    End Class 
End Namespace

