Namespace VO
    Public Class StorageLaneSwitchingStatus
        Inherits Common
        Property ID As String
        Property StorageLaneSwitchingID As String
        Property Status As String
        Property StatusBy As String
        Property StatusDate As DateTime
        Property Remarks As String
    End Class 
End Namespace

