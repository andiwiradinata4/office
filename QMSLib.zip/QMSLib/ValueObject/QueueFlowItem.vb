Namespace VO
    Public Class QueueFlowItem
        Inherits Common
        Property ID As String
        Property ItemCode As String
        Property ItemName As String
        Property QueueFlowID As String
    End Class 
End Namespace

