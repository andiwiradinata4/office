Namespace VO
    Public Class BloodType
        Inherits Common
        Property ID As Byte
        Property Description As String
        Property IDStatus As Byte
        Property Remarks As String

        Enum Values
            None = 0
        End Enum
    End Class
End Namespace

