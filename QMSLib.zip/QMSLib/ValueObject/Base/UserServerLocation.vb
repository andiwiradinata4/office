Namespace VO
    Public Class UserServerLocation
        Property ComLocDivSubDivID As Integer
        Property Server As String
        Property DBName As String
    End Class 
End Namespace

