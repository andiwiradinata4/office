﻿Namespace VO

    Public Class Item

        Inherits Common

        Private intItemID As Integer
        Private strItemCode, strItemName, strUomCode As String
        Private strRemarks As String

        Private intClassID As Integer
        Private strClassCode, strClassName As String

        Private intGroupID As Integer
        Private strGroupCode, strGroupName As String

        Private intCategoryID As Integer
        Private strCategoryCode, strCategoryName As String

        Private intSubCategory1ID As Integer
        Private strSubCategory1Code, strSubCategory1Name As String

        Private intSubCategory2ID As Integer
        Private strSubCategory2Code, strSubCategory2Name As String

        Private intAccGroupID As Integer
        Private strAccGroupCode, strAccGroupName As String

        Private intAccCategoryID As Integer
        Private strAccCategoryCode, strAccCategoryName As String

        Private intAccSubCategoryID As Integer
        Private strAccSubCategoryCode, strAccSubCategoryName As String

        Private intStatus As Integer
        Private strStatusBy As String
        Private strStatusRemarks As String
        Private dtmStatusDate As DateTime

        Private dblRefPrice As Double
        Private dtRefDate As Date

        Private strHSCode As String

        Private strxName, strxBrand, strxType, strxSpec, strxCountry As String

        Private dblxToleranceType, dblxToleranceValue As Double
        Private strxID1, strxID2, strxID2Uom As String
        Private dblxID2Ratio As Double

        Private intIsCriticalChemical, intIsCriticalFuel As Integer

        Private strGNCode, strGNName As String

        Private strHSCodeBy As String
        Private dtmHSCodeDate As String
        Private bolIsContract, bolLocationItem As Boolean
        Private decMinQty, decMaxQty, decWeighInKg As Decimal

        Private strItemChineseName, strItemSpanishName, strPartNumber As String
        Private strCurrency, strBPName, strPONumber As String
        Private decUnitPrice As Decimal
        Private dtPODate As DateTime

        Public Property ItemID() As Integer
            Get
                Return intItemID
            End Get
            Set(ByVal value As Integer)
                intItemID = value
            End Set
        End Property

        Public Property ItemCode() As String
            Get
                Return strItemCode
            End Get
            Set(ByVal value As String)
                strItemCode = value
            End Set
        End Property

        Public Property ItemName() As String
            Get
                Return strItemName
            End Get
            Set(ByVal value As String)
                strItemName = value
            End Set
        End Property

        Public Property UomCode() As String
            Get
                Return strUomCode
            End Get
            Set(ByVal value As String)
                strUomCode = value
            End Set
        End Property

        Public Property ClassID() As Integer
            Get
                Return intClassID
            End Get
            Set(ByVal value As Integer)
                intClassID = value
            End Set
        End Property

        Public Property ClassCode() As String
            Get
                Return strClassCode
            End Get
            Set(ByVal value As String)
                strClassCode = value
            End Set
        End Property

        Public Property ClassName() As String
            Get
                Return strClassName
            End Get
            Set(ByVal value As String)
                strClassName = value
            End Set
        End Property

        Public Property GroupID() As Integer
            Get
                Return intGroupID
            End Get
            Set(ByVal value As Integer)
                intGroupID = value
            End Set
        End Property

        Public Property GroupCode() As String
            Get
                Return strGroupCode
            End Get
            Set(ByVal value As String)
                strGroupCode = value
            End Set
        End Property

        Public Property GroupName() As String
            Get
                Return strGroupName
            End Get
            Set(ByVal value As String)
                strGroupName = value
            End Set
        End Property

        Public Property CategoryID() As Integer
            Get
                Return intCategoryID
            End Get
            Set(ByVal value As Integer)
                intCategoryID = value
            End Set
        End Property

        Public Property CategoryCode() As String
            Get
                Return strCategoryCode
            End Get
            Set(ByVal value As String)
                strCategoryCode = value
            End Set
        End Property

        Public Property CategoryName() As String
            Get
                Return strCategoryName
            End Get
            Set(ByVal value As String)
                strCategoryName = value
            End Set
        End Property

        Public Property SubCategory1ID() As Integer
            Get
                Return intSubCategory1ID
            End Get
            Set(ByVal value As Integer)
                intSubCategory1ID = value
            End Set
        End Property

        Public Property SubCategory1Code() As String
            Get
                Return strSubCategory1Code
            End Get
            Set(ByVal value As String)
                strSubCategory1Code = value
            End Set
        End Property

        Public Property SubCategory1Name() As String
            Get
                Return strSubCategory1Name
            End Get
            Set(ByVal value As String)
                strSubCategory1Name = value
            End Set
        End Property

        Public Property SubCategory2ID() As Integer
            Get
                Return intSubCategory2ID
            End Get
            Set(ByVal value As Integer)
                intSubCategory2ID = value
            End Set
        End Property

        Public Property SubCategory2Code() As String
            Get
                Return strSubCategory2Code
            End Get
            Set(ByVal value As String)
                strSubCategory2Code = value
            End Set
        End Property

        Public Property SubCategory2Name() As String
            Get
                Return strSubCategory2Name
            End Get
            Set(ByVal value As String)
                strSubCategory2Name = value
            End Set
        End Property

        Public Property AccGroupID() As Integer
            Get
                Return intAccGroupID
            End Get
            Set(ByVal value As Integer)
                intAccGroupID = value
            End Set
        End Property

        Public Property AccGroupCode() As String
            Get
                Return strAccGroupCode
            End Get
            Set(ByVal value As String)
                strAccGroupCode = value
            End Set
        End Property

        Public Property AccGroupName() As String
            Get
                Return strAccGroupName
            End Get
            Set(ByVal value As String)
                strAccGroupName = value
            End Set
        End Property

        Public Property AccCategoryID() As Integer
            Get
                Return intAccCategoryID
            End Get
            Set(ByVal value As Integer)
                intAccCategoryID = value
            End Set
        End Property

        Public Property AccCategoryCode() As String
            Get
                Return strAccCategoryCode
            End Get
            Set(ByVal value As String)
                strAccCategoryCode = value
            End Set
        End Property

        Public Property AccCategoryName() As String
            Get
                Return strAccCategoryName
            End Get
            Set(ByVal value As String)
                strAccCategoryName = value
            End Set
        End Property

        Public Property AccSubCategoryID() As Integer
            Get
                Return intAccSubCategoryID
            End Get
            Set(ByVal value As Integer)
                intAccSubCategoryID = value
            End Set
        End Property

        Public Property AccSubCategoryCode() As String
            Get
                Return strAccSubCategoryCode
            End Get
            Set(ByVal value As String)
                strAccSubCategoryCode = value
            End Set
        End Property

        Public Property AccSubCategoryName() As String
            Get
                Return strAccSubCategoryName
            End Get
            Set(ByVal value As String)
                strAccSubCategoryName = value
            End Set
        End Property

        Public Property Status() As Integer
            Get
                Return intStatus
            End Get
            Set(ByVal value As Integer)
                intStatus = value
            End Set
        End Property

        Public Property StatusBy() As String
            Get
                Return strStatusBy
            End Get
            Set(ByVal value As String)
                strStatusBy = value
            End Set
        End Property

        Public Property StatusRemarks() As String
            Get
                Return strStatusRemarks
            End Get
            Set(ByVal value As String)
                strStatusRemarks = value
            End Set
        End Property

        Public Property StatusDate() As DateTime
            Get
                Return dtmStatusDate
            End Get
            Set(ByVal value As DateTime)
                dtmStatusDate = value
            End Set
        End Property

        Public Property Remarks() As String
            Get
                Return strRemarks
            End Get
            Set(ByVal value As String)
                strRemarks = value
            End Set
        End Property

        Public Property xName() As String
            Get
                Return strxName
            End Get
            Set(ByVal value As String)
                strxName = value
            End Set
        End Property

        Public Property xBrand() As String
            Get
                Return strxBrand
            End Get
            Set(ByVal value As String)
                strxBrand = value
            End Set
        End Property

        Public Property xType() As String
            Get
                Return strxType
            End Get
            Set(ByVal value As String)
                strxType = value
            End Set
        End Property

        Public Property xSpec() As String
            Get
                Return strxSpec
            End Get
            Set(ByVal value As String)
                strxSpec = value
            End Set
        End Property

        Public Property xCountry() As String
            Get
                Return strxCountry
            End Get
            Set(ByVal value As String)
                strxCountry = value
            End Set
        End Property

        Public Property xToleranceType() As Double
            Get
                Return dblxToleranceType
            End Get
            Set(ByVal value As Double)
                dblxToleranceType = value
            End Set
        End Property

        Public Property xToleranceValue() As Double
            Get
                Return dblxToleranceValue
            End Get
            Set(ByVal value As Double)
                dblxToleranceValue = value
            End Set
        End Property

        Public Property xID1() As String
            Get
                Return strxID1
            End Get
            Set(ByVal value As String)
                strxID1 = value
            End Set
        End Property

        Public Property xID2() As String
            Get
                Return strxID2
            End Get
            Set(ByVal value As String)
                strxID2 = value
            End Set
        End Property

        Public Property xID2Uom() As String
            Get
                Return strxID2Uom
            End Get
            Set(ByVal value As String)
                strxID2Uom = value
            End Set
        End Property

        Public Property xID2Ratio() As Double
            Get
                Return dblxID2Ratio
            End Get
            Set(ByVal value As Double)
                dblxID2Ratio = value
            End Set
        End Property

        Public Property RefPrice() As Double
            Get
                Return dblRefPrice
            End Get
            Set(ByVal value As Double)
                dblRefPrice = value
            End Set
        End Property

        Public Property RefDate() As Date
            Get
                Return dtRefDate
            End Get
            Set(ByVal value As Date)
                dtRefDate = value
            End Set
        End Property

        Public Property HSCode() As String
            Get
                Return strHSCode
            End Get
            Set(ByVal value As String)
                strHSCode = value
            End Set
        End Property

        Public Property IsCriticalChemical() As Integer
            Get
                Return intIsCriticalChemical
            End Get
            Set(ByVal value As Integer)
                intIsCriticalChemical = value
            End Set
        End Property

        Public Property IsCriticalFuel() As Integer
            Get
                Return intIsCriticalFuel
            End Get
            Set(ByVal value As Integer)
                intIsCriticalFuel = value
            End Set
        End Property

        Public Property GNCode() As String
            Get
                Return strGNCode
            End Get
            Set(ByVal value As String)
                strGNCode = value
            End Set
        End Property

        Public Property GNName() As String
            Get
                Return strGNName
            End Get
            Set(ByVal value As String)
                strGNName = value
            End Set
        End Property

        Public Property HSCodeBy() As String
            Get
                Return strHSCodeBy
            End Get
            Set(ByVal value As String)
                strHSCodeBy = value
            End Set
        End Property

        Public Property HSCodeDate() As DateTime
            Get
                Return dtmHSCodeDate
            End Get
            Set(ByVal value As DateTime)
                dtmHSCodeDate = value
            End Set
        End Property

        Public Property MinQty() As Decimal
            Get
                Return decMinQty
            End Get
            Set(value As Decimal)
                decMinQty = value
            End Set
        End Property

        Public Property MaxQty() As Decimal
            Get
                Return decMaxQty
            End Get
            Set(value As Decimal)
                decMaxQty = value
            End Set
        End Property

        Public Property IsContract() As Boolean
            Get
                Return bolIsContract
            End Get
            Set(value As Boolean)
                bolIsContract = value
            End Set
        End Property

        'update RH20160408
        Public Property ItemChineseName() As String
            Get
                Return strItemChineseName
            End Get
            Set(ByVal value As String)
                strItemChineseName = value
            End Set
        End Property

        Public Property ItemSpanishName() As String
            Get
                Return strItemSpanishName
            End Get
            Set(ByVal value As String)
                strItemSpanishName = value
            End Set
        End Property

        Public Property WeightInKg() As Decimal
            Get
                Return decWeighInKg
            End Get
            Set(value As Decimal)
                decWeighInKg = value
            End Set
        End Property

        Public Property PartNumber() As String
            Get
                Return strPartNumber
            End Get
            Set(value As String)
                strPartNumber = value
            End Set
        End Property

        Public Property LastCurrency() As String
            Get
                Return strCurrency
            End Get
            Set(value As String)
                strCurrency = value
            End Set
        End Property

        Public Property LastUnitPrice() As Decimal
            Get
                Return decUnitPrice
            End Get
            Set(value As Decimal)
                decUnitPrice = value
            End Set
        End Property

        Public Property LastSupplier() As String
            Get
                Return strBPName
            End Get
            Set(value As String)
                strBPName = value
            End Set
        End Property

        Public Property LastPONumber() As String
            Get
                Return strPONumber
            End Get
            Set(value As String)
                strPONumber = value
            End Set
        End Property

        Public Property LastPODate() As DateTime
            Get
                Return dtPODate
            End Get
            Set(value As DateTime)
                dtPODate = value
            End Set
        End Property

        Public Property LocationItem() As Boolean
            Get
                Return bolLocationItem
            End Get
            Set(value As Boolean)
                bolLocationItem = value
            End Set
        End Property

    End Class

End Namespace
