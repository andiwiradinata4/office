Namespace VO
    Public Class Modules
        Inherits Common
        Property ID As Byte
        Property Description As String
        Property Remarks As String
        Property IsActive As Boolean

        Enum Values
            All = 0
            Station = 1
            SubStation = 2
            Gender = 3
            Religion = 4
            Nationality = 5
            MaritalStatus = 6
            BloodType = 7
            Occupations = 8
            DrivingLicenseType = 9
            ImageType = 10
            Driver = 11
            QueueFlow = 12
            Queue = 13
            RFID = 14
            Storage = 15
            QueueDetail = 16
        End Enum
    End Class
End Namespace

