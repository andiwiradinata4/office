Namespace VO
    Public Class LPRHistory
        Inherits Common
        Property ID As String
        Property RequestDate As DateTime
        Property ResponseDate As DateTime
        Property DifferentInSecond As Decimal
        Property ResponseID As String
        Property WBID As String
        Property GarduID As Integer
        Property Type As String
        Property PlatNumber As String
        Property PlatNumberResponse As String
        Property PlatNumberAcknowledge As String
        Property CaptureDate As DateTime
        Property Status As Boolean
        Property Message As String
        Property ReferencesID As String
        Property Remarks As String
    End Class 
End Namespace

