Namespace VO
    Public Class Station
        Inherits Common
        Property ID As Integer
        Property Description As String
        Property IsLinkStorage As Boolean
        Property IDStatus As Byte
        Property Remarks As String

        Enum Values
            All
            Security
            WeightBridge
            Laboratory
            Unloading
        End Enum

    End Class
End Namespace

