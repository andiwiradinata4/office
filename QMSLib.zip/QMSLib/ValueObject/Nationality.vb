Namespace VO
    Public Class Nationality
        Inherits Common
        Property ID As Byte
        Property Description As String
        Property IDStatus As Byte
        Property Remarks As String

        Enum Values
            WNI = 1
        End Enum
    End Class 
End Namespace

