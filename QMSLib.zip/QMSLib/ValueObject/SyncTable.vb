Namespace VO
    Public Class SyncTable
        Inherits Common
        Property ID As Integer
        Property ModuleID As Byte
        Property SyncDate As New DateTime(2000, 1, 1)
        Property SyncBy As String
    End Class 
End Namespace

