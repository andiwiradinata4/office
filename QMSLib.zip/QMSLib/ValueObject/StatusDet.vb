Namespace VO
    Public Class StatusDet
        Inherits Common
        Property ID As Integer
        Property ModuleID As Byte
        Property IDStatus As Byte
    End Class 
End Namespace

