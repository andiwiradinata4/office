Namespace DL
    Friend Class Religion

        Protected Friend Shared Function ListData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                  Optional ByVal bytIDStatus As Byte = VO.Status.Values.All) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "SELECT " & vbNewLine &
                   "    A.ID, A.Description, A.IDStatus, B.Description AS StatusInfo, A.Remarks, A.CreatedBy, A.CreatedDate, A.LogBy,   " & vbNewLine &
                   "    A.LogDate, A.LogInc  " & vbNewLine &
                   "FROM QMS_mstReligion A " & vbNewLine &
                   "INNER JOIN QMS_mstStatus B ON " & vbNewLine &
                   "    A.IDStatus=B.ID " & vbNewLine &
                   "WHERE 1=1 " & vbNewLine

                If bytIDStatus <> VO.Status.Values.All Then
                    .CommandText += "   AND A.IDStatus=@IDStatus " & vbNewLine
                End If

                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = bytIDStatus
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub SaveData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                             ByVal bolNew As Boolean, ByVal clsData As VO.Religion)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                If bolNew Then
                    .CommandText =
                       "INSERT INTO QMS_mstReligion " & vbNewLine &
                       "    (ID, Description, IDStatus, Remarks, CreatedBy, LogBy)   " & vbNewLine &
                       "VALUES " & vbNewLine &
                       "    (@ID, @Description, @IDStatus, @Remarks, @LogBy, @LogBy)  " & vbNewLine
                Else
                    .CommandText =
                       "UPDATE QMS_mstReligion SET " & vbNewLine &
                       "    Description=@Description, " & vbNewLine &
                       "    IDStatus=@IDStatus, " & vbNewLine &
                       "    Remarks=@Remarks, " & vbNewLine &
                       "    LogBy=@LogBy, " & vbNewLine &
                       "    LogDate=GETDATE(), " & vbNewLine &
                       "    LogInc=LogInc+1 " & vbNewLine &
                       "WHERE " & vbNewLine &
                       "    ID=@ID " & vbNewLine
                End If

                .Parameters.Add("@ID", SqlDbType.TinyInt).Value = clsData.ID
                .Parameters.Add("@Description", SqlDbType.VarChar, 50).Value = clsData.Description
                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = clsData.IDStatus
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal bytID As Byte) As VO.Religion
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voReturn As New VO.Religion
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                       "SELECT TOP 1 " & vbNewLine &
                       "    A.ID, A.Description, A.IDStatus, B.Description AS StatusInfo, A.Remarks, A.CreatedBy, A.CreatedDate, A.LogBy,   " & vbNewLine &
                       "    A.LogDate, A.LogInc  " & vbNewLine &
                       "FROM QMS_mstReligion A " & vbNewLine &
                       "INNER JOIN QMS_mstStatus B ON " & vbNewLine &
                       "    A.IDStatus=B.ID " & vbNewLine &
                       "WHERE " & vbNewLine &
                       "    A.ID=@ID " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.TinyInt).Value = bytID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voReturn.ID = .Item("ID")
                        voReturn.Description = .Item("Description")
                        voReturn.IDStatus = .Item("IDStatus")
                        voReturn.StatusInfo = .Item("StatusInfo")
                        voReturn.Remarks = .Item("Remarks")
                        voReturn.CreatedBy = .Item("CreatedBy")
                        voReturn.CreatedDate = .Item("CreatedDate")
                        voReturn.LogBy = .Item("LogBy")
                        voReturn.LogDate = .Item("LogDate")
                        voReturn.LogInc = .Item("LogInc")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voReturn
        End Function

        Protected Friend Shared Sub DeleteData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                               ByVal clsData As VO.Religion)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE QMS_mstReligion " & vbNewLine &
                    "   SET IDStatus=@IDStatus, " & vbNewLine &
                    "   LogBy=@LogBy, " & vbNewLine &
                    "   LogDate=GETDATE(), " & vbNewLine &
                    "   LogInc=LogInc+1  " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "   ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.TinyInt).Value = clsData.ID
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = VO.Status.Values.InActive
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetMaxID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intReturn As Integer = 0
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ID=ISNULL(MAX(ID),0) " & vbNewLine &
                        "FROM QMS_mstReligion " & vbNewLine

                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intReturn = .Item("ID") + 1
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return intReturn
        End Function

        Protected Friend Shared Function IsIDExists(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                    ByVal bytID As Byte) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ID " & vbNewLine &
                        "FROM QMS_mstReligion " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   ID=@ID " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.TinyInt).Value = bytID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

        Protected Friend Shared Function IsDescriptionExists(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                             ByVal bytID As Byte, ByVal strDescription As String) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   Description " & vbNewLine &
                        "FROM QMS_mstReligion " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   ID<>@ID AND Description=@Description " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.TinyInt).Value = bytID
                    .Parameters.Add("@Description", SqlDbType.VarChar, 100).Value = strDescription
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

        Protected Friend Shared Function IsInActive(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                    ByVal bytID As Byte) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   Description " & vbNewLine &
                        "FROM QMS_mstReligion " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   ID=@ID AND IDStatus=@IDStatus " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.TinyInt).Value = bytID
                    .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = VO.Status.Values.InActive
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

#Region "Post Data"

        Protected Friend Shared Function QueryOutstandingPosting() As String
            Dim strReturn As String = _
                   "SELECT " & vbNewLine & _
                   "    A.ID, A.Description, A.IDStatus, B.Description AS StatusInfo, A.Remarks, A.CreatedBy, A.CreatedDate, A.LogBy,   " & vbNewLine & _
                   "    A.LogDate, A.LogInc  " & vbNewLine & _
                   "FROM QMS_mstReligion A " & vbNewLine & _
                   "INNER JOIN QMS_mstStatus B ON " & vbNewLine & _
                   "    A.IDStatus=B.ID " & vbNewLine & _
                   "WHERE " & vbNewLine & _
                   "    A.LogDate>=@SyncDate " & vbNewLine
            Return strReturn
        End Function

        Protected Friend Shared Function QueryPostData() As String
            Dim strReturn As String = _
                    "IF NOT EXISTS(SELECT TOP 1 ID FROM QMS_mstReligion WHERE ID=@ID) " & vbNewLine & _
                    "BEGIN " & vbNewLine & _
                    "   INSERT INTO QMS_mstReligion " & vbNewLine & _
                    "   (ID, Description, IDStatus, Remarks, CreatedBy, CreatedDate, LogBy, LogDate, LogInc)   " & vbNewLine & _
                    "   VALUES " & vbNewLine & _
                    "   (@ID, @Description, @IDStatus, @Remarks, @CreatedBy, @CreatedDate, @LogBy, @LogDate, @LogInc)  " & vbNewLine & _
                    "END " & vbNewLine & _
                    "ELSE " & vbNewLine & _
                    "BEGIN " & vbNewLine & _
                    "   UPDATE QMS_mstReligion SET " & vbNewLine & _
                    "       Description=@Description, " & vbNewLine & _
                    "       IDStatus=@IDStatus, " & vbNewLine & _
                    "       Remarks=@Remarks, " & vbNewLine & _
                    "       CreatedBy=@CreatedBy, " & vbNewLine & _
                    "       CreatedDate=@CreatedDate, " & vbNewLine & _
                    "       LogBy=@LogBy, " & vbNewLine & _
                    "       LogDate=@LogDate, " & vbNewLine & _
                    "       LogInc=@LogInc " & vbNewLine & _
                    "   WHERE " & vbNewLine & _
                    "       ID=@ID " & vbNewLine & _
                    "END " & vbNewLine
            Return strReturn
        End Function

        Protected Friend Shared Function OutstandingPostingRDCtoLocation(ByVal dtmSyncDate As DateTime) As DataTable
            '# Add Parameter
            Dim sqlParams As New List(Of MM_Remoting_Service.SqlHelperParameter)
            sqlParams.Add(New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@SyncDate", SqlDbType.DateTime, dtmSyncDate))

            '# Get DataTables
            Dim MMRemotingService As MM_Remoting_Service.SqlHelper = BL.Server.DefaultRemotingService
            Return MMRemotingService.GetDataTable(CommandType.Text, QueryOutstandingPosting, sqlParams)
        End Function

        Protected Friend Shared Sub PostDataRDCtoLocation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                          ByVal clsData As VO.Religion)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText = QueryPostData()
                .Parameters.Add("@ID", SqlDbType.TinyInt).Value = clsData.ID
                .Parameters.Add("@Description", SqlDbType.VarChar, 50).Value = clsData.Description
                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = clsData.IDStatus
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@CreatedBy", SqlDbType.VarChar, 20).Value = clsData.CreatedBy
                .Parameters.Add("@CreatedDate", SqlDbType.DateTime).Value = clsData.CreatedDate
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
                .Parameters.Add("@LogDate", SqlDbType.DateTime).Value = clsData.LogDate
                .Parameters.Add("@LogInc", SqlDbType.Int).Value = clsData.LogInc
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

#End Region

    End Class

End Namespace

