Namespace DL
    Friend Class StorageLaneSwitching

#Region "Main"

        Protected Friend Shared Function ListData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                  ByVal strCompanyID As String, ByVal strLocationID As String, ByVal dtmDateFrom As DateTime, ByVal dtmDateTo As DateTime) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "SELECT " & vbNewLine &
                   "    A.ComLocDivSubDivID, A.CompanyID, VC.CompanyName, A.LocationID, VL.LocationName, A.ProgramID, A.ID, " & vbNewLine &
                   "    A.StorageGroupID, MS.StorageGroupName, A.StorageID, MS.StorageName, A.IsDeleted, A.Remarks, A.CreatedBy,   " & vbNewLine &
                   "    A.CreatedDate, A.LogBy, A.LogDate, A.LogInc  " & vbNewLine &
                   "FROM QMS_traStorageLaneSwitching A " & vbNewLine &
                   "INNER JOIN QMS_mstStorage MS ON " & vbNewLine &
                   "    A.ComLocDivSubDivID=MS.ComLocDivSubDivID " & vbNewLine &
                   "    AND A.ProgramID=MS.ProgramID " & vbNewLine &
                   "    AND A.StorageGroupID=MS.StorageGroupID " & vbNewLine &
                   "    AND A.StorageID=MS.StorageID " & vbNewLine &
                   "INNER JOIN QMS_vwCompany VC ON " & vbNewLine &
                   "    A.CompanyID=VC.CompanyID " & vbNewLine &
                   "INNER JOIN QMS_vwLocation VL ON " & vbNewLine &
                   "    A.LocationID=VL.LocationID " & vbNewLine &
                   "WHERE  " & vbNewLine &
                   "    A.CompanyID=@CompanyID " & vbNewLine &
                   "    AND A.LocationID=@LocationID " & vbNewLine &
                   "    AND A.CreatedDate>=@DateFrom AND A.CreatedDate<=@DateTo" & vbNewLine

                .Parameters.Add("@CompanyID", SqlDbType.VarChar, 10).Value = strCompanyID
                .Parameters.Add("@LocationID", SqlDbType.VarChar, 10).Value = strLocationID
                .Parameters.Add("@DateFrom", SqlDbType.DateTime).Value = dtmDateFrom
                .Parameters.Add("@DateTo", SqlDbType.DateTime).Value = dtmDateTo
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub SaveData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                             ByVal bolNew As Boolean, ByVal clsData As VO.StorageLaneSwitching)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                If bolNew Then
                    .CommandText =
                       "INSERT INTO QMS_traStorageLaneSwitching " & vbNewLine &
                       "    (ComLocDivSubDivID, CompanyID, LocationID, ID, ProgramID, StorageGroupID, StorageID, Remarks, CreatedBy, LogBy)   " & vbNewLine &
                       "VALUES " & vbNewLine &
                       "    (@ComLocDivSubDivID, @CompanyID, @LocationID, @ID, @ProgramID, @StorageGroupID, @StorageID, @Remarks, @LogBy, @LogBy)  " & vbNewLine
                Else
                    .CommandText =
                       "UPDATE QMS_traStorageLaneSwitching SET " & vbNewLine &
                       "    ComLocDivSubDivID=@ComLocDivSubDivID, " & vbNewLine &
                       "    CompanyID=@CompanyID, " & vbNewLine &
                       "    LocationID=@LocationID, " & vbNewLine &
                       "    ProgramID=@ProgramID, " & vbNewLine &
                       "    StorageGroupID=@StorageGroupID, " & vbNewLine &
                       "    StorageID=@StorageID, " & vbNewLine &
                       "    Remarks=@Remarks, " & vbNewLine &
                       "    LogBy=@LogBy, " & vbNewLine &
                       "    LogDate=GETDATE(), " & vbNewLine &
                       "    LogInc=LogInc+1 " & vbNewLine &
                       "WHERE " & vbNewLine &
                       "    ID=@ID " & vbNewLine
                End If

                .Parameters.Add("@ComLocDivSubDivID", SqlDbType.Int).Value = clsData.ComLocDivSubDivID
                .Parameters.Add("@CompanyID", SqlDbType.VarChar, 10).Value = clsData.CompanyID
                .Parameters.Add("@LocationID", SqlDbType.VarChar, 10).Value = clsData.LocationID
                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = clsData.ID
                .Parameters.Add("@ProgramID", SqlDbType.VarChar, 15).Value = clsData.ProgramID
                .Parameters.Add("@StorageGroupID", SqlDbType.VarChar, 100).Value = clsData.StorageGroupID
                .Parameters.Add("@StorageID", SqlDbType.VarChar, 100).Value = clsData.StorageID
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal strID As String) As VO.StorageLaneSwitching
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voReturn As New VO.StorageLaneSwitching
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                       "SELECT " & vbNewLine &
                       "    A.ComLocDivSubDivID, A.CompanyID, VC.CompanyName, A.LocationID, VL.LocationName, A.ProgramID, A.ID, " & vbNewLine &
                       "    A.StorageGroupID, MS.StorageGroupName, A.StorageID, MS.StorageName, A.IsDeleted, A.Remarks, A.CreatedBy,   " & vbNewLine &
                       "    A.CreatedDate, A.LogBy, A.LogDate, A.LogInc, A.IsDeleted  " & vbNewLine &
                       "FROM QMS_traStorageLaneSwitching A " & vbNewLine &
                       "INNER JOIN QMS_mstStorage MS ON " & vbNewLine &
                       "    A.ComLocDivSubDivID=MS.ComLocDivSubDivID " & vbNewLine &
                       "    AND A.ProgramID=MS.ProgramID " & vbNewLine &
                       "    AND A.StorageGroupID=MS.StorageGroupID " & vbNewLine &
                       "    AND A.StorageID=MS.StorageID " & vbNewLine &
                       "INNER JOIN QMS_vwCompany VC ON " & vbNewLine &
                       "    A.CompanyID=VC.CompanyID " & vbNewLine &
                       "INNER JOIN QMS_vwLocation VL ON " & vbNewLine &
                       "    A.LocationID=VL.LocationID " & vbNewLine &
                       "WHERE " & vbNewLine &
                       "    A.ID=@ID " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voReturn.ComLocDivSubDivID = .Item("ComLocDivSubDivID")
                        voReturn.CompanyID = .Item("CompanyID")
                        voReturn.CompanyName = .Item("CompanyName")
                        voReturn.LocationID = .Item("LocationID")
                        voReturn.LocationName = .Item("LocationName")
                        voReturn.ProgramID = .Item("ProgramID")
                        voReturn.ID = .Item("ID")
                        voReturn.StorageGroupID = .Item("StorageGroupID")
                        voReturn.StorageGroupName = .Item("StorageGroupName")
                        voReturn.StorageID = .Item("StorageID")
                        voReturn.StorageName = .Item("StorageName")
                        voReturn.IsDeleted = .Item("IsDeleted")
                        voReturn.Remarks = .Item("Remarks")
                        voReturn.CreatedBy = .Item("CreatedBy")
                        voReturn.CreatedDate = .Item("CreatedDate")
                        voReturn.LogBy = .Item("LogBy")
                        voReturn.LogDate = .Item("LogDate")
                        voReturn.LogInc = .Item("LogInc")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voReturn
        End Function

        Protected Friend Shared Sub DeleteData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                               ByVal clsData As VO.StorageLaneSwitching)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE QMS_traStorageLaneSwitching " & vbNewLine &
                    "SET IsDeleted=1, LogBy=@LogBy, LogDate=GETDATE(), LogInc=LogInc+1  " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "   ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = clsData.ID
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetMaxID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                  ByVal strID As String) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intReturn As Integer = 0
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ID=ISNULL(RIGHT(ID,3),0) " & vbNewLine &
                        "FROM QMS_traStorageLaneSwitching " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   LEFT(ID,12)=@ID " & vbNewLine &
                        "ORDER BY ID DESC " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intReturn = .Item("ID") + 1
                    Else : intReturn = 1
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return intReturn
        End Function

        Protected Friend Shared Function DataExists(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                    ByVal strID As String) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ID " & vbNewLine &
                        "FROM QMS_traStorageLaneSwitching " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   ID=@ID " & vbNewLine
                    .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

        Protected Friend Shared Function IsDeleted(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal strID As String) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ID " & vbNewLine &
                        "FROM QMS_traStorageLaneSwitching " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   ID=@ID " & vbNewLine &
                        "   AND IsDeleted=1 " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = strID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

#End Region

#Region "Detail"

        Protected Friend Shared Function ListDataDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                        ByVal strStorageLaneSwitchingID As String) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "SELECT " & vbNewLine &
                   "    A.ID, A.StorageLaneSwitchingID, A.SubStationID, MSS.Description AS SubStationName " & vbNewLine &
                   "FROM QMS_traStorageLaneSwitchingDet A " & vbNewLine &
                   "INNER JOIN QMS_mstSubStation MSS ON " & vbNewLine &
                   "    A.SubStationID=MSS.ID " & vbNewLine &
                   "WHERE  " & vbNewLine &
                   "    A.StorageLaneSwitchingID=@StorageLaneSwitchingID" & vbNewLine

                .Parameters.Add("@StorageLaneSwitchingID", SqlDbType.VarChar, 20).Value = strStorageLaneSwitchingID
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub SaveDataDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal clsData As VO.StorageLaneSwitchingDet)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "INSERT INTO QMS_traStorageLaneSwitchingDet " & vbNewLine &
                   "    (ID, StorageLaneSwitchingID, SubStationID)   " & vbNewLine &
                   "VALUES " & vbNewLine &
                   "    (@ID, @StorageLaneSwitchingID, @SubStationID)  " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 30).Value = clsData.ID
                .Parameters.Add("@StorageLaneSwitchingID", SqlDbType.VarChar, 20).Value = clsData.StorageLaneSwitchingID
                .Parameters.Add("@SubStationID", SqlDbType.Int).Value = clsData.SubStationID
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub DeleteDataDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                     ByVal strStorageLaneSwitchingID As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "DELETE FROM QMS_traStorageLaneSwitchingDet " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "   StorageLaneSwitchingID=@StorageLaneSwitchingID " & vbNewLine

                .Parameters.Add("@StorageLaneSwitchingID", SqlDbType.VarChar, 20).Value = strStorageLaneSwitchingID
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

#End Region

#Region "Status"

        Protected Friend Shared Function ListDataStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                        ByVal strStorageLaneSwitchingID As String) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "SELECT " & vbNewLine &
                   "    A.Status, A.StatusBy, A.StatusDate, A.Remarks  " & vbNewLine &
                   "FROM QMS_traStorageLaneSwitchingStatus A " & vbNewLine &
                   "WHERE  " & vbNewLine &
                   "    A.StorageLaneSwitchingID=@StorageLaneSwitchingID" & vbNewLine

                .Parameters.Add("@StorageLaneSwitchingID", SqlDbType.VarChar, 20).Value = strStorageLaneSwitchingID
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub SaveDataStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal clsData As VO.StorageLaneSwitchingStatus)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "INSERT INTO QMS_traStorageLaneSwitchingStatus " & vbNewLine &
                    "    (ID, StorageLaneSwitchingID, Status, StatusBy, StatusDate, Remarks)   " & vbNewLine &
                    "VALUES " & vbNewLine &
                    "    (@ID, @StorageLaneSwitchingID, @Status, @StatusBy, @StatusDate, @Remarks)  " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 30).Value = clsData.ID
                .Parameters.Add("@StorageLaneSwitchingID", SqlDbType.VarChar, 20).Value = clsData.StorageLaneSwitchingID
                .Parameters.Add("@Status", SqlDbType.VarChar, 150).Value = clsData.Status
                .Parameters.Add("@StatusBy", SqlDbType.VarChar, 20).Value = clsData.StatusBy
                .Parameters.Add("@StatusDate", SqlDbType.DateTime).Value = clsData.StatusDate
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetMaxIDStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                        ByVal strStorageLaneSwitchingID As String) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intReturn As Integer = 0
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT " & vbNewLine &
                        "   ID=COUNT(ID) " & vbNewLine &
                        "FROM QMS_traStorageLaneSwitchingStatus " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   StorageLaneSwitchingID=@StorageLaneSwitchingID " & vbNewLine

                    .Parameters.Add("@StorageLaneSwitchingID", SqlDbType.VarChar, 20).Value = strStorageLaneSwitchingID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intReturn = .Item("ID") + 1
                    Else
                        intReturn = 1
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return intReturn
        End Function

#End Region

    End Class

End Namespace

