Namespace DL
    Friend Class QueueFlow

#Region "Header"

        Protected Friend Shared Function ListData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "SELECT " & vbNewLine &
                   "    A.ID, A.Name, A.Type, CASE A.Type WHEN 1 THEN 'INCOMING' WHEN 2 THEN 'OUTGOING' END AS TypeInfo, A.IsDefault, " & vbNewLine &
                   "    A.IDStatus, B.Description AS StatusInfo, A.Remarks, A.CreatedBy, A.CreatedDate, A.LogBy, A.LogDate, A.LogInc  " & vbNewLine &
                   "FROM QMS_mstQueueFlow A " & vbNewLine &
                   "INNER JOIN QMS_mstStatus B ON " & vbNewLine &
                   "    A.IDStatus=B.ID " & vbNewLine

            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub SaveData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                             ByVal bolNew As Boolean, ByVal clsData As VO.QueueFlow)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                If bolNew Then
                    .CommandText =
                       "INSERT INTO QMS_mstQueueFlow " & vbNewLine &
                       "    (ID, Name, Type, IsDefault, IDStatus, Remarks, CreatedBy, LogBy)   " & vbNewLine &
                       "VALUES " & vbNewLine &
                       "    (@ID, @Name, @Type, @IsDefault, @IDStatus, @Remarks, @LogBy, @LogBy)  " & vbNewLine
                Else
                    .CommandText =
                       "UPDATE QMS_mstQueueFlow SET " & vbNewLine &
                       "    Name=@Name, " & vbNewLine &
                       "    Type=@Type, " & vbNewLine &
                       "    IsDefault=@IsDefault, " & vbNewLine &
                       "    IDStatus=@IDStatus, " & vbNewLine &
                       "    Remarks=@Remarks, " & vbNewLine &
                       "    LogBy=@LogBy, " & vbNewLine &
                       "    LogDate=GETDATE(), " & vbNewLine &
                       "    LogInc=LogInc+1 " & vbNewLine &
                       "WHERE " & vbNewLine &
                       "    ID=@ID " & vbNewLine
                End If

                .Parameters.Add("@ID", SqlDbType.VarChar, 10).Value = clsData.ID
                .Parameters.Add("@Name", SqlDbType.VarChar, 100).Value = clsData.Name
                .Parameters.Add("@Type", SqlDbType.TinyInt).Value = clsData.Type
                .Parameters.Add("@IsDefault", SqlDbType.Bit).Value = clsData.IsDefault
                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = clsData.IDStatus
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal strID As String) As VO.QueueFlow
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voReturn As New VO.QueueFlow
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                       "SELECT TOP 1 " & vbNewLine &
                       "    A.ID, A.Name, A.Type, A.IsDefault, A.IDStatus, B.Description AS StatusInfo, A.Remarks, A.CreatedBy,   " & vbNewLine &
                       "    A.CreatedDate, A.LogBy, A.LogDate, A.LogInc  " & vbNewLine &
                       "FROM QMS_mstQueueFlow A " & vbNewLine &
                       "INNER JOIN QMS_mstStatus B ON " & vbNewLine &
                       "    A.IDStatus=B.ID " & vbNewLine &
                       "WHERE " & vbNewLine &
                       "    A.ID=@ID " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.VarChar, 10).Value = strID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voReturn.ID = .Item("ID")
                        voReturn.Name = .Item("Name")
                        voReturn.Type = .Item("Type")
                        voReturn.IsDefault = .Item("IsDefault")
                        voReturn.IDStatus = .Item("IDStatus")
                        voReturn.StatusInfo = .Item("StatusInfo")
                        voReturn.Remarks = .Item("Remarks")
                        voReturn.CreatedBy = .Item("CreatedBy")
                        voReturn.CreatedDate = .Item("CreatedDate")
                        voReturn.LogBy = .Item("LogBy")
                        voReturn.LogDate = .Item("LogDate")
                        voReturn.LogInc = .Item("LogInc")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voReturn
        End Function

        Protected Friend Shared Sub DeleteData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                               ByVal clsData As VO.QueueFlow)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE QMS_mstQueueFlow " & vbNewLine &
                    "   SET IDStatus=@IDStatus, " & vbNewLine &
                    "   LogBy=@LogBy, " & vbNewLine &
                    "   LogDate=GETDATE(), " & vbNewLine &
                    "   LogInc=LogInc+1  " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "   ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 10).Value = clsData.ID
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = VO.Status.Values.InActive
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetMaxID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intReturn As Integer = 0
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ID=ISNULL(MAX(ID),0) " & vbNewLine &
                        "FROM QMS_mstQueueFlow " & vbNewLine
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intReturn = .Item("ID") + 1
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return intReturn
        End Function

        Protected Friend Shared Function IsIDExists(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                    ByVal strID As String) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ID " & vbNewLine &
                        "FROM QMS_mstQueueFlow " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   ID=@ID " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.VarChar, 10).Value = strID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

        Protected Friend Shared Function IsNameExists(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                      ByVal strID As String, ByVal strName As String) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   Name " & vbNewLine &
                        "FROM QMS_mstQueueFlow " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   ID<>@ID AND Name=@Name " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.VarChar, 10).Value = strID
                    .Parameters.Add("@Name", SqlDbType.VarChar, 100).Value = strName
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

        Protected Friend Shared Function IsInActive(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                    ByVal strID As Byte) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ID " & vbNewLine &
                        "FROM QMS_mstQueueFlow " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   ID=@ID AND IDStatus=@IDStatus " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.VarChar, 10).Value = strID
                    .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = VO.Status.Values.InActive
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

        Protected Friend Shared Function IsDefaultExists(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                         ByVal strID As String, ByVal bytType As Byte) As String
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim strReturn As String = ""
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ID " & vbNewLine &
                        "FROM QMS_mstQueueFlow " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   ID<>@ID AND Type=@Type AND IsDefault=1 " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.VarChar, 10).Value = strID
                    .Parameters.Add("@Type", SqlDbType.TinyInt).Value = bytType
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        strReturn = .Item("ID")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return strReturn
        End Function

        Protected Friend Shared Function GetDetailForQueue(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                           ByVal bytQueueType As Byte, ByVal strItemCode As String) As VO.QueueFlow
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voReturn As New VO.QueueFlow
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    If strItemCode Is Nothing Or strItemCode.Trim = "" Then
                        .CommandText =
                           "SELECT TOP 1 " & vbNewLine &
                           "    A.ID, A.Name, A.Type, A.IsDefault, A.IDStatus, B.Description AS StatusInfo, A.Remarks, A.CreatedBy,   " & vbNewLine &
                           "    A.CreatedDate, A.LogBy, A.LogDate, A.LogInc  " & vbNewLine &
                           "FROM QMS_mstQueueFlow A " & vbNewLine &
                           "INNER JOIN QMS_mstStatus B ON " & vbNewLine &
                           "    A.IDStatus=B.ID " & vbNewLine &
                           "WHERE " & vbNewLine &
                           "    A.Type=@Type " & vbNewLine &
                           "    AND A.IsDefault=1 " & vbNewLine
                    Else
                        .CommandText =
                           "SELECT TOP 1 " & vbNewLine &
                           "    A.ID, A.Name, A.Type, A.IsDefault, A.IDStatus, B.Description AS StatusInfo, A.Remarks, A.CreatedBy,   " & vbNewLine &
                           "    A.CreatedDate, A.LogBy, A.LogDate, A.LogInc  " & vbNewLine &
                           "FROM QMS_mstQueueFlow A " & vbNewLine &
                           "INNER JOIN QMS_mstStatus B ON " & vbNewLine &
                           "    A.IDStatus=B.ID " & vbNewLine &
                           "INNER JOIN QMS_mstQueueFlowItem QFI ON " & vbNewLine &
                           "    A.ID=QFI.QueueFlowID " & vbNewLine &
                           "WHERE " & vbNewLine &
                           "    A.Type=@Type " & vbNewLine &
                           "    AND QFI.ItemCode=@ItemCode " & vbNewLine
                    End If

                    .Parameters.Add("@Type", SqlDbType.TinyInt).Value = bytQueueType
                    .Parameters.Add("@ItemCode", SqlDbType.VarChar, 50).Value = strItemCode
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voReturn.ID = .Item("ID")
                        voReturn.Name = .Item("Name")
                        voReturn.Type = .Item("Type")
                        voReturn.IsDefault = .Item("IsDefault")
                        voReturn.IDStatus = .Item("IDStatus")
                        voReturn.StatusInfo = .Item("StatusInfo")
                        voReturn.Remarks = .Item("Remarks")
                        voReturn.CreatedBy = .Item("CreatedBy")
                        voReturn.CreatedDate = .Item("CreatedDate")
                        voReturn.LogBy = .Item("LogBy")
                        voReturn.LogDate = .Item("LogDate")
                        voReturn.LogInc = .Item("LogInc")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voReturn
        End Function

#End Region

#Region "Station"

        Protected Friend Shared Function ListDataStation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                         ByVal strQueueFlowID As String) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "SELECT " & vbNewLine &
                   "    A.ID, A.QueueFlowID, A.Idx, A.StationID, MS.Description AS StationName " & vbNewLine &
                   "FROM QMS_mstQueueFlowStation A " & vbNewLine &
                   "INNER JOIN QMS_mstStation MS ON " & vbNewLine &
                   "    A.StationID=MS.ID " & vbNewLine &
                   "WHERE  " & vbNewLine &
                   "    A.QueueFlowID=@QueueFlowID" & vbNewLine

                .Parameters.Add("@QueueFlowID", SqlDbType.VarChar, 10).Value = strQueueFlowID
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Function ListDataStationDefault(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                ByVal strQueueFlowID As String, ByVal strCompanyID As String, ByVal strLocationID As String,
                                                                ByVal intComLocDivSubDivID As Integer, ByVal strProgramID As String,
                                                                ByVal strStorageGroupID As String, ByVal strStorageID As String) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "SELECT TOP 1 " & vbNewLine &
                    "	A. ComLocDivSubDivID, A.ProgramID, A.StorageGroupID, A.StorageID, B.SubStationID " & vbNewLine &
                    "INTO #T_StorageLane" & vbNewLine &
                    "FROM QMS_traStorageLaneSwitching A " & vbNewLine &
                    "INNER JOIN QMS_traStorageLaneSwitchingDet B ON " & vbNewLine &
                    "	A.ID=B.StorageLaneSwitchingID " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "   A.ComLocDivSubDivID=@ComLocDivSubDivID " & vbNewLine &
                    "   AND A.ProgramID=@ProgramID " & vbNewLine &
                    "   AND A.StorageGroupID=@StorageGroupID " & vbNewLine &
                    "   AND A.StorageID=@StorageID " & vbNewLine &
                    "ORDER BY A.CreatedDate DESC " & vbNewLine &
                    " " & vbNewLine &
                    "SELECT " & vbNewLine &
                    "    A.Idx, A.StationID, MS.Description AS StationName, CAST(2 AS TINYINT) AS IsLinkedStorage, MSS.ID AS SubStationID, MSS.Description AS SubStationName " & vbNewLine &
                    "FROM QMS_mstQueueFlowStation A " & vbNewLine &
                    "INNER JOIN QMS_mstStation MS ON " & vbNewLine &
                    "    A.StationID=MS.ID " & vbNewLine &
                    "    AND MS.IsLinkStorage=0 " & vbNewLine &
                    "INNER JOIN QMS_mstSubStation MSS ON " & vbNewLine &
                    "    A.StationID=MSS.StationID " & vbNewLine &
                    "    AND MSS.CompanyID=@CompanyID " & vbNewLine &
                    "    AND MSS.LocationID=@LocationID " & vbNewLine &
                    "    AND MSS.IsDefault=1 " & vbNewLine &
                    "WHERE  " & vbNewLine &
                    "    A.QueueFlowID=@QueueFlowID" & vbNewLine

                .CommandText +=
                   "UNION ALL " & vbNewLine &
                   "SELECT " & vbNewLine &
                   "    A.Idx, A.StationID, MS.Description AS StationName, CAST(1 AS TINYINT) AS IsLinkedStorage, MSS.ID AS SubStationID, MSS.Description AS SubStationName " & vbNewLine &
                   "FROM QMS_mstQueueFlowStation A " & vbNewLine &
                   "INNER JOIN QMS_mstStation MS ON " & vbNewLine &
                   "    A.StationID=MS.ID " & vbNewLine &
                   "    AND MS.IsLinkStorage=1 " & vbNewLine &
                   "INNER JOIN QMS_mstSubStation MSS ON " & vbNewLine &
                   "    A.StationID=MSS.StationID " & vbNewLine &
                   "    AND MSS.CompanyID=@CompanyID " & vbNewLine &
                   "    AND MSS.LocationID=@LocationID " & vbNewLine &
                   "INNER JOIN #T_StorageLane TL ON " & vbNewLine &
                   "    MSS.ID=TL.SubStationID " & vbNewLine &
                   "WHERE  " & vbNewLine &
                   "    A.QueueFlowID=@QueueFlowID" & vbNewLine &
                   "ORDER BY A.Idx ASC " & vbNewLine

                .Parameters.Add("@ComLocDivSubDivID", SqlDbType.Int).Value = intComLocDivSubDivID
                .Parameters.Add("@ProgramID", SqlDbType.VarChar, 15).Value = strProgramID
                .Parameters.Add("@StorageGroupID", SqlDbType.VarChar, 100).Value = strStorageGroupID
                .Parameters.Add("@StorageID", SqlDbType.VarChar, 100).Value = strStorageID
                .Parameters.Add("@QueueFlowID", SqlDbType.VarChar, 10).Value = strQueueFlowID
                .Parameters.Add("@CompanyID", SqlDbType.VarChar, 10).Value = strCompanyID
                .Parameters.Add("@LocationID", SqlDbType.VarChar, 10).Value = strLocationID
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Function ListDataAllSubStation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                               ByVal strQueueFlowID As String, ByVal intComLocDivSubDivID As Integer, ByVal strProgramID As String,
                                                               ByVal strStorageGroupID As String, ByVal strStorageID As String) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "SELECT " & vbNewLine &
                    "	MAX(A.CreatedDate) LastDate, A.TankCode, B.SubStationID " & vbNewLine &
                    "INTO #T_TankLane" & vbNewLine &
                    "FROM QMS_traTankLaneSwitching A " & vbNewLine &
                    "INNER JOIN QMS_traTankLaneSwitchingDet B ON " & vbNewLine &
                    "	A.ID=B.TankLaneSwitchingID " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "   A.ComLocDivSubDivID=@ComLocDivSubDivID " & vbNewLine &
                    "   AND A.ProgramID=@ProgramID " & vbNewLine &
                    "   AND A.StorageGroupID=@StorageGroupID " & vbNewLine &
                    "   AND A.StorageID=@StorageID " & vbNewLine &
                    "GROUP BY A.TankCode, B.SubStationID" & vbNewLine &
                    " " & vbNewLine &
                    "SELECT " & vbNewLine &
                    "    A.Idx, A.StationID, MS.Description AS StationName, MSS.ID AS SubStationID, MSS.Description AS SubStationName " & vbNewLine &
                    "FROM QMS_mstQueueFlowStation A " & vbNewLine &
                    "INNER JOIN QMS_mstStation MS ON " & vbNewLine &
                    "    A.StationID=MS.ID " & vbNewLine &
                    "    AND MS.IsLinkToTank=0 " & vbNewLine &
                    "INNER JOIN QMS_mstSubStation MSS ON " & vbNewLine &
                    "    A.StationID=MSS.StationID " & vbNewLine &
                    "WHERE  " & vbNewLine &
                    "    A.QueueFlowID=@QueueFlowID" & vbNewLine

                .CommandText +=
                   "UNION ALL " & vbNewLine &
                   "SELECT " & vbNewLine &
                   "    A.Idx, A.StationID, MS.Description AS StationName, MSS.ID AS SubStationID, MSS.Description AS SubStationName " & vbNewLine &
                   "FROM QMS_mstQueueFlowStation A " & vbNewLine &
                   "INNER JOIN QMS_mstStation MS ON " & vbNewLine &
                   "    A.StationID=MS.ID " & vbNewLine &
                   "    AND MS.IsLinkToTank=1 " & vbNewLine &
                   "INNER JOIN QMS_mstSubStation MSS ON " & vbNewLine &
                   "    A.StationID=MSS.StationID " & vbNewLine &
                   "INNER JOIN #T_TankLane TL ON " & vbNewLine &
                   "    MSS.ID=TL.SubStationID " & vbNewLine &
                   "WHERE  " & vbNewLine &
                   "    A.QueueFlowID=@QueueFlowID" & vbNewLine &
                   "ORDER BY A.Idx ASC " & vbNewLine

                .Parameters.Add("@ComLocDivSubDivID", SqlDbType.Int).Value = intComLocDivSubDivID
                .Parameters.Add("@ProgramID", SqlDbType.VarChar, 15).Value = strProgramID
                .Parameters.Add("@StorageGroupID", SqlDbType.VarChar, 100).Value = strStorageGroupID
                .Parameters.Add("@StorageID", SqlDbType.VarChar, 100).Value = strStorageID
                .Parameters.Add("@QueueFlowID", SqlDbType.VarChar, 10).Value = strQueueFlowID
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub SaveDataStation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                    ByVal clsData As VO.QueueFlowStation)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "INSERT INTO QMS_mstQueueFlowStation " & vbNewLine &
                    "    (ID, QueueFlowID, Idx, StationID)   " & vbNewLine &
                    "VALUES " & vbNewLine &
                    "    (@ID, @QueueFlowID, @Idx, @StationID)  " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = clsData.ID
                .Parameters.Add("@QueueFlowID", SqlDbType.VarChar, 10).Value = clsData.QueueFlowID
                .Parameters.Add("@Idx", SqlDbType.Int).Value = clsData.Idx
                .Parameters.Add("@StationID", SqlDbType.Int).Value = clsData.StationID
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub DeleteDataStation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                      ByVal strQueueFlowID As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "DELETE FROM QMS_mstQueueFlowStation " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "   QueueFlowID=@QueueFlowID " & vbNewLine

                .Parameters.Add("@QueueFlowID", SqlDbType.VarChar, 10).Value = strQueueFlowID
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

#End Region

#Region "Item"

        Protected Friend Shared Function ListDataItem(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                      ByVal strQueueFlowID As String) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "SELECT " & vbNewLine &
                   "    A.ItemCode, VI.ItemName, A.QueueFlowID  " & vbNewLine &
                   "FROM QMS_mstQueueFlowItem A " & vbNewLine &
                   "INNER JOIN QMS_vwItem VI ON " & vbNewLine &
                   "    A.ItemCode=VI.ItemCode " & vbNewLine &
                   "WHERE  " & vbNewLine &
                   "    A.QueueFlowID=@QueueFlowID" & vbNewLine

                .Parameters.Add("@QueueFlowID", SqlDbType.VarChar, 10).Value = strQueueFlowID

            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub SaveDataItem(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                 ByVal clsData As VO.QueueFlowItem)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "INSERT INTO QMS_mstQueueFlowItem " & vbNewLine &
                    "    (ID, ItemCode, QueueFlowID)   " & vbNewLine &
                    "VALUES " & vbNewLine &
                    "    (@ID, @ItemCode, @QueueFlowID)  " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 20).Value = clsData.ID
                .Parameters.Add("@ItemCode", SqlDbType.VarChar, 50).Value = clsData.ItemCode
                .Parameters.Add("@QueueFlowID", SqlDbType.VarChar, 10).Value = clsData.QueueFlowID
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub DeleteDataItem(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal intQueueFlowID As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "DELETE FROM QMS_mstQueueFlowItem " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "   QueueFlowID=@QueueFlowID " & vbNewLine

                .Parameters.Add("@QueueFlowID", SqlDbType.Int).Value = intQueueFlowID
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function IsItemExists(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                      ByVal strQueueFlowID As String, ByVal strItemCode As String, ByVal bytType As Byte) As String
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim strReturn As String = ""
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   A.QueueFlowID " & vbNewLine &
                        "FROM QMS_mstQueueFlowItem A " & vbNewLine &
                        "INNER JOIN QMS_mstQueueFlow B ON " & vbNewLine &
                        "   A.QueueFlowID=B.ID " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   A.ItemCode=@ItemCode " & vbNewLine &
                        "   AND A.QueueFlowID<>@QueueFlowID " & vbNewLine &
                        "   AND B.Type=@Type " & vbNewLine

                    .Parameters.Add("@QueueFlowID", SqlDbType.VarChar, 10).Value = strQueueFlowID
                    .Parameters.Add("@ItemCode", SqlDbType.VarChar, 50).Value = strItemCode
                    .Parameters.Add("@Type", SqlDbType.TinyInt).Value = bytType
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        strReturn = .Item("QueueFlowID")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return strReturn
        End Function

#End Region

#Region "Post Data"

        Protected Friend Shared Function QueryOutstandingPosting() As String
            Dim strReturn As String = _
                   "SELECT " & vbNewLine & _
                   "    A.ID, A.Name, A.Type, CASE A.Type WHEN 0 THEN 'INCOMING' WHEN 1 THEN 'OUTGOING' END AS TypeInfo, A.IsDefault, " & vbNewLine & _
                   "    A.IDStatus, B.Description AS StatusInfo, A.Remarks, A.CreatedBy, A.CreatedDate, A.LogBy, A.LogDate, A.LogInc  " & vbNewLine & _
                   "FROM QMS_mstQueueFlow A " & vbNewLine & _
                   "INNER JOIN QMS_mstStatus B ON " & vbNewLine & _
                   "    A.IDStatus=B.ID " & vbNewLine & _
                   "WHERE " & vbNewLine & _
                   "    A.LogDate>=@SyncDate " & vbNewLine
            Return strReturn
        End Function

        Protected Friend Shared Function QueryPostData() As String
            Dim strReturn As String = _
                    "IF NOT EXISTS(SELECT TOP 1 ID FROM QMS_mstQueueFlow WHERE ID=@ID) " & vbNewLine & _
                    "BEGIN " & vbNewLine & _
                    "   INSERT INTO QMS_mstQueueFlow " & vbNewLine & _
                    "   (ID, Name, Type, IsDefault, IDStatus, Remarks, CreatedBy, CreatedDate, LogBy, LogDate, LogInc)   " & vbNewLine & _
                    "   VALUES " & vbNewLine & _
                    "   (@ID, @Name, @Type, @IsDefault, @IDStatus, @Remarks, @CreatedBy, @CreatedDate, @LogBy, @LogDate, @LogInc)  " & vbNewLine & _
                    "END " & vbNewLine & _
                    "ELSE " & vbNewLine & _
                    "BEGIN " & vbNewLine & _
                    "   UPDATE QMS_mstQueueFlow SET " & vbNewLine & _
                    "       Name=@Name, " & vbNewLine & _
                    "       Type=@Type, " & vbNewLine & _
                    "       IsDefault=@IsDefault, " & vbNewLine & _
                    "       IDStatus=@IDStatus, " & vbNewLine & _
                    "       Remarks=@Remarks, " & vbNewLine & _
                    "       CreatedBy=@CreatedBy, " & vbNewLine & _
                    "       CreatedDate=@CreatedDate, " & vbNewLine & _
                    "       LogBy=@LogBy, " & vbNewLine & _
                    "       LogDate=@LogDate, " & vbNewLine & _
                    "       LogInc=@LogInc " & vbNewLine & _
                    "   WHERE " & vbNewLine & _
                    "       ID=@ID " & vbNewLine & _
                    "END " & vbNewLine
            Return strReturn
        End Function

        Protected Friend Shared Function OutstandingPostingRDCtoLocation(ByVal dtmSyncDate As DateTime) As DataTable
            '# Add Parameter
            Dim sqlParams As New List(Of MM_Remoting_Service.SqlHelperParameter) From {
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@SyncDate", SqlDbType.DateTime, dtmSyncDate)
            }

            '# Get DataTables
            Dim MMRemotingService As MM_Remoting_Service.SqlHelper = BL.Server.DefaultRemotingService
            Return MMRemotingService.GetDataTable(CommandType.Text, QueryOutstandingPosting, sqlParams)
        End Function

        Protected Friend Shared Sub PostDataRDCtoLocation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                          ByVal clsData As VO.QueueFlow)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText = QueryPostData()
                .Parameters.Add("@ID", SqlDbType.VarChar, 10).Value = clsData.ID
                .Parameters.Add("@Name", SqlDbType.VarChar, 100).Value = clsData.Name
                .Parameters.Add("@Type", SqlDbType.TinyInt).Value = clsData.Type
                .Parameters.Add("@IsDefault", SqlDbType.Bit).Value = clsData.IsDefault
                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = clsData.IDStatus
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@CreatedBy", SqlDbType.VarChar, 20).Value = clsData.CreatedBy
                .Parameters.Add("@CreatedDate", SqlDbType.DateTime).Value = clsData.CreatedDate
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
                .Parameters.Add("@LogDate", SqlDbType.DateTime).Value = clsData.LogDate
                .Parameters.Add("@LogInc", SqlDbType.Int).Value = clsData.LogInc
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function QueryOutstandingPostingStation() As String
            Dim strReturn As String = _
                   "SELECT " & vbNewLine & _
                   "    A.ID, A.QueueFlowID, A.Idx, A.StationID, MS.Description AS StationName " & vbNewLine & _
                   "FROM QMS_mstQueueFlowStation A " & vbNewLine & _
                   "INNER JOIN QMS_mstStation MS ON " & vbNewLine & _
                   "    A.StationID=MS.ID " & vbNewLine & _
                   "INNER JOIN QMS_mstQueueFlow B ON " & vbNewLine & _
                   "    A.QueueFlowID=B.ID " & vbNewLine & _
                   "WHERE " & vbNewLine & _
                   "    B.LogDate>=@SyncDate " & vbNewLine
            Return strReturn
        End Function

        Protected Friend Shared Function OutstandingPostingRDCtoLocationStation(ByVal dtmSyncDate As DateTime) As DataTable
            '# Add Parameter
            Dim sqlParams As New List(Of MM_Remoting_Service.SqlHelperParameter) From {
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@SyncDate", SqlDbType.DateTime, dtmSyncDate)
            }

            '# Get DataTables
            Dim MMRemotingService As MM_Remoting_Service.SqlHelper = BL.Server.DefaultRemotingService
            Return MMRemotingService.GetDataTable(CommandType.Text, QueryOutstandingPostingStation, sqlParams)
        End Function

        Protected Friend Shared Function QueryOutstandingPostingItem() As String
            Dim strReturn As String = _
                   "SELECT " & vbNewLine & _
                   "    A.ID, A.ItemCode, VI.ItemName, A.QueueFlowID  " & vbNewLine & _
                   "FROM QMS_mstQueueFlowItem A " & vbNewLine & _
                   "INNER JOIN QMS_vwItem VI ON " & vbNewLine & _
                   "    A.ItemCode=VI.ItemCode " & vbNewLine & _
                   "INNER JOIN QMS_mstQueueFlow B ON " & vbNewLine & _
                   "    A.QueueFlowID=B.ID " & vbNewLine & _
                   "WHERE " & vbNewLine & _
                   "    B.LogDate>=@SyncDate " & vbNewLine
            Return strReturn
        End Function

        Protected Friend Shared Function OutstandingPostingRDCtoLocationItem(ByVal dtmSyncDate As DateTime) As DataTable
            '# Add Parameter
            Dim sqlParams As New List(Of MM_Remoting_Service.SqlHelperParameter) From {
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@SyncDate", SqlDbType.DateTime, dtmSyncDate)
            }

            '# Get DataTables
            Dim MMRemotingService As MM_Remoting_Service.SqlHelper = BL.Server.DefaultRemotingService
            Return MMRemotingService.GetDataTable(CommandType.Text, QueryOutstandingPostingItem, sqlParams)
        End Function

#End Region

    End Class

End Namespace

