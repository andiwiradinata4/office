Namespace DL
    Friend Class DrivingLicenseType

        Protected Friend Shared Function ListData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                  ByVal bytIDStatus As Byte) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
"
SELECT    
    A.ID, A.Description, A.IDStatus, B.Description AS StatusInfo, A.Remarks, A.CreatedBy, A.CreatedDate, A.LogBy,      
    A.LogDate, A.LogInc     
FROM QMS_mstDrivingLicenseType A    
INNER JOIN QMS_mstStatus B ON    
    A.IDStatus=B.ID    
WHERE 1=1   
"
                If bytIDStatus <> VO.Status.Values.All Then
                    .CommandText += "   AND A.IDStatus=@IDStatus " & vbNewLine
                End If
                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = bytIDStatus
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub SaveData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                             ByVal bolNew As Boolean, ByVal clsData As VO.DrivingLicenseType)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                If bolNew Then
                    .CommandText =
"
INSERT INTO QMS_mstDrivingLicenseType   
    (ID, Description, IDStatus, Remarks, CreatedBy, LogBy)     
VALUES   
    (@ID, @Description, @IDStatus, @Remarks, @LogBy, @LogBy)    
"
                Else
                    .CommandText =
"
UPDATE QMS_mstDrivingLicenseType SET  
    Description=@Description,  
    IDStatus=@IDStatus,  
    Remarks=@Remarks,  
    LogBy=@LogBy,  
    LogDate=GETDATE(),  
    LogInc=LogInc+1  
WHERE  
    ID=@ID  
"
                End If
                .Parameters.Add("@ID", SqlDbType.TinyInt).Value = clsData.ID
                .Parameters.Add("@Description", SqlDbType.VarChar, 50).Value = clsData.Description
                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = clsData.IDStatus
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal bytID As Byte) As VO.DrivingLicenseType
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voReturn As New VO.DrivingLicenseType
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
"
SELECT TOP 1  
    A.ID, A.Description, A.IDStatus, B.Description AS StatusInfo, A.Remarks, A.CreatedBy, A.CreatedDate, A.LogBy,    
    A.LogDate, A.LogInc   
FROM QMS_mstDrivingLicenseType A  
INNER JOIN QMS_mstStatus B ON  
    A.IDStatus=B.ID  
WHERE  
    A.ID=@ID  
"
                    .Parameters.Add("@ID", SqlDbType.TinyInt).Value = bytID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voReturn.ID = .Item("ID")
                        voReturn.Description = .Item("Description")
                        voReturn.IDStatus = .Item("IDStatus")
                        voReturn.StatusInfo = .Item("StatusInfo")
                        voReturn.Remarks = .Item("Remarks")
                        voReturn.CreatedBy = .Item("CreatedBy")
                        voReturn.CreatedDate = .Item("CreatedDate")
                        voReturn.LogBy = .Item("LogBy")
                        voReturn.LogDate = .Item("LogDate")
                        voReturn.LogInc = .Item("LogInc")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voReturn
        End Function

        Protected Friend Shared Sub DeleteData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                               ByVal clsData As VO.DrivingLicenseType)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
"
UPDATE QMS_mstDrivingLicenseType  
   SET IDStatus=@IDStatus,  
   LogBy=@LogBy,  
   LogDate=GETDATE(),  
   LogInc=LogInc+1   
WHERE  
   ID=@ID  
"
                .Parameters.Add("@ID", SqlDbType.TinyInt).Value = clsData.ID
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = VO.Status.Values.InActive
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetMaxID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intReturn As Integer = 0
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
"
SELECT TOP 1  
   ID=ISNULL(MAX(ID),0)  
FROM QMS_mstDrivingLicenseType  
"
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intReturn = .Item("ID") + 1
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return intReturn
        End Function

        Protected Friend Shared Function IsIDExists(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                    ByVal bytID As Byte) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
"
SELECT TOP 1  
   ID  
FROM QMS_mstDrivingLicenseType  
WHERE   
   ID=@ID  
"
                    .Parameters.Add("@ID", SqlDbType.TinyInt).Value = bytID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

        Protected Friend Shared Function IsDescriptionExists(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                             ByVal bytID As Byte, ByVal strDescription As String) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
"
SELECT TOP 1  
   Description  
FROM QMS_mstDrivingLicenseType  
WHERE   
   ID<>@ID AND Description=@Description  
"
                    .Parameters.Add("@ID", SqlDbType.TinyInt).Value = bytID
                    .Parameters.Add("@Description", SqlDbType.VarChar, 100).Value = strDescription
                End With
                sqlrdData = sqlcmdExecute.ExecuteReader(CommandBehavior.SingleRow)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

        Protected Friend Shared Function IsInActive(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                    ByVal bytID As Byte) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
"
SELECT TOP 1  
   Description  
FROM QMS_mstDrivingLicenseType  
WHERE   
   ID=@ID AND IDStatus=@IDStatus  
"
                    .Parameters.Add("@ID", SqlDbType.TinyInt).Value = bytID
                    .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = VO.Status.Values.InActive
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

#Region "Post Data"

        Protected Friend Shared Function QueryOutstandingPosting() As String
            Dim strReturn As String =
"
SELECT  
    A.ID, A.Description, A.IDStatus, B.Description AS StatusInfo, A.Remarks, A.CreatedBy, A.CreatedDate, A.LogBy,    
    A.LogDate, A.LogInc   
FROM QMS_mstDrivingLicenseType A  
INNER JOIN QMS_mstStatus B ON  
    A.IDStatus=B.ID  
WHERE  
    A.LogDate>=@SyncDate  
"
            Return strReturn
        End Function

        Protected Friend Shared Function QueryPostData() As String
            Dim strReturn As String =
"
IF NOT EXISTS(SELECT TOP 1 ID FROM QMS_mstDrivingLicenseType WHERE ID=@ID)  
BEGIN  
   INSERT INTO QMS_mstDrivingLicenseType  
   (ID, Description, IDStatus, Remarks, CreatedBy, CreatedDate, LogBy, LogDate, LogInc)    
   VALUES  
   (@ID, @Description, @IDStatus, @Remarks, @CreatedBy, @CreatedDate, @LogBy, @LogDate, @LogInc)   
END  
ELSE  
BEGIN  
   UPDATE QMS_mstDrivingLicenseType SET  
       Description=@Description,  
       IDStatus=@IDStatus,  
       Remarks=@Remarks,  
       CreatedBy=@CreatedBy,  
       CreatedDate=@CreatedDate,  
       LogBy=@LogBy,  
       LogDate=@LogDate,  
       LogInc=@LogInc  
   WHERE  
       ID=@ID  
END  
"
            Return strReturn
        End Function

        Protected Friend Shared Function OutstandingPostingRDCtoLocation(ByVal dtmSyncDate As DateTime) As DataTable
            '# Add Parameter
            Dim sqlParams As New List(Of MM_Remoting_Service.SqlHelperParameter) From {
                New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@SyncDate", SqlDbType.DateTime, dtmSyncDate)
            }

            '# Get DataTables
            Dim MMRemotingService As MM_Remoting_Service.SqlHelper = BL.Server.DefaultRemotingService
            Return MMRemotingService.GetDataTable(CommandType.Text, QueryOutstandingPosting, sqlParams)
        End Function

        Protected Friend Shared Sub PostDataRDCtoLocation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                          ByVal clsData As VO.DrivingLicenseType)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText = QueryPostData()
                .Parameters.Add("@ID", SqlDbType.TinyInt).Value = clsData.ID
                .Parameters.Add("@Description", SqlDbType.VarChar, 50).Value = clsData.Description
                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = clsData.IDStatus
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@CreatedBy", SqlDbType.VarChar, 20).Value = clsData.CreatedBy
                .Parameters.Add("@CreatedDate", SqlDbType.DateTime).Value = clsData.CreatedDate
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
                .Parameters.Add("@LogDate", SqlDbType.DateTime).Value = clsData.LogDate
                .Parameters.Add("@LogInc", SqlDbType.Int).Value = clsData.LogInc
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

#End Region

    End Class

End Namespace

