Namespace DL
    Friend Class SubStation

        Protected Friend Shared Function ListData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                  ByVal strCompanyID As String, ByVal strLocationID As String, ByVal intStationID As Integer,
                                                  ByVal enumIsLinkedStorage As VO.SubStation.FilterIsLinkedStorage, ByVal intComLocDivSubDivID As Integer,
                                                  ByVal strProgramID As String, ByVal strStorageGroupID As String, ByVal strStorageID As String) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "SELECT " & vbNewLine &
                   "    CAST(0 AS BIT) Pick, A.CompanyID, A.LocationID, A.ID, A.StationID, C.Description AS StationName, A.Description, A.IsDefault, " & vbNewLine &
                   "    A.ComputerName, A.InitialID, A.COMPort1, A.COMPort2, A.BaudRate, A.DataBits, A.Comparity, A.ComStopBits, A.IDStatus, " & vbNewLine &
                   "    B.Description AS StatusInfo, A.Remarks, A.CreatedBy, A.CreatedDate, A.LogBy, A.LogDate, A.LogInc  " & vbNewLine &
                   "FROM QMS_mstSubStation A " & vbNewLine &
                   "INNER JOIN QMS_mstStatus B ON " & vbNewLine &
                   "    A.IDStatus=B.ID " & vbNewLine &
                   "INNER JOIN QMS_mstStation C ON " & vbNewLine &
                   "    A.StationID=C.ID " & vbNewLine &
                   "WHERE  " & vbNewLine &
                   "    1=1" & vbNewLine

                If strCompanyID.Trim <> "" Then
                    .CommandText += "    AND A.CompanyID=@CompanyID " & vbNewLine
                End If

                If strLocationID.Trim <> "" Then
                    .CommandText += "    AND A.LocationID=@LocationID " & vbNewLine
                End If

                If intStationID > 0 Then
                    .CommandText += "    AND A.StationID=@StationID " & vbNewLine
                End If

                If enumIsLinkedStorage = VO.SubStation.FilterIsLinkedStorage.IsLinkedStorage Then
                    .CommandText += "    AND C.IsLinkStorage=1 " & vbNewLine

                    If strStorageID.Trim <> "" Then
                        .CommandText +=
                            "    AND A.ID IN " & vbNewLine &
                            "    (" & vbNewLine &
                            "	    SELECT SubStationID " & vbNewLine &
                            "	    FROM QMS_traStorageLaneSwitchingDet TLD " & vbNewLine &
                            "	    INNER JOIN " & vbNewLine &
                            "	    (" & vbNewLine &
                            "		    SELECT TOP 1 ID " & vbNewLine &
                            "		    FROM QMS_traStorageLaneSwitching " & vbNewLine &
                            "		    WHERE " & vbNewLine &
                            "			    ComLocDivSubDivID=@ComLocDivSubDivID " & vbNewLine &
                            "			    AND CompanyID=@CompanyID " & vbNewLine &
                            "			    AND LocationID=@LocationID " & vbNewLine &
                            "			    AND StorageGroupID=@StorageGroupID " & vbNewLine &
                            "			    AND StorageID=@StorageID " & vbNewLine &
                            "			    AND ProgramID=@ProgramID " & vbNewLine &
                            "			    AND IsDeleted=0 " & vbNewLine &
                            "		    ORDER BY CreatedDate DESC " & vbNewLine &
                            "	    ) TL ON TLD.StorageLaneSwitchingID=TL.ID " & vbNewLine &
                            "    )" & vbNewLine
                    End If

                ElseIf enumIsLinkedStorage = VO.SubStation.FilterIsLinkedStorage.IsNotLinkedStorage Then
                    .CommandText += "    AND C.IsLinkStorage=0 " & vbNewLine
                End If

                .Parameters.Add("@CompanyID", SqlDbType.VarChar, 10).Value = strCompanyID
                .Parameters.Add("@LocationID", SqlDbType.VarChar, 10).Value = strLocationID
                .Parameters.Add("@StationID", SqlDbType.Int).Value = intStationID
                .Parameters.Add("@ComLocDivSubDivID", SqlDbType.Int).Value = intComLocDivSubDivID
                .Parameters.Add("@ProgramID", SqlDbType.VarChar, 15).Value = strProgramID
                .Parameters.Add("@StorageGroupID", SqlDbType.VarChar, 100).Value = strStorageGroupID
                .Parameters.Add("@StorageID", SqlDbType.VarChar, 100).Value = strStorageID
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub SaveData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                             ByVal bolNew As Boolean, ByVal clsData As VO.SubStation)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                If bolNew Then
                    .CommandText =
                       "INSERT INTO QMS_mstSubStation " & vbNewLine &
                       "    (CompanyID, LocationID, ID, StationID, Description, IsDefault, " & vbNewLine &
                       "     IDStatus, Remarks, CreatedBy, CreatedDate, LogBy, LogDate)   " & vbNewLine &
                       "VALUES " & vbNewLine &
                       "    (@CompanyID, @LocationID, @ID, @StationID, @Description, @IsDefault, " & vbNewLine &
                       "     @IDStatus, @Remarks, @LogBy, GETDATE(), @LogBy, GETDATE())  " & vbNewLine
                Else
                    .CommandText =
                       "UPDATE QMS_mstSubStation SET " & vbNewLine &
                       "    CompanyID=@CompanyID, " & vbNewLine &
                       "    LocationID=@LocationID, " & vbNewLine &
                       "    StationID=@StationID, " & vbNewLine &
                       "    Description=@Description, " & vbNewLine &
                       "    IsDefault=@IsDefault, " & vbNewLine &
                       "    IDStatus=@IDStatus, " & vbNewLine &
                       "    Remarks=@Remarks, " & vbNewLine &
                       "    LogBy=@LogBy, " & vbNewLine &
                       "    LogDate=GETDATE(), " & vbNewLine &
                       "    LogInc=LogInc+1 " & vbNewLine &
                       "WHERE " & vbNewLine &
                       "    ID=@ID " & vbNewLine
                End If

                .Parameters.Add("@CompanyID", SqlDbType.VarChar, 10).Value = clsData.CompanyID
                .Parameters.Add("@LocationID", SqlDbType.VarChar, 10).Value = clsData.LocationID
                .Parameters.Add("@ID", SqlDbType.Int).Value = clsData.ID
                .Parameters.Add("@StationID", SqlDbType.Int).Value = clsData.StationID
                .Parameters.Add("@Description", SqlDbType.VarChar, 50).Value = clsData.Description
                .Parameters.Add("@IsDefault", SqlDbType.Bit).Value = clsData.IsDefault
                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = clsData.IDStatus
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With

            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal intID As Integer) As VO.SubStation
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voReturn As New VO.SubStation
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                       "SELECT TOP 1 " & vbNewLine &
                       "    A.CompanyID, CS.CompanyName, A.LocationID, CS.LocationName, A.ID, A.StationID, A.Description, A.IsDefault,   " & vbNewLine &
                       "    A.ComputerName, A.InitialID, A.COMPort1, A.COMPort2, A.BaudRate, A.DataBits, A.Comparity, A.ComStopBits, " & vbNewLine &
                       "    A.IDStatus, B.Description AS StatusInfo, A.Remarks, A.CreatedBy, A.CreatedDate, A.LogBy, A.LogDate, A.LogInc  " & vbNewLine &
                       "FROM QMS_mstSubStation A " & vbNewLine &
                       "INNER JOIN QMS_mstStatus B ON " & vbNewLine &
                       "    A.IDStatus=B.ID " & vbNewLine &
                       "INNER JOIN QMS_vwCompanyStructure CS ON " & vbNewLine &
                       "    A.CompanyID=CS.CompanyID " & vbNewLine &
                       "    AND A.LocationID=CS.LocationID " & vbNewLine &
                       "WHERE " & vbNewLine &
                       "    A.ID=@ID " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.Int).Value = intID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voReturn.CompanyID = .Item("CompanyID")
                        voReturn.LocationID = .Item("LocationID")
                        voReturn.CompanyName = .Item("CompanyName")
                        voReturn.LocationName = .Item("LocationName")
                        voReturn.ID = .Item("ID")
                        voReturn.StationID = .Item("StationID")
                        voReturn.Description = .Item("Description")
                        voReturn.IsDefault = .Item("IsDefault")
                        voReturn.ComputerName = .Item("ComputerName")
                        voReturn.InitialID = .Item("InitialID")
                        voReturn.COMPort1 = .Item("COMPort1")
                        voReturn.COMPort2 = .Item("COMPort2")
                        voReturn.BaudRate = .Item("BaudRate")
                        voReturn.DataBits = .Item("DataBits")
                        voReturn.Comparity = .Item("Comparity")
                        voReturn.ComStopBits = .Item("ComStopBits")
                        voReturn.IDStatus = .Item("IDStatus")
                        voReturn.StatusInfo = .Item("StatusInfo")
                        voReturn.Remarks = .Item("Remarks")
                        voReturn.CreatedBy = .Item("CreatedBy")
                        voReturn.CreatedDate = .Item("CreatedDate")
                        voReturn.LogBy = .Item("LogBy")
                        voReturn.LogDate = .Item("LogDate")
                        voReturn.LogInc = .Item("LogInc")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voReturn
        End Function

        Protected Friend Shared Function GetDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal strCompanyID As String, ByVal strLocationID As String, ByVal strComputerName As String) As VO.SubStation
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voReturn As New VO.SubStation
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                       "SELECT TOP 1 " & vbNewLine &
                       "    A.CompanyID, CS.CompanyName, A.LocationID, CS.LocationName, A.ID, A.StationID, A.Description, A.IsDefault,   " & vbNewLine &
                       "    A.ComputerName, A.InitialID, A.COMPort1, A.COMPort2, A.BaudRate, A.DataBits, A.Comparity, A.ComStopBits, " & vbNewLine &
                       "    A.IDStatus, B.Description AS StatusInfo, A.Remarks, A.CreatedBy, A.CreatedDate, A.LogBy, A.LogDate, A.LogInc  " & vbNewLine &
                       "FROM QMS_mstSubStation A " & vbNewLine &
                       "INNER JOIN QMS_mstStatus B ON " & vbNewLine &
                       "    A.IDStatus=B.ID " & vbNewLine &
                       "INNER JOIN QMS_vwCompanyStructure CS ON " & vbNewLine &
                       "    A.CompanyID=CS.CompanyID " & vbNewLine &
                       "    AND A.LocationID=CS.LocationID " & vbNewLine &
                       "WHERE " & vbNewLine &
                       "    A.CompanyID=@CompanyID " & vbNewLine &
                       "    AND A.LocationID=@LocationID " & vbNewLine &
                       "    AND A.ComputerName=@ComputerName" & vbNewLine

                    .Parameters.Add("@CompanyID", SqlDbType.VarChar, 10).Value = strCompanyID
                    .Parameters.Add("@LocationID", SqlDbType.VarChar, 10).Value = strLocationID
                    .Parameters.Add("@ComputerName", SqlDbType.VarChar, 100).Value = strComputerName.ToString
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voReturn.CompanyID = .Item("CompanyID")
                        voReturn.LocationID = .Item("LocationID")
                        voReturn.CompanyName = .Item("CompanyName")
                        voReturn.LocationName = .Item("LocationName")
                        voReturn.ID = .Item("ID")
                        voReturn.StationID = .Item("StationID")
                        voReturn.Description = .Item("Description")
                        voReturn.IsDefault = .Item("IsDefault")
                        voReturn.ComputerName = .Item("ComputerName")
                        voReturn.InitialID = .Item("InitialID")
                        voReturn.COMPort1 = .Item("COMPort1")
                        voReturn.COMPort2 = .Item("COMPort2")
                        voReturn.BaudRate = .Item("BaudRate")
                        voReturn.DataBits = .Item("DataBits")
                        voReturn.Comparity = .Item("Comparity")
                        voReturn.ComStopBits = .Item("ComStopBits")
                        voReturn.IDStatus = .Item("IDStatus")
                        voReturn.StatusInfo = .Item("StatusInfo")
                        voReturn.Remarks = .Item("Remarks")
                        voReturn.CreatedBy = .Item("CreatedBy")
                        voReturn.CreatedDate = .Item("CreatedDate")
                        voReturn.LogBy = .Item("LogBy")
                        voReturn.LogDate = .Item("LogDate")
                        voReturn.LogInc = .Item("LogInc")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voReturn
        End Function

        Protected Friend Shared Function GetInitalID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                     ByVal strCompanyID As String, ByVal strLocationID As String, ByVal strComputerName As String) As String
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim strReturn As String = ""
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                       "SELECT TOP 1 " & vbNewLine &
                       "    A.InitialID " & vbNewLine &
                       "FROM QMS_mstSubStation A " & vbNewLine &
                       "INNER JOIN QMS_mstStatus B ON " & vbNewLine &
                       "    A.IDStatus=B.ID " & vbNewLine &
                       "INNER JOIN QMS_vwCompanyStructure CS ON " & vbNewLine &
                       "    A.CompanyID=CS.CompanyID " & vbNewLine &
                       "    AND A.LocationID=CS.LocationID " & vbNewLine &
                       "WHERE " & vbNewLine &
                       "    A.CompanyID=@CompanyID " & vbNewLine &
                       "    AND A.LocationID=@LocationID " & vbNewLine &
                       "    AND A.ComputerName=@ComputerName" & vbNewLine

                    .Parameters.Add("@CompanyID", SqlDbType.VarChar, 10).Value = strCompanyID
                    .Parameters.Add("@LocationID", SqlDbType.VarChar, 10).Value = strLocationID
                    .Parameters.Add("@ComputerName", SqlDbType.VarChar, 100).Value = strComputerName.ToString
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        strReturn = .Item("InitialID")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return strReturn
        End Function

        Protected Friend Shared Sub DeleteData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                               ByVal clsData As VO.SubStation)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE QMS_mstSubStation " & vbNewLine &
                    "   SET IDStatus=@IDStatus, " & vbNewLine &
                    "   LogBy=@LogBy, " & vbNewLine &
                    "   LogDate=GETDATE(), " & vbNewLine &
                    "   LogInc=LogInc+1, " & vbNewLine &
                    "   IsDefault=0 " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "   ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.Int).Value = clsData.ID
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = VO.Status.Values.InActive
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetMaxID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intReturn As Integer = 0
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ID=ISNULL(MAX(ID),0) " & vbNewLine &
                        "FROM QMS_mstSubStation " & vbNewLine
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intReturn = .Item("ID") + 1
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return intReturn
        End Function

        Protected Friend Shared Function IsIDExists(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                    ByVal intID As Integer) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ID " & vbNewLine &
                        "FROM QMS_mstSubStation " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   ID=@ID " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.Int).Value = intID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

        Protected Friend Shared Function IsInActive(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                    ByVal intID As Integer) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   Description " & vbNewLine &
                        "FROM QMS_mstSubStation " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   ID=@ID AND IDStatus=@IDStatus " & vbNewLine

                    .Parameters.Add("@ID", SqlDbType.Int).Value = intID
                    .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = VO.Status.Values.InActive
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

        Protected Friend Shared Sub SetIsDefault(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                 ByVal strCompanyID As String, ByVal strLocationID As String, ByVal intStationID As Integer, ByVal bolValue As Boolean)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE QMS_mstSubStation " & vbNewLine &
                    "   SET IsDefault=@Value " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "   CompanyID=@CompanyID " & vbNewLine &
                    "   AND LocationID=@LocationID " & vbNewLine &
                    "   AND StationID=@StationID " & vbNewLine

                .Parameters.Add("@CompanyID", SqlDbType.VarChar, 10).Value = strCompanyID
                .Parameters.Add("@LocationID", SqlDbType.VarChar, 10).Value = strLocationID
                .Parameters.Add("@StationID", SqlDbType.Int).Value = intStationID
                .Parameters.Add("@Value", SqlDbType.Bit).Value = bolValue
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function IsFirstSubStation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                           ByVal intStationID As Integer) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = True
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT " & vbNewLine &
                        "   COUNT(ID) Total " & vbNewLine &
                        "FROM QMS_mstSubStation " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   StationID=@StationID " & vbNewLine

                    .Parameters.Add("@StationID", SqlDbType.Int).Value = intStationID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        If .Item("Total") > 0 Then bolExists = False
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

        Protected Friend Shared Sub SaveConfigurationRFIDReader(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                ByVal clsData As VO.SubStation)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "UPDATE QMS_mstSubStation SET " & vbNewLine &
                   "    ComputerName=@ComputerName, " & vbNewLine &
                   "    InitialID=@InitialID, " & vbNewLine &
                   "    COMPort1=@COMPort1, " & vbNewLine &
                   "    COMPort2=@COMPort2, " & vbNewLine &
                   "    BaudRate=@BaudRate, " & vbNewLine &
                   "    DataBits=@DataBits, " & vbNewLine &
                   "    Comparity=@Comparity, " & vbNewLine &
                   "    ComStopBits=@ComStopBits, " & vbNewLine &
                   "    LogBy=LogBy, " & vbNewLine &
                   "    LogDate=GETDATE(), " & vbNewLine &
                   "    LogInc=LogInc+1 " & vbNewLine &
                   "WHERE " & vbNewLine &
                   "    ID=@ID " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.VarChar, 10).Value = clsData.ID
                .Parameters.Add("@ComputerName", SqlDbType.VarChar, 100).Value = clsData.ComputerName
                .Parameters.Add("@InitialID", SqlDbType.VarChar, 10).Value = clsData.InitialID
                .Parameters.Add("@COMPort1", SqlDbType.VarChar, 10).Value = clsData.COMPort1
                .Parameters.Add("@COMPort2", SqlDbType.VarChar, 10).Value = clsData.COMPort2
                .Parameters.Add("@BaudRate", SqlDbType.Int).Value = clsData.BaudRate
                .Parameters.Add("@DataBits", SqlDbType.Int).Value = clsData.DataBits
                .Parameters.Add("@Comparity", SqlDbType.VarChar, 10).Value = clsData.Comparity
                .Parameters.Add("@ComStopBits", SqlDbType.VarChar, 10).Value = clsData.ComStopBits
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
            End With

            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

#Region "Post Data"

        Protected Friend Shared Function QueryOutstandingPosting() As String
            Dim strReturn As String = _
                   "SELECT " & vbNewLine & _
                   "    A.CompanyID, A.LocationID, A.ID, A.StationID, C.Description AS StationName, A.Description, A.IsDefault, " & vbNewLine & _
                   "    A.ComputerName, A.InitialID, A.COMPort1, A.COMPort2, A.BaudRate, A.DataBits, A.Comparity, A.ComStopBits, " & vbNewLine & _
                   "    A.IDStatus, B.Description AS StatusInfo, A.Remarks, A.CreatedBy, A.CreatedDate, A.LogBy, A.LogDate,   " & vbNewLine & _
                   "    A.LogInc  " & vbNewLine & _
                   "FROM QMS_mstSubStation A " & vbNewLine & _
                   "LEFT JOIN QMS_mstStatus B ON " & vbNewLine & _
                   "    A.IDStatus=B.ID " & vbNewLine & _
                   "INNER JOIN QMS_mstStation C ON " & vbNewLine & _
                   "    A.StationID=C.ID " & vbNewLine & _
                   "WHERE  " & vbNewLine & _
                   "    A.LogDate>=@SyncDate " & vbNewLine & _
                   "    AND A.CompanyID=@CompanyID " & vbNewLine & _
                   "    AND A.LocationID=@LocationID " & vbNewLine
            Return strReturn
        End Function

        Protected Friend Shared Function QueryPostData() As String
            Dim strReturn As String = _
                    "IF NOT EXISTS(SELECT TOP 1 ID FROM QMS_mstSubStation WHERE ID=@ID) " & vbNewLine & _
                    "BEGIN " & vbNewLine & _
                    "   INSERT INTO QMS_mstSubStation " & vbNewLine & _
                    "   (CompanyID, LocationID, ID, StationID, Description, IsDefault,   " & vbNewLine & _
                    "    ComputerName, InitialID, COMPort1, COMPort2, BaudRate, DataBits, Comparity, " & vbNewLine & _
                    "    ComStopBits, IDStatus, Remarks, CreatedBy, CreatedDate, LogBy, LogDate, LogInc)   " & vbNewLine & _
                    "   VALUES " & vbNewLine & _
                    "   (@CompanyID, @LocationID, @ID, @StationID, @Description, @IsDefault, " & vbNewLine & _
                    "    @ComputerName, @InitialID, @COMPort1, @COMPort2, @BaudRate, @DataBits, @Comparity, " & vbNewLine & _
                    "    @ComStopBits, @IDStatus, @Remarks, @CreatedBy, @CreatedDate, @LogBy, @LogDate, @LogInc)  " & vbNewLine & _
                    "END " & vbNewLine & _
                    "ELSE " & vbNewLine & _
                    "BEGIN " & vbNewLine & _
                    "   UPDATE QMS_mstSubStation SET " & vbNewLine & _
                    "       CompanyID=@CompanyID, " & vbNewLine & _
                    "       LocationID=@LocationID, " & vbNewLine & _
                    "       StationID=@StationID, " & vbNewLine & _
                    "       Description=@Description, " & vbNewLine & _
                    "       IsDefault=@IsDefault, " & vbNewLine & _
                    "       ComputerName=@ComputerName, " & vbNewLine & _
                    "       InitialID=@InitialID, " & vbNewLine & _
                    "       COMPort1=@COMPort1, " & vbNewLine & _
                    "       COMPort2=@COMPort2, " & vbNewLine & _
                    "       BaudRate=@BaudRate, " & vbNewLine & _
                    "       DataBits=@DataBits, " & vbNewLine & _
                    "       Comparity=@Comparity, " & vbNewLine & _
                    "       ComStopBits=@ComStopBits, " & vbNewLine & _
                    "       IDStatus=@IDStatus, " & vbNewLine & _
                    "       Remarks=@Remarks, " & vbNewLine & _
                    "       CreatedBy=@CreatedBy, " & vbNewLine & _
                    "       CreatedDate=@CreatedDate, " & vbNewLine & _
                    "       LogBy=@LogBy, " & vbNewLine & _
                    "       LogDate=@LogDate, " & vbNewLine & _
                    "       LogInc=@LogInc " & vbNewLine & _
                    "   WHERE " & vbNewLine & _
                    "       ID=@ID " & vbNewLine & _
                    "END " & vbNewLine
            Return strReturn
        End Function

        Protected Friend Shared Function OutstandingPostingRDCtoLocation(ByVal dtmSyncDate As DateTime, ByVal strCompanyID As String, ByVal strLocationID As String) As DataTable
            '# Add Parameter
            Dim sqlParams As New List(Of MM_Remoting_Service.SqlHelperParameter)
            sqlParams.Add(New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@SyncDate", SqlDbType.DateTime, dtmSyncDate))
            sqlParams.Add(New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@CompanyID", SqlDbType.VarChar, strCompanyID))
            sqlParams.Add(New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@LocationID", SqlDbType.VarChar, strLocationID))

            '# Get DataTables
            Dim MMRemotingService As MM_Remoting_Service.SqlHelper = BL.Server.DefaultRemotingService
            Return MMRemotingService.GetDataTable(CommandType.Text, QueryOutstandingPosting, sqlParams)
        End Function

        Protected Friend Shared Sub PostDataRDCtoLocation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                          ByVal clsData As VO.SubStation)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText = QueryPostData()
                .Parameters.Add("@CompanyID", SqlDbType.VarChar, 10).Value = clsData.CompanyID
                .Parameters.Add("@LocationID", SqlDbType.VarChar, 10).Value = clsData.LocationID
                .Parameters.Add("@ID", SqlDbType.Int).Value = clsData.ID
                .Parameters.Add("@StationID", SqlDbType.Int).Value = clsData.StationID
                .Parameters.Add("@Description", SqlDbType.VarChar, 50).Value = clsData.Description
                .Parameters.Add("@IsDefault", SqlDbType.Bit).Value = clsData.IsDefault
                .Parameters.Add("@ComputerName", SqlDbType.VarChar, 100).Value = clsData.ComputerName
                .Parameters.Add("@InitialID", SqlDbType.VarChar, 10).Value = clsData.InitialID
                .Parameters.Add("@COMPort1", SqlDbType.VarChar, 10).Value = clsData.COMPort1
                .Parameters.Add("@COMPort2", SqlDbType.VarChar, 10).Value = clsData.COMPort2
                .Parameters.Add("@BaudRate", SqlDbType.Int).Value = clsData.BaudRate
                .Parameters.Add("@DataBits", SqlDbType.Int).Value = clsData.DataBits
                .Parameters.Add("@Comparity", SqlDbType.VarChar, 10).Value = clsData.Comparity
                .Parameters.Add("@ComStopBits", SqlDbType.VarChar, 10).Value = clsData.ComStopBits
                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = clsData.IDStatus
                .Parameters.Add("@Remarks", SqlDbType.VarChar, 250).Value = clsData.Remarks
                .Parameters.Add("@CreatedBy", SqlDbType.VarChar, 20).Value = clsData.CreatedBy
                .Parameters.Add("@CreatedDate", SqlDbType.DateTime).Value = clsData.CreatedDate
                .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = clsData.LogBy
                .Parameters.Add("@LogDate", SqlDbType.DateTime).Value = clsData.LogDate
                .Parameters.Add("@LogInc", SqlDbType.Int).Value = clsData.LogInc
            End With

            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

#End Region

    End Class

End Namespace

