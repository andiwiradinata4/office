Imports System.Runtime.Remoting
Imports MM_Remoting_Service

Namespace DL
    Friend Class Storage

#Region "Main"

        Protected Friend Shared Function ListData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                  ByVal strCompanyID As String, ByVal strLocationID As String) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "SELECT " & vbNewLine &
                   "    A.ComLocDivSubDivID, A.CompanyID, A.LocationID, A.ProgramID, A.StorageGroupID, A.StorageID, A.StorageGroupName,   " & vbNewLine &
                   "    A.StorageName, A.IsBlackList  " & vbNewLine &
                   "FROM QMS_mstStorage A " & vbNewLine &
                   "WHERE  " & vbNewLine &
                   "    A.CompanyID=@CompanyID" & vbNewLine &
                   "    AND A.LocationID=@LocationID" & vbNewLine

                .Parameters.Add("@CompanyID", SqlDbType.VarChar, 10).Value = strCompanyID
                .Parameters.Add("@LocationID", SqlDbType.VarChar, 10).Value = strLocationID
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub SaveData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                             ByVal bolNew As Boolean, ByVal clsData As VO.Storage)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                If bolNew Then
                    .CommandText =
                       "INSERT INTO QMS_mstStorage " & vbNewLine &
                       "    (ComLocDivSubDivID, CompanyID, LocationID, ProgramID, StorageGroupID, StorageID, StorageGroupName,   " & vbNewLine &
                       "     StorageName, IsBlackList)   " & vbNewLine &
                       "VALUES " & vbNewLine &
                       "    (@ComLocDivSubDivID, @CompanyID, @LocationID, @ProgramID, @StorageGroupID, @StorageID, @StorageGroupName,   " & vbNewLine &
                       "     @StorageName, @IsBlackList)  " & vbNewLine
                Else
                    .CommandText =
                       "UPDATE QMS_mstStorage SET " & vbNewLine &
                       "    CompanyID=@CompanyID, " & vbNewLine &
                       "    LocationID=@LocationID, " & vbNewLine &
                       "    StorageGroupName=@StorageGroupName, " & vbNewLine &
                       "    StorageName=@StorageName, " & vbNewLine &
                       "    IsBlackList=@IsBlackList " & vbNewLine &
                       "WHERE " & vbNewLine &
                       "    ComLocDivSubDivID=@ComLocDivSubDivID " & vbNewLine &
                       "    AND ProgramID=@ProgramID " & vbNewLine &
                       "    AND StorageGroupID=@StorageGroupID " & vbNewLine &
                       "    AND StorageID=@StorageID " & vbNewLine
                End If

                .Parameters.Add("@ComLocDivSubDivID", SqlDbType.Int).Value = clsData.ComLocDivSubDivID
                .Parameters.Add("@CompanyID", SqlDbType.VarChar, 10).Value = clsData.CompanyID
                .Parameters.Add("@LocationID", SqlDbType.VarChar, 10).Value = clsData.LocationID
                .Parameters.Add("@ProgramID", SqlDbType.VarChar, 15).Value = clsData.ProgramID
                .Parameters.Add("@StorageGroupID", SqlDbType.VarChar, 100).Value = clsData.StorageGroupID
                .Parameters.Add("@StorageID", SqlDbType.VarChar, 100).Value = clsData.StorageID
                .Parameters.Add("@StorageGroupName", SqlDbType.VarChar, 100).Value = clsData.StorageGroupName
                .Parameters.Add("@StorageName", SqlDbType.VarChar, 100).Value = clsData.StorageName
                .Parameters.Add("@IsBlackList", SqlDbType.Bit).Value = clsData.IsBlackList
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal intComLocDivSubDivID As Integer, ByVal strProgramID As String, ByVal strStorageGroupID As String, ByVal strStorageID As String) As VO.Storage
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voReturn As New VO.Storage
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                       "SELECT TOP 1 " & vbNewLine &
                       "    A.ComLocDivSubDivID, A.CompanyID, A.LocationID, A.ProgramID, A.StorageGroupID, A.StorageID, A.StorageGroupName,   " & vbNewLine &
                       "    A.StorageName, A.IsBlackList  " & vbNewLine &
                       "FROM QMS_mstStorage A " & vbNewLine &
                       "WHERE " & vbNewLine &
                       "    ComLocDivSubDivID=@ComLocDivSubDivID " & vbNewLine &
                       "    AND ProgramID=@ProgramID " & vbNewLine &
                       "    AND StorageGroupID=@StorageGroupID " & vbNewLine &
                       "    AND StorageID=@StorageID " & vbNewLine

                    .Parameters.Add("@ComLocDivSubDivID", SqlDbType.Int).Value = intComLocDivSubDivID
                    .Parameters.Add("@ProgramID", SqlDbType.VarChar, 15).Value = strProgramID
                    .Parameters.Add("@StorageGroupID", SqlDbType.VarChar, 100).Value = strStorageGroupID
                    .Parameters.Add("@StorageID", SqlDbType.VarChar, 100).Value = strStorageID

                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voReturn.ComLocDivSubDivID = .Item("ComLocDivSubDivID")
                        voReturn.CompanyID = .Item("CompanyID")
                        voReturn.LocationID = .Item("LocationID")
                        voReturn.ProgramID = .Item("ProgramID")
                        voReturn.StorageGroupID = .Item("StorageGroupID")
                        voReturn.StorageID = .Item("StorageID")
                        voReturn.StorageGroupName = .Item("StorageGroupName")
                        voReturn.StorageName = .Item("StorageName")
                        voReturn.IsBlackList = .Item("IsBlackList")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voReturn
        End Function

        Protected Friend Shared Function DataExists(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                    ByVal intComLocDivSubDivID As Integer, ByVal strProgramID As String, ByVal strStorageGroupID As String, ByVal strStorageID As String) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolExists As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ComLocDivSubDivID " & vbNewLine &
                        "FROM QMS_mstStorage " & vbNewLine &
                        "WHERE  " & vbNewLine &
                        "   ComLocDivSubDivID=@ComLocDivSubDivID " & vbNewLine &
                        "   AND ProgramID=@ProgramID " & vbNewLine &
                        "   AND StorageGroupID=@StorageGroupID " & vbNewLine &
                        "   AND StorageID=@StorageID " & vbNewLine

                    .Parameters.Add("@ComLocDivSubDivID", SqlDbType.Int).Value = intComLocDivSubDivID
                    .Parameters.Add("@ProgramID", SqlDbType.VarChar, 15).Value = strProgramID
                    .Parameters.Add("@StorageGroupID", SqlDbType.VarChar, 100).Value = strStorageGroupID
                    .Parameters.Add("@StorageID", SqlDbType.VarChar, 100).Value = strStorageID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolExists = True
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolExists
        End Function

#End Region

#Region "Post Data"

        Protected Friend Shared Function ListDataMMRemoting() As DataTable
            Dim QueryListDataFromAnotherOpsys As String = _
                "--INVENTORY " & vbNewLine & _
                "SELECT " & vbNewLine & _
                "	A.ComLocDivSubDivID, CS.CompanyID, CS.LocationID, A.ProgramID, A.WarehouseID AS StorageGroupID, A.WarehouseName AS StorageGroupName, B.RackID AS StorageID, " & vbNewLine & _
                "	B.RackName AS StorageName, A.IsBlackList " & vbNewLine & _
                "FROM Inventory.dbo.IVN_mstWarehouse A WITH(NOLOCK) " & vbNewLine & _
                "INNER JOIN Inventory.dbo.IVN_mstWarehouseRacks B WITH(NOLOCK) ON " & vbNewLine & _
                "	A.ComLocDivSubDivID = B.ComLocDivSubDivID " & vbNewLine & _
                "	AND A.ProgramID = B.ProgramID " & vbNewLine & _
                "	AND A.WarehouseID = B.WarehouseID " & vbNewLine & _
                "	AND B.TankID='' -- Just Get All Storage Non Tank " & vbNewLine & _
                "INNER JOIN WeighbridgeMgt.dbo.QMS_vwCompanyStructure CS ON " & vbNewLine & _
                "	A.ComLocDivSubDivID=CS.ComLocDivSubDivID " & vbNewLine

            'Get DataTables
            Dim MMRemotingService As MM_Remoting_Service.SqlHelper = BL.Server.DefaultRemotingService
            Return MMRemotingService.GetDataTable(CommandType.Text, QueryListDataFromAnotherOpsys)
        End Function

        Protected Friend Shared Function ListDataMMRemoting(ByVal strCompanyID As String, ByVal strLocationID As String) As DataTable
            Dim QueryListDataFromAnotherOpsys As String =
                "-- TANK MANAGEMENT | JOHN.HALIM -> Ada Jenis TANK FISIK BESAR, TANK FISIK KECIL (PRODUKSI), TANK VIRTUAL " & vbNewLine &
                "select" & vbNewLine &
                "	0 AS ComLocDivSubDivID, cl.Company_id AS CompanyID, cl.Location_Id AS LocationID, 'TM' AS ProgramID, " & vbNewLine &
                "	f.TankFarm_Id StorageGroupID, s.Tank_id	StorageID , f.Name StorageGroupName, s.Name StorageName, " & vbNewLine &
                "	ISNULL(s.IsBlackList,0) AS IsBlackList" & vbNewLine &
                "from KONTR.dbo.XTM_Storage s " & vbNewLine &
                "inner join KONTR.dbo.XTM_Farm f on s.TankFarm_Id = f.TankFarm_Id" & vbNewLine &
                "inner join KONTR.dbo.v_ABSNew_MM_Com_Loc_Div cld on f.Com_Loc_Div_Id = cld.Com_Loc_Div_Id" & vbNewLine &
                "inner join KONTR.dbo.v_ABSNew_MM_Com_Loc cl on cld.Com_Loc_Id = cl.Com_Loc_Id " & vbNewLine &
                "WHERE " & vbNewLine &
                "	cl.Company_id=@CompanyID " & vbNewLine &
                "	AND cl.Location_Id=@LocationID " & vbNewLine &
                "" & vbNewLine &
                "UNION ALL" & vbNewLine &
                "-- INVENTORY | FENDY.LUO" & vbNewLine &
                "SELECT " & vbNewLine &
                "	A.ComLocDivSubDivID, CS.CompanyID, CS.LocationID, A.ProgramID, " & vbNewLine &
                "	A.WarehouseID AS StorageGroupID, A.WarehouseName AS StorageGroupName, B.RackID AS StorageID, B.RackName AS StorageName, A.IsBlackList" & vbNewLine &
                "FROM Inventory.dbo.IVN_mstWarehouse A WITH(NOLOCK) " & vbNewLine &
                "INNER JOIN Inventory.dbo.IVN_mstWarehouseRacks B WITH(NOLOCK) ON " & vbNewLine &
                "	A.ComLocDivSubDivID = B.ComLocDivSubDivID " & vbNewLine &
                "	AND A.ProgramID = B.ProgramID " & vbNewLine &
                "	AND A.WarehouseID = B.WarehouseID " & vbNewLine &
                "	AND B.TankID='' -- Just Get All Storage Non Tank " & vbNewLine &
                "INNER JOIN Inventory.dbo.IVN_vwCompanyStructure CS ON " & vbNewLine &
                "	A.ComLocDivSubDivID=CS.ComLocDivSubDivID " & vbNewLine &
                "WHERE " & vbNewLine &
                "	CS.CompanyID=@CompanyID " & vbNewLine &
                "	AND CS.LocationID=@LocationID " & vbNewLine

            ''Add Parameter
            'Dim sqlParams As New List(Of MM_Remoting_Service.SqlHelperParameter)
            'sqlParams.Add(New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@CompanyID", SqlDbType.VarChar, 15, strCompanyID))
            'sqlParams.Add(New MM_Remoting_Service.SqlHelperParameter(ParameterDirection.Input, "@LocationID", SqlDbType.VarChar, 15, strLocationID))
            ''Get DataTables
            'Dim MMRemotingService As MM_Remoting_Service.SqlHelper = BL.Server.DefaultRemotingService
            'Return MMRemotingService.GetDataTable(CommandType.Text, QueryListDataFromAnotherOpsys, sqlParams)

            Dim dtData As DataTable
            Dim MMRemotingServiceServer As MM_Remoting_Service_Server = BL.Server.DefaultRemotingServiceServer
            With MMRemotingServiceServer
                .CommandType = CommandType.Text
                .Query = QueryListDataFromAnotherOpsys
                .Add("@CompanyID", SqlDbType.VarChar, 15).Value = strCompanyID
                .Add("@LocationID", SqlDbType.VarChar, 15).Value = strLocationID
                dtData = .pubGetData()
            End With
            Return dtData
        End Function

#End Region

    End Class

End Namespace

