﻿Namespace DL
    Public Class Learning

        Protected Friend Shared Sub TrialInOutParamsStoredProcedure(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                    intAssignParams As Integer)
            Dim intReturnParams As Integer = 0
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.StoredProcedure
                .CommandText = "[dbo].[usp_QMS_Learn_InOut_Params]"
                .Parameters.Add("@AssignParams", SqlDbType.Int).Value = intAssignParams
                .Parameters.Add("@ReturnParams", SqlDbType.Int).Value = intReturnParams
                .Parameters("@ReturnParams").Direction = ParameterDirection.InputOutput
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
                intReturnParams = sqlcmdExecute.Parameters("@ReturnParams").Value
                Console.WriteLine("Return Params => " & intReturnParams)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function CheckTimeoutError(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction) As DataTable
            Dim intReturnParams As Integer = 0
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText = "SELECT * FROM QMS_mstRFIDCard"
            End With
            Try
                Return DL.SQL.QueryDataTable(sqlcmdExecute, sqlTrans, 5)
            Catch ex As SqlException
                Throw ex
            End Try
        End Function

        Protected Friend Shared Function CheckReaderClosed(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction) As String
            Dim strReturn As String = ""
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText = "SELECT TOP 1 ID FROM QMS_mstRFIDCard"
            End With
            Try
                sqlrdData = DL.SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                sqlrdData.Close()
                If sqlrdData.HasRows Then
                    sqlrdData.Read()
                    strReturn = sqlrdData.Item("ID")
                End If
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return strReturn
        End Function

    End Class
End Namespace