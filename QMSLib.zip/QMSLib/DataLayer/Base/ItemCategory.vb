﻿Namespace DL

    Friend Class ItemCategory

        Public Shared Function ListData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                        Optional ByVal intGroupID As Integer = -1) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "SELECT " &
                    "   A.CategoryID, A.CategoryCode, A.CategoryName, " &
                    "   A.ClassID, B.ClassCode, B.ClassName, " &
                    "   A.GroupID, C.GroupCode, C.GroupName, " &
                    "   A.Status,CASE A.Status WHEN 0 THEN 'ACTIVE' WHEN 1 THEN 'IN-ACTIVE' END AS StatusInfo," &
                    "   A.LogInc, A.LogBy, A.LogDate " &
                    "FROM QMS_vwItemCategory A " &
                    "INNER JOIN QMS_vwItemClass B ON " &
                    "   A.ClassID=B.ClassID " &
                    "INNER JOIN QMS_vwItemGroup C ON " &
                    "   A.GroupID=C.GroupID "
                If intGroupID <> -1 Then
                    .CommandText += "WHERE A.GroupID = @GroupID "
                    .Parameters.Add("@GroupID", SqlDbType.Int).Value = intGroupID
                End If
                .CommandText += "ORDER BY A.CategoryCode, B.ClassCode, C.GroupCode"
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Function ListDataDistinct(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "SELECT DISTINCT CategoryName " &
                    "FROM QMS_vwItemCategory " &
                    "ORDER BY CategoryName"
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function
    End Class

End Namespace