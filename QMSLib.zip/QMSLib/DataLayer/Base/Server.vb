﻿Namespace DL
    Friend Class Server

        Protected Friend Shared Function ServerList(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                If VO.DefaultServer.ReportingServer = 0 Then
                    .CommandText =
                    "SELECT " & vbNewLine &
                    "   Server, DBName, UserID, UserPassword " & vbNewLine &
                    "FROM QMS_sysServerList " & vbNewLine &
                    "WHERE IsActive = 1 " & vbNewLine &
                    "GROUP BY " & vbNewLine &
                    "   Server, DBName, UserID, UserPassword " & vbNewLine &
                    "ORDER BY Server "
                Else
                    .CommandText =
                    "SELECT " & vbNewLine &
                    "   ServerReport as Server, DBName, UserID, UserPassword " & vbNewLine &
                    "FROM QMS_sysServerList " & vbNewLine &
                    "WHERE IsActive = 1 " & vbNewLine &
                    "AND ServerReport <> '' " & vbNewLine &
                    "GROUP BY " & vbNewLine &
                    "   ServerReport, DBName, UserID, UserPassword " & vbNewLine &
                    "ORDER BY ServerReport "
                End If
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Function ServerCount(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction) As Integer
            Dim intCount As Integer = 0
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    If VO.DefaultServer.ReportingServer = 0 Then
                        .CommandText =
                        "SELECT COUNT(*) AS Total " & vbNewLine &
                        "FROM " & vbNewLine &
                        "   (SELECT Server, DBName " & vbNewLine &
                        "   FROM QMS_sysServerList " & vbNewLine &
                        "   GROUP BY Server, DBName) A "
                    Else
                        .CommandText =
                        "SELECT COUNT(*) AS Total " & vbNewLine &
                        "FROM " & vbNewLine &
                        "   (SELECT ServerReport as Server, DBName " & vbNewLine &
                        "   FROM QMS_sysServerList " & vbNewLine &
                        "   WHERE IsActive = 1 " & vbNewLine &
                        "   AND ServerReport <> '' " & vbNewLine &
                        "   GROUP BY ServerReport, DBName) A "
                    End If
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intCount = .Item("Total")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return intCount
        End Function

        Protected Friend Shared Function ServerAllCompanyList(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                If VO.DefaultServer.ReportingServer = 0 Then
                    .CommandText =
                    "SELECT " & vbNewLine &
                    "   CompanyID, Server, DBName, UserID, UserPassword " & vbNewLine &
                    "FROM QMS_sysServerList " & vbNewLine &
                    "WHERE IsActive = 1 " & vbNewLine &
                    "ORDER BY " & vbNewLine &
                    "   CompanyID "
                Else
                    .CommandText =
                    "SELECT " & vbNewLine &
                    "   CompanyID, ServerReport as Server, DBName, UserID, UserPassword " & vbNewLine &
                    "FROM QMS_sysServerList " & vbNewLine &
                    "WHERE IsActive = 1 " & vbNewLine &
                    "AND ServerReport <> '' " & vbNewLine &
                    "ORDER BY " & vbNewLine &
                    "   CompanyID "
                End If
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Function ServerByCompany(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                         ByVal strCompanyID As String) As VO.Server
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim clsReturn As New VO.Server
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    If VO.DefaultServer.ReportingServer = 0 Then
                        .CommandText =
                        "SELECT TOP 1  " & vbNewLine &
                        "   Server, DBName, UserID, UserPassword " & vbNewLine &
                        "FROM QMS_sysServerList " & vbNewLine &
                        "WHERE " & vbNewLine &
                        "   CompanyID=@CompanyID "
                    Else
                        .CommandText =
                        "SELECT TOP 1  " & vbNewLine &
                        "   ServerReport as Server, DBName, UserID, UserPassword " & vbNewLine &
                        "FROM QMS_sysServerList " & vbNewLine &
                        "WHERE " & vbNewLine &
                        "   CompanyID=@CompanyID "
                    End If

                    .Parameters.Add("@CompanyID", SqlDbType.VarChar, 10).Value = strCompanyID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        clsReturn.CompanyID = strCompanyID
                        clsReturn.Server = .Item("Server")
                        clsReturn.DBName = .Item("DBName")
                        clsReturn.UserID = .Item("UserID")
                        clsReturn.UserPassword = .Item("UserPassword")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return clsReturn
        End Function

    End Class
End Namespace
