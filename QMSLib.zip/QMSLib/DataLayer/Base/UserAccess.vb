﻿Namespace DL

    Friend Class UserAccess

        Friend Shared aRight(,) As String

        Protected Friend Shared Function UserList(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                  Optional ByVal intComLocDivSubDivID As Integer = 0) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                If intComLocDivSubDivID = 0 Then
                    .CommandText =
                        "SELECT " & vbNewLine &
                        "   UserID, UserName, UserPosition, Email, ExtNumber, HeadID " & vbNewLine &
                        "FROM QMS_vwUserList " & vbNewLine &
                        "ORDER BY UserID "
                ElseIf intComLocDivSubDivID > 0 Then
                    .CommandText =
                        "SELECT " & vbNewLine &
                        "   A.UserID, A.UserName, A.UserPosition, A.Email, A.ExtNumber, A.HeadID " & vbNewLine &
                        "FROM QMS_vwUserList A " & vbNewLine &
                        "INNER JOIN QMS_vwUserListDtl B ON " & vbNewLine &
                        "   A.UserID = B.UserID " & vbNewLine &
                        "WHERE " & vbNewLine &
                        "   B.ComLocDivSubDivID = @ComLocDivSubDivID " & vbNewLine &
                        "ORDER BY A.UserID "
                End If
                .Parameters.Add("@ComLocDivSubDivID", SqlDbType.Int).Value = intComLocDivSubDivID
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Function AccessList(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                    ByVal strUserID As String, strUserCompanyID As String) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "SELECT " & vbNewLine &
                    "   A.ProgramID, B.ProgramName, " & vbNewLine &
                    "   C.ComLocDivSubDivID, C.CompanyID, C.CompanyName, C.LocationID, C.LocationName, " & vbNewLine &
                    "   C.DivisionID, C.DivisionName, C.SubDivisionID, C.SubDivisionName " & vbNewLine &
                    "FROM QMS_vwUserListDtl A " & vbNewLine &
                    "INNER JOIN QMS_vwUserProgramList B ON " & vbNewLine &
                    "   A.ProgramID=B.ProgramID " & vbNewLine &
                    "INNER JOIN QMS_vwCompanyStructure C ON " & vbNewLine &
                    "   A.ComLocDivSubDivID=C.ComLocDivSubDivID " & vbNewLine &
                    "--INNER JOIN QMS_sysServerList D ON " & vbNewLine &
                    "--   C.CompanyID=D.CompanyID " & vbNewLine &
                    "WHERE A.UserID=@UserID " & vbNewLine

                If strUserCompanyID <> "" Then
                    .CommandText += " AND C.CompanyID=@CompanyID " & vbNewLine
                    .Parameters.Add("@CompanyID", SqlDbType.VarChar, 15).Value = strUserCompanyID
                End If

                .CommandText += "ORDER BY A.ProgramID, C.CompanyName, C.SubDivisionName " & vbNewLine

                .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strUserID
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Function GetDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal strUserID As String) As VO.User
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voUser As New VO.User
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   UserID,UserName,Password,Email,ExtNumber,HeadID,EmployeeID " & vbNewLine &
                        "FROM QMS_vwUserList " & vbNewLine &
                        "WHERE " & vbNewLine &
                        "   UserID = @UserID " & vbNewLine &
                        "   AND Active = 1 "

                    .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strUserID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voUser.ID = .Item("UserID")
                        voUser.Name = .Item("UserName")
                        voUser.Password = .Item("Password")
                        voUser.Email = .Item("Email")
                        voUser.ExtNumber = .Item("ExtNumber")
                        voUser.HeadID = .Item("HeadID")
                        voUser.EmployeeID = .Item("EmployeeID")
                    Else
                        voUser.ID = ""
                        voUser.Name = ""
                        voUser.Password = ""
                        voUser.Email = ""
                        voUser.ExtNumber = ""
                        voUser.HeadID = ""
                        voUser.EmployeeID = ""
                    End If
                End With
            Catch ex As Exception
                Throw (ex)
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voUser
        End Function

        Protected Friend Shared Function GetDetailNE(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                     ByVal strUserID As String) As VO.User
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim voUser As New VO.User
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   UserID,UserName,Password,Email,ExtNumber,HeadID " & vbNewLine &
                        "FROM ABSNEWNE.dbo.Sys_UserList " & vbNewLine &
                        "WHERE " & vbNewLine &
                        "   UserID = @UserID " & vbNewLine &
                        "   AND Active = 1 "

                    .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strUserID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voUser.ID = .Item("UserID")
                        voUser.Name = .Item("UserName")
                        voUser.Password = .Item("Password")
                        voUser.Email = .Item("Email")
                        voUser.ExtNumber = .Item("ExtNumber")
                        voUser.HeadID = .Item("HeadID")
                    Else
                        voUser.ID = ""
                        voUser.Name = ""
                        voUser.Password = ""
                        voUser.Email = ""
                        voUser.ExtNumber = ""
                        voUser.HeadID = ""
                    End If
                End With
            Catch ex As Exception
                Throw (ex)
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return voUser
        End Function

        Protected Friend Shared Function GetPassword(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                     ByVal strUserID As String) As String
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim strPassword As String = ""
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1  " & vbNewLine &
                        "   Password " & vbNewLine &
                        "FROM QMS_vwUserList " & vbNewLine &
                        "WHERE " & vbNewLine &
                        "   UserID=@UserID "

                    .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strUserID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        strPassword = .Item("Password")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return strPassword
        End Function

        Protected Friend Shared Sub ChangePassword(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal strUserID As String, ByVal strNewPassword As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE QMS_vwUserList SET " & vbNewLine &
                    "   Password=@NewPassword " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "   UserID=@UserID "

                .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strUserID
                .Parameters.Add("@NewPassword", SqlDbType.NVarChar, 100).Value = strNewPassword
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Private Shared Function AccessRightCount(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                 ByVal strProgramID As String) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intTotal As Integer = 0
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT " & vbNewLine &
                        "   COUNT(AccessRight) AS AccessRightCount " & vbNewLine &
                        "FROM QMS_vwUserAccessLevel " & vbNewLine &
                        "WHERE " & vbNewLine &
                        "   ProgramID=@ProgramID "

                    .Parameters.Add("@ProgramID", SqlDbType.VarChar, 15).Value = strProgramID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intTotal = .Item("AccessRightCount")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return intTotal
        End Function

        Protected Friend Shared Sub AccessFillRight(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                    ByVal strProgramID As String)
            Dim intTotal As Integer = AccessRightCount(sqlCon, sqlTrans, strProgramID)

            Dim intPos As Integer = 0
            ReDim aRight(intTotal, 1)

            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT " & vbNewLine &
                        "   AccessRight, AccessValue " & vbNewLine &
                        "FROM QMS_vwUserAccessLevel " & vbNewLine &
                        "WHERE " & vbNewLine &
                        "   ProgramID=@ProgramID " & vbNewLine &
                        "ORDER BY AccessValue "

                    .Parameters.Add("@ProgramID", SqlDbType.VarChar, 15).Value = strProgramID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        While .Read()
                            aRight(intPos, 0) = .Item("AccessRight")
                            aRight(intPos, 1) = .Item("AccessValue")
                            intPos += 1
                        End While
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
        End Sub

        Private Shared Function GetAccessValue(ByVal strAccessRight As String) As Integer
            Dim shtI As Integer
            Dim shtReturn As Integer = 0
            For shtI = 0 To aRight.GetUpperBound(0)
                If UCase(aRight(shtI, 0)) = UCase(strAccessRight) Then
                    shtReturn = aRight(shtI, 1)
                End If
            Next
            Return shtReturn
        End Function

        Protected Friend Shared Function CheckAccess(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                     ByVal strUserID As String, ByVal strProgramID As String, ByVal strModuleID As String, ByVal strAccessCode As String) As Boolean
            Dim shtRightValue As Integer = GetAccessValue(strAccessCode)
            Dim bolResult As Boolean = False
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intTotal As Integer = 0
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   AccessLevel " & vbNewLine &
                        "FROM QMS_vwUserListDtl A " & vbNewLine &
                        "INNER JOIN QMS_vwUserProgramMenu B ON " & vbNewLine &
                        "   A.ProgramID = B.ProgramID " & vbNewLine &
                        "   AND A.UserMenu = B.MenuID " & vbNewLine &
                        "INNER JOIN QMS_vwUserProgramMenuDtl C ON " & vbNewLine &
                        "   B.MenuID = C.MenuID " & vbNewLine &
                        "WHERE " & vbNewLine &
                        "   A.UserID=@UserID " & vbNewLine &
                        "   AND A.ProgramID=@ProgramID " & vbNewLine &
                        "   AND C.ModuleID=@ModuleID " & vbNewLine &
                        "ORDER BY AccessLevel DESC "

                    .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strUserID
                    .Parameters.Add("@ProgramID", SqlDbType.VarChar, 15).Value = strProgramID
                    .Parameters.Add("@ModuleID", SqlDbType.VarChar, 50).Value = strModuleID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolResult = CType(.Item("AccessLevel"), Integer) And shtRightValue
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolResult
        End Function

        Protected Friend Shared Function CheckAccess2(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                      ByVal strUserID As String, ByVal strProgramID As String, ByVal strModuleID As String, ByVal strAccessCode As String, ByVal intComLocDivSubDivID As Integer) As Boolean
            Dim shtRightValue As Short = GetAccessValue(strAccessCode)
            Dim bolResult As Boolean = False

            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intTotal As Integer = 0
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   AccessLevel " & vbNewLine &
                        "FROM QMS_vwUserListDtl A " & vbNewLine &
                        "INNER JOIN QMS_vwUserProgramMenu B ON " & vbNewLine &
                        "   A.ProgramID=B.ProgramID " & vbNewLine &
                        "   AND A.UserMenu=B.MenuID " & vbNewLine &
                        "INNER JOIN QMS_vwUserProgramMenuDtl C ON " & vbNewLine &
                        "   B.MenuID=C.MenuID " & vbNewLine &
                        "WHERE " & vbNewLine &
                        "   A.UserID=@UserID " & vbNewLine &
                        "   AND A.ComLocDivSubDivID = @ComLocDivSubDivID " & vbNewLine &
                        "   AND A.ProgramID=@ProgramID " & vbNewLine &
                        "   AND C.ModuleID=@ModuleID "

                    .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strUserID
                    .Parameters.Add("@ComLocDivSubDivID", SqlDbType.Int).Value = intComLocDivSubDivID
                    .Parameters.Add("@ProgramID", SqlDbType.VarChar, 15).Value = strProgramID
                    .Parameters.Add("@ModuleID", SqlDbType.VarChar, 50).Value = strModuleID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolResult = CType(.Item("AccessLevel"), Short) And shtRightValue
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolResult
        End Function

        Protected Friend Shared Function GetDelegatedFrom(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                          ByVal strUserID As String, ByVal dtmPeriod As DateTime) As String
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim strGetDelegatedUserID As String = ""
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 UserID " & vbNewLine &
                        "FROM QMS_sysDelegated " & vbNewLine &
                        "WHERE DelegatedUserID=@UserID " & vbNewLine &
                        "   AND @Period BETWEEN DateFrom AND DateTo "

                    .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strUserID
                    .Parameters.Add("@Period", SqlDbType.DateTime).Value = dtmPeriod
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        strGetDelegatedUserID = .Item("UserID")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return strGetDelegatedUserID
        End Function

        Protected Friend Shared Function GetDelegatedUserID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                            ByVal strUserID As String, ByVal dtmPeriod As DateTime, ByVal strLogBy As String) As String
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim strGetDelegatedUserID As String = ""
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 DelegatedUserID " & vbNewLine &
                        "FROM QMS_sysDelegated " & vbNewLine &
                        "WHERE " & vbNewLine &
                        "   UserID=@UserID " & vbNewLine &
                        "   AND @Period BETWEEN DateFrom AND DateTo " & vbNewLine &
                        "   AND DelegatedUserID = @LogBy "

                    .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strUserID
                    .Parameters.Add("@Period", SqlDbType.DateTime).Value = dtmPeriod
                    .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = strLogBy
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        strGetDelegatedUserID = .Item("DelegatedUserID")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return strGetDelegatedUserID
        End Function

        Protected Friend Shared Function IsValidDelegatedUserID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                ByVal strUserID As String, ByVal strDelegatedUserID As String, ByVal dtmPeriod As DateTime) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim bolValid As Boolean = False
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "IF EXISTS " & vbNewLine &
                        "   (SELECT UserID " & vbNewLine &
                        "   FROM QMS_sysDelegated " & vbNewLine &
                        "   WHERE " & vbNewLine &
                        "       UserID = @UserID " & vbNewLine &
                        "       AND DelegatedUserID = @DelegatedUserID " & vbNewLine &
                        "       AND @Period BETWEEN DateFrom AND DateTo) " & vbNewLine &
                        "SELECT CAST(1 AS BIT) " & vbNewLine &
                        "ELSE " & vbNewLine &
                        "   SELECT CAST(0 AS BIT) "

                    .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strUserID
                    .Parameters.Add("@DelegatedUserID", SqlDbType.VarChar).Value = strDelegatedUserID
                    .Parameters.Add("@Period", SqlDbType.DateTime).Value = dtmPeriod
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolValid = .Item(0)
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return bolValid
        End Function

        Protected Friend Shared Function GetUserIDByLegacyUser(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                               ByVal strLegacyUser As String) As String
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim strUserID As String = ""
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 UserID " & vbNewLine &
                        "FROM ABSNEW.dbo.sys_UserList " & vbNewLine &
                        "WHERE LegacyID = @LegacyID "

                    .Parameters.Add("@LegacyID", SqlDbType.VarChar, 20).Value = strLegacyUser
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        strUserID = .Item(0)
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return strUserID
        End Function

        Protected Friend Shared Function GetUserEmail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                      ByVal strUserID As String) As String
            Dim strEmail As String = ""
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT Email " & vbNewLine &
                        "FROM QMS_vwUserList " & vbNewLine &
                        "WHERE UserID = @UserID "

                    .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strUserID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        strEmail = .Item("Email")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return strEmail
        End Function

        Protected Friend Shared Function GetProgramList(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "SELECT ProgramID, ProgramName " & vbNewLine &
                    "FROM ABSNEW.dbo.sys_ProgramList " & vbNewLine &
                    "WHERE ProgramID = 'QMS' "
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub CopyProgramList(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "IF NOT EXISTS " & vbNewLine &
                    "   (SELECT ProgramID FROM ABSNEW.dbo.sys_ProgramList " & vbNewLine &
                    "   WHERE ProgramID LIKE 'CPS%') " & vbNewLine &
                    "INSERT INTO ABSNEW.dbo.sys_ProgramList " & vbNewLine &
                    "SELECT ProgramID, ProgramName " & vbNewLine &
                    "FROM ABSNEWNE.dbo.sysProgramList " & vbNewLine &
                    "WHERE ProgramID = 'QMS' "
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetModuleList(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "SELECT ProgramID, ModuleID, ModuleName " & vbNewLine &
                    "FROM ABSNEW.dbo.sys_ModuleList " & vbNewLine &
                    "WHERE ProgramID = 'QMS' "
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub CopyModuleList(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "IF NOT EXISTS " & vbNewLine &
                    "   (SELECT ProgramID FROM ABSNEW.dbo.sys_ModuleList " & vbNewLine &
                    "   WHERE ProgramID LIKE 'CPS%') " & vbNewLine &
                    "INSERT INTO ABSNEW.dbo.sys_ModuleList " & vbNewLine &
                    "SELECT ProgramID, ModuleID, ModuleName " & vbNewLine &
                    "FROM ABSNEWNE.dbo.sys_ModuleList " & vbNewLine &
                    "WHERE ProgramID = 'QMS' "
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetAccessLevel(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "SELECT ProgramID, AccessRight, AccessValue " & vbNewLine &
                    "FROM ABSNEW.dbo.sys_AccessLevel " & vbNewLine &
                    "WHERE ProgramID = 'QMS' "
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub CopyAccessLevel(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "IF NOT EXISTS " & vbNewLine &
                    "   (SELECT ProgramID FROM ABSNEW.dbo.sys_AccessLevel " & vbNewLine &
                    "   WHERE ProgramID LIKE 'CPS%') " & vbNewLine &
                    "INSERT INTO ABSNEW.dbo.sys_AccessLevel " & vbNewLine &
                    "SELECT ProgramID, AccessRight, AccessValue " & vbNewLine &
                    "FROM ABSNEWNE.dbo.sys_AccessLevel " & vbNewLine &
                    "WHERE ProgramID = 'QMS' "
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetProgramMenu(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "SELECT MenuID, MenuName, ProgramID " & vbNewLine &
                    "FROM ABSNEW.dbo.sys_ProgramMenu " & vbNewLine &
                    "WHERE ProgramID = 'QMS' "
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub CopyProgramMenu(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "IF NOT EXISTS " & vbNewLine &
                    "   (SELECT ProgramID FROM ABSNEW.dbo.sys_ProgramMenu " & vbNewLine &
                    "   WHERE ProgramID LIKE 'CPS%') " & vbNewLine &
                    "INSERT INTO ABSNEW.dbo.sys_ProgramMenu " & vbNewLine &
                    "SELECT MenuID, MenuName, ProgramID " & vbNewLine &
                    "FROM ABSNEWNE.dbo.sys_ProgramMenu " & vbNewLine &
                    "WHERE ProgramID = 'QMS' "
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetProgramMenuDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "SELECT MenuID, ModuleID, AccessLevel " & vbNewLine &
                    "FROM ABSNEW.dbo.sys_ProgramMenuDtl " & vbNewLine &
                    "WHERE MenuID = 'QMS' "
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub CopyProgramMenuDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "IF NOT EXISTS " & vbNewLine &
                    "   (SELECT MenuID FROM ABSNEW.dbo.sys_ProgramMenuDtl " & vbNewLine &
                    "   WHERE MenuID LIKE 'CPS%') " & vbNewLine &
                    "INSERT INTO ABSNEW.dbo.sys_ProgramMenuDtl " & vbNewLine &
                    "SELECT MenuID, ModuleID, AccessLevel " & vbNewLine &
                    "FROM ABSNEWNE.dbo.sys_ProgramMenuDtl " & vbNewLine &
                    "WHERE MenuID = 'QMS' "
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetUserListDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                           ByVal strUserID As String, ByVal strDBName As String) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                If UCase(Left(strDBName, 3)) <> "KPA" Then
                    .CommandText =
                        "SELECT * " & vbNewLine &
                        "FROM ABSNEWNE.dbo.Sys_UserListDtl " & vbNewLine &
                        "WHERE UserID = @UserID AND ProgramID = 'QMS' "
                Else
                    .CommandText =
                        "SELECT * " & vbNewLine &
                        "FROM KPA_ABSNEWNE.dbo.Sys_UserListDtl " & vbNewLine &
                        "WHERE UserID = @UserID AND ProgramID = 'QMS' "
                End If

                .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strUserID
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Function GetUserProgramMenu(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                            ByVal strUserID As String, ByVal strProgramID As String) As String
            Dim strProgramMenu As String = ""
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT MAX(UserMenu) AS UserMenu " & vbNewLine &
                        "FROM ABSNEWNE.dbo.sys_UserListDtl " & vbNewLine &
                        "WHERE " & vbNewLine &
                        "   UserID = @UserID " & vbNewLine &
                        "   AND ProgramID = @ProgramID " & vbNewLine &
                        "GROUP BY UserID, ProgramID "

                    .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strUserID
                    .Parameters.Add("@ProgramID", SqlDbType.VarChar, 20).Value = strProgramID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        strProgramMenu = .Item(0)
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return strProgramMenu
        End Function

        Protected Friend Shared Sub CopyUserListDetail(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                       ByVal strUserID As String, ByVal strSubDivID As String, ByVal strComLocDivID As String, ByVal strProgramID As String, ByVal strUserMenu As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "IF NOT EXISTS " & vbNewLine &
                    "   (SELECT UserID " & vbNewLine &
                    "   FROM ABSNEW.dbo.Sys_UserListDtl " & vbNewLine &
                    "   WHERE " & vbNewLine &
                    "       UserID = @UserID " & vbNewLine &
                    "       AND Sub_Div_Id = @SubDivID " & vbNewLine &
                    "       AND Com_Loc_Div_Id = @ComLocDivID " & vbNewLine &
                    "       AND ProgramID = @ProgramID) " & vbNewLine &
                    "INSERT INTO ABSNEW.dbo.Sys_UserListDtl " & vbNewLine &
                    "   (UserID, Sub_Div_Id, Com_Loc_Div_Id, ProgramID, UserMenu) " & vbNewLine &
                    "VALUES " & vbNewLine &
                    "   (@UserID, @SubDivID, @ComLocDivID, @ProgramID, @UserMenu) "

                .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strUserID
                .Parameters.Add("@SubDivID", SqlDbType.VarChar, 50).Value = strSubDivID
                .Parameters.Add("@ComLocDivID", SqlDbType.VarChar, 50).Value = strComLocDivID
                .Parameters.Add("@ProgramID", SqlDbType.VarChar, 20).Value = strProgramID
                .Parameters.Add("@UserMenu", SqlDbType.VarChar, 50).Value = strUserMenu
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub UpdateLegacyID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal strNewUserID As String, ByVal strLegacyID As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "UPDATE ABSNEWNE.dbo.Sys_UserList " & vbNewLine &
                    "SET LegacyID = @UserID " & vbNewLine &
                    "WHERE UserID = @LegacyID "
                .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strNewUserID
                .Parameters.Add("@LegacyID", SqlDbType.VarChar, 20).Value = strLegacyID
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetHeadID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal strUserID As String) As String
            Dim strHeadID As String = ""
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                    "SELECT HeadID " & vbNewLine &
                    "FROM QMS_vwUserList " & vbNewLine &
                    "WHERE UserID = @UserID "
                    .Parameters.Add("@UserID", SqlDbType.VarChar).Value = strUserID
                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        strHeadID = .Item("HeadID")
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return strHeadID
        End Function

        Protected Friend Shared Function GetUserEmailList(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                          ByVal strUserIDList As String) As String
            Dim sqlcmdExecute As New SqlCommand
            Dim dtEmail As New DataTable
            Dim strEmailList As String = ""
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "SELECT Email " & vbNewLine &
                    "FROM QMS_vwUserList " & vbNewLine &
                    "WHERE UserID IN (" & strUserIDList & ") " & vbNewLine &
                    "GROUP BY Email "
            End With

            dtEmail = SQL.QueryDataTable(sqlcmdExecute, sqlTrans)

            If dtEmail.Rows.Count > 0 Then
                For Each dr As DataRow In dtEmail.Rows
                    strEmailList += dr("Email") & ","
                Next
                strEmailList = Left(strEmailList, Len(strEmailList) - 1)
            End If

            Return strEmailList
        End Function

    End Class

End Namespace
