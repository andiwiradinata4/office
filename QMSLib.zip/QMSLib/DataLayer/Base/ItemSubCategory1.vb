﻿Namespace DL

    Friend Class ItemSubCategory1

        Protected Friend Shared Function ListData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                  Optional ByVal intCategoryID As Integer = -1) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "SELECT " &
                    "   A.SubCategory1ID, A.SubCategory1Code, A.SubCategory1Name, " &
                    "   A.ClassID, B.ClassCode, B.ClassName, " &
                    "   A.GroupID, C.GroupCode, C.GroupName, " &
                    "   A.CategoryID, D.CategoryCode, D.CategoryName, " &
                    "   A.Status,CASE A.Status WHEN 0 THEN 'ACTIVE' WHEN 1 THEN 'IN-ACTIVE' END AS StatusInfo," &
                    "   A.LogInc, A.LogBy, A.LogDate " &
                    "FROM QMS_vwItemSubCategory1 A " &
                    "INNER JOIN QMS_vwItemClass B ON " &
                    "   A.ClassID=B.ClassID " &
                    "INNER JOIN QMS_vwItemGroup C ON " &
                    "   A.GroupID=C.GroupID " &
                    "INNER JOIN QMS_vwItemCategory D ON " &
                    "   A.CategoryID=D.CategoryID "

                If intCategoryID <> -1 Then
                    .CommandText += "WHERE A.CategoryID = @CategoryID "
                    .Parameters.Add("@CategoryID", SqlDbType.Int).Value = intCategoryID
                End If

                .CommandText += "ORDER BY A.SubCategory1Code, B.ClassCode, C.GroupCode, D.CategoryCode "
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

    End Class

End Namespace