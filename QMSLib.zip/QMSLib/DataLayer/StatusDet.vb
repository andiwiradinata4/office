Namespace DL
    Friend Class StatusDet

        Protected Friend Shared Function ListDataByIDStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                            ByVal bytIDStatus As VO.Status.Values) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "SELECT " & vbNewLine &
                   "    B.ID, A.ID AS ModuleID, A.Description AS ModuleName " & vbNewLine &
                   "FROM QMS_mstModules A " & vbNewLine &
                   "INNER JOIN QMS_mstStatusDet B ON " & vbNewLine &
                   "    A.ID=B.ModuleID" & vbNewLine &
                   "WHERE  " & vbNewLine &
                   "    B.IDStatus=@IDStatus" & vbNewLine

                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = bytIDStatus
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Function ListDataByModuleID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                            ByVal bytModuleID As VO.Modules.Values) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                   "SELECT " & vbNewLine &
                   "    B.ID, A.ID AS IDStatus, A.Description AS StatusName " & vbNewLine &
                   "FROM QMS_mstStatus A " & vbNewLine &
                   "INNER JOIN QMS_mstStatusDet B ON " & vbNewLine &
                   "    A.ID=B.IDStatus" & vbNewLine &
                   "WHERE  " & vbNewLine &
                   "    B.ModuleID=@ModuleID" & vbNewLine

                .Parameters.Add("@ModuleID", SqlDbType.TinyInt).Value = bytModuleID
            End With
            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)
        End Function

        Protected Friend Shared Sub SaveData(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                             ByVal clsData As VO.StatusDet)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "INSERT INTO QMS_mstStatusDet " & vbNewLine &
                    "    (ID, ModuleID, IDStatus)   " & vbNewLine &
                    "VALUES " & vbNewLine &
                    "    (@ID, @ModuleID, @IDStatus)  " & vbNewLine

                .Parameters.Add("@ID", SqlDbType.Int).Value = clsData.ID
                .Parameters.Add("@ModuleID", SqlDbType.TinyInt).Value = clsData.ModuleID
                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = clsData.IDStatus
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub DeleteDataByIDStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                         ByVal bytIDStatus As Byte)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "DELETE FROM QMS_mstStatusDet " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "   IDStatus=@IDStatus " & vbNewLine

                .Parameters.Add("@IDStatus", SqlDbType.TinyInt).Value = bytIDStatus
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub DeleteDataByMobuleID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                         ByVal bytModuleID As Byte)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .Connection = sqlCon
                .Transaction = sqlTrans
                .CommandType = CommandType.Text
                .CommandText =
                    "DELETE FROM QMS_mstStatusDet " & vbNewLine &
                    "WHERE " & vbNewLine &
                    "   ModuleID=@ModuleID " & vbNewLine

                .Parameters.Add("@ModuleID", SqlDbType.TinyInt).Value = bytModuleID
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetMaxID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing
            Dim intReturn As Integer = 0
            Try
                With sqlcmdExecute
                    .Connection = sqlCon
                    .Transaction = sqlTrans
                    .CommandType = CommandType.Text
                    .CommandText =
                        "SELECT TOP 1 " & vbNewLine &
                        "   ID=ISNULL(MAX(ID),0) " & vbNewLine &
                        "FROM QMS_mstStatusDet " & vbNewLine

                End With
                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intReturn = .Item("ID") + 1
                    End If
                End With
            Catch ex As Exception
                Throw ex
            Finally
                If sqlrdData IsNot Nothing Then sqlrdData.Close()
            End Try
            Return intReturn
        End Function

    End Class

End Namespace

