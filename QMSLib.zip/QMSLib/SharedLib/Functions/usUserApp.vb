﻿Namespace UI

    Public Class usUserApp
        Public Shared UserID, UserCompanyID As String
        Public Shared DelegateUserID As String
        Public Shared AccessList As DataTable
        Public Shared ProgramID, ProgramName As String
        Public Shared CompanyID, CompanyName As String
        Public Shared LocationID, LocationName As String
        Public Shared DivisionID, DivisionName As String
        Public Shared SubDivisionID, SubDivisionName As String
        Public Shared SubCategory2ID As String
        Public Shared ComLocDivSubDivID As Integer
        Public Shared UserEmail As String
        Public Shared ProgramType As Integer
    End Class

End Namespace
