﻿Imports System.Windows.Forms

Public Class usFormRemarks

#Region "Property Handle"

    Private strTitle As String = "Fill Internal Remarks"
    Private strInfo As String = "Internal Remarks"
    Private strLabel As String = "Internal Remarks"
    Private strValue As String = ""
    Private bolIsSave As Boolean = False
    Private Const cSave = 0, cClose = 1

    Public WriteOnly Property pubTitle As String
        Set(value As String)
            strTitle = value
        End Set
    End Property

    Public WriteOnly Property pubInfo As String
        Set(value As String)
            strLabel = strInfo
        End Set
    End Property

    Public WriteOnly Property pubLabel As String
        Set(value As String)
            strLabel = value
        End Set
    End Property

    Public ReadOnly Property pubValue As String
        Get
            Return strValue
        End Get
    End Property

    Public ReadOnly Property pubIsSave As Boolean
        Get
            Return bolIsSave
        End Get
    End Property

#End Region

#Region "Function Handle"

    Private Sub prvSetIcon()
        UI.usForm.SetToolBar(Me, ToolBar, "0,Save,1,Close")
    End Sub

    Private Sub prvSave()
        If txtValue.Text.Trim = "" Then
            UI.usForm.frmMessageBox(strLabel & " not allow blank")
            txtValue.Focus()
            Exit Sub
        End If

        If Not UI.usForm.frmAskQuestion("Save this data?") Then Exit Sub

        strValue = txtValue.Text.Trim()
        bolIsSave = True
        Me.Close()
    End Sub

#End Region

#Region "Form Handle"

    Private Sub usFormRemarks_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            If UI.usForm.frmAskQuestion("Close this form?") Then Me.Close()
        End If
    End Sub

    Private Sub usFormRemarks_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Text = strTitle
        lblInfo.Text += strInfo
        lblLabel.Text = strLabel
        prvSetIcon()
    End Sub

    Private Sub ToolBar_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        If e.Button.Text = "Close" Then
            Me.Close()
        ElseIf e.Button.Text = "Save" Then
            prvSave()
        End If
    End Sub

#End Region

End Class