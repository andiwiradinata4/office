﻿Imports System
Imports System.Threading
Imports System.Windows.Forms

Public Class usComboBox : Inherits ComboBox

    Public Sub New()
        Me.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
    End Sub

End Class
