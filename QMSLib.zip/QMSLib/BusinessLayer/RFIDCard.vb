Namespace BL
    Friend Class RFIDCard

#Region "Main"

        Protected Friend Shared Function ListData(Optional ByVal intIDStatus As VO.Status.Values = VO.Status.Values.All) As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.RFIDCard.ListData(sqlCon, Nothing, intIDStatus)
            End Using
        End Function

        Protected Friend Shared Function GetNewID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                  ByVal strCompanyID As String, ByVal strLocationID As String)
            Dim strNewID As String = DL.CS.GetComLocInitialByLocationID(sqlCon, sqlTrans, strCompanyID, strLocationID) & "-" & Format(Now, "yyyy")
            strNewID &= Format(DL.RFIDCard.GetMaxID(sqlCon, sqlTrans, strNewID), "00000")
            Return strNewID
        End Function

        Protected Friend Shared Function SaveData(ByVal bolNew As Boolean, ByVal clsData As VO.RFIDCard) As String
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                Try
                    If bolNew Then
                        clsData.ID = GetNewID(sqlCon, sqlTrans, clsData.CompanyID, clsData.LocationID)
                        If DL.RFIDCard.IDExists(sqlCon, sqlTrans, clsData.ID) Then
                            Err.Raise(515, "", "Cannot Save. ID already exist")
                        End If
                    End If

                    If DL.RFIDCard.RFIDExists(sqlCon, sqlTrans, clsData.RFID, clsData.ID) Then
                        Err.Raise(515, "", "Cannot Save. RFID already exist")
                    End If

                    DL.RFIDCard.SaveData(sqlCon, sqlTrans, bolNew, clsData)
                    Dim strStatus As String = IIf(bolNew, "NEW", "EDIT")
                    Dim clsDetail As VO.RFIDCard = DL.RFIDCard.GetDetail(sqlCon, sqlTrans, clsData.ID)
                    If clsDetail.IDStatus = VO.Status.Values.InActive And clsData.IDStatus = VO.Status.Values.Active Then strStatus = "ACTIVE"

                    '# Save data Status
                    BL.RFIDCard.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, strStatus, clsData.LogBy, clsData.Remarks)

                    sqlTrans.Commit()
                Catch ex As Exception
                    sqlTrans.Rollback()
                    Throw ex
                End Try
            End Using
            Return clsData.ID
        End Function

        Protected Friend Shared Function GetDetail(ByVal strID As String) As VO.RFIDCard
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.RFIDCard.GetDetail(sqlCon, Nothing, strID)
            End Using
        End Function

        Protected Friend Shared Sub DeleteData(ByVal clsData As VO.RFIDCard)
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                Try
                    If DL.RFIDCard.IsInActive(sqlCon, sqlTrans, clsData.ID) Then
                        Err.Raise(515, "", "Cannot Delete. Data is not active")
                    End If

                    DL.RFIDCard.DeleteData(sqlCon, sqlTrans, clsData)

                    '#Save data Status
                    BL.RFIDCard.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, "IN-ACTIVE", clsData.LogBy, clsData.Remarks)

                    sqlTrans.Commit()
                Catch ex As Exception
                    sqlTrans.Rollback()
                    Throw ex
                End Try
            End Using
        End Sub

        Protected Friend Shared Sub DeleteData(ByVal clsDataAll() As VO.RFIDCard)
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                Try
                    For Each clsData As VO.RFIDCard In clsDataAll
                        If DL.RFIDCard.IsInActive(sqlCon, sqlTrans, clsData.ID) Then
                            Err.Raise(515, "", "Cannot Delete. Data is not active")
                        End If

                        DL.RFIDCard.DeleteData(sqlCon, sqlTrans, clsData)

                        '#Save data Status
                        BL.RFIDCard.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, "IN-ACTIVE", clsData.LogBy, clsData.Remarks)
                    Next

                    sqlTrans.Commit()
                Catch ex As Exception
                    sqlTrans.Rollback()
                    Throw ex
                End Try
            End Using
        End Sub

        Protected Friend Shared Function RFIDExists(ByVal strRFID As String) As VO.RFIDCard
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.RFIDCard.RFIDExists(sqlCon, Nothing, strRFID)
            End Using
        End Function

#End Region

#Region "Status"

        Protected Friend Shared Function ListDataStatus(ByVal strRFIDCardID As String) As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.RFIDCard.ListDataStatus(sqlCon, Nothing, strRFIDCardID)
            End Using
        End Function

        Protected Friend Shared Sub SaveDataStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal strRFIDCardID As String, ByVal strStatus As String,
                                                   ByVal strStatusBy As String, ByVal strRemarks As String)
            Dim clsData As New VO.RFIDCardStatus
            clsData.ID = strRFIDCardID & "-" & Format(DL.RFIDCard.GetMaxIDStatus(sqlCon, sqlTrans, strRFIDCardID), "000")
            clsData.RFIDCardID = strRFIDCardID
            clsData.Status = strStatus
            clsData.StatusBy = strStatusBy
            clsData.StatusDate = Now
            clsData.Remarks = strRemarks
            DL.RFIDCard.SaveDataStatus(sqlCon, sqlTrans, clsData)
        End Sub

#End Region

    End Class

End Namespace

