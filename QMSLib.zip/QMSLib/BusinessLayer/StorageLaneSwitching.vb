Namespace BL
    Friend Class StorageLaneSwitching

#Region "Main"

        Protected Friend Shared Function ListData(ByVal strCompanyID As String, ByVal strLocationID As String, ByVal dtmDateFrom As DateTime, ByVal dtmDateTo As DateTime) As DataTable
            dtmDateTo = dtmDateTo.AddHours(23).AddMinutes(59).AddSeconds(59)
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.StorageLaneSwitching.ListData(sqlCon, Nothing, strCompanyID, strLocationID, dtmDateFrom, dtmDateTo)
            End Using
        End Function

        Private Shared Function GetNewID(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                         ByVal dtmCreatedDate As DateTime, ByVal strCompanyID As String, ByVal strLocationID As String) As String
            Dim strNewID As String = "SL" & Format(dtmCreatedDate, "yyMMdd") & "-" & DL.CS.GetComLocInitialByLocationID(sqlCon, sqlTrans, strCompanyID, strLocationID)
            strNewID = strNewID & "-" & Format(DL.StorageLaneSwitching.GetMaxID(sqlCon, sqlTrans, strNewID), "000")

            If DL.StorageLaneSwitching.DataExists(sqlCon, sqlTrans, strNewID) Then
                Err.Raise(515, "", "Cannot Save. ID already exist")
            End If
            Return strNewID
        End Function

        Protected Friend Shared Function SaveData(ByVal bolNew As Boolean, ByVal clsData As VO.StorageLaneSwitching, ByVal clsDataDet() As VO.StorageLaneSwitchingDet) As String
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                Try
                    If bolNew Then
                        '# Get new ID
                        clsData.ID = GetNewID(sqlCon, sqlTrans, clsData.CreatedDate, clsData.CompanyID, clsData.LocationID)
                    Else
                        If DL.StorageLaneSwitching.IsDeleted(sqlCon, sqlTrans, clsData.ID) Then
                            Err.Raise(515, "", "Cannot Save. Data already deleted")
                        End If
                        DL.StorageLaneSwitching.DeleteDataDetail(sqlCon, sqlTrans, clsData.ID)
                    End If

                    DL.StorageLaneSwitching.SaveData(sqlCon, sqlTrans, bolNew, clsData)

                    '# Save Data Detail
                    Dim intCount As Integer = 1
                    For Each clsItem As VO.StorageLaneSwitchingDet In clsDataDet
                        clsItem.ID = clsData.ID & "-" & Format(intCount, "000")
                        clsItem.StorageLaneSwitchingID = clsData.ID
                        DL.StorageLaneSwitching.SaveDataDetail(sqlCon, sqlTrans, clsItem)
                        intCount += 1
                    Next

                    '# Save Data Status
                    BL.StorageLaneSwitching.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, IIf(bolNew, "NEW", "EDIT"), clsData.LogBy, clsData.Remarks)

                    sqlTrans.Commit()
                Catch ex As Exception
                    sqlTrans.Rollback()
                    Throw ex
                End Try
            End Using
            Return clsData.ID
        End Function

        Protected Friend Shared Function GetDetail(ByVal strID As String) As VO.StorageLaneSwitching
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.StorageLaneSwitching.GetDetail(sqlCon, Nothing, strID)
            End Using
        End Function

        Protected Friend Shared Sub DeleteData(ByVal clsData As VO.StorageLaneSwitching)
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                Try
                    If DL.StorageLaneSwitching.IsDeleted(sqlCon, sqlTrans, clsData.ID) Then
                        Err.Raise(515, "", "Cannot tSave. Data already deleted")
                    End If

                    DL.StorageLaneSwitching.DeleteData(sqlCon, sqlTrans, clsData)

                    '# Save data Status
                    BL.StorageLaneSwitching.SaveDataStatus(sqlCon, sqlTrans, clsData.ID, "DELETE", clsData.LogBy, clsData.Remarks)

                    sqlTrans.Commit()
                Catch ex As Exception
                    sqlTrans.Rollback()
                    Throw ex
                End Try
            End Using
        End Sub

#End Region

#Region "Detail"

        Protected Friend Shared Function ListDataDetail(ByVal strStorageLaneSwitchingID As String) As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.StorageLaneSwitching.ListDataDetail(sqlCon, Nothing, strStorageLaneSwitchingID)
            End Using
        End Function

#End Region

#Region "Status"

        Protected Friend Shared Function ListDataStatus(ByVal strStorageLaneSwitchingID As String) As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.StorageLaneSwitching.ListDataStatus(sqlCon, Nothing, strStorageLaneSwitchingID)
            End Using
        End Function

        Protected Friend Shared Sub SaveDataStatus(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                   ByVal strStorageLaneSwitchingID As String, ByVal strStatus As String, ByVal strStatusBy As String,
                                                   ByVal strRemarks As String)
            Dim clsData As New VO.StorageLaneSwitchingStatus With {
                .ID = strStorageLaneSwitchingID & "-" & Format(DL.StorageLaneSwitching.GetMaxIDStatus(sqlCon, sqlTrans, strStorageLaneSwitchingID), "000"),
                .StorageLaneSwitchingID = strStorageLaneSwitchingID,
                .Status = strStatus,
                .StatusBy = strStatusBy,
                .StatusDate = Now,
                .Remarks = strRemarks
            }
            DL.StorageLaneSwitching.SaveDataStatus(sqlCon, sqlTrans, clsData)
        End Sub

#End Region

    End Class

End Namespace

