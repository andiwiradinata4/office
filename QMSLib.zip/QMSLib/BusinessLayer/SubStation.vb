Namespace BL
    Public Class SubStation

        Protected Friend Shared Function ListData(Optional ByVal strCompanyID As String = "", Optional ByVal strLocationID As String = "", _
                                                  Optional ByVal intStationID As Integer = 0, Optional ByVal enumIsLinkedTank As VO.SubStation.FilterIsLinkedStorage = VO.SubStation.FilterIsLinkedStorage.All, _
                                                  Optional ByVal intComLocDivSubDivID As Integer = 0, Optional ByVal strProgramID As String = "", Optional ByVal strStorageGroupID As String = "", _
                                                  Optional ByVal strStorageID As String = "") As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.SubStation.ListData(sqlCon, Nothing, strCompanyID, strLocationID, intStationID, enumIsLinkedTank, intComLocDivSubDivID, strProgramID, strStorageGroupID, strStorageID)
            End Using
        End Function

        Protected Friend Shared Function SaveData(ByVal bolNew As Boolean, ByVal clsData As VO.SubStation) As String
            BL.Server.ServerDefault()
            Try
                Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                    Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                    Try
                        If bolNew Then
                            clsData.ID = DL.SubStation.GetMaxID(sqlCon, sqlTrans)
                            If DL.SubStation.IsIDExists(sqlCon, sqlTrans, clsData.ID) Then
                                Err.Raise(515, "", "Cannot Save. ID already exist")
                            End If
                        End If
                        If DL.SubStation.IsFirstSubStation(sqlCon, sqlTrans, clsData.StationID) Then clsData.IsDefault = True
                        If clsData.IsDefault Then DL.SubStation.SetIsDefault(sqlCon, sqlTrans, clsData.CompanyID, clsData.LocationID, clsData.StationID, False)

                        DL.SubStation.SaveData(sqlCon, sqlTrans, bolNew, clsData)

                        sqlTrans.Commit()
                    Catch ex As Exception
                        sqlTrans.Rollback()
                        Throw ex
                    End Try
                End Using

                If Not BL.Server.IsServerTesting Then
                    Dim dtDB As DataTable = BL.Server.ServerList
                    For Each drDB As DataRow In dtDB.Rows
                        BL.Server.SetServer(drDB.Item("Server"), drDB.Item("DBName"), drDB.Item("UserID"), drDB.Item("UserPassword"))
                        Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                            Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                            Try
                                If clsData.IsDefault Then DL.SubStation.SetIsDefault(sqlCon, sqlTrans, clsData.CompanyID, clsData.LocationID, clsData.StationID, False)
                                DL.SubStation.SaveData(sqlCon, sqlTrans, bolNew, clsData)

                                sqlTrans.Commit()
                            Catch ex As Exception
                                sqlTrans.Rollback()
                                Throw ex
                            End Try
                        End Using
                    Next
                End If
            Catch ex As Exception
                Throw ex
            End Try
            Return clsData.Description
        End Function

        Public Shared Function GetInitalID(ByVal strServer As String, ByVal strCompanyID As String, ByVal strLocationID As String, ByVal strComputerName As String) As String
            If strServer.Trim = "" Then
                Err.Raise(515, "", "Server not allow blank")
            ElseIf strCompanyID.Trim = "" Then
                Err.Raise(515, "", "Company ID not allow blank")
            ElseIf strLocationID.Trim = "" Then
                Err.Raise(515, "", "Location ID not allow blank")
            End If
            BL.Server.SetServerOtherOpsys(strServer)
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.SubStation.GetInitalID(sqlCon, Nothing, strCompanyID, strLocationID, strComputerName)
            End Using
        End Function

        Protected Friend Shared Function GetDetail(ByVal strCompanyID As String, ByVal strLocationID As String, ByVal strComputerName As String) As VO.SubStation
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.SubStation.GetDetail(sqlCon, Nothing, strCompanyID, strLocationID, strComputerName)
            End Using
        End Function

        Protected Friend Shared Function GetDetail(ByVal intID As Integer) As VO.SubStation
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.SubStation.GetDetail(sqlCon, Nothing, intID)
            End Using
        End Function

        Protected Friend Shared Sub DeleteData(ByVal clsData As VO.SubStation)
            BL.Server.ServerDefault()
            Try
                Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                    If DL.SubStation.IsInActive(sqlCon, Nothing, clsData.ID) Then
                        Err.Raise(515, "", "Cannot Delete. Data is Not Active")
                    End If

                    DL.SubStation.DeleteData(sqlCon, Nothing, clsData)
                End Using

                If Not BL.Server.IsServerTesting Then
                    Dim dtDB As DataTable = BL.Server.ServerList
                    For Each drDB As DataRow In dtDB.Rows
                        BL.Server.SetServer(drDB.Item("Server"), drDB.Item("DBName"), drDB.Item("UserID"), drDB.Item("UserPassword"))
                        Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                            DL.SubStation.DeleteData(sqlCon, Nothing, clsData)
                        End Using
                    Next
                End If
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function SaveConfigurationRFIDReader(ByVal clsData As VO.SubStation) As Boolean
            Dim bolReturn As Boolean = False
            BL.Server.ServerDefault()
            Try
                Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                    DL.SubStation.SaveConfigurationRFIDReader(sqlCon, Nothing, clsData)
                End Using

                If Not BL.Server.IsServerTesting Then
                    Dim dtDB As New DataTable
                    dtDB = BL.Server.ServerList
                    For Each drDB As DataRow In dtDB.Rows
                        BL.Server.SetServer(drDB.Item("Server"), drDB.Item("DBName"), drDB.Item("UserID"), drDB.Item("UserPassword"))
                        Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                            DL.SubStation.SaveConfigurationRFIDReader(sqlCon, Nothing, clsData)
                        End Using
                    Next
                End If
                bolReturn = True
            Catch ex As Exception
                Throw ex
            End Try
            Return bolReturn
        End Function

    End Class
End Namespace

