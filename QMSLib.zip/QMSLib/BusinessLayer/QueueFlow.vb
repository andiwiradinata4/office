Namespace BL
    Friend Class QueueFlow

#Region "Header"

        Protected Friend Shared Function ListData() As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.QueueFlow.ListData(sqlCon, Nothing)
            End Using
        End Function

        Protected Friend Shared Function ListDataType() As DataTable
            Dim dtReturn As New DataTable
            dtReturn.Columns.Add("ID", GetType(Integer))
            dtReturn.Columns.Add("Description", GetType(String))
            Dim drNew As DataRow
            For i As Integer = 1 To 2
                drNew = dtReturn.NewRow
                drNew.BeginEdit()
                drNew.Item("ID") = i
                drNew.Item("Description") = IIf(i = 1, "INCOMING", "OUTGOING")
                drNew.EndEdit()
                dtReturn.Rows.Add(drNew)
            Next
            dtReturn.AcceptChanges()
            Return dtReturn
        End Function

        Protected Friend Shared Function SaveData(ByVal bolNew As Boolean, ByVal clsData As VO.QueueFlow, _
                                                  ByVal clsDataStation() As VO.QueueFlowStation, ByVal clsDataItem() As VO.QueueFlowItem) As String
            BL.Server.ServerDefault()
            Dim strIsDefaultExistsID As String = ""
            Try
                Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                    Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                    Try
                        If bolNew Then
                            clsData.ID = Format(DL.QueueFlow.GetMaxID(sqlCon, sqlTrans), "00000")
                            If DL.QueueFlow.IsIDExists(sqlCon, sqlTrans, clsData.ID) Then
                                Err.Raise(515, "", "Cannot Save. ID already exist")
                            End If
                        End If

                        If clsData.IsDefault Then
                            strIsDefaultExistsID = DL.QueueFlow.IsDefaultExists(sqlCon, sqlTrans, clsData.ID, clsData.Type)
                        End If

                        If DL.QueueFlow.IsNameExists(sqlCon, sqlTrans, clsData.ID, clsData.Name) Then
                            Err.Raise(515, "", "Cannot Save. Name " & clsData.Name & " already exist")
                        ElseIf strIsDefaultExistsID <> "" Then
                            Err.Raise(515, "", "Cannot Save with IsDefault. Because 1 type just 1 IsDefault, previous ID already set IsDefault is " & strIsDefaultExistsID)
                        ElseIf clsData.IsDefault = False Then
                            For Each clsItem In clsDataItem
                                Dim strItemExistsID As String = ""
                                strItemExistsID = DL.QueueFlow.IsItemExists(sqlCon, sqlTrans, clsData.ID, clsItem.ItemCode, clsData.Type)
                                If strItemExistsID <> "" Then
                                    Err.Raise(515, "", "Cannot Save. Item code " & clsItem.ItemCode & " already exists in ID " & strItemExistsID)
                                End If
                            Next
                        End If

                        If Not bolNew Then
                            DL.QueueFlow.DeleteDataStation(sqlCon, sqlTrans, clsData.ID)
                            DL.QueueFlow.DeleteDataItem(sqlCon, sqlTrans, clsData.ID)
                        End If

                        DL.QueueFlow.SaveData(sqlCon, sqlTrans, bolNew, clsData)

                        For i As Integer = 0 To clsDataStation.Length - 1
                            clsDataStation(i).ID = clsData.ID & "-" & Format(i + 1, "000")
                            clsDataStation(i).QueueFlowID = clsData.ID
                            DL.QueueFlow.SaveDataStation(sqlCon, sqlTrans, clsDataStation(i))
                        Next

                        For i As Integer = 0 To clsDataItem.Length - 1
                            clsDataItem(i).ID = clsData.ID & "-" & Format(i + 1, "000")
                            clsDataItem(i).QueueFlowID = clsData.ID
                            DL.QueueFlow.SaveDataItem(sqlCon, sqlTrans, clsDataItem(i))
                        Next

                        sqlTrans.Commit()
                    Catch ex As Exception
                        sqlTrans.Rollback()
                        Throw ex
                    End Try
                End Using


                If Not BL.Server.IsServerTesting Then
                    Dim dtDB As New DataTable
                    dtDB = BL.Server.ServerList
                    For Each drDB As DataRow In dtDB.Rows
                        BL.Server.SetServer(drDB.Item("Server"), drDB.Item("DBName"), drDB.Item("UserID"), drDB.Item("UserPassword"))
                        Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                            Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                            Try
                                If Not bolNew Then
                                    DL.QueueFlow.DeleteDataStation(sqlCon, sqlTrans, clsData.ID)
                                    DL.QueueFlow.DeleteDataItem(sqlCon, sqlTrans, clsData.ID)
                                End If

                                DL.QueueFlow.SaveData(sqlCon, sqlTrans, bolNew, clsData)

                                For i As Integer = 0 To clsDataStation.Length - 1
                                    DL.QueueFlow.SaveDataStation(sqlCon, sqlTrans, clsDataStation(i))
                                Next

                                For Each clsItem In clsDataItem
                                    DL.QueueFlow.SaveDataItem(sqlCon, sqlTrans, clsItem)
                                Next
                                sqlTrans.Commit()
                            Catch ex As Exception
                                sqlTrans.Rollback()
                                Throw ex
                            End Try
                        End Using
                    Next
                End If
            Catch ex As Exception
                Throw ex
            End Try
            Return clsData.Name
        End Function

        Protected Friend Shared Function GetDetail(ByVal strID As String) As VO.QueueFlow
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.QueueFlow.GetDetail(sqlCon, Nothing, strID)
            End Using
        End Function

        Protected Friend Shared Sub DeleteData(ByVal clsData As VO.QueueFlow)
            BL.Server.ServerDefault()
            Try
                Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                    If DL.QueueFlow.IsInActive(sqlCon, Nothing, clsData.ID) Then
                        Err.Raise(515, "", "Cannot Delete. Data is Not Active")
                    End If

                    DL.QueueFlow.DeleteData(sqlCon, Nothing, clsData)
                End Using

                If Not BL.Server.IsServerTesting Then
                    Dim dtDB As New DataTable
                    dtDB = BL.Server.ServerList
                    For Each drDB As DataRow In dtDB.Rows
                        BL.Server.SetServer(drDB.Item("Server"), drDB.Item("DBName"), drDB.Item("UserID"), drDB.Item("UserPassword"))
                        Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                            DL.QueueFlow.DeleteData(sqlCon, Nothing, clsData)
                        End Using
                    Next
                End If
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Function GetDetailForQueue(ByVal bytQueueType As Byte, ByVal strItemCode As String) As VO.QueueFlow
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.QueueFlow.GetDetailForQueue(sqlCon, Nothing, bytQueueType, strItemCode)
            End Using
        End Function

#End Region

#Region "Station"

        Protected Friend Shared Function ListDataStation(ByVal strQueueFlowID As String) As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.QueueFlow.ListDataStation(sqlCon, Nothing, strQueueFlowID)
            End Using
        End Function

        Protected Friend Shared Function ListDataStationDefault(ByVal strQueueFlowID As String, ByVal strCompanyID As String, ByVal strLocationID As String, _
                                                                Optional ByVal intComLocDivSubDivID As Integer = 0, Optional ByVal strProgramID As String = "", _
                                                                Optional ByVal strStorageGroupID As String = "", _
                                                                Optional ByVal strStorageID As String = "") As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.QueueFlow.ListDataStationDefault(sqlCon, Nothing, strQueueFlowID, strCompanyID, strLocationID, intComLocDivSubDivID, strProgramID, strStorageGroupID, strStorageID)
            End Using
        End Function

        Protected Friend Shared Function ListDataAllSubStation(ByVal strQueueFlowID As String, ByVal intComLocDivSubDivID As Integer, ByVal strProgramID As String, _
                                                               ByVal strStorageGroupID As String, ByVal strStorageID As String) As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.QueueFlow.ListDataAllSubStation(sqlCon, Nothing, strQueueFlowID, intComLocDivSubDivID, strProgramID, strStorageGroupID, strStorageID)
            End Using
        End Function

#End Region

#Region "Item"

        Protected Friend Shared Function ListDataItem(ByVal strQueueFlowID As String) As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.QueueFlow.ListDataItem(sqlCon, Nothing, strQueueFlowID)
            End Using
        End Function

#End Region

    End Class

End Namespace

