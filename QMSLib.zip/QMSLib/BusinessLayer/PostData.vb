﻿Namespace BL
    Friend Class PostData
        Friend Const _
               mStation = "STATION", mSubStation = "SUBSTATION", mGender = "GENDER", mReligion = "RELIGION", mNationality = "NATIONALITY", mMaritalStatus = "MARITALSTATUS", _
               mBloodType = "BLOODTYPE", mOccupations = "OCCUPATIONS", mDrivingLicenseType = "DRIVINGLICENSETYPE", mImageType = "IMAGETYPE", mDriver = "DRIVER", _
               mDriverImage = "DRIVERIMAGE", mDriverStatus = "DRIVERSTATUS", mQueueFlow = "QUEUEFLOW", mQueueFlowStation = "QUEUEFLOWSTATION", mQueueFlowItem = "QUEUEFLOWITEM", _
               mStatus = "STATUS", mModules = "MODULES", mStorage = "STORAGE"

#Region "Collect Data Master RDC to Location"

        Protected Friend Shared Function CollectDataMasterStationRDCtoLocation() As DataTable
            '# Connect Current Server (Local)
            BL.Server.ServerDefault()
            Dim clsSyncTable As New VO.SyncTable
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                clsSyncTable = DL.SyncTable.GetLastDataByModuleID(sqlCon, Nothing, VO.Modules.Values.Station)
            End Using

            '# Remote and Get Data from HO
            BL.Server.SetUserServerLocation()
            Dim dtReturn As DataTable = DL.Station.OutstandingPostingRDCtoLocation(clsSyncTable.SyncDate)
            dtReturn.TableName = mStation
            Return dtReturn
        End Function

        Protected Friend Shared Function CollectDataMasterSubStationRDCtoLocation(ByVal strCompanyID As String, ByVal strLocationID As String) As DataTable
            '# Connect Current Server (Local)
            BL.Server.ServerDefault()
            Dim clsSyncTable As New VO.SyncTable
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                clsSyncTable = DL.SyncTable.GetLastDataByModuleID(sqlCon, Nothing, VO.Modules.Values.SubStation)
            End Using

            '# Remote and Get Data from HO
            BL.Server.SetUserServerLocation()
            Dim dtReturn As DataTable = DL.SubStation.OutstandingPostingRDCtoLocation(clsSyncTable.SyncDate, strCompanyID, strLocationID)
            dtReturn.TableName = mSubStation
            Return dtReturn
        End Function

        Protected Friend Shared Function CollectDataMasterGenderRDCtoLocation() As DataTable
            '# Connect Current Server (Local)
            BL.Server.ServerDefault()
            Dim clsSyncTable As New VO.SyncTable
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                clsSyncTable = DL.SyncTable.GetLastDataByModuleID(sqlCon, Nothing, VO.Modules.Values.Gender)
            End Using

            '# Remote and Get Data from HO
            BL.Server.SetUserServerLocation()
            Dim dtReturn As DataTable = DL.Gender.OutstandingPostingRDCtoLocation(clsSyncTable.SyncDate)
            dtReturn.TableName = mGender
            Return dtReturn
        End Function

        Protected Friend Shared Function CollectDataMasterReligionRDCtoLocation() As DataTable
            '# Connect Current Server (Local)
            BL.Server.ServerDefault()
            Dim clsSyncTable As New VO.SyncTable
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                clsSyncTable = DL.SyncTable.GetLastDataByModuleID(sqlCon, Nothing, VO.Modules.Values.Religion)
            End Using

            '# Remote and Get Data from HO
            BL.Server.SetUserServerLocation()
            Dim dtReturn As DataTable = DL.Religion.OutstandingPostingRDCtoLocation(clsSyncTable.SyncDate)
            dtReturn.TableName = mReligion
            Return dtReturn
        End Function

        Protected Friend Shared Function CollectDataMasterNationalityRDCtoLocation() As DataTable
            '# Connect Current Server (Local)
            BL.Server.ServerDefault()
            Dim clsSyncTable As New VO.SyncTable
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                clsSyncTable = DL.SyncTable.GetLastDataByModuleID(sqlCon, Nothing, VO.Modules.Values.Nationality)
            End Using

            '# Remote and Get Data from HO
            BL.Server.SetUserServerLocation()
            Dim dtReturn As DataTable = DL.Nationality.OutstandingPostingRDCtoLocation(clsSyncTable.SyncDate)
            dtReturn.TableName = mReligion
            Return dtReturn
        End Function

        Protected Friend Shared Function CollectDataMasterMaritalStatusRDCtoLocation() As DataTable
            '# Connect Current Server (Local)
            BL.Server.ServerDefault()
            Dim clsSyncTable As New VO.SyncTable
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                clsSyncTable = DL.SyncTable.GetLastDataByModuleID(sqlCon, Nothing, VO.Modules.Values.MaritalStatus)
            End Using

            '# Remote and Get Data from HO
            BL.Server.SetUserServerLocation()
            Dim dtReturn As DataTable = DL.MaritalStatus.OutstandingPostingRDCtoLocation(clsSyncTable.SyncDate)
            dtReturn.TableName = mReligion
            Return dtReturn
        End Function

        Protected Friend Shared Function CollectDataMasterBloodTypeRDCtoLocation() As DataTable
            '# Connect Current Server (Local)
            BL.Server.ServerDefault()
            Dim clsSyncTable As New VO.SyncTable
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                clsSyncTable = DL.SyncTable.GetLastDataByModuleID(sqlCon, Nothing, VO.Modules.Values.BloodType)
            End Using

            '# Remote and Get Data from HO
            BL.Server.SetUserServerLocation()
            Dim dtReturn As DataTable = DL.BloodType.OutstandingPostingRDCtoLocation(clsSyncTable.SyncDate)
            dtReturn.TableName = mBloodType
            Return dtReturn
        End Function

        Protected Friend Shared Function CollectDataMasterOccupationsRDCtoLocation() As DataTable
            '# Connect Current Server (Local)
            BL.Server.ServerDefault()
            Dim clsSyncTable As New VO.SyncTable
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                clsSyncTable = DL.SyncTable.GetLastDataByModuleID(sqlCon, Nothing, VO.Modules.Values.Occupations)
            End Using

            '# Remote and Get Data from HO
            BL.Server.SetUserServerLocation()
            Dim dtReturn As DataTable = DL.Occupations.OutstandingPostingRDCtoLocation(clsSyncTable.SyncDate)
            dtReturn.TableName = mOccupations
            Return dtReturn
        End Function

        Protected Friend Shared Function CollectDataMasterDrivingLicenseTypeRDCtoLocation() As DataTable
            '# Connect Current Server (Local)
            BL.Server.ServerDefault()
            Dim clsSyncTable As New VO.SyncTable
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                clsSyncTable = DL.SyncTable.GetLastDataByModuleID(sqlCon, Nothing, VO.Modules.Values.DrivingLicenseType)
            End Using

            '# Remote and Get Data from HO
            BL.Server.SetUserServerLocation()
            Dim dtReturn As DataTable = DL.DrivingLicenseType.OutstandingPostingRDCtoLocation(clsSyncTable.SyncDate)
            dtReturn.TableName = mDrivingLicenseType
            Return dtReturn
        End Function

        Protected Friend Shared Function CollectDataMasterImageTypeRDCtoLocation() As DataTable
            '# Connect Current Server (Local)
            BL.Server.ServerDefault()
            Dim clsSyncTable As New VO.SyncTable
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                clsSyncTable = DL.SyncTable.GetLastDataByModuleID(sqlCon, Nothing, VO.Modules.Values.ImageType)
            End Using

            '# Remote and Get Data from HO
            BL.Server.SetUserServerLocation()
            Dim dtReturn As DataTable = DL.ImageType.OutstandingPostingRDCtoLocation(clsSyncTable.SyncDate)
            dtReturn.TableName = mImageType
            Return dtReturn
        End Function

        Protected Friend Shared Function CollectDataMasterDriverRDCtoLocation() As DataTable
            '# Connect Current Server (Local)
            BL.Server.ServerDefault()
            Dim clsSyncTable As New VO.SyncTable
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                clsSyncTable = DL.SyncTable.GetLastDataByModuleID(sqlCon, Nothing, VO.Modules.Values.Driver)
            End Using

            '# Remote and Get Data from HO
            BL.Server.SetUserServerLocation()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim dtReturn As New DataTable()
                dtReturn = DL.Driver.OutstandingPostingRDCtoLocation(sqlCon, Nothing, clsSyncTable.SyncDate)
                dtReturn.TableName = mDriver
                Return dtReturn
            End Using
        End Function

        Protected Friend Shared Function CollectDataMasterDriverImageRDCtoLocation() As DataTable
            '# Connect Current Server (Local)
            BL.Server.ServerDefault()
            Dim clsSyncTable As New VO.SyncTable
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                clsSyncTable = DL.SyncTable.GetLastDataByModuleID(sqlCon, Nothing, VO.Modules.Values.Driver)
            End Using

            '# Remote and Get Data from HO
            BL.Server.SetUserServerLocation()
            Dim dtReturn As DataTable = DL.Driver.OutstandingPostingRDCtoLocationImage(clsSyncTable.SyncDate)
            dtReturn.TableName = mDriverImage
            Return dtReturn
        End Function

        Protected Friend Shared Function CollectDataMasterDriverStatusRDCtoLocation() As DataTable
            '# Connect Current Server (Local)
            BL.Server.ServerDefault()
            Dim clsSyncTable As New VO.SyncTable
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                clsSyncTable = DL.SyncTable.GetLastDataByModuleID(sqlCon, Nothing, VO.Modules.Values.Driver)
            End Using

            '# Remote and Get Data from HO
            BL.Server.SetUserServerLocation()
            Dim dtReturn As DataTable = DL.Driver.OutstandingPostingRDCtoLocationStatus(clsSyncTable.SyncDate)
            dtReturn.TableName = mDriverStatus
            Return dtReturn
        End Function

        Protected Friend Shared Function CollectDataMasterQueueFlowRDCtoLocation() As DataTable
            '# Connect Current Server (Local)
            BL.Server.ServerDefault()
            Dim clsSyncTable As New VO.SyncTable
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                clsSyncTable = DL.SyncTable.GetLastDataByModuleID(sqlCon, Nothing, VO.Modules.Values.QueueFlow)
            End Using

            '# Remote and Get Data from HO
            BL.Server.SetUserServerLocation()
            Dim dtReturn As DataTable = DL.QueueFlow.OutstandingPostingRDCtoLocation(clsSyncTable.SyncDate)
            dtReturn.TableName = mQueueFlow
            Return dtReturn
        End Function

        Protected Friend Shared Function CollectDataMasterQueueFlowStationRDCtoLocation() As DataTable
            '# Connect Current Server (Local)
            BL.Server.ServerDefault()
            Dim clsSyncTable As New VO.SyncTable
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                clsSyncTable = DL.SyncTable.GetLastDataByModuleID(sqlCon, Nothing, VO.Modules.Values.QueueFlow)
            End Using

            '# Remote and Get Data from HO
            BL.Server.SetUserServerLocation()
            Dim dtReturn As DataTable = DL.QueueFlow.OutstandingPostingRDCtoLocationStation(clsSyncTable.SyncDate)
            dtReturn.TableName = mQueueFlowStation
            Return dtReturn
        End Function

        Protected Friend Shared Function CollectDataMasterQueueFlowItemRDCtoLocation() As DataTable
            '# Connect Current Server (Local)
            BL.Server.ServerDefault()
            Dim clsSyncTable As New VO.SyncTable
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                clsSyncTable = DL.SyncTable.GetLastDataByModuleID(sqlCon, Nothing, VO.Modules.Values.QueueFlow)
            End Using

            '# Remote and Get Data from HO
            BL.Server.SetUserServerLocation()
            Dim dtReturn As DataTable = DL.QueueFlow.OutstandingPostingRDCtoLocationItem(clsSyncTable.SyncDate)
            dtReturn.TableName = mQueueFlowItem
            Return dtReturn
        End Function

        Protected Friend Shared Function CollectDataMasterStorageRDCtoLocation(ByVal strCompanyID As String, ByVal strLocationID As String) As DataTable
            '# Remote and Get Data from HO
            BL.Server.SetUserServerLocation()
            Dim dtReturn As New DataTable()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                dtReturn = DL.Storage.ListDataMMRemoting(strCompanyID, strLocationID)
            End Using
            dtReturn.TableName = mStorage
            Return dtReturn
        End Function

        Protected Friend Shared Function CollectDataMasterStatusRDCtoLocation() As DataTable
            '# Remote and Get Data from HO
            BL.Server.SetUserServerLocation()
            Dim dtReturn As New DataTable()
            dtReturn = DL.Status.OutstandingPostingRDCtoLocation
            dtReturn.TableName = mStatus
            Return dtReturn
        End Function

        Protected Friend Shared Function CollectDataMasterModulesRDCtoLocation() As DataTable
            '# Remote and Get Data from HO
            BL.Server.SetUserServerLocation()
            Dim dtReturn As New DataTable()
            dtReturn = DL.Modules.OutstandingPostingRDCtoLocation
            dtReturn.TableName = mModules
            Return dtReturn
        End Function

#End Region

#Region "Post Data Master RDC to Location"

        Protected Friend Shared Sub PostDataMasterStationRDCtoLocation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                       ByVal clsData As VO.Station)
            '# Sync Data
            DL.Station.PostDataRDCtoLocation(sqlCon, sqlTrans, clsData)
        End Sub

        Protected Friend Shared Sub PostDataMasterSubStationRDCtoLocation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                          ByVal clsData As VO.SubStation)
            '# Sync Data
            DL.SubStation.PostDataRDCtoLocation(sqlCon, sqlTrans, clsData)
        End Sub

        Protected Friend Shared Sub PostDataMasterGenderRDCtoLocation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                      ByVal clsData As VO.Gender)
            '# Sync Data
            DL.Gender.PostDataRDCtoLocation(sqlCon, sqlTrans, clsData)
        End Sub

        Protected Friend Shared Sub PostDataMasterReligionRDCtoLocation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                        ByVal clsData As VO.Religion)
            '# Sync Data
            DL.Religion.PostDataRDCtoLocation(sqlCon, sqlTrans, clsData)
        End Sub

        Protected Friend Shared Sub PostDataMasterNationalityRDCtoLocation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                           ByVal clsData As VO.Nationality)
            '# Sync Data
            DL.Nationality.PostDataRDCtoLocation(sqlCon, sqlTrans, clsData)
        End Sub

        Protected Friend Shared Sub PostDataMasterMaritalStatusRDCtoLocation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                             ByVal clsData As VO.MaritalStatus)
            '# Sync Data
            DL.MaritalStatus.PostDataRDCtoLocation(sqlCon, sqlTrans, clsData)
        End Sub

        Protected Friend Shared Sub PostDataMasterBloodTypeRDCtoLocation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                         ByVal clsData As VO.BloodType)
            '# Sync Data
            DL.BloodType.PostDataRDCtoLocation(sqlCon, Nothing, clsData)
        End Sub

        Protected Friend Shared Sub PostDataMasterOccupationsRDCtoLocation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                           ByVal clsData As VO.Occupations)
            '# Sync Data
            DL.Occupations.PostDataRDCtoLocation(sqlCon, sqlTrans, clsData)
        End Sub

        Protected Friend Shared Sub PostDataMasterDrivingLicenseTypeRDCtoLocation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                                  ByVal clsData As VO.DrivingLicenseType)
            '# Sync Data
            DL.DrivingLicenseType.PostDataRDCtoLocation(sqlCon, sqlTrans, clsData)
        End Sub

        Protected Friend Shared Sub PostDataMasterImageTypeRDCtoLocation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                         ByVal clsData As VO.ImageType)
            '# Sync Data
            DL.ImageType.PostDataRDCtoLocation(sqlCon, sqlTrans, clsData)
        End Sub

        Protected Friend Shared Sub PostDataMasterDriverRDCtoLocation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                      ByVal clsData As VO.Driver)
            '# Sync Data
            DL.Driver.PostDataRDCtoLocation(sqlCon, sqlTrans, clsData)
            DL.Driver.DeleteDataImage(sqlCon, sqlTrans, clsData.ID)
            DL.Driver.DeleteDataStatus(sqlCon, sqlTrans, clsData.ID)
        End Sub

        Protected Friend Shared Sub PostDataMasterDriverImageRDCtoLocation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                           ByVal clsData As VO.DriverImage)
            '# Sync Data
            DL.Driver.SaveDataImage(sqlCon, sqlTrans, clsData)
        End Sub

        Protected Friend Shared Sub PostDataMasterDriverStatusRDCtoLocation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                            ByVal clsData As VO.DriverStatus)
            '# Sync Data
            DL.Driver.SaveDataStatus(sqlCon, sqlTrans, clsData)
        End Sub

        Protected Friend Shared Sub PostDataMasterQueueFlowRDCtoLocation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                         ByVal clsData As VO.QueueFlow)
            '# Sync Data
            DL.QueueFlow.PostDataRDCtoLocation(sqlCon, sqlTrans, clsData)
            DL.QueueFlow.DeleteDataStation(sqlCon, sqlTrans, clsData.ID)
            DL.QueueFlow.DeleteDataItem(sqlCon, sqlTrans, clsData.ID)
        End Sub

        Protected Friend Shared Sub PostDataMasterQueueFlowStationRDCtoLocation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                                ByVal clsData As VO.QueueFlowStation)
            '# Sync Data
            DL.QueueFlow.SaveDataStation(sqlCon, sqlTrans, clsData)
        End Sub

        Protected Friend Shared Sub PostDataMasterQueueFlowItemRDCtoLocation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                             ByVal clsData As VO.QueueFlowItem)
            '# Sync Data
            DL.QueueFlow.SaveDataItem(sqlCon, sqlTrans, clsData)
        End Sub

        Protected Friend Shared Sub PostDataMasterStorageRDCtoLocation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction, ByVal clsData As VO.Storage)
            '# Sync Data
            Dim bolExists As Boolean = DL.Storage.DataExists(sqlCon, sqlTrans, clsData.ComLocDivSubDivID, clsData.ProgramID, clsData.StorageGroupID, clsData.StorageID)
            DL.Storage.SaveData(sqlCon, sqlTrans, Not bolExists, clsData)
        End Sub

        Protected Friend Shared Sub PostDataMasterStatusRDCtoLocation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                      ByVal clsData As VO.Status)
            '# Sync Data
            DL.Status.PostDataRDCtoLocation(sqlCon, sqlTrans, clsData)
        End Sub

        Protected Friend Shared Sub PostDataMasterModulesRDCtoLocation(ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction,
                                                                       ByVal clsData As VO.Modules)
            '# Sync Data
            DL.Modules.PostDataRDCtoLocation(sqlCon, sqlTrans, clsData)
        End Sub

#End Region

#Region "Collect Data Location to RDC"

        Protected Friend Shared Function CollectDataMasterDriverLocationtoRDC() As DataTable
            BL.Server.ServerDefault()
            Dim clsSyncTable As New VO.SyncTable
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                clsSyncTable = DL.SyncTable.GetLastDataByModuleID(sqlCon, Nothing, VO.Modules.Values.Driver)
            End Using

            'Get Data
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim dtReturn As New DataTable
                dtReturn = DL.Driver.OutstandingPostingLocationtoRDC(sqlCon, Nothing, clsSyncTable.SyncDate)
                dtReturn.TableName = mDriver
                Return dtReturn
            End Using
        End Function

        Protected Friend Shared Function CollectDataMasterDriverImageLocationtoRDC() As DataTable
            BL.Server.ServerDefault()
            Dim clsSyncTable As New VO.SyncTable
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                clsSyncTable = DL.SyncTable.GetLastDataByModuleID(sqlCon, Nothing, VO.Modules.Values.Driver)
            End Using

            'Get Data 
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim dtReturn As New DataTable
                dtReturn = DL.Driver.OutstandingPostingLocationtoRDCImage(sqlCon, Nothing, clsSyncTable.SyncDate)
                dtReturn.TableName = mDriverImage
                Return dtReturn
            End Using
        End Function

        Protected Friend Shared Function CollectDataMasterDriverStatusLocationtoRDC() As DataTable
            BL.Server.ServerDefault()
            Dim clsSyncTable As New VO.SyncTable
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                clsSyncTable = DL.SyncTable.GetLastDataByModuleID(sqlCon, Nothing, VO.Modules.Values.Driver)
            End Using

            'Get Data
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim dtReturn As New DataTable
                dtReturn = DL.Driver.OutstandingPostingLocationtoRDCStatus(sqlCon, Nothing, clsSyncTable.SyncDate)
                dtReturn.TableName = mDriverStatus
                Return dtReturn
            End Using
        End Function

#End Region

#Region "Post Data Master Location to RDC"

        Protected Friend Shared Sub PostDataMasterDriverLocationtoRDC(ByVal clsData As VO.Driver)
            '# Sync Data
            BL.Server.SetUserServerLocation()
            DL.Driver.PostDataLocationtoRDC(clsData)
        End Sub

        Protected Friend Shared Sub PostDataMasterDriverImageLocationtoRDC(ByVal clsData As VO.DriverImage)
            '# Sync Data
            BL.Server.SetUserServerLocation()
            DL.Driver.PostDataLocationtoRDCImage(clsData)
        End Sub

        Protected Friend Shared Sub PostDataMasterDriverStatusLocationtoRDC(ByVal clsData As VO.DriverStatus)
            '# Sync Data
            BL.Server.SetUserServerLocation()
            DL.Driver.PostDataLocationtoRDCStatus(clsData)
        End Sub

#End Region

    End Class
End Namespace