Namespace BL

    Friend Class UserAccess

        Protected Friend Shared Function UserList(Optional ByVal intComLocDivSubDivID As Integer = 0) As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.UserAccess.UserList(sqlCon, Nothing, intComLocDivSubDivID)
            End Using
        End Function

        Protected Friend Shared Function AccessList(ByVal strUserID As String, ByVal strUserCompanyID As String) As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.UserAccess.AccessList(sqlCon, Nothing, strUserID, strUserCompanyID)
            End Using
        End Function

        Protected Friend Shared Function CheckUserLogin(ByVal strUserID As String, ByVal strUserPassword As String) As Boolean
            BL.Server.ServerDefault()

            Dim voUser As New VO.User
            Dim bolLogin As Boolean = False
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                voUser = DL.UserAccess.GetDetailNE(sqlCon, Nothing, strUserID)
            End Using
            If PasswordDecrypt(voUser.Password) = strUserPassword Then
                bolLogin = True
            End If
            Return bolLogin
        End Function

        Protected Friend Shared Function GetPassword(ByVal strUserID As String) As String
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return PasswordDecrypt(DL.UserAccess.GetPassword(sqlCon, Nothing, strUserID))
            End Using
        End Function

        Protected Friend Shared Sub ChangePassword(ByVal strUserID As String, ByVal strCurrenctPassword As String, ByVal strNewPassword As String)
            If GetPassword(strUserID) <> strCurrenctPassword Then
                Err.Raise(515, "", "Cannot Save. Current Password Wrong")
            Else
                BL.Server.ServerDefault()
                Dim dtDB As New DataTable
                Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                    DL.UserAccess.ChangePassword(sqlCon, Nothing, strUserID, PasswordEncrypt(strNewPassword))

                    dtDB = DL.Server.ServerList(sqlCon, Nothing)
                End Using

                For Each drDB As DataRow In dtDB.Rows
                    BL.Server.SetServer(drDB.Item("Server"), drDB.Item("DBName"), drDB.Item("UserID"), drDB.Item("UserPassword"))
                    Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                        DL.UserAccess.ChangePassword(sqlCon, Nothing, strUserID, PasswordEncrypt(strNewPassword))
                    End Using
                Next
            End If
        End Sub

        Protected Friend Shared Function CheckAccess(ByVal strUserID As String, strDelegateUserID As String, ByVal strProgramID As String, ByVal strModuleID As String, ByVal strAccessCode As String) As Boolean
            BL.Server.ServerDefault()
            If strUserID.Trim = "ADMIN" Or strUserID.Trim = "IT.SWS" Or strUserID.Trim = "TEST-USER" Then Return True

            Dim bolAccess As Boolean
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                bolAccess = DL.UserAccess.CheckAccess(sqlCon, Nothing, strUserID, strProgramID, strModuleID, strAccessCode)

                If Not bolAccess And strDelegateUserID <> "" Then
                    bolAccess = DL.UserAccess.CheckAccess(sqlCon, Nothing, strDelegateUserID, strProgramID, strModuleID, strAccessCode)
                End If
            End Using

            Return bolAccess
        End Function

        Protected Friend Shared Function CheckAccess2(ByVal strUserID As String, strDelegateUserID As String, ByVal strProgramID As String, ByVal strModuleID As String, ByVal strAccessCode As String, ByVal intComLocDivSubDivID As Integer) As Boolean
            BL.Server.ServerDefault()
            Dim bolAccess As Boolean
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim strDelegatedUserID As String = ""
                bolAccess = DL.UserAccess.CheckAccess2(sqlCon, Nothing, strUserID, strProgramID, strModuleID, strAccessCode, intComLocDivSubDivID)

                If Not bolAccess And strDelegatedUserID <> "" Then
                    bolAccess = DL.UserAccess.CheckAccess2(sqlCon, Nothing, strDelegatedUserID, strProgramID, strModuleID, strAccessCode, intComLocDivSubDivID)
                End If
            End Using
            Return bolAccess
        End Function

        Protected Friend Shared Sub AccessFillRight()
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                DL.UserAccess.AccessFillRight(sqlCon, Nothing, "QMS")
            End Using
        End Sub

        Protected Friend Shared Function IsValidDelegatedUserID(ByVal strUserID As String, ByVal strDelegatedUserID As String, ByVal dtmPeriod As DateTime) As Boolean
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.UserAccess.IsValidDelegatedUserID(sqlCon, Nothing, strUserID, strDelegatedUserID, dtmPeriod)
            End Using
        End Function

        Protected Friend Shared Function GetDelegatedFrom(ByVal strUserID As String, ByVal dtmPeriod As DateTime) As String
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.UserAccess.GetDelegatedFrom(sqlCon, Nothing, strUserID, dtmPeriod)
            End Using
        End Function

        Protected Friend Shared Function GetDelegatedUserID(ByVal strUserID As String, ByVal dtmPeriod As DateTime, ByVal strLogBy As String) As String
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.UserAccess.GetDelegatedUserID(sqlCon, Nothing, strUserID, dtmPeriod, strLogBy)
            End Using
        End Function

        Protected Friend Shared Function GetUserIDByLegacyUser(ByVal strCompanyID As String, ByVal strLegacyUser As String) As String
            BL.Server.SetServer(strCompanyID)
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.UserAccess.GetUserIDByLegacyUser(sqlCon, Nothing, strLegacyUser)
            End Using
        End Function

        Protected Friend Shared Function GetUserEmail(ByVal strUserID As String) As String
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.UserAccess.GetUserEmail(sqlCon, Nothing, strUserID)
            End Using
        End Function

        Private Shared Function PasswordDecrypt(ByVal strText As String) As String
            Dim strKey As String
            Dim intI As Integer
            Dim strResult As String = ""
            If Len(strText) < 50 Then Return ""
            strKey = Microsoft.VisualBasic.Right(strText, 50)
            For intI = 1 To Len(strKey)
                If intI > Len(strText) Then
                    strResult &= Chr(255 - Asc(Mid(strKey, intI, 1)))
                ElseIf Mid(strText, intI, 1) = Chr(255 - Asc(Mid(strKey, intI, 1))) Then
                    strResult &= ""
                Else
                    strResult &= Chr(Asc(Mid(strText, intI, 1)) - Asc(Mid(strKey, intI, 1)))
                End If
            Next
            Return strResult
        End Function

        Private Shared Function PasswordEncrypt(ByVal strText As String) As String
            Dim strKey As String = RandomBigString()
            Dim intI As Integer
            Dim strResult As String = ""
            For intI = 1 To Len(strKey)
                If intI <= Len(strText) Then
                    strResult &= Chr(Asc(Mid(strText, intI, 1)) + Asc(Mid(strKey, intI, 1)))
                Else
                    strResult &= Chr(255 - Asc(Mid(strKey, intI, 1)))
                End If
            Next
            strResult &= strKey
            Return strResult
        End Function

        Private Shared Function RandomBigString() As String
            Const Numcharacters As Integer = 50
            Dim intI As Integer
            Dim intRand As Integer
            Dim strText As String = ""
            Dim oRand As New Random
            For intI = 1 To Numcharacters
                intRand = oRand.Next(100)
                If intRand < 15 Then
                    strText &= " "
                ElseIf intRand < 20 Then
                    strText &= Mid("aeiou", oRand.Next(1, 5), 1)
                Else
                    strText &= Chr(oRand.Next(97, 122))
                End If
            Next
            Return strText
        End Function

        Protected Friend Shared Sub CopyGlobalSetting()
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                Try
                    DL.UserAccess.CopyProgramList(sqlCon, sqlTrans)
                    DL.UserAccess.CopyModuleList(sqlCon, sqlTrans)
                    DL.UserAccess.CopyAccessLevel(sqlCon, sqlTrans)
                    DL.UserAccess.CopyProgramMenu(sqlCon, sqlTrans)
                    DL.UserAccess.CopyProgramMenuDetail(sqlCon, sqlTrans)

                    sqlTrans.Commit()
                Catch ex As Exception
                    sqlTrans.Rollback()
                End Try
            End Using
        End Sub

        Protected Friend Shared Function GetProgramList() As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.UserAccess.GetProgramList(sqlCon, Nothing)
            End Using
        End Function

        Protected Friend Shared Function GetModuleList() As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.UserAccess.GetModuleList(sqlCon, Nothing)
            End Using
        End Function

        Protected Friend Shared Function GetAccessLevel() As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.UserAccess.GetAccessLevel(sqlCon, Nothing)
            End Using
        End Function

        Protected Friend Shared Function GetProgramMenu() As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.UserAccess.GetProgramMenu(sqlCon, Nothing)
            End Using
        End Function

        Protected Friend Shared Function GetProgramMenuDetail() As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.UserAccess.GetProgramMenuDetail(sqlCon, Nothing)
            End Using
        End Function

        Protected Friend Shared Sub CopyUserList(ByVal strNewUserID As String, ByVal strLegacyUserID As String)
            Dim dtDB As New DataTable
            Dim dtAll As New DataTable
            Dim dtUserListDetail As New DataTable

            BL.Server.ServerDefault()
            dtDB = BL.Server.ServerList

            For Each drDB As DataRow In dtDB.Rows
                DL.SQL.strServer = drDB.Item("Server")
                DL.SQL.strDatabase = drDB.Item("DBName")
                DL.SQL.strSAID = drDB.Item("UserID")
                DL.SQL.strSAPassword = drDB.Item("UserPassword")
                Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                    dtUserListDetail = DL.UserAccess.GetUserListDetail(sqlCon, Nothing, strLegacyUserID, drDB.Item("DBName"))
                End Using
                dtAll.Merge(dtUserListDetail)
            Next

            If dtAll.Rows.Count > 0 Then
                BL.Server.ServerDefault()
                Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                    Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                    Try
                        For Each drData As DataRow In dtAll.Rows
                            Dim strUserMenu As String = DL.UserAccess.GetUserProgramMenu(sqlCon, sqlTrans, strLegacyUserID, drData("ProgramID"))
                            DL.UserAccess.CopyUserListDetail(sqlCon, sqlTrans, strNewUserID, drData("Sub_Div_Id"), drData("Com_Loc_Div_Id"), drData("ProgramId"), strUserMenu)
                        Next
                        sqlTrans.Commit()
                    Catch ex As Exception
                        sqlTrans.Rollback()
                    End Try
                End Using
            End If
        End Sub

        Protected Friend Shared Function GetUserIDByLegacyUserForCopyUser(ByVal strLegacyUser As String) As String
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.UserAccess.GetUserIDByLegacyUser(sqlCon, Nothing, strLegacyUser)
            End Using
        End Function

        Protected Friend Shared Function GetHeadID(ByVal strUserID As String) As String
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.UserAccess.GetHeadID(sqlCon, Nothing, strUserID)
            End Using
        End Function

        Protected Friend Shared Function GetUserEmailList(ByVal strUserIDList As String) As String
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.UserAccess.GetUserEmailList(sqlCon, Nothing, strUserIDList)
            End Using
        End Function
    End Class

End Namespace
