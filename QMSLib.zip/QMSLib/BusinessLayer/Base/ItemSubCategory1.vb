﻿Namespace BL

    Friend Class ItemSubCategory1

        Protected Friend Shared Function ListData(Optional ByVal intCategoryID As Integer = -1) As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.ItemSubCategory1.ListData(sqlCon, Nothing, intCategoryID)
            End Using
        End Function

    End Class

End Namespace