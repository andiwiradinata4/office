﻿Namespace BL

    Friend Class ItemCategory

        Protected Friend Shared Function ListData(Optional ByVal intGroupID As Integer = -1) As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.ItemCategory.ListData(sqlCon, Nothing, intGroupID)
            End Using
        End Function

        Protected Friend Shared Function ListDataDistinct() As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.ItemCategory.ListDataDistinct(sqlCon, Nothing)
            End Using
        End Function

    End Class

End Namespace