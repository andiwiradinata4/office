﻿Namespace BL

    Friend Class CS

        Protected Friend Shared Function GetComLocInfoByComLocDiv(ByVal intComLocDivSubDivID As Integer) As VO.CS
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.CS.GetComLocInfoByComLocDiv(sqlCon, Nothing, intComLocDivSubDivID)
            End Using
        End Function

        Protected Friend Shared Function ListDataAllComLocInitial(ByVal strCompanyID As String) As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.CS.ListDataAllComLocInitial(sqlCon, Nothing, strCompanyID)
            End Using
        End Function

    End Class

End Namespace