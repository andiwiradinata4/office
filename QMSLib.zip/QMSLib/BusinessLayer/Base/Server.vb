﻿Imports Newtonsoft.Json
Imports System.Windows.Forms
Imports System.Reflection
Imports MM_Remoting_Service
Namespace BL

    Friend Class Server

        Protected Friend Shared Sub ServerTemp()
            DL.SQL.strServer = "isql.local.com"
            DL.SQL.strDatabase = "QMS"
            DL.SQL.strSAID = ""
            DL.SQL.strSAPassword = ""
        End Sub

        <System.Diagnostics.DebuggerStepThrough>
        Protected Friend Shared Sub ServerDefault()
            DL.SQL.strServer = VO.DefaultServer.Server
            DL.SQL.strDatabase = VO.DefaultServer.Database
            DL.SQL.strSAID = ""
            DL.SQL.strSAPassword = ""
        End Sub

        <System.Diagnostics.DebuggerStepThrough>
        Protected Friend Shared Sub SetUserServerLocation(ByVal intComLocDivSubDivID As Integer)
            ServerDefault()
            Dim clsData As New VO.UserServerLocation
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                clsData = DL.UserServerLocation.GetDetail(sqlCon, Nothing, intComLocDivSubDivID)
            End Using
            If clsData Is Nothing Then Exit Sub
            DL.SQL.strServer = clsData.Server
            DL.SQL.strDatabase = clsData.DBName
            DL.SQL.strSAID = ""
            DL.SQL.strSAPassword = ""
        End Sub

        <System.Diagnostics.DebuggerStepThrough>
        Protected Friend Shared Sub SetUserServerLocation()
            DL.SQL.strServer = VO.DefaultServer.UserServerLocation.Server
            DL.SQL.strDatabase = VO.DefaultServer.UserServerLocation.DBName
            DL.SQL.strSAID = ""
            DL.SQL.strSAPassword = ""
        End Sub

        <System.Diagnostics.DebuggerStepThrough>
        Protected Friend Shared Function DefaultRemotingService() As MM_Remoting_Service.SqlHelper
            Dim MM_Remoting As New MM_Remoting_Service.SqlHelper
            With MM_Remoting
                .ServerName = DL.SQL.strServer
                .Database = DL.SQL.strDatabase
                .ApplicationName = DL.SQL.strAplicationName
            End With
            Return MM_Remoting
        End Function

        '<System.Diagnostics.DebuggerStepThrough>
        Protected Friend Shared Function DefaultRemotingServiceServer() As MM_Remoting_Service_Server
            Dim MM_Remoting As New MM_Remoting_Service_Server
            With MM_Remoting
                .Clear()
                .ClearParameters()
                .Server = DL.SQL.strServer
                .Database = DL.SQL.strDatabase
            End With
            Return MM_Remoting
        End Function

        Protected Friend Shared Function ServerList() As DataTable
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Server.ServerList(sqlCon, Nothing)
            End Using
        End Function

        Protected Friend Shared Sub ServerAllCompanyList()
            ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                VO.ServerList.ServerList = DL.Server.ServerAllCompanyList(sqlCon, Nothing)
            End Using
        End Sub

        <System.Diagnostics.DebuggerStepThrough>
        Protected Friend Shared Sub SetServer(ByVal strCompanyID As String)
            For Each dtRow As DataRow In VO.ServerList.ServerList.Rows
                If dtRow.Item("CompanyID") = strCompanyID Then
                    DL.SQL.strServer = dtRow.Item("Server")
                    DL.SQL.strDatabase = dtRow.Item("DBName")
                    DL.SQL.strSAID = dtRow.Item("UserID")
                    DL.SQL.strSAPassword = dtRow.Item("UserPassword")
                    Exit For
                End If
            Next
        End Sub

        <System.Diagnostics.DebuggerStepThrough>
        Protected Friend Shared Sub SetServer(ByVal strServer As String, ByVal strDBName As String, ByVal strUserID As String, ByVal strUserPassword As String)
            DL.SQL.strServer = strServer
            DL.SQL.strDatabase = strDBName
            DL.SQL.strSAID = strUserID
            DL.SQL.strSAPassword = strUserPassword
        End Sub

        <System.Diagnostics.DebuggerStepThrough>
        Protected Friend Shared Sub SetServerOtherOpsys(ByVal strServer As String, Optional ByVal strDBName As String = "WeighbridgeMgt", _
                                                        Optional ByVal strUserID As String = "", Optional ByVal strUserPassword As String = "")
            DL.SQL.strServer = strServer
            DL.SQL.strDatabase = strDBName
            DL.SQL.strSAID = strUserID
            DL.SQL.strSAPassword = strUserPassword
        End Sub

        Protected Friend Shared Function IsServerAlpa() As Boolean
            Dim bolReturn As Boolean = False
            If VO.DefaultServer.Server = "IDTJMMM-FS03" Or VO.DefaultServer.Server = "172.18.3.14" Then
                bolReturn = True
            End If
            Return bolReturn
        End Function

        Protected Friend Shared Function IsServerUAT() As Boolean
            Dim bolReturn As Boolean = False
            If VO.DefaultServer.Server = "192.168.80.151" Then
                bolReturn = True
            End If
            Return bolReturn
        End Function

        Protected Friend Shared Function IsServerTesting() As Boolean
            Dim bolReturn As Boolean = False
            If IsServerAlpa() Or IsServerUAT() Then
                bolReturn = True
            End If
            Return bolReturn
        End Function

        Protected Friend Shared Sub InitDefaultValue()
            Dim path As String = Application.StartupPath
            Console.WriteLine("Path " & path)
            Dim strXML As String = path & "\QMS-CONFIG.XML"
            Console.WriteLine("XML Path " & strXML)

            If Not IO.File.Exists(strXML) Then
                Console.WriteLine("XML Not Exists")
                UI.usForm.frmMessageBox("XML File Not Found ... ")
            Else
                Console.WriteLine("XML Exists")
                Dim xmlHandle As New usXML(strXML)
                With xmlHandle
                    VO.DefaultServer.Server = .GetConfigInfo("CONNECTION", "SERVER", ".").Item(1)
                    VO.DefaultServer.Database = .GetConfigInfo("CONNECTION", "DATABASE", ".").Item(1)
                    VO.DefaultServer.CompanyID = .GetConfigInfo("CONNECTION", "COMPANY", "").Item(1)
                    VO.DefaultServer.LocationID = .GetConfigInfo("CONNECTION", "LOCATION", "").Item(1)
                    VO.DefaultServer.Database = .GetConfigInfo("CONNECTION", "DATABASE", ".").Item(1)
                    VO.DefaultServer.ReportingServer = .GetConfigInfo("CONNECTION", "REPORTSERVER", "0").Item(1)
                    VO.DefaultServer.DSPath = .GetConfigInfo("CONNECTION", "DSPATH", "C:\DATA").Item(1)
                    VO.DefaultServer.DSTempPath = .GetConfigInfo("CONNECTION", "DSTEMPPATH", "C:\DATA").Item(1)
                    VO.DefaultServer.Use2FA = CBool(.GetConfigInfo("CONNECTION", "USE2FA", "0").Item(1))
                    VO.DefaultServer.WebAPILPRReGet = .GetConfigInfo("CONNECTION", "WEBAPILPRREGET", "localhost").Item(1)
                    VO.DefaultServer.WebAPILPRGet = .GetConfigInfo("CONNECTION", "WEBAPILPRGET", "localhost").Item(1)
                    VO.DefaultServer.AutoDoneStationID = .GetConfigInfo("CONNECTION", "AUTODONESTATIONID", 1).Item(1)
                    VO.DefaultServer.IsLinkRFIDDevice1 = .GetConfigInfo("CONNECTION", "ISLINKRFIDDEVICE1", False).Item(1)
                    VO.DefaultServer.IsLinkRFIDDevice2 = .GetConfigInfo("CONNECTION", "ISLINKRFIDDEVICE2", False).Item(1)
                    VO.DefaultServer.IsAutoConfirm = .GetConfigInfo("CONNECTION", "ISAUTOCONFIRM", False).Item(1)
                    VO.DefaultServer.ComputerName = SharedLib.Common.GetCompName

                    '# Get default value for Auto Confirm
                    VO.DefaultValueAutoConfirm.QueueType = .GetConfigInfo("DEFAULTAUTOCONFIRMVALUE", "QUEUETYPE", False).Item(1)
                    VO.DefaultValueAutoConfirm.ItemCode = .GetConfigInfo("DEFAULTAUTOCONFIRMVALUE", "ITEMCODE", "").Item(1)
                    VO.DefaultValueAutoConfirm.ComLocDivSubDivIDStorage = .GetConfigInfo("DEFAULTAUTOCONFIRMVALUE", "COMLOCDIVSUBDIVIDSTORAGE", 0).Item(1)
                    VO.DefaultValueAutoConfirm.ProgramIDStorage = .GetConfigInfo("DEFAULTAUTOCONFIRMVALUE", "PROGRAMIDSTORAGE", "").Item(1)
                    VO.DefaultValueAutoConfirm.StorageGroupID = .GetConfigInfo("DEFAULTAUTOCONFIRMVALUE", "STORAGEGROUPID", "").Item(1)
                    VO.DefaultValueAutoConfirm.StorageID = .GetConfigInfo("DEFAULTAUTOCONFIRMVALUE", "STORAGEID", "").Item(1)
                End With
            End If
        End Sub

    End Class

End Namespace
