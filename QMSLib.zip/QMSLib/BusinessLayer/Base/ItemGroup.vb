﻿Namespace BL

    Friend Class ItemGroup

        Protected Friend Shared Function ListData(Optional ByVal intClassID As Integer = -1) As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.ItemGroup.ListData(sqlCon, Nothing, intClassID)
            End Using
        End Function

    End Class

End Namespace