Namespace BL
    Friend Class Gender

        Protected Friend Shared Function ListData(Optional ByVal bytIDStatus As VO.Status.Values = VO.Status.Values.All) As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Gender.ListData(sqlCon, Nothing, bytIDStatus)
            End Using
        End Function

        Protected Friend Shared Function SaveData(ByVal bolNew As Boolean, ByVal clsData As VO.Gender) As String
            BL.Server.ServerDefault()

            Try
                Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                    If bolNew Then
                        clsData.ID = DL.Gender.GetMaxID(sqlCon, Nothing)
                        If DL.Gender.IsIDExists(sqlCon, Nothing, clsData.ID) Then
                            Err.Raise(515, "", "Cannot Save. ID already exist")
                        End If
                    End If

                    If DL.Gender.IsDescriptionExists(sqlCon, Nothing, clsData.ID, clsData.Description) Then
                        Err.Raise(515, "", "Cannot Save. Description (" & clsData.Description & ") already exist")
                    End If

                    DL.Gender.SaveData(sqlCon, Nothing, bolNew, clsData)
                End Using

                If Not BL.Server.IsServerTesting Then
                    Dim dtDB As DataTable = BL.Server.ServerList
                    For Each drDB As DataRow In dtDB.Rows
                        BL.Server.SetServer(drDB.Item("Server"), drDB.Item("DBName"), drDB.Item("UserID"), drDB.Item("UserPassword"))
                        Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                            DL.Gender.SaveData(sqlCon, Nothing, bolNew, clsData)
                        End Using
                    Next
                End If
            Catch ex As Exception
                Throw ex
            End Try

            Return clsData.Description
        End Function

        Protected Friend Shared Function GetDetail(ByVal bytID As Byte) As VO.Gender
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Gender.GetDetail(sqlCon, Nothing, bytID)
            End Using
        End Function

        Protected Friend Shared Sub DeleteData(ByVal clsData As VO.Gender)
            BL.Server.ServerDefault()
            Try
                Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                    If DL.Gender.IsInActive(sqlCon, Nothing, clsData.ID) Then
                        Err.Raise(515, "", "Cannot Delete. Data is Not Active")
                    End If

                    DL.Gender.DeleteData(sqlCon, Nothing, clsData)
                End Using

                If Not BL.Server.IsServerTesting Then
                    Dim dtDB As DataTable = BL.Server.ServerList
                    For Each drDB As DataRow In dtDB.Rows
                        BL.Server.SetServer(drDB.Item("Server"), drDB.Item("DBName"), drDB.Item("UserID"), drDB.Item("UserPassword"))
                        Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                            DL.Gender.DeleteData(sqlCon, Nothing, clsData)
                        End Using
                    Next
                End If
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

    End Class

End Namespace

