Namespace BL
    Friend Class StatusDet
        Protected Friend Shared Function ListDataByIDStatus(ByVal bytIDStatus As VO.Status.Values) As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.StatusDet.ListDataByIDStatus(sqlCon, Nothing, bytIDStatus)
            End Using
        End Function

        Protected Friend Shared Function ListDataByModuleID(ByVal bytModuleID As VO.Modules.Values) As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.StatusDet.ListDataByModuleID(sqlCon, Nothing, bytModuleID)
            End Using
        End Function

        Protected Friend Shared Sub SaveDataByIDStatus(ByVal clsDataAll() As VO.StatusDet)
            BL.Server.ServerDefault()
            Try
                Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                    Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                    Try
                        DL.StatusDet.DeleteDataByIDStatus(sqlCon, sqlTrans, clsDataAll(0).IDStatus)
                        For Each clsItem As VO.StatusDet In clsDataAll
                            clsItem.ID = DL.StatusDet.GetMaxID(sqlCon, sqlTrans)
                            DL.StatusDet.SaveData(sqlCon, sqlTrans, clsItem)
                        Next

                        sqlTrans.Commit()
                    Catch ex As Exception
                        sqlTrans.Rollback()
                        Throw ex
                    End Try
                End Using

                If Not BL.Server.IsServerTesting Then
                    Dim dtDB As DataTable = BL.Server.ServerList
                    For Each drDB As DataRow In dtDB.Rows
                        BL.Server.SetServer(drDB.Item("Server"), drDB.Item("DBName"), drDB.Item("UserID"), drDB.Item("UserPassword"))
                        Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                            Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                            Try
                                DL.StatusDet.DeleteDataByIDStatus(sqlCon, sqlTrans, clsDataAll(0).IDStatus)
                                For Each clsItem As VO.StatusDet In clsDataAll
                                    clsItem.ID = DL.StatusDet.GetMaxID(sqlCon, sqlTrans)
                                    DL.StatusDet.SaveData(sqlCon, sqlTrans, clsItem)
                                Next
                                sqlTrans.Commit()
                            Catch ex As Exception
                                sqlTrans.Rollback()
                                Throw ex
                            End Try
                        End Using

                    Next
                End If
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Protected Friend Shared Sub SaveDataByModuleID(ByVal clsDataAll() As VO.StatusDet)
            BL.Server.ServerDefault()
            Try
                Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                    Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                    Try
                        DL.StatusDet.DeleteDataByMobuleID(sqlCon, sqlTrans, clsDataAll(0).ModuleID)
                        For Each clsItem As VO.StatusDet In clsDataAll
                            clsItem.ID = DL.StatusDet.GetMaxID(sqlCon, sqlTrans)
                            DL.StatusDet.SaveData(sqlCon, sqlTrans, clsItem)
                        Next
                        sqlTrans.Commit()
                    Catch ex As Exception
                        sqlTrans.Rollback()
                        Throw ex
                    End Try
                End Using

                If Not BL.Server.IsServerTesting Then
                    Dim dtDB As DataTable = BL.Server.ServerList
                    For Each drDB As DataRow In dtDB.Rows
                        BL.Server.SetServer(drDB.Item("Server"), drDB.Item("DBName"), drDB.Item("UserID"), drDB.Item("UserPassword"))
                        Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                            Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction
                            Try
                                DL.StatusDet.DeleteDataByMobuleID(sqlCon, sqlTrans, clsDataAll(0).ModuleID)
                                For Each clsItem As VO.StatusDet In clsDataAll
                                    clsItem.ID = DL.StatusDet.GetMaxID(sqlCon, sqlTrans)
                                    DL.StatusDet.SaveData(sqlCon, sqlTrans, clsItem)
                                Next
                            Catch ex As Exception
                                sqlTrans.Rollback()
                                Throw ex
                            End Try
                        End Using

                    Next
                End If
            Catch ex As Exception
                Throw ex
            End Try

        End Sub

    End Class

End Namespace

