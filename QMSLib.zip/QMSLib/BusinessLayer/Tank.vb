﻿Namespace BL
    Friend Class Tank

        Protected Friend Shared Function ListData() As DataTable
            BL.Server.ServerDefault()
            Using sqlCon As SqlConnection = DL.SQL.OpenConnection
                Return DL.Tank.ListData(sqlCon, Nothing)
            End Using
        End Function

    End Class
End Namespace