﻿using FBP.Lib.VO;
using System.Net.Http.Json;
using UMS.Core.DTOs;


namespace FBP.Lib.Utilities
{
    public static class UsHttpClient
    {

        public enum Method
        {
            Get,
            Post,
            Put,
            Delete
        }

        public static void SetToken(TokenDTO token)
        {
            if (!FBP.Lib.VO.DefaultSettings.HttpHeaders.ContainsKey("Authorization"))
            {
                FBP.Lib.VO.DefaultSettings.HttpHeaders.Add("Authorization", $"Bearer {token.AccessToken}");
            }
            else
            {
                FBP.Lib.VO.DefaultSettings.HttpHeaders["Authorization"] = $"Bearer {token.AccessToken}";
            }

            if (!FBP.Lib.VO.DefaultSettings.HttpHeaders.ContainsKey("RefreshToken"))
            {
                FBP.Lib.VO.DefaultSettings.HttpHeaders.Add("RefreshToken", token.RefreshToken);
            }
            else
            {
                FBP.Lib.VO.DefaultSettings.HttpHeaders["RefreshToken"] = token.RefreshToken;
            }
            FBP.Lib.VO.DefaultSettings.Token = token;
        }

        public static async Task<bool> CheckToken()
        {
            if (!string.IsNullOrEmpty(FBP.Lib.VO.DefaultSettings.Token.UserName))
            {
                long intValidTo;
                Int64.TryParse(FBP.Lib.VO.DefaultSettings.Token.ValidTo.ToString("yyyyMMddHHmmss"), out intValidTo);
                if (intValidTo > 0)
                {
                    long intNow;
                    Int64.TryParse(DateTime.Now.ToString("yyyyMMddHHmmss"), out intNow);

                    if (intNow >= intValidTo) await RefreshToken();
                }
            }
            return true;
        }

        public static async Task<bool> RefreshToken()
        {
            if (!VO.DefaultSettings.HttpHeaders.ContainsKey("RefreshToken")) return false;
            using (HttpClient client = Init(VO.DefaultSettings.BaseUrl.UMS))
            {
                client.DefaultRequestHeaders.Remove("Authorization");
                HttpResponseMessage response = await client.PostAsJsonAsync("/api/v1/token/refresh", new { });
                MessageObject<TokenDTO> body = await response.Content.ReadAsAsync<MessageObject<TokenDTO>>();
                if (body == null) return false;
                if (body.Data == null) return false;
                SetToken(body.Data);
                return true;
            }
        }

        public static HttpClient Init(string baseAddress)
        {
            var client = new HttpClient();
            client.BaseAddress = new Uri(baseAddress);
            client.DefaultRequestHeaders.Accept.Clear();
            foreach (var header in FBP.Lib.VO.DefaultSettings.HttpHeaders)
            {
                client.DefaultRequestHeaders.Add(header.Key, header.Value);
            }
            return client;
        }

        public static async Task<MessageObject<T>> CallApi<T>(Method method, string baseUrl, string endPoint, object? data = null)
        {
            int loop = 0;
            try
            {
                await CheckToken();
            repeat:
                using (HttpClient client = Init(baseUrl))
                {
                    HttpResponseMessage response = new HttpResponseMessage();
                    if (method == Method.Get)
                    {
                        response = await client.GetAsync(endPoint);
                    }
                    else if (method == Method.Post)
                    {
                        response = await client.PostAsJsonAsync(endPoint, data);
                    }
                    else if (method == Method.Put)
                    {
                        response = await client.PutAsJsonAsync(endPoint, data);
                    }
                    else if (method == Method.Delete)
                    {
                        response = await client.DeleteAsync(endPoint);
                    }

                    if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                    {
                        loop++;
                        if (loop >= 3) throw new UsException("Unauthorized");
                        await RefreshToken();
                        if (loop < 3) goto repeat;
                    }
                    else if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
                    {
                        throw new UsException("Data not found");
                    }

                    MessageObject<T> body = await response.Content.ReadAsAsync<MessageObject<T>>();

                    if (body == null) throw new UsException(response.ReasonPhrase ?? "body is null");
                    if (body.Errors.Count() > 0) throw new UsException(string.Join("\n", body.Errors.Select(e => e.Description).ToList()));
                    if (body.Informations.Count() > 0) throw new UsException(string.Join("\n", body.Errors.Select(e => e.Description).ToList()), UsException.ErrorType.Information);
                    if (body.Warnings.Count() > 0) throw new UsException(string.Join("\n", body.Errors.Select(e => e.Description).ToList()), UsException.ErrorType.Warning);
                    if (body.Data == null) throw new UsException(response.ReasonPhrase ?? "Data is null");
                    return body;
                }
            }
            catch (UsException) { throw; }
        }

        public static async Task<PageObject<T>> CallApi<T>(string baseUrl, string endPoint, QueryObject query)
        {
            int loop = 0;
            try
            {
                await CheckToken();
            repeat:
                using (HttpClient client = Init(baseUrl))
                {
                    HttpResponseMessage response = await client.PostAsJsonAsync(endPoint, query);
                    if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                    {
                        loop++;
                        if (loop >= 3) throw new UsException("Unauthorized");
                        await RefreshToken();
                        if (loop < 3) goto repeat;
                    }
                    else if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
                    {
                        throw new UsException("Data not found");
                    }

                    PageObject<T> body = await response.Content.ReadAsAsync<PageObject<T>>();
                    if (body == null) throw new UsException(response.ReasonPhrase ?? "body is null");
                    return body;
                }
            }
            catch (UsException) { throw; }
        }
    }
}
