﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FBP.Lib.Utilities
{
    public class UsException : Exception
    {
        public enum ErrorType
        {
            Error,
            Warning,
            Information
        }

        private string _Message;
        private ErrorType _Type;

        public override string Message => base.Message ?? _Message;
        public ErrorType Type => _Type;

        public UsException(string message, ErrorType type = ErrorType.Error) : base(message)
        {
            _Message = message;
            _Type = type;
        }

    }
}
