﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace FBP.Lib.VO
{
    public class DefaultSettings
    {
        public static BaseUrl BaseUrl { get; set; } = new BaseUrl();
        public static Dictionary<string, string> HttpHeaders { get; set; } = new Dictionary<string, string>();
        public static UMS.Core.DTOs.TokenDTO Token { get; set; } = new UMS.Core.DTOs.TokenDTO();
    }

    public class BaseUrl
    {
        public string Default { get; set; } = String.Empty;
        public string UMS { get; set; } = String.Empty;
    }    
}