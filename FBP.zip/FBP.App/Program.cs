using Microsoft.Extensions.Configuration;

namespace FBP.App
{
    internal static class Program
    {

        public static IConfiguration Configuration { get; private set; }

        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
            Configuration = builder.Build();

            //// To customize application configuration such as set high DPI settings or default font,
            //// see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            SetDefaultSettings();


            Application.Run(new FBP.App.UI.Systems.frmSysLogin());
        }

        private static void SetDefaultSettings()
        {
            FBP.Lib.VO.DefaultSettings.BaseUrl.Default = Configuration["DefaultSettings:BaseUrl:Default"] ?? "";
            FBP.Lib.VO.DefaultSettings.BaseUrl.UMS = Configuration["DefaultSettings:BaseUrl:UMS"] ?? "";
            FBP.Lib.VO.DefaultSettings.HttpHeaders.Add("Accept", "application/json");
        }
    }
}