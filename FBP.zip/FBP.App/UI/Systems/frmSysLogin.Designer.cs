﻿namespace FBP.App.UI.Systems
{
    partial class frmSysLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPanel1 = new TableLayoutPanel();
            rtxResponse = new RichTextBox();
            panel1 = new Panel();
            btnListPage = new Button();
            btnDisable = new Button();
            btnUpdate = new Button();
            label4 = new Label();
            txtName = new TextBox();
            label3 = new Label();
            txtEmail = new TextBox();
            btnMe = new Button();
            btnLogin = new Button();
            label2 = new Label();
            label1 = new Label();
            txtPassword = new TextBox();
            txtUsername = new TextBox();
            cboLookup = new ComboBox();
            tableLayoutPanel1.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 60F));
            tableLayoutPanel1.Controls.Add(rtxResponse, 1, 0);
            tableLayoutPanel1.Controls.Add(panel1, 0, 0);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.Size = new Size(870, 420);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // rtxResponse
            // 
            rtxResponse.Dock = DockStyle.Fill;
            rtxResponse.Location = new Point(351, 3);
            rtxResponse.Name = "rtxResponse";
            rtxResponse.Size = new Size(516, 414);
            rtxResponse.TabIndex = 1;
            rtxResponse.Text = "";
            // 
            // panel1
            // 
            panel1.Controls.Add(cboLookup);
            panel1.Controls.Add(btnListPage);
            panel1.Controls.Add(btnDisable);
            panel1.Controls.Add(btnUpdate);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(txtName);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(txtEmail);
            panel1.Controls.Add(btnMe);
            panel1.Controls.Add(btnLogin);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(txtPassword);
            panel1.Controls.Add(txtUsername);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(3, 3);
            panel1.Name = "panel1";
            panel1.Size = new Size(342, 414);
            panel1.TabIndex = 0;
            // 
            // btnListPage
            // 
            btnListPage.Location = new Point(237, 296);
            btnListPage.Name = "btnListPage";
            btnListPage.Size = new Size(75, 23);
            btnListPage.TabIndex = 10;
            btnListPage.Text = "List Page";
            btnListPage.UseVisualStyleBackColor = true;
            btnListPage.Click += btnListPage_Click;
            // 
            // btnDisable
            // 
            btnDisable.Location = new Point(156, 267);
            btnDisable.Name = "btnDisable";
            btnDisable.Size = new Size(75, 23);
            btnDisable.TabIndex = 9;
            btnDisable.Text = "Disable";
            btnDisable.UseVisualStyleBackColor = true;
            btnDisable.Click += btnDisable_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.Location = new Point(237, 267);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(75, 23);
            btnUpdate.TabIndex = 8;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(24, 241);
            label4.Name = "label4";
            label4.Size = new Size(39, 15);
            label4.TabIndex = 7;
            label4.Text = "Name";
            // 
            // txtName
            // 
            txtName.Location = new Point(97, 238);
            txtName.Name = "txtName";
            txtName.Size = new Size(215, 23);
            txtName.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(24, 212);
            label3.Name = "label3";
            label3.Size = new Size(36, 15);
            label3.TabIndex = 5;
            label3.Text = "Email";
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(97, 209);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(215, 23);
            txtEmail.TabIndex = 4;
            // 
            // btnMe
            // 
            btnMe.Location = new Point(156, 89);
            btnMe.Name = "btnMe";
            btnMe.Size = new Size(75, 23);
            btnMe.TabIndex = 2;
            btnMe.Text = "Me";
            btnMe.UseVisualStyleBackColor = true;
            btnMe.Click += btnMe_Click;
            // 
            // btnLogin
            // 
            btnLogin.Location = new Point(237, 89);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(75, 23);
            btnLogin.TabIndex = 3;
            btnLogin.Text = "Login";
            btnLogin.UseVisualStyleBackColor = true;
            btnLogin.Click += btnLogin_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(24, 63);
            label2.Name = "label2";
            label2.Size = new Size(57, 15);
            label2.TabIndex = 3;
            label2.Text = "Password";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(24, 34);
            label1.Name = "label1";
            label1.Size = new Size(60, 15);
            label1.TabIndex = 2;
            label1.Text = "Username";
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(97, 60);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(215, 23);
            txtPassword.TabIndex = 1;
            // 
            // txtUsername
            // 
            txtUsername.Location = new Point(97, 31);
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(215, 23);
            txtUsername.TabIndex = 0;
            // 
            // cboLookup
            // 
            cboLookup.DropDownStyle = ComboBoxStyle.DropDownList;
            cboLookup.FormattingEnabled = true;
            cboLookup.Location = new Point(97, 350);
            cboLookup.Name = "cboLookup";
            cboLookup.Size = new Size(215, 23);
            cboLookup.TabIndex = 11;
            // 
            // frmSysLogin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(870, 420);
            Controls.Add(tableLayoutPanel1);
            Name = "frmSysLogin";
            Text = "Login";
            Load += frmSysLogin_Load;
            tableLayoutPanel1.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private RichTextBox rtxResponse;
        private Panel panel1;
        private Button btnLogin;
        private Label label2;
        private Label label1;
        private TextBox txtPassword;
        private TextBox txtUsername;
        private Button btnMe;
        private Label label4;
        private TextBox txtName;
        private Label label3;
        private TextBox txtEmail;
        private Button btnDisable;
        private Button btnUpdate;
        private Button btnListPage;
        private ComboBox cboLookup;
    }
}