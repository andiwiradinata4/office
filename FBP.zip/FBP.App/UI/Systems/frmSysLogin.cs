﻿using FBP.App.SharedLib;
using FBP.Lib.Utilities;
using System.Data;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using UMS.Core.DTOs;
using UMS.Core.Entities;

namespace FBP.App.UI.Systems
{
    public partial class frmSysLogin : Form
    {
        public frmSysLogin()
        {
            InitializeComponent();
        }

        private AppUser clsUser = new AppUser();

        private void frmSysLogin_Load(object sender, EventArgs e)
        {
        }

        private async void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;
                MessageObject<TokenDTO> body =
                    await UsHttpClient.CallApi<TokenDTO>(UsHttpClient.Method.Post,
                    FBP.Lib.VO.DefaultSettings.BaseUrl.UMS,
                    "/api/v1/token/login",
                    new LoginDTO() { Username = txtUsername.Text.Trim(), Password = txtPassword.Text.Trim() });
                UsHttpClient.SetToken(body.Data);
                this.Cursor = Cursors.Default;
                UsForm.ShowMessage("Login Data Success!", "Message", UsException.ErrorType.Information);
            }
            catch (UsException ex)
            {
                UsForm.ShowMessage(ex.Message, "Message", ex.Type);
                return;
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }

        private async void btnMe_Click(object sender, EventArgs e)
        {
            try
            {
                MessageObject<AppUser> body =
                    await UsHttpClient.CallApi<AppUser>(UsHttpClient.Method.Get,
                    FBP.Lib.VO.DefaultSettings.BaseUrl.UMS,
                    "/api/v1/user/me");
                txtEmail.Text = body.Data.Email;
                txtName.Text = body.Data.Name;
                clsUser = body.Data;
                UsForm.ShowMessage("Get Data Success!", "Message", UsException.ErrorType.Information);
            }
            catch (UsException ex)
            {
                UsForm.ShowMessage(ex.Message, "Message", ex.Type);
                return;
            }
        }

        private async void btnUpdate_Click(object sender, EventArgs e)
        {
            if (!UsForm.ShowAskMessage("Update this data?")) return;
            try
            {
                clsUser.Username = "andi.wiradinata";
                clsUser.Email = txtEmail.Text;
                clsUser.Name = txtName.Text;
                clsUser.NormalizedUserName = txtName.Text;
                MessageObject<AppUser> body =
                    await UsHttpClient.CallApi<AppUser>(UsHttpClient.Method.Put,
                    FBP.Lib.VO.DefaultSettings.BaseUrl.UMS,
                    $"/api/v1/user/{clsUser.Id}",
                    clsUser);
                txtEmail.Text = body.Data.Email;
                txtName.Text = body.Data.Name;
                clsUser = body.Data;
                UsForm.ShowMessage("Save Data Success!", "Message", UsException.ErrorType.Information);
            }
            catch (UsException ex)
            {
                UsForm.ShowMessage(ex.Message, "Message", ex.Type);
                return;
            }
        }

        private async void btnDisable_Click(object sender, EventArgs e)
        {
            try
            {
                clsUser.Email = txtEmail.Text;
                clsUser.Name = txtName.Text;
                clsUser.NormalizedUserName = txtName.Text;
                MessageObject<AppUser> body =
                    await UsHttpClient.CallApi<AppUser>(UsHttpClient.Method.Put,
                    FBP.Lib.VO.DefaultSettings.BaseUrl.UMS,
                    $"/api/v1/user/{clsUser.Id}/disable",
                    clsUser);
                txtEmail.Text = body.Data.Email;
                txtName.Text = body.Data.Name;
                clsUser = body.Data;
                UsForm.ShowMessage("Save Data Success!", "Message", UsException.ErrorType.Information);
            }
            catch (UsException ex)
            {
                UsForm.ShowMessage(ex.Message, "Message", ex.Type);
                return;
            }
        }

        private async void btnListPage_Click(object sender, EventArgs e)
        {
            try
            {
                FBP.Lib.VO.PageObject<AppUser> body =
                    await UsHttpClient.CallApi<AppUser>(FBP.Lib.VO.DefaultSettings.BaseUrl.UMS,
                    "/api/v1/user/page-with-disabled",
                    new QueryObject() { Columns = "Id, Username, Name, Email, EmailConfirmed", Page = 0, PageSize = 2 });
                rtxResponse.Text = string.Join("\n", body.DataSet.Select(e => $"{e.Id} {e.Username} {e.Name} {e.Email}").ToList());
                UsForm.FillComboBox<AppUser>(ref cboLookup, body.DataSet, "Id", "Email");
            }
            catch (UsException ex)
            {
                UsForm.ShowMessage(ex.Message, "Message", ex.Type);
                return;
            }
        }
    }
}
