﻿using FBP.Lib.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FBP.App.SharedLib
{
    public static class UsForm
    {
        public static void ShowMessage(string message, string caption = "Message", UsException.ErrorType type = UsException.ErrorType.Error)
        {
            MessageBoxIcon icon = MessageBoxIcon.Error;
            switch (type)
            {
                case UsException.ErrorType.Error: icon = MessageBoxIcon.Error; break;
                case UsException.ErrorType.Information: icon = MessageBoxIcon.Information; break;
                case UsException.ErrorType.Warning: icon = MessageBoxIcon.Warning; break;
            }
            MessageBox.Show(message, caption, MessageBoxButtons.OK, icon);
        }

        public static bool ShowAskMessage(string message, string caption = "Message")
        {
            if (MessageBox.Show(message, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) return true;
            return false;
        }

        public static void FillComboBox<T>(ref ComboBox cbo, List<T> data, string valueMember, string displayMember)
        {
            cbo.Items.Clear();
            cbo.ValueMember = valueMember;
            cbo.DisplayMember = displayMember;
            foreach (var item in data)
            {
                cbo.Items.Add(item);
            }
        }

        
    }
}
