﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UMS.Infrastructure.Interfaces.Services
{
    public interface IClientCredentialService
    {
        Task<TResponse?> GetAsync<TResponse>(string uri, Dictionary<string, string> headers, bool needAuthentication = false);
        Task<TResponse?> PostAsync<TRequest, TResponse>(string uri, Dictionary<string, string> headers, TRequest data, bool needAuthentication = false);
        Task<TResponse?> PutAsync<TRequest, TResponse>(string uri, Dictionary<string, string> headers, TRequest data, bool needAuthentication = false);
        Task<TResponse?> DeleteAsync<TResponse>(string uri, Dictionary<string, string> headers, bool needAuthentication = false);
    }
}
