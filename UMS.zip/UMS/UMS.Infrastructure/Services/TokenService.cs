﻿using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Linq.Dynamic.Core.Tokenizer;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using UMS.Core.Contexts;
using UMS.Core.DTOs;
using UMS.Core.Entities;
using UMS.Infrastructure.Interfaces.Repositories;
using UMS.Infrastructure.Interfaces.Services;
using UMS.Infrastructure.Utils;

namespace UMS.Infrastructure.Services
{
    public class TokenService : BaseService<UMSDbContext, AppToken>, ITokenService
    {
        private readonly SymmetricSecurityKey _key;
        private readonly IConfiguration _configuration;
        private readonly IUserRepository _userRepo;

        public TokenService(IBaseRepository<UMSDbContext, AppToken> repo, IConfiguration configuration, IUserRepository userRepo) : base(repo)
        {
            _configuration = configuration;
            _userRepo = userRepo;
            _key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JWT:SigningKey"] ?? ""));
        }

        public MessageObject<TokenDTO> NewToken(string username, string password)
        {
            UMSDbContext context = base.repo.GetDbContext();
            MessageObject<TokenDTO> message = new MessageObject<TokenDTO>();
            using (var transaction = context.Database.BeginTransaction())
            {
                try
                {
                    var data = _userRepo.GetByConditionAsQueryable(e => e.Username == username);
                    if (data.Count() == 0) throw new Exception("User not yet register");

                    AppUser user = data.First();
                    bool isValid = PasswordHasher.VerifyPassword(password, user.PasswordHash);
                    if (!isValid) throw new Exception("Invalid username and password");
                    if (string.IsNullOrEmpty(user.Id)) throw new Exception("User ID not Valid!");

                    TokenDTO token = GenerateJWTToken(user);
                    var refreshToken = GenerateRefreshToken();
                    var tokenExists = base.repo.GetByConditionAsQueryableWithDisabledRecord(e => e.UserID == user.Id && (e.TokenType == AppToken.TokenTypeValue.LOGIN_TOKEN.ToString() || e.TokenType == AppToken.TokenTypeValue.REFRESH_TOKEN.ToString())).ToList();
                    if (tokenExists.Count > 0) context.RemoveRange(tokenExists);

                    message.Data = new()
                    {
                        UserName = user.Username ?? "",
                        Email = user.Email ?? "",
                        AccessToken = token.AccessToken,
                        ValidFrom = token.ValidFrom,
                        ValidTo = token.ValidTo,
                        RefreshToken = refreshToken,
                        Issuer = _configuration["JWT:Issuer"] ?? "",
                        Audience = _configuration["JWT:Audience"] ?? ""
                    };

                    base.repo.CreateAsync(new AppToken()
                    {
                        UserID = user.Id,
                        TokenType = AppToken.TokenTypeValue.LOGIN_TOKEN.ToString(),
                        TokenValue = message.Data.AccessToken,
                        ValidFrom = message.Data.ValidFrom,
                        ValidTo = message.Data.ValidTo,
                    }, true);

                    base.repo.CreateAsync(new AppToken
                    {
                        UserID = user.Id,
                        TokenType = AppToken.TokenTypeValue.REFRESH_TOKEN.ToString(),
                        TokenValue = refreshToken,
                        ValidFrom = DateTime.Today,
                        ValidTo = DateTime.Today.AddYears(100),
                    }, true);

                    context.SaveChanges();
                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    /// Log Error
                    Console.WriteLine(ex.Message);
                    message.AddException(ex);
                    transaction.Rollback();
                }
            }
            return message;
        }

        public MessageObject<TokenDTO> RefreshToken(string refreshToken)
        {
            UMSDbContext context = base.repo.GetDbContext();
            MessageObject<TokenDTO> message = new MessageObject<TokenDTO>();
            using (var transaction = context.Database.BeginTransaction())
            {
                try
                {
                    var tokenExists = base.repo.GetByConditionAsQueryableWithDisabledRecord(e => e.TokenType == AppToken.TokenTypeValue.REFRESH_TOKEN.ToString() && e.TokenValue == refreshToken);
                    if (tokenExists.Count() == 0) throw new Exception("Invalid refresh token");
                    string nowString = DateTime.Now.ToString("yyyyMMddHHmmss");
                    Int64 nowResult = Convert.ToInt64(DateTime.Now.ToString("yyyyMMddHHmmss"));
                    Int64 expiredResult = Convert.ToInt64(tokenExists.First().ValidTo.ToString("yyyyMMddHHmmss"));

                    if (nowResult > expiredResult) throw new Exception("Refresh token has been expired");

                    var data = _userRepo.GetByConditionAsQueryable(e => e.Id == tokenExists.First().UserID);
                    AppUser user = data.First();
                    if (data.Count() == 0) throw new Exception("User not valid");
                    if (string.IsNullOrEmpty(user.Id)) throw new Exception("User ID not Valid!");

                    TokenDTO newToken = GenerateJWTToken(user);
                    var newRefreshToken = GenerateRefreshToken();
                    var oldTokenExists = base.repo.GetByConditionAsQueryableWithDisabledRecord(e => e.UserID == user.Id && (e.TokenType == AppToken.TokenTypeValue.LOGIN_TOKEN.ToString() || e.TokenType == AppToken.TokenTypeValue.REFRESH_TOKEN.ToString())).ToList();
                    if (oldTokenExists.Count > 0) context.RemoveRange(oldTokenExists);

                    message.Data = new()
                    {
                        UserName = user.Username ?? "",
                        Email = user.Email ?? "",
                        AccessToken = newToken.AccessToken,
                        ValidFrom = newToken.ValidFrom,
                        ValidTo = newToken.ValidTo,
                        RefreshToken = refreshToken,
                        Issuer = _configuration["JWT:Issuer"] ?? "",
                        Audience = _configuration["JWT:Audience"] ?? ""
                    };

                    base.repo.CreateAsync(new AppToken()
                    {
                        UserID = user.Id,
                        TokenType = AppToken.TokenTypeValue.LOGIN_TOKEN.ToString(),
                        TokenValue = newToken.AccessToken,
                        ValidFrom = message.Data.ValidFrom,
                        ValidTo = message.Data.ValidTo,
                    }, true);

                    base.repo.Create(new AppToken
                    {
                        UserID = user.Id,
                        TokenType = AppToken.TokenTypeValue.REFRESH_TOKEN.ToString(),
                        TokenValue = refreshToken,
                        ValidFrom = DateTime.Now,
                        ValidTo = DateTime.Now.AddSeconds(5),
                    }, true);

                    context.SaveChanges();
                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    /// Log Error
                    Console.WriteLine(ex.Message);
                    message.AddException(ex);
                    transaction.Rollback();
                }
            }
            return message;
        }

        private static string GenerateRefreshToken()
        {
            var randomNumber = new byte[64];
            using var rng = RandomNumberGenerator.Create();
            rng.GetBytes(randomNumber);
            return Convert.ToBase64String(randomNumber);
        }

        private TokenDTO GenerateJWTToken(AppUser user)
        {
            var claims = new List<Claim> {
                        new Claim(JwtRegisteredClaimNames.Sub, user.Id ?? ""),
                        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                        new Claim(JwtRegisteredClaimNames.Name, user.Username ?? ""),
                        new Claim(JwtRegisteredClaimNames.Email, user.Email ?? ""),
                        new Claim(JwtRegisteredClaimNames.GivenName, user.Name ?? "")
                    };
            var creds = new SigningCredentials(_key, SecurityAlgorithms.HmacSha512Signature);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims),
                Expires = DateTime.Now.AddMinutes(15000),
                SigningCredentials = creds,
                Issuer = _configuration["JWT:Issuer"],
                Audience = _configuration["JWT:Audience"]
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDescriptor);
            var resultToken = tokenHandler.WriteToken(token);

            TokenDTO tokenDTO = new()
            {
                UserName = user.Username ?? "",
                Email = user.Email ?? "",
                AccessToken = resultToken,
                ValidFrom = token.ValidFrom,
                ValidTo = token.ValidTo,
                RefreshToken = "",
                Issuer = _configuration["JWT:Issuer"] ?? "",
                Audience = _configuration["JWT:Audience"] ?? ""
            };
            return tokenDTO;
        }
    }
}
