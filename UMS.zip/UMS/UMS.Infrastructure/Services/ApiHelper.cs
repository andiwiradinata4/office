﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace UMS.Infrastructure.Services
{
    public class ApiHelper
    {
        //private readonly HttpClient _httpClient;
        //public ApiHelper(HttpClient httpClient)
        //{
        //    _httpClient = httpClient;
        //}

        //public async Task<TResponse?> GetAsync<TResponse>(string url)
        //{
        //    return await CallApi<TResponse>(Method.Get, url, null);
        //}

        //public async Task<TResponse?> PostAsync<TResponse>(string url, object data)
        //{
        //    return await CallApi<TResponse>(Method.Post, url, data);
        //}

        //private async Task<TResponse?> CallApi<TResponse>(Method method, string url, object data)
        //{
        //    var response = await _httpClient.GetAsync(url);
        //    response.EnsureSuccessStatusCode();
        //    var content = await response.Content.ReadAsStringAsync();
        //    return JsonSerializer.Deserialize<TResponse>(content);
        //}


    }
}
