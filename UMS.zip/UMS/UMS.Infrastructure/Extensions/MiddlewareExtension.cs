﻿using Microsoft.AspNetCore.Builder;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UMS.Infrastructure.Middlewares;

namespace UMS.Infrastructure.Extensions
{
    public static class MiddlewareExtension
    {
        public static IApplicationBuilder UsAuthenticationRule(this IApplicationBuilder builder) => builder.UseMiddleware<AuthenticationRule>();
    }
}
