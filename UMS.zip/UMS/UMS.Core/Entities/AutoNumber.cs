﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UMS.Core.Entities
{
    [Table("UMS_sysAutoNumber")]
    public class AutoNumber: BaseEntity
    {
        [StringLength(256)]
        public string Initial { get; set; } = string.Empty;
        [StringLength(256)]
        public string Format { get; set; } = string.Empty;
    }
}
