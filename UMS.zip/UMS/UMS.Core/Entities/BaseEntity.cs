﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UMS.Core.Entities.Interface;

namespace UMS.Core.Entities
{
    public class BaseEntity : BaseEntityCustom, IEntityStandard, IBaseEntityStandard
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
    }
}
