﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UMS.Core.Contexts;
using UMS.Core.DTOs;
using UMS.Core.Entities;
using UMS.Infrastructure.Interfaces.Services;

namespace UMS.Web.Controllers.v1
{
    [Route("api/v1/[controller]")]
    [ApiController]
    public class UserController : BaseController<UMSDbContext, AppUser>
    {
        private readonly IUserService _svc;
        public UserController(IBaseService<UMSDbContext, AppUser> baseSvc, IUserService svc) : base(baseSvc) { _svc = svc; }

        [HttpPost("register")]
        public async Task<IActionResult> Register(AppUser obj)
        {
            if (!base.ModelState.IsValid)
            {
                return BadRequest(base.ModelState);
            }

            MessageObject<AppUser> messageObject = await _svc.CreateAsync(obj);
            if (messageObject.ProcessingStatus)
            {
                return Ok(messageObject);
            }

            return BadRequest(messageObject);
        }
    }
}
