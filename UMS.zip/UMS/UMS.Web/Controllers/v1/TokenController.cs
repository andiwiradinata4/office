﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UMS.Core.Contexts;
using UMS.Core.DTOs;
using UMS.Core.Entities;
using UMS.Infrastructure.Interfaces.Services;

namespace UMS.Web.Controllers.v1
{
    [Route("api/v1/[controller]")]
    [ApiController]
    public class TokenController : BaseController<UMSDbContext, AppToken>
    {
        private readonly ITokenService _svc;
        public TokenController(IBaseService<UMSDbContext, AppToken> baseSvc, ITokenService svc) : base(baseSvc) { _svc = svc; }

        [HttpPost("new")]
        public IActionResult New([FromBody] LoginDTO data)
        {
            MessageObject<TokenDTO> messageObject = _svc.NewToken(data.Username, data.Password);
            if (messageObject.ProcessingStatus)
            {
                return Ok(messageObject);
            }
            return Unauthorized(messageObject);
        }

        [HttpPost("refresh")]
        public IActionResult Refresh()
        {
            MessageObject<TokenDTO> messageObject = new MessageObject<TokenDTO>();
            string? refreshToken = HttpContext.Request.Headers["RefreshToken"];
            if (string.IsNullOrEmpty(refreshToken)) messageObject.AddMessage(new Message(MessageType.Error, "401", "Unauthorized", "RefreshToken"));
            messageObject = _svc.RefreshToken(refreshToken!);
            if (messageObject.ProcessingStatus)
            {
                return Ok(messageObject);
            }
            return Unauthorized(messageObject);
        }
    }
}
