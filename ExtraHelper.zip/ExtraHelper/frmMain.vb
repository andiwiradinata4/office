﻿Imports DevExpress.XtraEditors.Controls


Public Class frmMain

#Region "Var"

    Private Qu1 As String = """"
    Private Qu2 As String = """"""
    Private strFolderName As String = ""
    Private strKeyFolder As String = ""
    Private bolSuccess As Boolean = False
    Private dtDataType As New DataTable
    Private dtDataF3 As New DataTable
    Private clsUserSelection As New VO.UserSelection

#End Region

#Region "Const"

    Const _
        cCheckAll = 0, cUncheckAll = 1, _
        cCheckAllF2 = 0, cUncheckAllF2 = 1, cSep1F2 = 2, cRefreshF2 = 3, _
        cLengthType1 = 1, cLengthType2 = 2, _
        cGenerateF3 = 0, cSep1F3 = 1, cDeleteF3 = 2

#End Region

    Private Sub prvSetIcon()
        UI.usForm.SetToolBar(Me, ToolBar, "0,Checked,1,Unapproved,3,Refresh")
        UI.usForm.SetToolBar(Me, ToolBarGenerateRFCFile, "0,Checked,1,Unapproved,3,Refresh")
        UI.usForm.SetToolBar(Me, ToolBarGenerateRFCFileGenerate, "0,Get")
        UI.usForm.SetToolBar(Me, ToolBarCreateTable, "0,Get,2,Delete")
    End Sub

    Private Sub prvSetGrid()
        '=== F1 ===
        UI.usForm.SetGrid(grdView, "Pick", "Pick", 50, UI.usDefGrid.gBoolean, True, False)
        UI.usForm.SetGrid(grdView, "IsHeader", "IsHeader", 80, UI.usDefGrid.gBoolean, True, False)
        UI.usForm.SetGrid(grdView, "TableName", "Table Name", 700, UI.usDefGrid.gString)

        '=== F2 ===
        UI.usForm.SetGrid(grdServerListView, "Pick", "Pick", 50, UI.usDefGrid.gBoolean, True, False)
        UI.usForm.SetGrid(grdServerListView, "ServerName", "Server", 350, UI.usDefGrid.gString)

        '=== F3 ===
        UI.usForm.SetGrid(grdViewF3, "AutoNumber", "No.", 80, UI.usDefGrid.gIntNum, True, False)
        UI.usForm.SetGrid(grdViewF3, "TableName", "Table Name", 150, UI.usDefGrid.gString, False)
        UI.usForm.SetGrid(grdViewF3, "IsPrimaryKey", "IsPrimaryKey", 50, UI.usDefGrid.gBoolean, True, False)
        UI.usForm.SetGrid(grdViewF3, "ColumnName", "Column Name", 150, UI.usDefGrid.gString, True, False)
        UI.usForm.SetGrid(grdViewF3, "DataType", "Data Type", 80, UI.usDefGrid.gString, True, False)
        UI.usForm.SetGrid(grdViewF3, "Length", "Length", 80, UI.usDefGrid.gString, True, False)
        UI.usForm.SetGrid(grdViewF3, "IsDefault", "IsDefault", 50, UI.usDefGrid.gBoolean, True, False)
        grdViewF3.Columns("TableName").GroupIndex = 0
        grdViewF3.Columns("DataType").ColumnEdit = cboGrdDataTypeF3
        grdViewF3.Columns("AutoNumber").ColumnEdit = rpiAutoNumber
    End Sub

    Private Sub prvSetDefaultServer()
        txtServer.Text = VO.DefaultServer.Server
    End Sub

    Private Sub prvDBMSList()
        VO.DatabaseList.DatabaseList = BL.DatabaseList.ListData(txtServer.Text.Trim)
        'Dim coll As ComboBoxItemCollection = cboDBMS.Properties.Items
        'coll.BeginUpdate()
        'Try
        '    For i As Integer = 0 To VO.DatabaseList.DatabaseList.Rows.Count - 1
        '        coll.Add(New DBMSInfo(Format(i + 1, "000"), VO.DatabaseList.DatabaseList.Rows(i).Item("name")))
        '    Next
        'Catch ex As Exception
        'Finally
        '    coll.EndUpdate()
        'End Try
        'cboDBMS.SelectedIndex = -1

        For Each drDBMS As DataRow In VO.DatabaseList.DatabaseList.Rows
            cboDBMS.Properties.Items.Add(drDBMS.Item("name"))
        Next
        If VO.DatabaseList.DatabaseList.Rows.Count > 0 Then cboDBMS.SelectedIndex = 0
    End Sub

    Private Sub prvReloadTable()
        Try
            grdMain.DataSource = BL.TableList.ListData(txtServer.Text.Trim, cboDBMS.SelectedItem)
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
        prvSetButton()
    End Sub

    Private Sub prvSetButton()
        Dim bolEnable As Boolean = IIf(grdView.RowCount > 0, True, False)
        With ToolBar.Buttons
            .Item(cCheckAll).Enabled = bolEnable
            .Item(cUncheckAll).Enabled = bolEnable
        End With
    End Sub

    Private Sub prvCheckUncheckAll(ByVal bolValue As Boolean)
        With grdView
            For i As Integer = 0 To .RowCount - 1
                .SetRowCellValue(i, "Pick", bolValue)
            Next
            grdMain.Refresh()
            .UpdateCurrentRow()
        End With
    End Sub

    Private Sub prvGenerate()
        Dim intPick As Integer = 0
        Dim bolCanReplace As Boolean = True
        With grdView
            For i As Integer = 0 To .RowCount - 1
                If .GetRowCellValue(i, "Pick") Then
                    intPick += 1
                    If Not .GetRowCellValue(i, "TableName").ToString.Contains(txtReplaceText.Text.Trim) Then
                        bolCanReplace = False
                    End If
                End If

            Next
            If intPick = 0 Then UI.usForm.frmMessageBox("Please pick table name") : Exit Sub

            If bolCanReplace = False Then
                If Not UI.usForm.frmAskQuestion("Selected table names(s) does not contain the text to replace." & vbCrLf & "Do you still want to continue?") Then
                    Exit Sub
                End If
            End If

            If Not UI.usForm.frmAskQuestion("Generate File?") Then Exit Sub

            prvUserSelectionSetup()

            If chkGenerateForm.Checked Then prvGenerateForm()

            If chkGenerateBL.Checked Or chkGenerateDL.Checked Or chkGenerateVO.Checked Then
                _LIB.modGenerateLib.strClassAccessType = IIf(rdPublic.Checked = True, "Public", IIf(rdProtected.Checked = True, "Friend", ""))
                _LIB.modGenerateLib.strFuncAccessType = IIf(rdPublic.Checked = True, "Public", IIf(rdProtected.Checked = True, "Protected Friend", ""))

                If chkGenerateBL.Checked Then prvGenerateBL()

                If chkGenerateDL.Checked Then prvGenerateDL()

                If chkGenerateVO.Checked Then prvGenerateVO()

            End If

            prvCheckUncheckAll(False)

            bolSuccess = True
        End With
    End Sub

    Private Sub prvUserSelectionSetup()
        With clsUserSelection
            .Server = txtServer.Text.Trim
            .Database = cboDBMS.SelectedItem
            .TextToReplace = txtReplaceText.Text.Trim
            If rdFormTypeMaster.Checked Then
                .FormType = VO.UserSelection.eFormType.MasterForm
            Else
                .FormType = VO.UserSelection.eFormType.TransactionForm
            End If
            .IsIncludeStatus = chkTransStatus.Checked
            If rdShareTools.Checked Then
                .ToolType = VO.UserSelection.eToolType.Share
            Else
                .ToolType = VO.UserSelection.eToolType.NotShare
            End If
            If rdPublic.Checked Then
                .AccessType = VO.UserSelection.eAccessType.PublicAccessType
            Else
                .AccessType = VO.UserSelection.eAccessType.ProtectedAccessType
            End If
            .IsGenerateForm = chkGenerateForm.Checked
            .IsGenerateBL = chkGenerateBL.Checked
            .IsGenerateDL = chkGenerateDL.Checked
            .IsGenerateVO = chkGenerateVO.Checked

            If rdSharedConnection.Checked Then
                .ConnectionType = VO.UserSelection.eConnectionType.SharedConnection
            Else
                .ConnectionType = VO.UserSelection.eConnectionType.SelfConnection
            End If
        End With
    End Sub

    Function prvSetUpperCaseFirstLetter(ByVal strVal As String)
        If String.IsNullOrEmpty(strVal) Then
            Return strVal
        End If

        Dim strArray() As Char = strVal.ToCharArray

        strArray(0) = Char.ToUpper(strArray(0))

        Return New String(strArray)
    End Function

    Private Sub prvGenerateForm()
        With grdView
            Dim strFormName1 As String = "", strFormName2 As String = "", intLength As Integer = 0, strFormName As String = "", strDataName As String = ""

            strFolderName = "\Form\"
            UI.usForm.MakeDirectory(strKeyFolder, strFolderName)

            For i As Integer = 0 To .RowCount - 1
                If .GetRowCellValue(i, "Pick") Then
                    intLength = .GetRowCellValue(i, "TableName").ToString.Substring(0, .GetRowCellValue(i, "TableName").ToString.IndexOf("_")).Length + 2
                    strFormName1 = .GetRowCellValue(i, "TableName").ToString.Substring(intLength, .GetRowCellValue(i, "TableName").ToString.Length - (intLength))
                    strFormName2 = .GetRowCellValue(i, "TableName").ToString.Substring(intLength - 1, .GetRowCellValue(i, "TableName").ToString.Length - (intLength - 1)).Substring(0, 1).ToUpper
                    strFormName = "frm" & strFormName2.Trim & strFormName1
                    strDataName = strFormName.Substring(6)

                    If clsUserSelection.FormType = VO.UserSelection.eFormType.MasterForm Then
                        FormMaster.modGenerateFormMaster.pubGenerateFormDesignerHeader(strFormName, strFolderName, strDataName)
                        FormMaster.modGenerateFormMaster.pubGenerateFormVBHeader(strFormName, .GetRowCellValue(i, "TableName"), strFolderName, False, clsUserSelection)
                        FormMaster.modGenerateFormMaster.pubGenerateFormDesignerDetail(strFormName.Trim & "Det", .GetRowCellValue(i, "TableName"), strFolderName, False, strDataName, clsUserSelection)
                        FormMaster.modGenerateFormMaster.pubGenerateFormVBDetail(strFormName.Trim, .GetRowCellValue(i, "TableName"), strFolderName, Replace(.GetRowCellValue(i, "TableName"), txtReplaceText.Text.Trim, ""), False, clsUserSelection)
                    ElseIf clsUserSelection.FormType = VO.UserSelection.eFormType.TransactionForm Then
                        FormTransaction.modGenerateFormTransaction.pubGenerateFormDesignerHeader(strFormName, strFolderName, strDataName)
                        FormTransaction.modGenerateFormTransaction.pubGenerateFormVBHeader(strFormName, .GetRowCellValue(i, "TableName"), strFolderName, False, clsUserSelection)
                        FormTransaction.modGenerateFormTransaction.pubGenerateFormDesignerDetail(strFormName.Trim & "Det", .GetRowCellValue(i, "TableName"), strFolderName, False, strDataName, clsUserSelection)
                        FormTransaction.modGenerateFormTransaction.pubGenerateFormVBDetail(strFormName.Trim, .GetRowCellValue(i, "TableName"), strFolderName, Replace(.GetRowCellValue(i, "TableName"), txtReplaceText.Text.Trim, ""), False, clsUserSelection)
                    End If

                End If
            Next
        End With
    End Sub

    Private Sub prvGenerateBL()
        With grdView
            strFolderName = "\BL\"
            UI.usForm.MakeDirectory(strKeyFolder, strFolderName)
            For i As Integer = 0 To .RowCount - 1
                If .GetRowCellValue(i, "Pick") Then
                    _LIB.modGenerateLib.pubGenerateBL(.GetRowCellValue(i, "TableName"), strFolderName, clsUserSelection, .GetRowCellValue(i, "IsHeader"))
                End If
            Next
        End With
    End Sub

    Private Sub prvGenerateDL()
        With grdView
            strFolderName = "\DL\"
            UI.usForm.MakeDirectory(strKeyFolder, strFolderName)

            For i As Integer = 0 To .RowCount - 1
                If .GetRowCellValue(i, "Pick") Then
                    _LIB.modGenerateLib.pubGenerateDL(.GetRowCellValue(i, "TableName"), strFolderName, clsUserSelection, .GetRowCellValue(i, "IsHeader"))
                End If
            Next
        End With
    End Sub

    Private Sub prvGenerateVO()
        With grdView
            strFolderName = "\VO\"
            UI.usForm.MakeDirectory(strKeyFolder, strFolderName)
            For i As Integer = 0 To .RowCount - 1
                If .GetRowCellValue(i, "Pick") Then
                    _LIB.modGenerateLib.pubGenerateVO(.GetRowCellValue(i, "TableName"), strFolderName, clsUserSelection)
                End If
            Next
        End With
    End Sub

    Private Sub prvGenerateScript()
        Dim frmDetail As New frmScript
        With frmScript
            .pubDBMSName = cboDBMS.SelectedItem
            .pubFolderName = "\Script-RFC"
            .ShowDialog()
            If .pubGenerate Then
                UI.usForm.frmMessageBox("Generate success!")
            End If
        End With
    End Sub

    Private Sub prvSyncColumn(ByVal bolKKPA As Boolean)
        Dim intPick As Integer = 0
        Dim strResult As String = ""
        Dim strDBMS As String = ""
        With grdView
            For i As Integer = 0 To .RowCount - 1
                If .GetRowCellValue(i, "Pick") Then
                    intPick += 1
                End If
            Next

            If intPick = 0 Then UI.usForm.frmMessageBox("Please pick table first") : Exit Sub
            strFolderName = "\Script-SyncColumn"
            UI.usForm.MakeDirectory(strKeyFolder, strFolderName)
            strDBMS = IIf(bolKKPA, "KPA_", "") & cboDBMS.SelectedItem

            strResult = "USE " & strDBMS & vbNewLine
            For i As Integer = 0 To .RowCount - 1
                If .GetRowCellValue(i, "Pick") Then
                    strResult += _
                        SyncDBMS.modSyncDBMS.pubGenerateColumnScipt(.GetRowCellValue(i, "TableName"), clsUserSelection) & vbNewLine & vbNewLine & vbNewLine
                End If
            Next

            For i As Integer = 0 To .RowCount - 1
                If .GetRowCellValue(i, "Pick") Then
                    strResult += _
                       "EXEC GenerateAudittrail '" & .GetRowCellValue(i, "TableName") & "','dbo','_History',0,'" & strDBMS & "_Audit'" & vbNewLine & _
                       "GO" & vbNewLine & vbNewLine
                End If
            Next
            UI.usForm.AppendText_txt(strFolderName, "SyncColumn", ".txt", strResult)
            UI.usForm.frmMessageBox("Generate success.")
        End With
    End Sub

    Private Sub prvSyncTable(ByVal bolKKPA As Boolean)
        Dim intPick As Integer = 0
        Dim strResult As String = ""
        Dim strDBMS As String = ""
        With grdView
            For i As Integer = 0 To .RowCount - 1
                If .GetRowCellValue(i, "Pick") Then
                    intPick += 1
                End If
            Next

            If intPick = 0 Then UI.usForm.frmMessageBox("Please pick table first") : Exit Sub
            strFolderName = "\Script-SyncTable"
            UI.usForm.MakeDirectory(strKeyFolder, strFolderName)
            strDBMS = IIf(bolKKPA, "KPA_", "") & cboDBMS.SelectedItem

            strResult = "USE " & strDBMS & vbNewLine
            For i As Integer = 0 To .RowCount - 1
                If .GetRowCellValue(i, "Pick") Then
                    strResult += _
                        SyncDBMS.modSyncDBMS.pubGenerateTableScipt(.GetRowCellValue(i, "TableName"), clsUserSelection) & vbNewLine & vbNewLine & vbNewLine
                End If
            Next

            'For i As Integer = 0 To .RowCount - 1
            '    If .GetRowCellValue(i, "Pick") Then
            '        strResult += _
            '           "EXEC GenerateAudittrail '" & .GetRowCellValue(i, "TableName") & "','dbo','_History',0,'" & strDBMS & "_Audit'" & vbNewLine & _
            '           "GO" & vbNewLine & vbNewLine
            '    End If
            'Next
            UI.usForm.AppendText_txt(strFolderName, "SyncTable", ".txt", strResult)
            UI.usForm.frmMessageBox("Generate success.")
        End With
    End Sub

    Private Sub prvGetScript()
        Dim intPick As Integer = 0
        Dim strResult As String = ""
        Dim strDBMS As String = ""
        With grdView
            strFolderName = "\Get-Script"
            UI.usForm.MakeDirectory(strKeyFolder, strFolderName)
            strDBMS = cboDBMS.SelectedItem

            GetScript.modGetScript.pubGenerateScipt(strFolderName, clsUserSelection)

            UI.usForm.frmMessageBox("Generate success.")
        End With
    End Sub

    'setup your default here for less startup actions
    Private Sub prvFavDefaultFill()
        cboDBMS.SelectedItem = VO.DefaultFillForm.Database
        txtReplaceText.Text = VO.DefaultFillForm.ReplaceText

        prvReloadTable()
        If VO.DefaultFillForm.SelectedTable.Trim <> "" Then
            With grdView
                For i As Integer = 0 To .RowCount - 1
                    If .GetRowCellValue(i, "TableName") = VO.DefaultFillForm.SelectedTable.Trim Then
                        .SetRowCellValue(i, "Pick", True)
                        Exit For
                    End If
                Next
            End With
        End If

        grdView.RefreshData()

        rdFormTypeTransaction.Checked = False
        rdNotShareTools.Checked = False
        rdProtected.Checked = True

        chkGenerateForm.Checked = False
        chkGenerateBL.Checked = False
        chkGenerateDL.Checked = True
        chkGenerateVO.Checked = False

        'cboDBMS.SelectedItem = "CPS"
        'txtReplaceText.Text = "CPS_mst"

        'prvReloadTable()

        'rdFormTypeTransaction.Checked = True
        'rdNotShareTools.Checked = True
        'rdProtected.Checked = False

        'chkGenerateForm.Checked = True
        'chkGenerateBL.Checked = True
        'chkGenerateDL.Checked = True
        'chkGenerateVO.Checked = True

        clsUserSelection.Server = txtServer.Text.Trim
        clsUserSelection.Database = cboDBMS.Text.Trim
    End Sub

#Region "F2"

    Private Sub prvQueryServerList()
        Try
            grdServerList.DataSource = BL.Server.ServerListForRFC(cboDBMS.Text.Trim)
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
        prvSetButtonF2()
    End Sub

    Private Sub prvCheckUncheckAllGridF2(ByVal bolValue As Boolean)
        With grdServerListView
            For i As Integer = 0 To .RowCount - 1
                .SetRowCellValue(i, "Pick", bolValue)
            Next
            grdServerList.Refresh()
            .UpdateCurrentRow()
        End With
    End Sub

    Private Sub prvGenerateF2()
        txtScript.Focus()
        If txtScript.Text.Trim = "" Then
            UI.usForm.frmMessageBox("Script not allow blank")
            TabHelper.SelectedIndex = 1
            txtScript.Focus()
            Exit Sub
        End If

        Dim dtData As DataTable = grdServerList.DataSource
        Dim drPick() As DataRow = dtData.Select("Pick=true")

        If drPick.Length = 0 Then
            UI.usForm.frmMessageBox("Please pick server first")
            TabHelper.SelectedIndex = 1
            grdServerList.Focus()
            Exit Sub
        End If

        strKeyFolder = Now.Year.ToString & Now.Month.ToString & Now.Day.ToString & Now.Hour.ToString & Now.Minute.ToString & Now.Second.ToString
        strFolderName = "\Script-RFC"

        Try
            UI.usForm.MakeDirectory(strKeyFolder, strFolderName)
            GenerateScript.modGenerateScript.ScriptRFC(txtScript.Text, strFolderName, drPick, cboDBMS.Text.Trim)
            UI.usForm.frmMessageBox("Generate data success...")
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvSetButtonF2()
        Dim bolEnable As Boolean = IIf(grdServerListView.RowCount > 0, True, False)
        With ToolBarGenerateRFCFile.Buttons
            .Item(cCheckAllF2).Enabled = bolEnable
            .Item(cUncheckAllF2).Enabled = bolEnable
        End With
    End Sub

#End Region

#Region "F3"

    Private Sub prvFillDataType()
        dtDataType = BL.DataTypeList.ListData(chkViewAllDataTypeF3.Checked)
        cboDataTypeF3.Properties.Items.Clear()
        cboGrdDataTypeF3.Items.Clear()
        For Each drItem As DataRow In dtDataType.Rows
            cboDataTypeF3.Properties.Items.Add(drItem.Item("name"))
            cboGrdDataTypeF3.Items.Add(drItem.Item("name"))
        Next
        If dtDataType.Rows.Count > 0 Then cboDataTypeF3.SelectedIndex = 0
    End Sub

    Private Function prvCheckDataType(ByVal LengthType As Byte) As Boolean
        Dim bolEnable As Boolean = False
        If LengthType = cLengthType1 Then
            If cboDataTypeF3.Text.Trim = "char" Or cboDataTypeF3.Text.Trim = "decimal" Or _
            cboDataTypeF3.Text.Trim = "numeric" Or cboDataTypeF3.Text.Trim = "nvarchar" Or _
            cboDataTypeF3.Text.Trim = "text" Or cboDataTypeF3.Text.Trim = "varchar" Then
                bolEnable = True
            End If
        ElseIf LengthType = cLengthType2 Then
            If cboDataTypeF3.Text.Trim = "decimal" Or cboDataTypeF3.Text.Trim = "numeric" Then
                bolEnable = True
            End If
        End If
        Return bolEnable
    End Function

    Private Sub prvGenerateTableF3()
        With dtDataF3
            .Columns.Add("AutoNumber", GetType(Integer))
            .Columns.Add("TableName", GetType(String))
            .Columns.Add("ColumnName", GetType(String))
            .Columns.Add("IsPrimaryKey", GetType(Boolean))
            .Columns.Add("DataType", GetType(String))
            .Columns.Add("Length", GetType(String))
            .Columns.Add("IsDefault", GetType(Boolean))
        End With
    End Sub

    Private Function prvCheckExistsF3() As Boolean
        Dim bolExists As Boolean = False
        Dim drItem() As DataRow = dtDataF3.Select("TableName='" & txtTableName.Text.Trim & "' AND ColumnName='" & txtColumnName.Text.Trim & "'")

        If drItem.Length > 0 Then
            bolExists = True
        End If

        Return bolExists
    End Function

    Private Sub prvSetButtonF3()
        Dim bolEnable As Boolean = IIf(grdViewF3.RowCount > 0, True, False)
        With ToolBarCreateTable.Buttons
            .Item(cGenerateF3).Enabled = bolEnable
            .Item(cDeleteF3).Enabled = bolEnable
        End With
    End Sub

    Private Sub prvAddF3()
        If txtTableName.Text.Trim = "" Then
            UI.usForm.frmMessageBox("Table name not allow blank")
            txtTableName.Focus()
            Exit Sub
        ElseIf txtColumnName.Text.Trim = "" Then
            UI.usForm.frmMessageBox("Column name not allow blank")
            txtColumnName.Focus()
            Exit Sub
        ElseIf prvCheckDataType(cLengthType1) And txtLength1F3.EditValue <= 0 Then
            UI.usForm.frmMessageBox("Length must more than zero")
            txtLength1F3.Focus()
            Exit Sub
        ElseIf prvCheckDataType(cLengthType2) And txtLength2F3.EditValue <= 0 Then
            UI.usForm.frmMessageBox("Length must more than zero")
            txtLength2F3.Focus()
            Exit Sub
        ElseIf prvCheckExistsF3() Then
            UI.usForm.frmMessageBox("Data already exists")
            txtColumnName.Focus()
            Exit Sub
        End If

        Dim intCount As Integer = 0
        Dim int As Integer = grdViewF3.DataRowCount
        If grdViewF3.RowCount > 0 Then intCount = grdViewF3.GetRowCellValue(grdViewF3.RowCount - 1, "AutoNumber")

        Dim drItem As DataRow
        drItem = dtDataF3.NewRow
        drItem.BeginEdit()
        drItem.Item("AutoNumber") = grdViewF3.DataRowCount + 1 ' intCount + 1
        drItem.Item("TableName") = txtTableName.Text.Trim
        drItem.Item("IsPrimaryKey") = chkIsPrimaryKey.Checked
        drItem.Item("ColumnName") = txtColumnName.Text.Trim
        drItem.Item("DataType") = cboDataTypeF3.Text.Trim
        drItem.Item("Length") = IIf(prvCheckDataType(cLengthType2), txtLength1F3.EditValue & "," & txtLength2F3.EditValue, IIf(prvCheckDataType(cLengthType1), txtLength1F3.EditValue, ""))
        drItem.Item("IsDefault") = chkSetDefaultF3.Checked
        drItem.EndEdit()
        dtDataF3.Rows.Add(drItem)
        dtDataF3.AcceptChanges()

        grdMainF3.DataSource = dtDataF3
        grdViewF3.ExpandAllGroups()
        grdViewF3.BestFitColumns()

        txtColumnName.Text = ""
        chkIsPrimaryKey.Checked = False
        txtLength1F3.Text = "0"
        txtLength2F3.Text = "0"
        prvSetButtonF3()
    End Sub

    Private Sub prvDeleteItemF3()
        Dim intPos As Integer = grdViewF3.FocusedRowHandle
        Dim dtData As DataTable = grdMainF3.DataSource
        grdViewF3.DeleteRow(intPos)
        dtData.AcceptChanges()
        prvCountGrid()
    End Sub

    Private Sub prvGenerateF3()
        grdViewF3.FocusedRowHandle = DevExpress.XtraGrid.GridControl.AutoFilterRowHandle
        grdViewF3.FocusedColumn = grdView.Columns("TableName")
        grdViewF3.ShowEditor()
        If grdViewF3.RowCount = 0 Then
            UI.usForm.frmMessageBox("Grid item not allow blank")
            Exit Sub
        End If

        If Not UI.usForm.frmAskQuestion("Generate table?") Then Exit Sub

        strKeyFolder = Now.Year.ToString & Now.Month.ToString & Now.Day.ToString & Now.Hour.ToString & Now.Minute.ToString & Now.Second.ToString
        strFolderName = "\Create-Table"

        Try
            UI.usForm.MakeDirectory(strKeyFolder, strFolderName)
            GenerateScript.modGenerateScript.ScriptF3(strFolderName, cboDBMS.Text.Trim, grdMainF3.DataSource)
            UI.usForm.frmMessageBox("Generate success!")
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

    Private Sub prvUpRow()
        With grdViewF3
            Dim intPos As Integer = .FocusedRowHandle
            If intPos > 0 Then
                .SetRowCellValue(intPos, "AutoNumber", .GetRowCellValue(intPos, "AutoNumber") - 1)
                .SetRowCellValue(intPos - 1, "AutoNumber", .GetRowCellValue(intPos - 1, "AutoNumber") + 1)
                prvSortGrid()
            End If
        End With
    End Sub

    Private Sub prvDownRow()
        With grdViewF3
            Dim intPos As Integer = .FocusedRowHandle
            If intPos < .RowCount - 1 Then
                .SetRowCellValue(intPos, "AutoNumber", .GetRowCellValue(intPos, "AutoNumber") + 1)
                .SetRowCellValue(intPos + 1, "AutoNumber", .GetRowCellValue(intPos + 1, "AutoNumber") - 1)
                prvSortGrid()
            End If
        End With
    End Sub

    Private Sub prvCountGrid()
        With grdViewF3
            For i As Integer = 0 To .RowCount - 1
                .SetRowCellValue(i, "AutoNumber", i + 1)
            Next
        End With
    End Sub

    Private Sub prvSortGrid()
        With grdViewF3
            Try
                .ClearSorting()
                .BeginSort()
                .Columns("AutoNumber").SortOrder = DevExpress.Data.ColumnSortOrder.Ascending
            Finally
                .EndSort()
            End Try
        End With
    End Sub

#End Region

#Region "F5"

    Private Sub btnImportExcel_Click(sender As Object, e As EventArgs) Handles btnImportExcel.Click
        With OpenFileImport
            .Title = "Please Select a File"
            .InitialDirectory = "C:temp"
            .Filter = "Excel files (*.xls)|*.xlsx|All files (*.*)|*.*"
            .ShowDialog()
        End With
    End Sub

    Private Sub OpenFileImport_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles OpenFileImport.FileOk
        Try

            Dim dtSubItemImportExcelTemp As New DataTable
            Dim strFilePath As String = OpenFileImport.FileName
            Dim MyConnection As System.Data.OleDb.OleDbConnection
            Dim DtSet As New System.Data.DataSet
            Dim MyCommand As System.Data.OleDb.OleDbDataAdapter
            'MyConnection = New System.Data.OleDb.OleDbConnection("provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & strFilePath & ";Extended Properties=Excel 8.0;")
            MyConnection = New System.Data.OleDb.OleDbConnection("provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & strFilePath & ";Extended Properties=Excel 12.0;")
            MyCommand = New System.Data.OleDb.OleDbDataAdapter("select TableName, TableKey, FieldName, FieldType, FieldLength, DefValue, IsIdentity, StartIdx, IntervalIdx  from [RFC$]", MyConnection)
            MyCommand.TableMappings.Add("Table", "Net-informations.com")
            DtSet = New System.Data.DataSet
            MyCommand.Fill(DtSet)
            dtSubItemImportExcelTemp = DtSet.Tables(0)
            MyConnection.Close()

            'Dim bolNothing As Boolean
            'Dim strNotifNotAvailable As String = ""
            'Dim strNotifNotActive As String = ""
            'Dim strNotifDouble As String = ""
            'Dim strNotifHasBeenUsed As String = ""
            'Dim strNotifSubItemName As String = ""
            'Dim strNotifSubItemCode As String = ""
            'Dim strNotifQuantity As String = ""
            'Dim strSubItemCode As String = "'"

            'Check file excel 
            Dim strDBName As String = cboDBMS.Text.Trim
            Dim strScriptAll As String = "USE " & cboDBMS.Text.Trim & vbCrLf & "GO " & vbCrLf & vbCrLf
            Dim strTableName As String = ""
            Dim strFieldList As String = ""
            Dim strPK As String = ""
            Dim strDefVal As String = ""
            Dim strAuditTrail As String = ""

            Dim intPos As Integer = 0
            With dtSubItemImportExcelTemp
                For Each dtRowA As DataRow In .Rows
                    intPos += 1
                    If Not IsDBNull(dtRowA.Item("TableName")) Then
                        If strTableName = "" Then
                            strTableName = dtRowA.Item("TableName")
                            'strAuditTrail += "EXEC GenerateAudittrail '" & strTableName & "','dbo','_History',0,'" & strDBName & "_Audit'" & vbCrLf & "GO" & vbCrLf

                            If strTableName.Contains("_") Then
                                Dim strCekTableDb As String = strTableName.Substring(0, strTableName.IndexOf("_"))
                                If strCekTableDb <> strDBName Then
                                    If Not UI.usForm.frmAskQuestion("Selected and Specified DBNames are different." & vbCrLf & "Do you still want to continue ?") Then
                                        Exit Sub
                                    End If
                                End If
                            End If
                        Else
                            'COPY TO MASTER & RESET ALL !!!
                            If dtRowA.Item("TableName") <> strTableName Then
                                strAuditTrail += "EXEC GenerateAudittrail '" & strTableName & "','dbo','_History',0,'" & strDBName & "_Audit'" & vbCrLf & "GO" & vbCrLf
                                strScriptAll += _
                                "/****** Object:  Table [dbo].[" & strTableName & "]    Script Date: " & Now.ToString & "******/" & vbCrLf & _
                                "SET ANSI_NULLS ON" & vbCrLf & _
                                "GO" & vbCrLf & _
                                "SET QUOTED_IDENTIFIER ON" & vbCrLf & _
                                "GO" & vbCrLf & _
                                "SET ANSI_PADDING ON" & vbCrLf & _
                                "GO" & vbCrLf & _
                                "CREATE TABLE [dbo].[" & strTableName & "](" & vbCrLf & _
                                strFieldList & vbCrLf & _
                                " CONSTRAINT [PK_" & strTableName & "] PRIMARY KEY CLUSTERED" & vbCrLf & _
                                "(" & vbCrLf & _
                                strPK & vbCrLf & _
                                ")  ON [PRIMARY]" & vbCrLf & _
                                ")  ON [PRIMARY]" & vbCrLf & _
                                "GO" & vbCrLf & _
                                "SET ANSI_PADDING OFF" & vbCrLf & _
                                "GO" & vbCrLf & _
                                "" & vbCrLf & _
                                strDefVal & vbCrLf

                                '====================================
                                strFieldList = ""
                                strPK = ""
                                strDefVal = ""
                                strTableName = dtRowA.Item("TableName")
                            End If
                        End If
                    End If


                    If Not IsDBNull(dtRowA.Item("FieldName")) Then
                        strFieldList += "[" & dtRowA.Item("FieldName") & "] [" & _
                            dtRowA.Item("FieldType") & "] " & _
                            IIf(UCase(dtRowA.Item("FieldType")) = "VARCHAR" Or UCase(dtRowA.Item("FieldType")) = "DECIMAL", "(" & dtRowA.Item("FieldLength") & ") ", "") & _
                            IIf((UCase(dtRowA.Item("FieldType")) = "INT" Or UCase(dtRowA.Item("FieldType")) = "BIGINT" Or UCase(dtRowA.Item("FieldType")) = "DECIMAL") _
                    And Not IsDBNull(dtRowA.Item("IsIdentity")), " IDENTITY (" & IIf(Not IsDBNull(dtRowA.Item("StartIdx")), dtRowA.Item("StartIdx"), 1) & "," & IIf(Not IsDBNull(dtRowA.Item("IntervalIdx")), dtRowA.Item("IntervalIdx"), 1) & ") ", "") & _
                            " NOT NULL, " & vbCrLf
                        If Not IsDBNull(dtRowA.Item("TableKey")) Then
                            strPK += IIf(strPK <> "", ", " & vbCrLf, "") & "[" & dtRowA.Item("FieldName") & "] ASC"
                        Else
                            strDefVal += "ALTER TABLE [dbo].[" & strTableName & "] ADD  CONSTRAINT [DF_" & strTableName & "_" & dtRowA.Item("FieldName") & "]  DEFAULT ("
                            If UCase(dtRowA.Item("FieldType")) = "VARCHAR" Then
                                If IsDBNull(dtRowA.Item("DefValue")) Then
                                    strDefVal += "''"
                                Else
                                    strDefVal += "'" & dtRowA.Item("DefValue") & "'"
                                End If
                            ElseIf UCase(dtRowA.Item("FieldType")) = "DATETIME" Then
                                If IsDBNull(dtRowA.Item("DefValue")) Then
                                    strDefVal += "GETDATE()"
                                Else
                                    strDefVal += "'" & dtRowA.Item("DefValue") & "'"
                                End If
                            Else
                                If IsDBNull(dtRowA.Item("DefValue")) Then
                                    strDefVal += "0"
                                Else
                                    strDefVal += dtRowA.Item("DefValue")
                                End If
                            End If
                            strDefVal += ") FOR [" & dtRowA.Item("FieldName") & "]" & vbCrLf & "GO" & vbCrLf
                        End If
                    End If
                Next

                'FILL IN LAST TABLE INFO
                strAuditTrail += "EXEC GenerateAudittrail '" & strTableName & "','dbo','_History',0,'" & strDBName & "_Audit'" & vbCrLf & "GO" & vbCrLf
                strScriptAll += _
                "/****** Object:  Table [dbo].[" & strTableName & "]    Script Date: " & Now.ToString & "******/" & vbCrLf & _
                "SET ANSI_NULLS ON" & vbCrLf & _
                "GO" & vbCrLf & _
                "SET QUOTED_IDENTIFIER ON" & vbCrLf & _
                "GO" & vbCrLf & _
                "SET ANSI_PADDING ON" & vbCrLf & _
                "GO" & vbCrLf & _
                "CREATE TABLE [dbo].[" & strTableName & "](" & vbCrLf & _
                strFieldList & vbCrLf & _
                " CONSTRAINT [PK_" & strTableName & "] PRIMARY KEY CLUSTERED" & vbCrLf & _
                "(" & vbCrLf & _
                strPK & vbCrLf & _
                ")  ON [PRIMARY]" & vbCrLf & _
                ")  ON [PRIMARY]" & vbCrLf & _
                "GO" & vbCrLf & _
                "SET ANSI_PADDING OFF" & vbCrLf & _
                "GO" & vbCrLf & _
                "" & vbCrLf & _
                strDefVal & vbCrLf
                '*******************************************************************************

                strScriptAll += strAuditTrail
            End With

            'GENERATE NEW TXT FILE
            'Dim strFldrName As String = "E:\Rudy.Handala\SQL\SQL\bin\Debug\Result\"
            Dim strFldrName As String = (".\Result\" & Now.Year.ToString & Now.Month.ToString & Now.Day.ToString & Now.Hour.ToString & Now.Minute.ToString & Now.Second.ToString & " Scripts")
            MkDir(strFldrName)

            Dim strFileName As String = "RFCScript"

            Using w As StreamWriter = File.AppendText(strFldrName & "\" & strFileName & ".txt")
                w.WriteLine(strScriptAll & vbCrLf)
            End Using

            MsgBox("Success export Create Table Script in Folder " & strFldrName)

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub btnCopy_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCopy.Click
        txtResult.SelectAll()
        txtResult.Copy()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtResult.Text = ""
    End Sub

    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        Dim strRawQuery As String = txtResult.Text
        If strRawQuery = "" Then
            MessageBox.Show("No data to process")
            Exit Sub
        Else
            Dim strPart1 As String = ""
            Dim strPart2 As String = ""
            Dim intNextIdx = strRawQuery.IndexOf(".Parameters")

            If intNextIdx > -1 Then 'no-param query
                strPart1 = strRawQuery.Substring(0, intNextIdx)
                strPart2 = strRawQuery.Substring(intNextIdx, strRawQuery.Length - intNextIdx)

                strPart2 = strPart2.Replace("""", "")
                strPart2 = strPart2.Replace(".Parameters.Add(", "DECLARE ")
                strPart2 = strPart2.Replace(", SqlDbType.", " AS ")
                strPart2 = strPart2.Replace("VarChar, ", "VarChar(")
                strPart2 = strPart2.Replace(".Value", " ")

                strPart2 = strPart2.Replace("Int)", "Int ")
                strPart2 = strPart2.Replace("DateTime)", "DateTime ")
                strPart2 = strPart2.Replace("Bit)", "Bit ")
                strPart2 = strPart2.Replace("Decimal)", "Decimal ")
            Else
                strPart1 = strRawQuery
            End If

            strPart1 = strPart1.Replace("""", "")
            strPart1 = strPart1.Replace("& _", "")
            strPart1 = strPart1.Replace("& vbNewLine", "")
            strPart1 = strPart1.Replace("& vbCrLf", "")
            strPart1 = strPart1.Replace("&", "")

            txtResult.Text = IIf(strPart2 <> "", strPart2 & vbCrLf & vbCrLf, "") & strPart1

        End If
    End Sub

    Private Sub btnInsert_Click(sender As Object, e As EventArgs) Handles btnInsert.Click
        Dim strResult As String = txtResult.Text

        strResult = Replace(strResult, vbTab & vbTab, "")

        strResult = Replace(strResult, vbCrLf, " "" & vbNewLine & _" & vbCrLf & """")
        If strResult.Length >= 6 Then
            Dim strCek As String = strResult.Substring(strResult.Length - 6, 6)
            If strResult.Substring(strResult.Length - 6, 6) = "& _" & vbCrLf & """" Then
                txtResult.Text = """" & strResult.Substring(0, strResult.Length - 6)
            Else
                txtResult.Text = """" & strResult & " "" & vbNewLine "
            End If
        Else
            txtResult.Text = """" & strResult & " "" & vbNewLine "
        End If


    End Sub

#End Region

#Region "F6"

    Private Sub prvGetDataExcel()
        Dim strFilePath As String = Application.StartupPath & "\Server.xlsx"

        Using con As New System.Data.OleDb.OleDbConnection
            Try
                con.ConnectionString = "provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & strFilePath & ";Extended Properties=Excel 12.0;"
                'con.ConnectionString = "provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & strFilePath & ";Extended Properties=Excel 8.0;"
                Using cmd As New System.Data.OleDb.OleDbDataAdapter("SELECT DBMS, CompanyID, Server, ServerType FROM [Sheet1$]", con)
                    cmd.TableMappings.Add("Table", "Net-informations.com")
                    Using ds As New System.Data.DataSet
                        cmd.Fill(ds)
                        'dtDataExcelF6 = ds.Tables(0)
                        VO.DefaultServer.AllServers = ds.Tables(0)
                    End Using
                End Using
            Catch ex As Exception
                UI.usForm.frmMessageBox(ex.Message)
            Finally
                cboFormatF6.SelectedIndex = 0
            End Try
        End Using

    End Sub

    Private Sub prvFillCompanyF6()
        '# Filter Data Table Excel, Only Get Company By Selected DBMS
        Dim dtFilter As New DataTable
        Dim drFilter() As DataRow = VO.DefaultServer.AllServers.Select("DBMS='" & cboDBMS.SelectedItem & "'")
        dtFilter = VO.DefaultServer.AllServers.Clone

        '# Generate Row All Company
        If drFilter.Count > 0 Then
            Dim dr As DataRow = dtFilter.NewRow
            dr.BeginEdit()
            dr.Item("CompanyID") = "All Company"
            dr.Item("Server") = "All Server"
            dr.Item("DBMS") = cboDBMS.SelectedItem
            dr.EndEdit()
            dtFilter.Rows.Add(dr)
            dtFilter.AcceptChanges()

            '# Import All Selected Company
            For Each row In drFilter
                dtFilter.ImportRow(row)
            Next

            '# Filter Data Table Excel (KKPA), Only Get Company By Selected DBMS
            drFilter = VO.DefaultServer.AllServers.Select("DBMS='KPA_" & cboDBMS.SelectedItem & "'")
        End If

        '# Fill Selected Copany to ComboBox
        cboCompanyF6.DataSource = dtFilter
        cboCompanyF6.DisplayMember = "CompanyID"
        cboCompanyF6.ValueMember = "Server"
    End Sub

#End Region

#Region "Form Handle"

    Private Sub frmMain_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.F1 Then
            TabHelper.SelectedIndex = 0
        ElseIf e.KeyCode = Keys.F2 Then
            TabHelper.SelectedIndex = 1
        ElseIf e.KeyCode = Keys.F3 Then
            TabHelper.SelectedIndex = 2
        ElseIf e.KeyCode = Keys.F4 Then
            TabHelper.SelectedIndex = 3
        ElseIf e.KeyCode = Keys.F5 Then
            TabHelper.SelectedIndex = 4
        ElseIf e.KeyCode = Keys.F6 Then
            TabHelper.SelectedIndex = 5
        End If
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        '=== Main ===
        prvSetIcon()
        prvSetGrid()
        prvSetButton()
        ProcessLoad()
        prvSetDefaultServer()
        prvDBMSList()

        '=== F2 ===
        prvQueryServerList()

        '=== F3 ===
        'grdViewF3.BestFitColumns()
        prvFillDataType()
        prvGenerateTableF3()
        prvSetButtonF3()

        prvFavDefaultFill()

        '=== F6 ===
        prvGetDataExcel()
        prvFillCompanyF6()
        cboServerTypeF6.SelectedIndex = 0
    End Sub

    Private Sub btnReloadDBMS_Click(sender As Object, e As EventArgs) Handles btnReloadDBMS.Click
        prvDBMSList()
    End Sub

    Private Sub btnReloadTable_Click(sender As Object, e As EventArgs) Handles btnReloadTable.Click
        prvReloadTable()
    End Sub

    Private Sub cboDBMS_KeyDown(sender As Object, e As KeyEventArgs) Handles cboDBMS.KeyDown
        If e.KeyCode = Keys.Enter Then
            prvReloadTable()
        End If
    End Sub

    Private Sub btnGenerate_Click(sender As Object, e As EventArgs) Handles btnGenerate.Click
        If Not chkGenerateForm.Checked And Not chkGenerateBL.Checked And Not chkGenerateDL.Checked And Not chkGenerateVO.Checked Then ' And Not chkGenerateScriptRFC.Checked Then
            UI.usForm.frmMessageBox("Please pick action first")
            Exit Sub
        ElseIf txtReplaceText.Text = "" Then
            If Not UI.usForm.frmAskQuestion("Text to replace is not yet filled in." & vbCrLf & "Do you still want to continue?") Then
                txtReplaceText.Focus()
                Exit Sub
            End If
        End If

        Me.Cursor = Cursors.WaitCursor
        strKeyFolder = Now.Year.ToString & Now.Month.ToString & Now.Day.ToString & Now.Hour.ToString & Now.Minute.ToString & Now.Second.ToString
        If chkGenerateForm.Checked Or chkGenerateBL.Checked Or chkGenerateDL.Checked Or chkGenerateVO.Checked Then
            prvGenerate()
            prvCheckUncheckAll(False)
            If bolSuccess Then UI.usForm.frmMessageBox("Generate success!")
            'ElseIf chkGenerateScriptRFC.Checked Then
            '    prvGenerateScript()
        End If

        Me.Cursor = Cursors.Default
    End Sub

    Private Sub ToolBar_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick
        Select Case e.Button.Text
            Case "Check All" : prvCheckUncheckAll(True)
            Case "Uncheck All" : prvCheckUncheckAll(False)
            Case "Refresh" : prvReloadTable()
        End Select
    End Sub

    Private Sub cboDBMS_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboDBMS.SelectedIndexChanged
        txtReplaceText.Text = cboDBMS.SelectedItem & "_tra"
        clsUserSelection.Server = txtServer.Text.Trim
        clsUserSelection.Database = cboDBMS.Text.Trim
    End Sub

    Public Sub pubRefresh(Optional ByVal strSearch As String = "")
        With grdView
            If Not grdView.FocusedValue Is Nothing And strSearch = "" Then
                strSearch = grdView.GetRowCellValue(grdView.FocusedRowHandle, "TableName")
            End If
            If grdView.RowCount > 0 Then UI.usForm.GridMoveRow(grdView, "TableName", strSearch)
        End With
    End Sub

    Private Sub btnSyncColumn_Click(sender As Object, e As EventArgs) Handles btnSyncColumn.Click
        strKeyFolder = Now.Year.ToString & Now.Month.ToString & Now.Day.ToString & Now.Hour.ToString & Now.Minute.ToString & Now.Second.ToString
        prvSyncColumn(UI.usForm.frmAskQuestion("Sync table KPA?"))
    End Sub

    Private Sub btnSyncTable_Click(sender As Object, e As EventArgs) Handles btnSyncTable.Click
        strKeyFolder = Now.Year.ToString & Now.Month.ToString & Now.Day.ToString & Now.Hour.ToString & Now.Minute.ToString & Now.Second.ToString
        prvSyncTable(UI.usForm.frmAskQuestion("Sync table KPA?"))
    End Sub

    Private Sub btnGetScript_Click(sender As Object, e As EventArgs) Handles btnGetScript.Click
        strKeyFolder = Now.Year.ToString & Now.Month.ToString & Now.Day.ToString & Now.Hour.ToString & Now.Minute.ToString & Now.Second.ToString
        prvGetScript()
    End Sub

    '=== F2 ===
    Private Sub ToolBarGenerateRFCFile_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBarGenerateRFCFile.ButtonClick
        Select Case e.Button.Text
            Case "Check All" : prvCheckUncheckAllGridF2(True)
            Case "Uncheck All" : prvCheckUncheckAllGridF2(False)
            Case "Refresh" : prvQueryServerList()
        End Select
    End Sub

    Private Sub ToolBarGenerateRFCFileGenerate_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBarGenerateRFCFileGenerate.ButtonClick
        prvGenerateF2()
    End Sub

    '=== F3 ===
    Private Sub cboDataTypeF3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboDataTypeF3.SelectedIndexChanged
        txtLength1F3.Enabled = prvCheckDataType(cLengthType1)
        txtLength2F3.Enabled = prvCheckDataType(cLengthType2)
    End Sub

    Private Sub chkViewAllDataTypeF3_CheckedChanged(sender As Object, e As EventArgs) Handles chkViewAllDataTypeF3.CheckedChanged
        prvFillDataType()
    End Sub

    Private Sub btnAddColumnF3_Click(sender As Object, e As EventArgs) Handles btnAddColumnF3.Click
        prvAddF3()
    End Sub

    Private Sub ToolBarCreateTable_ButtonClick(sender As Object, e As ToolBarButtonClickEventArgs) Handles ToolBarCreateTable.ButtonClick
        Select Case e.Button.Text
            Case "Generate" : prvGenerateF3()
            Case "Delete" : prvDeleteItemF3()
        End Select
    End Sub

    Private Sub chkIsPrimaryKey_CheckedChanged(sender As Object, e As EventArgs) Handles chkIsPrimaryKey.CheckedChanged
        chkSetDefaultF3.Enabled = Not chkIsPrimaryKey.Checked
    End Sub

    Private Sub rpiAutoNumber_ButtonClick(sender As Object, e As DevExpress.XtraEditors.Controls.ButtonPressedEventArgs) Handles rpiAutoNumber.ButtonClick
        Select Case e.Button.Index
            Case 0 : prvUpRow()
            Case 1 : prvDownRow()
        End Select
    End Sub

    Private Sub rpiAutoNumber_KeyPress(sender As Object, e As KeyPressEventArgs) Handles rpiAutoNumber.KeyPress
        If Not Char.IsNumber(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub btnExecuteConvert_Click(sender As Object, e As EventArgs) Handles btnExecuteConvert.Click
        If txtValueToConvert_F4.Text.Trim = "" Then
            UI.usForm.frmMessageBox("Value to Convert not allow blank")
            txtValueToConvert_F4.Focus()
            Exit Sub
        End If
        Dim strResult As String = ""
        If cboConvertType.SelectedIndex = 0 Then
            strResult = Converter.ConvertTo(Converter.ConvertType.SQLQueriesToVB_NET, txtValueToConvert_F4.Text.Trim)
        ElseIf cboConvertType.SelectedIndex = 1 Then
            strResult = Converter.ConvertTo(Converter.ConvertType.SQLQueriesToCSharp, txtValueToConvert_F4.Text.Trim)
        ElseIf cboConvertType.SelectedIndex = 2 Then
            strResult = Converter.ConvertTo(Converter.ConvertType.VB_NETToSQLQueries, txtValueToConvert_F4.Text.Trim)
        ElseIf cboConvertType.SelectedIndex = 3 Then
            strResult = Converter.ConvertTo(Converter.ConvertType.CSharpToSQLQueries, txtValueToConvert_F4.Text.Trim)
        End If

        txtResultConvert_F4.Text = strResult
    End Sub

    Private Sub rdFormTypeTransaction_CheckedChanged(sender As Object, e As EventArgs) Handles rdFormTypeTransaction.CheckedChanged
        If rdFormTypeTransaction.Checked Then
            chkTransStatus.Enabled = True
            chkTransStatus.Checked = True
        Else
            chkTransStatus.Enabled = False
            chkTransStatus.Checked = False
        End If
    End Sub

    '=== F6 ===
    Private Sub btnReloadCompanyF6_Click(sender As Object, e As EventArgs) Handles btnReloadCompanyF6.Click
        prvFillCompanyF6()
    End Sub

    Private Sub btnExecuteF6_Click(sender As Object, e As EventArgs) Handles btnExecuteF6.Click
        Try
            grdMainF6.DataSource = Nothing
            grdViewMainF6.Columns.Clear()
            If rtbQueryF6.Text.Trim = "" Then UI.usForm.frmMessageBox("Please fill query first") : rtbQueryF6.Focus() : Exit Sub
            If cboCompanyF6.SelectedIndex = -1 Then UI.usForm.frmMessageBox("Please select company first") : cboCompanyF6.Focus() : Exit Sub
            If cboServerTypeF6.SelectedIndex = -1 Then UI.usForm.frmMessageBox("Please select server type first") : cboCompanyF6.Focus() : Exit Sub
            Me.Cursor = Cursors.WaitCursor
            grdMainF6.DataSource = BL.TableList.ExecuteScriptF6(cboCompanyF6.SelectedItem, rtbQueryF6.Text.Trim, cboServerTypeF6.Text.Trim)
            grdViewMainF6.BestFitColumns()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message, "Execute Scripts")
        Finally
            Me.Cursor = Cursors.Default
        End Try
    End Sub

    Private Sub btnExportToExcelF6_Click(sender As Object, e As EventArgs) Handles btnExportToExcelF6.Click
        If grdViewMainF6.RowCount = 0 Then UI.usForm.frmMessageBox("Data is empty") : Exit Sub

        Dim sharedLib As New SharedLib.ExcelExporter
        Dim format As New SharedLib.ExcelExporter.Format

        If cboFormatF6.SelectedIndex = 0 Then
            format = ExtraHelper.SharedLib.ExcelExporter.Format.xls
        ElseIf cboFormatF6.SelectedIndex = 1 Then
            format = ExtraHelper.SharedLib.ExcelExporter.Format.xlsx
        End If

        Dim strFileName As String = cboDBMS.SelectedText.Trim & "_"
        If cboCompanyF6.SelectedItem.Row.Item("CompanyID") = "All Company" Then
            strFileName += "AllCompany"
        Else
            strFileName += cboCompanyF6.SelectedItem.Row.Item("CompanyID")
        End If
        sharedLib.ExportToExcel(Me, grdMainF6, strFileName, "Sheet1", , , , , format)
    End Sub

#End Region

End Class