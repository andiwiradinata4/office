﻿
Class DBMSInfo

    Private _p1 As String
    Private _p2 As String

    Sub New(p1 As String, p2 As String)
        ' TODO: Complete member initialization 
        _p1 = p1
        _p2 = p2
    End Sub

End Class
