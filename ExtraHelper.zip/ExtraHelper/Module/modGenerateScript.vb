﻿Namespace GenerateScript
    Module modGenerateScript
        Public Sub ScriptRFC(ByVal strScriptRFC As String, ByVal strFolderName As String, ByVal drServer() As DataRow, ByVal strDBMSName As String)
            Dim dtServerName As New DataTable
            Dim strFileName As String = ""
            Dim intCount As Integer = 0
            Try
                For Each drItem As DataRow In drServer
                    strFileName = Format(intCount + 1, "00") & ". " & drItem.Item("ServerName") & "_" & strDBMSName
                    UI.usForm.AppendText_txt(strFolderName, strFileName, ".txt", strScriptRFC)
                    intCount += 1
                Next

                strFileName = "Description" & "_" & strDBMSName
                strScriptRFC = _
                    "Database to update : " & strDBMSName & vbNewLine & _
                    "Server to update : " & vbNewLine

                intCount = 0
                For Each drItem As DataRow In drServer
                    strScriptRFC += _
                         intCount + 1 & IIf(intCount + 1 <= 9, ".  ", ". ") & drItem.Item("ServerName") & vbNewLine
                    intCount += 1
                Next

                strScriptRFC += _
                    "Program affected : " & strDBMSName & vbNewLine & _
                    "Description :" & vbNewLine & _
                    "- " & vbNewLine

                UI.usForm.AppendText_txt(strFolderName, strFileName, ".txt", strScriptRFC)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

#Region "F3"

        Private Function DataTypeF3(ByVal strDataType As String, ByVal strLength As String) As String
            Dim strResult As String = ""
            If strDataType.Trim = "decimal" Or strDataType.Trim = "numeric" Or strDataType.Trim = "varchar" Or _
                strDataType.Trim = "char" Or strDataType.Trim = "nvarchar" Then
                strResult = "[" & strDataType & "] " & "(" & strLength & ") "
            Else
                strResult = "[" & strDataType & "] "
            End If
            Return strResult
        End Function

        Private Function GenerateColumnF3(ByVal dvColumn As DataView) As String
            Dim strResult As String = ""

            For Each dvCol As DataRowView In dvColumn
                strResult += _
                    "	[" & dvCol("ColumnName") & "] " & _
                    DataTypeF3(dvCol("DataType"), dvCol("Length")) & _
                    IIf(dvCol("IsPrimaryKey"), "NOT NULL", IIf(dvCol("IsDefault"), " NOT NULL", " NULL")) & "," & vbNewLine
            Next

            Return strResult
        End Function

        Private Function GeneratePKF3(ByVal dvColumn As DataView) As String
            Dim strResult As String = ""
            Dim dtData As DataTable = dvColumn.ToTable
            Dim drColumn() As DataRow = dtData.Select("IsPrimaryKey=True")

            For i As Integer = 0 To drColumn.Length - 1
                strResult += "  [" & drColumn(i).Item("ColumnName") & "] ASC" & IIf(i = drColumn.Length - 1, "", ",") & vbNewLine
            Next

            Return strResult
        End Function

        Private Function GenerateDefaultDataTypeF3(ByVal strDataType As String, ByVal strColumnName As String) As String
            Dim strResult As String = ""
            Select Case strDataType.Trim
                Case "text", "uniqueidentifier", "nvarchar" : strResult = "''"
                Case "date", "smalldatetime", "datetime" : strResult = IIf(strColumnName.Trim = "LogDate" Or strColumnName.Trim = "CreatedDate", "GETDATE()", "'2000/01/01'")
                Case "tinyint", "smallint", "int", "money", "bit", "decimal", "numeric", "smallmoney", "bigint" : strResult = "(0)"
                Case "varchar", "char" : strResult = IIf(strColumnName.Trim = "LogBy" Or strColumnName.Trim = "CreatedBy", "'SYSTEM'", "''")
                Case Else
                    strResult = ""
            End Select
            Return strResult
        End Function

        Private Function GenerateDefaultConstraint(ByVal dvColumn As DataView) As String
            Dim strResult As String = ""
            Dim dtData As DataTable = dvColumn.ToTable
            Dim drColumn() As DataRow = dtData.Select("IsDefault=True")

            For Each drCol As DataRow In drColumn
                strResult += _
                    "ALTER TABLE [dbo].[" & drCol("TableName") & "] ADD  CONSTRAINT [DF_" & drCol("TableName") & "_" & drCol("ColumnName") & "]  DEFAULT (" & GenerateDefaultDataTypeF3(drCol("DataType"), drCol("ColumnName")) & ") FOR [" & drCol("ColumnName") & "]" & vbNewLine & _
                    "GO" & vbNewLine & vbNewLine
            Next

            Return strResult
        End Function

        Public Sub ScriptF3(ByVal strFolderName As String, ByVal strDBMSName As String, ByVal dtData As DataTable)
            Dim strFileName As String = "", strTableName As String = "", strScript As String = ""
            Dim intCount As Integer = 0
            Dim clsHelper As New DataSetHelper
            Dim dtTable As New DataTable
            Dim dvColumn As New DataView(dtData)

            dtTable = clsHelper.SelectGroupByInto("TableName", dtData, "TableName", "", "TableName")
            Try
                For Each drItem As DataRow In dtTable.Rows
                    strTableName = drItem.Item("TableName")
                    dvColumn.RowFilter = "TableName='" & strTableName & "'"
                    strScript = _
                        "USE [" & strDBMSName.Trim & "]" & vbNewLine & _
                        "GO" & vbNewLine & vbNewLine & _
                        "/****** Object:  Table [dbo].[" & strTableName & "]    Script Date: " & Now & " ******/" & vbNewLine & _
                        "SET ANSI_NULLS ON" & vbNewLine & _
                        "GO" & vbNewLine & _
                        "" & vbNewLine & _
                        "SET QUOTED_IDENTIFIER ON" & vbNewLine & _
                        "GO" & vbNewLine & _
                        "" & vbNewLine & _
                        "SET ANSI_PADDING ON" & vbNewLine & _
                        "GO" & vbNewLine & _
                        "" & vbNewLine & _
                        "CREATE TABLE [dbo].[" & strTableName & "](" & vbNewLine

                    strScript += GenerateColumnF3(dvColumn)

                    strScript += _
                        " CONSTRAINT [PK_" & strTableName & "] PRIMARY KEY CLUSTERED " & vbNewLine & _
                        "(" & vbNewLine

                    strScript += GeneratePKF3(dvColumn)

                    strScript += _
                        ")WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]" & vbNewLine & _
                        ") ON [PRIMARY]" & vbNewLine & _
                        "" & vbNewLine & _
                        "GO " & vbNewLine & _
                        "" & vbNewLine & _
                        "SET ANSI_PADDING OFF" & vbNewLine & _
                        "GO" & vbNewLine & _
                        "" & vbNewLine

                    strScript += GenerateDefaultConstraint(dvColumn)

                    strScript += _
                        "EXEC GenerateAudittrail '" & strTableName & "','dbo','_History',0,'" & strDBMSName & "_Audit'" & vbNewLine & _
                        "GO " & vbNewLine & vbNewLine

                    strFileName = strTableName
                    UI.usForm.AppendText_txt(strFolderName, strFileName, ".txt", strScript)
                Next
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

#End Region


    End Module
End Namespace

