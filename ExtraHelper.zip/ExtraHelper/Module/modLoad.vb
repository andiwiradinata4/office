﻿Module modLoad
    Public Sub ProcessLoad()
        Dim bolReturn As Boolean = False
        Dim strXML As String = Application.StartupPath & "\ExtraHelper-CONFIG.XML"
        If Not IO.File.Exists(strXML) Then
            UI.usForm.frmMessageBox("XML File Not Found ... ")
            Exit Sub
        End If
        Dim xmlHandle As New usXML(strXML)
        With xmlHandle
            VO.DefaultServer.Server = .GetConfigInfo("CONNECTION", "SERVER", ".").Item(1)
            VO.DefaultServer.Database = .GetConfigInfo("CONNECTION", "DATABASE", ".").Item(1)

            'Default Fill Form
            VO.DefaultFillForm.Database = .GetConfigInfo("DEFAULTFILLFORM", "DATABASE", "ABSNEWNE").Item(1)
            VO.DefaultFillForm.ReplaceText = .GetConfigInfo("DEFAULTFILLFORM", "REPLACETEXT", "_").Item(1)
            VO.DefaultFillForm.SelectedTable = .GetConfigInfo("DEFAULTFILLFORM", "SELECTEDTABLE", "").Item(1)
        End With
    End Sub
End Module
