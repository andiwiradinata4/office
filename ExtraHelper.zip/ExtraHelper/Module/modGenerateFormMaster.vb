﻿Namespace FormMaster

    Module modGenerateFormMaster

        Public Sub pubGenerateFormDesignerHeader(ByVal strFormName As String, ByVal strFolderName As String, ByVal strDataName As String)
            Dim strValue As String = ""
            strValue = _
                "<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _" & vbNewLine & _
                "Partial Class " & strFormName & vbNewLine & _
                "    Inherits System.Windows.Forms.Form" & vbNewLine & _
                "" & vbNewLine & _
                "    'Form overrides dispose to clean up the component list." & vbNewLine & _
                "    <System.Diagnostics.DebuggerNonUserCode()> _" & vbNewLine & _
                "    Protected Overrides Sub Dispose(ByVal disposing As Boolean)" & vbNewLine & _
                "        Try" & vbNewLine & _
                "            If disposing AndAlso components IsNot Nothing Then" & vbNewLine & _
                "                components.Dispose()" & vbNewLine & _
                "            End If" & vbNewLine & _
                "        Finally" & vbNewLine & _
                "            MyBase.Dispose(disposing)" & vbNewLine & _
                "        End Try" & vbNewLine & _
                "    End Sub" & vbNewLine & _
                "" & vbNewLine & _
                "    'Required by the Windows Form Designer" & vbNewLine & _
                "    Private components As System.ComponentModel.IContainer" & vbNewLine & _
                "" & vbNewLine & _
                "    'NOTE: The following procedure is required by the Windows Form Designer" & vbNewLine & _
                "    'It can be modified using the Windows Form Designer.  " & vbNewLine & _
                "    'Do not modify it using the code editor." & vbNewLine & _
                "    <System.Diagnostics.DebuggerStepThrough()> _" & vbNewLine & _
                "    Private Sub InitializeComponent()" & vbNewLine & _
                "        Me.ToolBar = New System.Windows.Forms.ToolBar()" & vbNewLine & _
                "        Me.BarGet = New System.Windows.Forms.ToolBarButton()" & vbNewLine & _
                "        Me.BarSep1 = New System.Windows.Forms.ToolBarButton()" & vbNewLine & _
                "        Me.BarNew = New System.Windows.Forms.ToolBarButton()" & vbNewLine & _
                "        Me.BarDetail = New System.Windows.Forms.ToolBarButton()" & vbNewLine & _
                "        Me.BarDelete = New System.Windows.Forms.ToolBarButton()" & vbNewLine & _
                "        Me.BarSep2 = New System.Windows.Forms.ToolBarButton()" & vbNewLine & _
                "        Me.BarRefresh = New System.Windows.Forms.ToolBarButton()" & vbNewLine & _
                "        Me.BarClose = New System.Windows.Forms.ToolBarButton()" & vbNewLine & _
                "        Me.grdMain = New DevExpress.XtraGrid.GridControl()" & vbNewLine & _
                "        Me.grdView = New DevExpress.XtraGrid.Views.Grid.GridView()" & vbNewLine & _
                "        CType(Me.grdMain, System.ComponentModel.ISupportInitialize).BeginInit()" & vbNewLine & _
                "        CType(Me.grdView, System.ComponentModel.ISupportInitialize).BeginInit()" & vbNewLine & _
                "        Me.SuspendLayout()" & vbNewLine & _
                "        '" & vbNewLine & _
                "        'ToolBar" & vbNewLine & _
                "        '" & vbNewLine & _
                "        Me.ToolBar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat" & vbNewLine & _
                "        Me.ToolBar.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.BarGet, Me.BarSep1, Me.BarNew, Me.BarDetail, Me.BarDelete, Me.BarSep2, Me.BarRefresh, Me.BarClose})" & vbNewLine & _
                "        Me.ToolBar.DropDownArrows = True" & vbNewLine & _
                "        Me.ToolBar.Location = New System.Drawing.Point(0, 0)" & vbNewLine & _
                "        Me.ToolBar.Name = " & """ToolBar""" & vbNewLine & _
                "        Me.ToolBar.ShowToolTips = True" & vbNewLine & _
                "        Me.ToolBar.Size = New System.Drawing.Size(984, 28)" & vbNewLine & _
                "        Me.ToolBar.TabIndex = 0" & vbNewLine & _
                "        Me.ToolBar.TextAlign = System.Windows.Forms.ToolBarTextAlign.Right" & vbNewLine & _
                "        '" & vbNewLine & _
                "        'BarGet" & vbNewLine & _
                "        '" & vbNewLine & _
                "        Me.BarGet.Name = " & """BarGet""" & vbNewLine & _
                "        Me.BarGet.Text = " & """Get""" & vbNewLine & _
                "        '" & vbNewLine & _
                "        'BarSep1" & vbNewLine & _
                "        '" & vbNewLine & _
                "        Me.BarSep1.Name = " & """BarSep1""" & vbNewLine & _
                "        Me.BarSep1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator" & vbNewLine & _
                "        '" & vbNewLine & _
                "        'BarNew" & vbNewLine & _
                "        '" & vbNewLine & _
                "        Me.BarNew.Name = " & """BarNew""" & vbNewLine & _
                "        Me.BarNew.Text = " & """New""" & vbNewLine & _
                "        '" & vbNewLine & _
                "        'BarDetail" & vbNewLine & _
                "        '" & vbNewLine & _
                "        Me.BarDetail.Name = " & """BarDetail""" & vbNewLine & _
                "        Me.BarDetail.Text = " & """Detail""" & vbNewLine & _
                "        '" & vbNewLine & _
                "        'BarDelete" & vbNewLine & _
                "        '" & vbNewLine & _
                "        Me.BarDelete.Name = " & """BarDelete""" & vbNewLine & _
                "        Me.BarDelete.Text = " & """Delete""" & vbNewLine & _
                "        '" & vbNewLine & _
                "        'BarSep2" & vbNewLine & _
                "        '" & vbNewLine & _
                "        Me.BarSep2.Name = " & """BarSep2""" & vbNewLine & _
                "        Me.BarSep2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator" & vbNewLine & _
                "        '" & vbNewLine & _
                "        'BarRefresh" & vbNewLine & _
                "        '" & vbNewLine & _
                "        Me.BarRefresh.Name = " & """BarRefresh""" & vbNewLine & _
                "        Me.BarRefresh.Text = " & """Refresh""" & vbNewLine & _
                "        '" & vbNewLine & _
                "        'BarClose" & vbNewLine & _
                "        '" & vbNewLine & _
                "        Me.BarClose.Name = " & """BarClose""" & vbNewLine & _
                "        Me.BarClose.Text = " & """Close""" & vbNewLine & _
                "        '" & vbNewLine & _
                "        'grdMain" & vbNewLine & _
                "        '" & vbNewLine & _
                "        Me.grdMain.Dock = System.Windows.Forms.DockStyle.Fill" & vbNewLine & _
                "        Me.grdMain.EmbeddedNavigator.Buttons.Append.Enabled = False" & vbNewLine & _
                "        Me.grdMain.EmbeddedNavigator.Buttons.Append.Visible = False" & vbNewLine & _
                "        Me.grdMain.EmbeddedNavigator.Buttons.CancelEdit.Enabled = False" & vbNewLine & _
                "        Me.grdMain.EmbeddedNavigator.Buttons.CancelEdit.Visible = False" & vbNewLine & _
                "        Me.grdMain.EmbeddedNavigator.Buttons.Edit.Enabled = False" & vbNewLine & _
                "        Me.grdMain.EmbeddedNavigator.Buttons.Edit.Visible = False" & vbNewLine & _
                "        Me.grdMain.EmbeddedNavigator.Buttons.EndEdit.Enabled = False" & vbNewLine & _
                "        Me.grdMain.EmbeddedNavigator.Buttons.EndEdit.Visible = False" & vbNewLine & _
                "        Me.grdMain.EmbeddedNavigator.Buttons.NextPage.Enabled = False" & vbNewLine & _
                "        Me.grdMain.EmbeddedNavigator.Buttons.NextPage.Visible = False" & vbNewLine & _
                "        Me.grdMain.EmbeddedNavigator.Buttons.PrevPage.Enabled = False" & vbNewLine & _
                "        Me.grdMain.EmbeddedNavigator.Buttons.PrevPage.Visible = False" & vbNewLine & _
                "        Me.grdMain.EmbeddedNavigator.Buttons.Remove.Enabled = False" & vbNewLine & _
                "        Me.grdMain.EmbeddedNavigator.Buttons.Remove.Visible = False" & vbNewLine & _
                "        Me.grdMain.Location = New System.Drawing.Point(0, 28)" & vbNewLine & _
                "        Me.grdMain.MainView = Me.grdView" & vbNewLine & _
                "        Me.grdMain.Name = " & """grdMain""" & vbNewLine & _
                "        Me.grdMain.Size = New System.Drawing.Size(984, 584)" & vbNewLine & _
                "        Me.grdMain.TabIndex = 1" & vbNewLine & _
                "        Me.grdMain.UseEmbeddedNavigator = True" & vbNewLine & _
                "        Me.grdMain.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.grdView})" & vbNewLine & _
                "        '" & vbNewLine & _
                "        'grdView" & vbNewLine & _
                "        '" & vbNewLine & _
                "        Me.grdView.GridControl = Me.grdMain" & vbNewLine & _
                "        Me.grdView.Name = " & """grdView""" & vbNewLine & _
                "        Me.grdView.OptionsCustomization.AllowColumnMoving = False" & vbNewLine & _
                "        Me.grdView.OptionsCustomization.AllowGroup = False" & vbNewLine & _
                "        Me.grdView.OptionsView.ColumnAutoWidth = False" & vbNewLine & _
                "        Me.grdView.OptionsView.ShowAutoFilterRow = True" & vbNewLine & _
                "        Me.grdView.OptionsView.ShowGroupPanel = False" & vbNewLine & _
                "        '" & vbNewLine & _
                "        '" & strFormName.Trim & vbNewLine & _
                "        '" & vbNewLine & _
                "        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)" & vbNewLine & _
                "        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font" & vbNewLine & _
                "        Me.ClientSize = New System.Drawing.Size(984, 612)" & vbNewLine & _
                "        Me.Controls.Add(Me.grdMain)" & vbNewLine & _
                "        Me.Controls.Add(Me.ToolBar)" & vbNewLine & _
                "        Me.Font = New System.Drawing.Font(" & """Tahoma""" & ", 8.25!)" & vbNewLine & _
                "        Me.KeyPreview = True" & vbNewLine & _
                "        Me.Name = """ & strFormName.Trim & """" & vbNewLine & _
                "        Me.Text = """ & strDataName.Trim & """" & vbNewLine & _
                "        CType(Me.grdMain, System.ComponentModel.ISupportInitialize).EndInit()" & vbNewLine & _
                "        CType(Me.grdView, System.ComponentModel.ISupportInitialize).EndInit()" & vbNewLine & _
                "        Me.ResumeLayout(False)" & vbNewLine & _
                "        Me.PerformLayout()" & vbNewLine & _
                "" & vbNewLine & _
                "    End Sub" & vbNewLine & _
                "    Friend WithEvents ToolBar As System.Windows.Forms.ToolBar" & vbNewLine & _
                "    Friend WithEvents BarGet As System.Windows.Forms.ToolBarButton" & vbNewLine & _
                "    Friend WithEvents BarSep1 As System.Windows.Forms.ToolBarButton" & vbNewLine & _
                "    Friend WithEvents BarNew As System.Windows.Forms.ToolBarButton" & vbNewLine & _
                "    Friend WithEvents BarDetail As System.Windows.Forms.ToolBarButton" & vbNewLine & _
                "    Friend WithEvents BarDelete As System.Windows.Forms.ToolBarButton" & vbNewLine & _
                "    Friend WithEvents BarSep2 As System.Windows.Forms.ToolBarButton" & vbNewLine & _
                "    Friend WithEvents BarRefresh As System.Windows.Forms.ToolBarButton" & vbNewLine & _
                "    Friend WithEvents BarClose As System.Windows.Forms.ToolBarButton" & vbNewLine & _
                "    Friend WithEvents grdMain As DevExpress.XtraGrid.GridControl" & vbNewLine & _
                "    Friend WithEvents grdView As DevExpress.XtraGrid.Views.Grid.GridView" & vbNewLine & _
                "End Class" & vbNewLine & _
                "" & vbNewLine

            UI.usForm.AppendText_txt(strFolderName, strFormName, ".Designer.vb", strValue)
        End Sub

        Public Sub pubGenerateFormVBHeader(ByVal strFormName As String, ByVal strTableName As String, ByVal strFolderName As String, ByVal bolUseParentTools As Boolean, ByVal cls As VO.UserSelection)
            Dim strScript As String = ""
            strScript = _
                "Public Class " & strFormName & vbNewLine & _
                "" & vbNewLine & _
                "    Public pubLUdtRow As DataRow" & vbNewLine & _
                "    Public pubIsLookUp As Boolean = False" & vbNewLine & _
                "    Public pubIsLookUpGet As Boolean = False" & vbNewLine & _
                "" & vbNewLine

            strScript += FormFunction.modGenerateFormFunction.FunctPrivateConst(0, cls)

            strScript += _
                "    Private intPos As Integer" & vbNewLine & _
                "" & vbNewLine

            strScript += FormFunction.modGenerateFormFunction.FunctSetIcon(0, cls)

            strScript += FormFunction.modGenerateFormFunction.FunctUserAccess(False, cls) & vbNewLine

            strScript += FormFunction.modGenerateFormFunction.FunctSetTittleForm(False)

            strScript += FormFunction.modGenerateFormFunction.FunctSetGrid(strTableName, cls)

            strScript += FormFunction.modGenerateFormFunction.FunctQuery(strTableName, cls)

            strScript += FormFunction.modGenerateFormFunction.FunctSetButton(cls)

            strScript += FormFunction.modGenerateFormFunction.FunctGet()

            strScript += FormFunction.modGenerateFormFunction.FunctNew(strTableName, strFormName & "Det", cls)

            strScript += FormFunction.modGenerateFormFunction.FunctDetail(strTableName, strFormName & "Det", cls)

            strScript += FormFunction.modGenerateFormFunction.FunctDelete(strTableName, Replace(strTableName, cls.TextToReplace, ""), cls)

            strScript += FormFunction.modGenerateFormFunction.FunctRefresh(strTableName, cls)

            strScript += _
                "#Region " & """Form Handle""" & vbNewLine & vbNewLine

            strScript += FormHandle.modGenerateFormHandle.FunctFormLoad(strFormName, False, bolUseParentTools, cls)

            strScript += FormHandle.modGenerateFormHandle.FunctFormKeyDown(strFormName, False, cls)

            strScript += FormHandle.modGenerateFormHandle.FunctToolBarButton(False, cls)

            strScript += FormHandle.modGenerateFormHandle.FunctGridRowStyle(cls)

            strScript += FormHandle.modGenerateFormHandle.FuncGridDoubleClick()

            strScript += _
                "#End Region " & vbNewLine

            strScript += _
                "" & vbNewLine & _
                "End Class" & vbNewLine & _
                "" & vbNewLine

            UI.usForm.AppendText_txt(strFolderName, strFormName, ".vb", strScript)
        End Sub

        Public Sub pubGenerateFormDesignerDetail(ByVal strFormName As String, ByVal strTableName As String, ByVal strFolderName As String, ByVal bolUseParentTools As Boolean, ByVal strDataName As String, ByVal cls As VO.UserSelection)
            Dim strValue As String = ""
            Dim intCount As Integer = 0
            VO.ColumnList.ColumnList = BL.ColumnList.ListData(strTableName, cls)
            strValue = _
                "<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _" & vbNewLine & _
                "Partial Class " & strFormName & vbNewLine & _
                "    Inherits System.Windows.Forms.Form" & vbNewLine & _
                "" & vbNewLine & _
                "    'Form overrides dispose to clean up the component list." & vbNewLine & _
                "    <System.Diagnostics.DebuggerNonUserCode()> _" & vbNewLine & _
                "    Protected Overrides Sub Dispose(ByVal disposing As Boolean)" & vbNewLine & _
                "        Try" & vbNewLine & _
                "            If disposing AndAlso components IsNot Nothing Then" & vbNewLine & _
                "                components.Dispose()" & vbNewLine & _
                "            End If" & vbNewLine & _
                "        Finally" & vbNewLine & _
                "            MyBase.Dispose(disposing)" & vbNewLine & _
                "        End Try" & vbNewLine & _
                "    End Sub" & vbNewLine & _
                "" & vbNewLine & _
                "    'Required by the Windows Form Designer" & vbNewLine & _
                "    Private components As System.ComponentModel.IContainer" & vbNewLine & _
                "" & vbNewLine & _
                "    'NOTE: The following procedure is required by the Windows Form Designer" & vbNewLine & _
                "    'It can be modified using the Windows Form Designer.  " & vbNewLine & _
                "    'Do not modify it using the code editor." & vbNewLine & _
                "    <System.Diagnostics.DebuggerStepThrough()> _" & vbNewLine & _
                "    Private Sub InitializeComponent()" & vbNewLine & _
                "        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(" & strFormName & "))" & vbNewLine

            If Not bolUseParentTools Then
                strValue += _
                "        Me.ToolBar = New System.Windows.Forms.ToolBar()" & vbNewLine & _
                "        Me.BarSave = New System.Windows.Forms.ToolBarButton()" & vbNewLine & _
                "        Me.BarClose = New System.Windows.Forms.ToolBarButton()" & vbNewLine & _
                "        Me.lblInfo = New System.Windows.Forms.Label()" & vbNewLine
            End If

            strValue += _
                "        Me.StatusStrip = New System.Windows.Forms.StatusStrip()" & vbNewLine & _
                "        Me.ToolStripEmpty = New System.Windows.Forms.ToolStripStatusLabel()" & vbNewLine & _
                "        Me.ToolStripLogInc = New System.Windows.Forms.ToolStripStatusLabel()" & vbNewLine & _
                "        Me.ToolStripLogBy = New System.Windows.Forms.ToolStripStatusLabel()" & vbNewLine & _
                "        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()" & vbNewLine & _
                "        Me.ToolStripLogDate = New System.Windows.Forms.ToolStripStatusLabel()" & vbNewLine & _
                "        Me.pnlDetail = New System.Windows.Forms.Panel()" & vbNewLine

            Dim bolHasStatus As Boolean = False
            For Each drColumn As DataRow In VO.ColumnList.ColumnList.Rows
                Dim strCName As String = drColumn.Item("ColumnName")
                Dim strCType As String = drColumn.Item("DataType")

                If strCName.Trim <> "IsSync" And strCName.Trim <> "CreateBy" And strCName.Trim <> "CreateDate" And _
                    strCName.Trim <> "CreatedBy" And strCName.Trim <> "CreatedDate" And _
                    strCName.Trim <> "LogBy" And strCName.Trim <> "LogDate" And strCName.Trim <> "LogInc" Then

                    strValue += _
                        "        Me.lbl" & strCName.Trim & " = New System.Windows.Forms.Label()" & vbNewLine

                    If strCName.Trim = "Status" And (strCType.Trim = "tinyint" Or strCType.Trim = "smallint" Or strCType.Trim = "int" Or strCType.Trim = "bit") Then
                        strValue += _
                            "        Me.cbo" & strCName.Trim & " = New DevExpress.XtraEditors.ComboBoxEdit()" & vbNewLine
                        bolHasStatus = True
                    ElseIf strCType.Trim = "date" Or strCType.Trim = "datetime2" Or strCType.Trim = "smalldatetime" Or strCType.Trim = "datetime" Then
                        strValue += _
                            "        Me.dtp" & strCName.Trim & " = New System.Windows.Forms.DateTimePicker()" & vbNewLine
                    Else
                        strValue += _
                            "        Me.txt" & strCName.Trim & " = New usTextBox()" & vbNewLine
                    End If
                End If
            Next

            strValue += _
            "        Me.StatusStrip.SuspendLayout()" & vbNewLine & _
            "        Me.pnlDetail.SuspendLayout()" & vbNewLine

            If bolHasStatus Then
                strValue += _
            "        CType(Me.cboStatus.Properties, System.ComponentModel.ISupportInitialize).BeginInit()" & vbNewLine
            End If

            strValue += _
            "        Me.SuspendLayout()" & vbNewLine

            If Not bolUseParentTools Then
                strValue += _
            "        '" & vbNewLine & _
            "        'ToolBar" & vbNewLine & _
            "        '" & vbNewLine & _
            "        Me.ToolBar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat" & vbNewLine & _
            "        Me.ToolBar.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.BarSave, Me.BarClose})" & vbNewLine & _
            "        Me.ToolBar.DropDownArrows = True" & vbNewLine & _
            "        Me.ToolBar.Font = New System.Drawing.Font(" & """Tahoma""" & ", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))" & vbNewLine & _
            "        Me.ToolBar.Location = New System.Drawing.Point(0, 0)" & vbNewLine & _
            "        Me.ToolBar.Name = " & """ToolBar""" & vbNewLine & _
            "        Me.ToolBar.ShowToolTips = True" & vbNewLine & _
            "        Me.ToolBar.Size = New System.Drawing.Size(484, 28)" & vbNewLine & _
            "        Me.ToolBar.TabIndex = 0" & vbNewLine & _
            "        Me.ToolBar.TextAlign = System.Windows.Forms.ToolBarTextAlign.Right" & vbNewLine & _
            "        '" & vbNewLine & _
            "        'BarSave" & vbNewLine & _
            "        '" & vbNewLine & _
            "        Me.BarSave.Name = " & """BarSave""" & vbNewLine & _
            "        Me.BarSave.Text = " & """Save""" & vbNewLine & _
            "        '" & vbNewLine & _
            "        'BarClose" & vbNewLine & _
            "        '" & vbNewLine & _
            "        Me.BarClose.Name = " & """BarClose""" & vbNewLine & _
            "        Me.BarClose.Text = " & """Close""" & vbNewLine & _
            "        '" & vbNewLine & _
            "        'lblInfo" & vbNewLine & _
            "        '" & vbNewLine & _
            "        Me.lblInfo.BackColor = System.Drawing.Color.CadetBlue" & vbNewLine & _
            "        Me.lblInfo.Dock = System.Windows.Forms.DockStyle.Top" & vbNewLine & _
            "        Me.lblInfo.Font = New System.Drawing.Font(" & """Tahoma""" & ", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))" & vbNewLine & _
            "        Me.lblInfo.ForeColor = System.Drawing.Color.White" & vbNewLine & _
            "        Me.lblInfo.Location = New System.Drawing.Point(0, 28)" & vbNewLine & _
            "        Me.lblInfo.Name = " & """lblInfo""" & vbNewLine & _
            "        Me.lblInfo.Size = New System.Drawing.Size(484, 22)" & vbNewLine & _
            "        Me.lblInfo.TabIndex = 1" & vbNewLine & _
            "        Me.lblInfo.Text = """ & "« " & strDataName & """" & vbNewLine & _
            "        Me.lblInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft" & vbNewLine
            End If


            strValue += _
            "        '" & vbNewLine & _
            "        'StatusStrip" & vbNewLine & _
            "        '" & vbNewLine & _
            "        Me.StatusStrip.Font = New System.Drawing.Font(" & """Tahoma""" & ", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))" & vbNewLine & _
            "        Me.StatusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripEmpty, Me.ToolStripLogInc, Me.ToolStripLogBy, Me.ToolStripStatusLabel1, Me.ToolStripLogDate})" & vbNewLine & _
            "        Me.StatusStrip.Location = New System.Drawing.Point(0, 320)" & vbNewLine & _
            "        Me.StatusStrip.Name = " & """StatusStrip""" & vbNewLine & _
            "        Me.StatusStrip.Size = New System.Drawing.Size(484, 22)" & vbNewLine & _
            "        Me.StatusStrip.TabIndex = 0" & vbNewLine & _
            "        Me.StatusStrip.Text = " & """StatusStrip1""" & vbNewLine & _
            "        '" & vbNewLine & _
            "        'ToolStripEmpty" & vbNewLine & _
            "        '" & vbNewLine & _
            "        Me.ToolStripEmpty.Name = " & """ToolStripEmpty""" & vbNewLine & _
            "        Me.ToolStripEmpty.Size = New System.Drawing.Size(361, 17)" & vbNewLine & _
            "        Me.ToolStripEmpty.Spring = True" & vbNewLine & _
            "        '" & vbNewLine & _
            "        'ToolStripLogInc" & vbNewLine & _
            "        '" & vbNewLine & _
            "        Me.ToolStripLogInc.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _" & vbNewLine & _
            "            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _" & vbNewLine & _
            "            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)" & vbNewLine & _
            "        Me.ToolStripLogInc.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter" & vbNewLine & _
            "        Me.ToolStripLogInc.Name = " & """ToolStripLogInc""" & vbNewLine & _
            "        Me.ToolStripLogInc.Size = New System.Drawing.Size(48, 17)" & vbNewLine & _
            "        Me.ToolStripLogInc.Text = " & """Log Inc : """ & vbNewLine & _
            "        '" & vbNewLine & _
            "        'ToolStripLogBy" & vbNewLine & _
            "        '" & vbNewLine & _
            "        Me.ToolStripLogBy.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _" & vbNewLine & _
            "            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _" & vbNewLine & _
            "            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)" & vbNewLine & _
            "        Me.ToolStripLogBy.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter" & vbNewLine & _
            "        Me.ToolStripLogBy.Name = " & """ToolStripLogBy""" & vbNewLine & _
            "        Me.ToolStripLogBy.Size = New System.Drawing.Size(48, 17)" & vbNewLine & _
            "        Me.ToolStripLogBy.Text = " & """Last Log :""" & vbNewLine & _
            "        '" & vbNewLine & _
            "        'ToolStripStatusLabel1" & vbNewLine & _
            "        '" & vbNewLine & _
            "        Me.ToolStripStatusLabel1.Name = " & """ToolStripStatusLabel1""" & vbNewLine & _
            "        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(0, 17)" & vbNewLine & _
            "        '" & vbNewLine & _
            "        'ToolStripLogDate" & vbNewLine & _
            "        '" & vbNewLine & _
            "        Me.ToolStripLogDate.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _" & vbNewLine & _
            "            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _" & vbNewLine & _
            "            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)" & vbNewLine & _
            "        Me.ToolStripLogDate.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter" & vbNewLine & _
            "        Me.ToolStripLogDate.Name = " & """ToolStripLogDate""" & vbNewLine & _
            "        Me.ToolStripLogDate.Size = New System.Drawing.Size(12, 17)" & vbNewLine & _
            "        Me.ToolStripLogDate.Text = " & """-""" & vbNewLine & _
            "        '" & vbNewLine & _
            "        'pnlDetail" & vbNewLine & _
            "        '" & vbNewLine & _
            "        Me.pnlDetail.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D" & vbNewLine

            For Each drColumn As DataRow In VO.ColumnList.ColumnList.Rows
                Dim strCName As String = drColumn.Item("ColumnName")
                Dim strCType As String = drColumn.Item("DataType")

                If strCName.Trim <> "IsSync" And strCName.Trim <> "CreateBy" And strCName.Trim <> "CreateDate" And _
                    strCName.Trim <> "LogBy" And strCName.Trim <> "LogDate" And strCName.Trim <> "LogInc" And _
                    strCName.Trim <> "CreatedBy" And strCName.Trim <> "CreatedDate" Then

                    strValue += _
                        "        Me.pnlDetail.Controls.Add(Me.lbl" & strCName & ")" & vbNewLine

                    If strCName.Trim = "Status" And (strCType.Trim = "tinyint" Or strCType.Trim = "smallint" Or strCType.Trim = "int" Or strCType.Trim = "bit") Then
                        strValue += _
                            "        Me.pnlDetail.Controls.Add(Me.cbo" & strCName & ")" & vbNewLine

                    ElseIf strCType.Trim = "date" Or strCType.Trim = "datetime2" Or strCType.Trim = "smalldatetime" Or strCType.Trim = "datetime" Then
                        strValue += _
                            "        Me.pnlDetail.Controls.Add(Me.dtp" & strCName.Trim & ")" & vbNewLine
                    Else
                        strValue += _
                            "        Me.pnlDetail.Controls.Add(Me.txt" & strCName.Trim & ")" & vbNewLine
                    End If
                End If
            Next

            strValue += _
                "        Me.pnlDetail.Dock = System.Windows.Forms.DockStyle.Fill" & vbNewLine & _
                "        Me.pnlDetail.Location = New System.Drawing.Point(0, 50)" & vbNewLine & _
                "        Me.pnlDetail.Name = """ & "pnlDetail""" & vbNewLine & _
                "        Me.pnlDetail.Size = New System.Drawing.Size(484, 290)" & vbNewLine & _
                "        Me.pnlDetail.TabIndex = 2" & vbNewLine

            Dim intPoint As Integer = 18, intTabIndex As Integer = 0, intHeight As Integer = 0, intWidth As Integer = 0, _
                intAllHeight As Integer = 0
            For Each drColumn As DataRow In VO.ColumnList.ColumnList.Rows
                Dim strCName As String = drColumn.Item("ColumnName")
                Dim strCType As String = drColumn.Item("DataType")

                If drColumn.Item("MaxLength") >= 50 Then
                    intWidth = 300
                    intHeight = 60
                Else
                    intWidth = 160
                    intHeight = 21
                End If


                If strCName.Trim <> "IsSync" And strCName.Trim <> "CreateBy" And strCName.Trim <> "CreateDate" And _
                    strCName.Trim <> "LogBy" And strCName.Trim <> "LogDate" And strCName.Trim <> "LogInc" And _
                    strCName.Trim <> "CreatedBy" And strCName.Trim <> "CreatedDate" Then
                    strValue += _
                        "        '" & vbNewLine & _
                        "        'lbl" & strCName & vbNewLine & _
                        "        '" & vbNewLine & _
                        "        Me.lbl" & strCName & ".AutoSize = True" & vbNewLine & _
                        "        Me.lbl" & strCName & ".BackColor = System.Drawing.Color.Transparent" & vbNewLine & _
                        "        Me.lbl" & strCName & ".ForeColor = System.Drawing.Color.Black" & vbNewLine & _
                        "        Me.lbl" & strCName & ".Location = New System.Drawing.Point(20, " & intPoint & ")" & vbNewLine & _
                        "        Me.lbl" & strCName & ".Name = """ & "lbl" & strCName & """" & vbNewLine & _
                        "        Me.lbl" & strCName & ".Size = New System.Drawing.Size(84, 13)" & vbNewLine & _
                        "        Me.lbl" & strCName & ".TabIndex = 93" & vbNewLine & _
                        "        Me.lbl" & strCName & ".Text = """ & strCName & """" & vbNewLine

                    If strCName.Trim = "Status" And (strCType.Trim = "tinyint" Or strCType.Trim = "smallint" Or strCType.Trim = "int" Or strCType.Trim = "bit") Then
                        strValue += _
                            "        '" & vbNewLine & _
                            "        'cboStatus" & vbNewLine & _
                            "        '" & vbNewLine & _
                            "        Me.cboStatus.EditValue = """ & "ACTIVE""" & vbNewLine & _
                            "        Me.cboStatus.Location = New System.Drawing.Point(112, " & intPoint - 3 & ")" & vbNewLine & _
                            "        Me.cboStatus.Name = """ & "cboStatus""" & vbNewLine & _
                            "        Me.cboStatus.Properties.Appearance.BackColor = System.Drawing.Color.White" & vbNewLine & _
                            "        Me.cboStatus.Properties.Appearance.Options.UseBackColor = True" & vbNewLine & _
                            "        Me.cboStatus.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})" & vbNewLine & _
                            "        Me.cboStatus.Properties.Items.AddRange(New Object() {" & """ACTIVE" & """, ""IN-ACTIVE""})" & vbNewLine & _
                            "        Me.cboStatus.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor" & vbNewLine & _
                            "        Me.cboStatus.Size = New System.Drawing.Size(98, 20)" & vbNewLine & _
                            "        Me.cboStatus.TabIndex = " & intTabIndex & vbNewLine

                    ElseIf strCType.Trim = "date" Or strCType.Trim = "datetime2" Or strCType.Trim = "smalldatetime" Or strCType.Trim = "datetime" Then
                        strValue += _
                            "        '" & vbNewLine & _
                            "        'dtp" & strCName & vbNewLine & _
                            "        '" & vbNewLine & _
                            "        Me.dtp" & strCName & ".CustomFormat = ""dd/MM/yyyy""" & vbNewLine & _
                            "        Me.dtp" & strCName & ".Enabled = False" & vbNewLine & _
                            "        Me.dtp" & strCName & ".Font = New System.Drawing.Font(""Tahoma"", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))" & vbNewLine & _
                            "        Me.dtp" & strCName & ".Format = System.Windows.Forms.DateTimePickerFormat.Custom" & vbNewLine & _
                            "        Me.dtp" & strCName & ".Location = New System.Drawing.Point(112, " & intPoint - 3 & ")" & vbNewLine & _
                            "        Me.dtp" & strCName & ".Name = """ & "dtp" & strCName & """" & vbNewLine & _
                            "        Me.dtp" & strCName & ".Size = New System.Drawing.Size(101, 21)" & vbNewLine & _
                            "        Me.dtp" & strCName & ".TabIndex = " & intTabIndex & vbNewLine & _
                            "        Me.dtp" & strCName & ".Value = New Date(2019, 5, 1, 0, 0, 0, 0)" & vbNewLine

                    Else
                        strValue += _
                            "        '" & vbNewLine & _
                            "        'txt" & strCName & vbNewLine & _
                            "        '" & vbNewLine & _
                            "        Me.txt" & strCName & ".BackColor = System.Drawing.Color." & IIf(drColumn.Item("PrimaryKey"), "LightYellow", "White") & vbNewLine & _
                            "        Me.txt" & strCName & ".CharacterCasing = System.Windows.Forms.CharacterCasing.Upper" & vbNewLine & _
                            "        Me.txt" & strCName & ".Location = New System.Drawing.Point(112, " & intPoint - 3 & ")" & vbNewLine & _
                            "        Me.txt" & strCName & ".MaxLength = 250" & vbNewLine & _
                            "        Me.txt" & strCName & ".Multiline = " & IIf(drColumn.Item("MaxLength") >= 50, "True", "False") & vbNewLine & _
                            "        Me.txt" & strCName & ".Name = """ & "txt" & strCName & """" & vbNewLine & _
                            "        Me.txt" & strCName & ".ReadOnly = " & IIf(drColumn.Item("PrimaryKey"), "True", "False") & vbNewLine & _
                            "        Me.txt" & strCName & ".Size = New System.Drawing.Size(" & intWidth & "," & intHeight & ")" & vbNewLine & _
                            "        Me.txt" & strCName & ".TabIndex = " & intTabIndex & vbNewLine

                    End If

                    intPoint += intHeight + 10
                    intTabIndex += 1
                    intAllHeight += intHeight + 10
                End If

            Next

            strValue += _
                "        Me.pnlDetail.Dock = System.Windows.Forms.DockStyle.Fill" & vbNewLine & _
                "        Me.pnlDetail.Location = New System.Drawing.Point(0, 50)" & vbNewLine & _
                "        Me.pnlDetail.Name = " & """pnlDetail""" & vbNewLine & _
                "        Me.pnlDetail.Size = New System.Drawing.Size(484, 270)" & vbNewLine & _
                "        Me.pnlDetail.TabIndex = 2" & vbNewLine & _
                "        '" & vbNewLine & _
                "        '" & strFormName & vbNewLine & _
                "        '" & vbNewLine & _
                "        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)" & vbNewLine & _
                "        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font" & vbNewLine & _
                "        Me.ClientSize = New System.Drawing.Size(484, " & intAllHeight + 105 & ")" & vbNewLine & _
                "        Me.Controls.Add(Me.pnlDetail)" & vbNewLine & _
                "        Me.Controls.Add(Me.StatusStrip)" & vbNewLine

            If Not bolUseParentTools Then
                strValue += _
                "        Me.Controls.Add(Me.lblInfo)" & vbNewLine & _
                "        Me.Controls.Add(Me.ToolBar)" & vbNewLine
            End If

            strValue += _
                "        Me.Font = New System.Drawing.Font(" & """Tahoma""" & ", 8.25!)" & vbNewLine & _
                "        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle" & vbNewLine & _
                "        Me.KeyPreview = True" & vbNewLine & _
                "        Me.MaximizeBox = False" & vbNewLine & _
                "        Me.MinimizeBox = False" & vbNewLine & _
                "        Me.Name = """ & strFormName & """" & vbNewLine & _
                "        Me.Text = """ & strDataName & """" & vbNewLine & _
                "        Me.StatusStrip.ResumeLayout(False)" & vbNewLine & _
                "        Me.StatusStrip.PerformLayout()" & vbNewLine & _
                "        Me.pnlDetail.ResumeLayout(False)" & vbNewLine & _
                "        Me.pnlDetail.PerformLayout()" & vbNewLine & _
                "        'CType(Me.cboStatus.Properties, System.ComponentModel.ISupportInitialize).EndInit()" & vbNewLine & _
                "        Me.ResumeLayout(False)" & vbNewLine & _
                "        Me.PerformLayout()" & vbNewLine & _
                "" & vbNewLine & _
                "    End Sub" & vbNewLine

            If Not bolUseParentTools Then
                strValue += _
                "    Friend WithEvents ToolBar As System.Windows.Forms.ToolBar" & vbNewLine & _
                "    Friend WithEvents BarSave As System.Windows.Forms.ToolBarButton" & vbNewLine & _
                "    Friend WithEvents BarClose As System.Windows.Forms.ToolBarButton" & vbNewLine & _
                "    Friend WithEvents lblInfo As System.Windows.Forms.Label" & vbNewLine

            End If

            strValue += _
                "    Friend WithEvents StatusStrip As System.Windows.Forms.StatusStrip" & vbNewLine & _
                "    Friend WithEvents ToolStripEmpty As System.Windows.Forms.ToolStripStatusLabel" & vbNewLine & _
                "    Friend WithEvents ToolStripLogInc As System.Windows.Forms.ToolStripStatusLabel" & vbNewLine & _
                "    Friend WithEvents ToolStripLogBy As System.Windows.Forms.ToolStripStatusLabel" & vbNewLine & _
                "    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel" & vbNewLine & _
                "    Friend WithEvents ToolStripLogDate As System.Windows.Forms.ToolStripStatusLabel" & vbNewLine & _
                "    Friend WithEvents pnlDetail As System.Windows.Forms.Panel" & vbNewLine

            For Each drColumn As DataRow In VO.ColumnList.ColumnList.Rows
                Dim strCName As String = drColumn.Item("ColumnName")
                Dim strCType As String = drColumn.Item("DataType")

                If strCName.Trim <> "IsSync" And strCName.Trim <> "CreateBy" And strCName.Trim <> "CreateDate" And _
                    strCName.Trim <> "LogBy" And strCName.Trim <> "LogDate" And strCName.Trim <> "LogInc" And _
                    strCName.Trim <> "CreatedBy" And strCName.Trim <> "CreatedDate" Then

                    strValue += _
                        "    Friend WithEvents lbl" & strCName.Trim & " AS System.Windows.Forms.Label" & vbNewLine

                    If strCName.Trim = "Status" And (strCType.Trim = "tinyint" Or strCType.Trim = "smallint" Or strCType.Trim = "int" Or strCType.Trim = "bit") Then
                        strValue += _
                            "    Friend WithEvents cbo" & strCName.Trim & " AS DevExpress.XtraEditors.ComboBoxEdit" & vbNewLine
                        bolHasStatus = True
                    ElseIf strCType.Trim = "date" Or strCType.Trim = "datetime2" Or strCType.Trim = "smalldatetime" Or strCType.Trim = "datetime" Then
                        strValue += _
                            "    Friend WithEvents dtp" & strCName.Trim & " AS System.Windows.Forms.DateTimePicker" & vbNewLine
                    Else
                        strValue += _
                            "    Friend WithEvents txt" & strCName.Trim & " AS usTextBox" & vbNewLine
                    End If
                End If
            Next

            strValue += _
                "End Class" & vbNewLine & _
                "" & vbNewLine

            UI.usForm.AppendText_txt(strFolderName, strFormName, ".Designer.vb", strValue)
        End Sub

        Public Sub pubGenerateFormVBDetail(ByVal strFormName As String, ByVal strTableName As String, ByVal strFolderName As String, ByVal strFileName As String, ByVal bolUseParentTools As Boolean, ByVal cls As VO.UserSelection)
            Dim strScript As String = ""
            Dim frmFormNameOri As String = strFormName
            strFormName = strFormName & "Det"
            Dim dtColumnPK As New DataTable
            Dim strTypeVar As String = "", strType As String = ""

            dtColumnPK = BL.ColumnList.ListDataPK(strTableName, cls)

            strScript = _
                "Public Class " & strFormName & vbNewLine & _
                " " & vbNewLine & _
                "#Region """ & "Property""" & vbNewLine & _
                "    Private frmParent As " & frmFormNameOri & vbNewLine & _
                "    Private clsData As VO." & strFileName & vbNewLine

            For Each drColumn As DataRow In dtColumnPK.Rows
                strScript += _
                "    Property pub" & drColumn.Item("ColumnName") & " As " & _LIB.modGenerateLib.pubGetVBType(drColumn.Item("DataType")) & vbNewLine
            Next

            strScript += _
                "    Property pubIsNew As Boolean = False " & vbNewLine & _
                "    Property pubIsSave As Boolean = False " & vbNewLine & _
                "" & vbNewLine & _
                "    Public Sub pubShowDialog(ByVal frmGetParent As Form) " & vbNewLine & _
                "        frmParent = frmGetParent" & vbNewLine & _
                "        Me.ShowDialog()" & vbNewLine & _
                "    End Sub " & vbNewLine & _
                "#End Region " & vbNewLine & vbNewLine

            strScript += FormFunction.modGenerateFormFunction.FunctPrivateConst(True, cls)

            If Not bolUseParentTools Then
                strScript += FormFunction.modGenerateFormFunction.FunctSetIcon(True, cls)
            End If

            If Not bolUseParentTools Then
                strScript += FormFunction.modGenerateFormFunction.FunctUserAccess(True, cls)
            End If

            strScript += FormFunction.modGenerateFormFunction.FunctSetTittleForm(True)

            strScript += FormFunction.modGenerateFormFunction.FunctFillForm(strTableName, strFileName, "", cls)

            strScript += FormFunction.modGenerateFormFunction.FunctSave(strTableName, strFileName, bolUseParentTools, "", cls)

            strScript += FormFunction.modGenerateFormFunction.FunctClear(strTableName, strFileName, "", cls)

            strScript += _
            "#Region " & """Form Handle""" & vbNewLine & vbNewLine

            strScript += FormHandle.modGenerateFormHandle.FunctFormLoad(strFormName, True, bolUseParentTools, cls)

            strScript += FormHandle.modGenerateFormHandle.FunctFormKeyDown(strFormName, True, cls)

            If Not bolUseParentTools Then
                strScript += FormHandle.modGenerateFormHandle.FunctToolBarButton(True, cls)
            End If

            strScript += _
            "#End Region " & vbNewLine

            strScript += _
                "" & vbNewLine & _
                "End Class" & vbNewLine & _
                "" & vbNewLine

            UI.usForm.AppendText_txt(strFolderName, strFormName, ".vb", strScript)
        End Sub

    End Module
End Namespace

