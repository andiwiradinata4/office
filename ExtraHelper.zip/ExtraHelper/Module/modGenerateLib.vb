﻿Imports ExtraHelperLib.VO.UserSelection

Namespace _LIB

    Module modGenerateLib

        Private Const Qu1 As String = """"
        Private Const Qu2 As String = """"""
        Private Const QuTab1 As String = "	"
        Private Const QuTab3 As String = "            "
        Private Const QuTab4 As String = "                "
        Private Const QuTab5 As String = "                    "
        Private Const QuTab6 As String = "                        "

        Public strClassAccessType As String = ""
        Public strFuncAccessType As String = ""

#Region "Common"

        Public Function pubGetVBType(ByVal strType As String)
            Dim strScript As String = ""
            Select Case strType.Trim
                Case "varchar", "nvarchar"
                    strScript += "String"
                Case "bigint", "int", "smallint"
                    strScript += "Integer"
                Case "tinyint"
                    strScript += "Byte"
                Case "numeric", "decimal", "money", "smallmoney"
                    strScript += "Decimal"
                Case "datetime", "smalldatetime"
                    strScript += "DateTime"
                Case "bit"
                    strScript += "Boolean"
            End Select
            Return strScript
        End Function

        Public Function pubGetVBInit(ByVal strType As String)
            Dim strScript As String = ""
            Select Case strType.Trim
                Case "varchar", "nvarchar"
                    strScript += "str"
                Case "bigint", "int", "smallint"
                    strScript += "int"
                Case "tinyint"
                    strScript += "byt"
                Case "numeric", "decimal", "money", "smallmoney"
                    strScript += "dec"
                Case "datetime", "smalldatetime"
                    strScript += "dtm"
                Case "bit"
                    strScript += "bol"
            End Select
            Return strScript
        End Function

        Private Function SetupParameters(ByVal dtColumn As DataTable, ByVal bolInitial As Boolean)
            Dim strScript As String = ""

            For Each drColumn As DataRow In dtColumn.Rows
                If drColumn.Item("ColumnName") <> "LogInc" And drColumn.Item("ColumnName") <> "IsSync" And drColumn.Item("ColumnName") <> "LogDate" And
                   drColumn.Item("ColumnName") <> "CreateBy" And drColumn.Item("ColumnName") <> "CreateDate" And
                   drColumn.Item("ColumnName") <> "CreatedBy" And drColumn.Item("ColumnName") <> "CreatedDate" Then
                    strScript += QuTab4 & ".Parameters.Add(""@" & drColumn.Item("ColumnName") & """, SqlDbType." & drColumn.Item("DataType")

                    If drColumn.Item("DataType") = "varchar" Then
                        strScript += ", " & drColumn.Item("MaxLength")
                    End If

                    strScript += ").Value = " & IIf(bolInitial, pubGetVBInit(drColumn.Item("DataType")), "clsData.") & drColumn.Item("ColumnName") & vbNewLine
                End If
            Next

            Return strScript
        End Function

        Private Function SetupReturn(ByVal dtColumn As DataTable)
            Dim strScript As String = ""

            For Each drColumn As DataRow In dtColumn.Rows
                strScript += "                        voReturn." & drColumn.Item("ColumnName") & " = .Item(""" & drColumn.Item("ColumnName") & """)" & vbNewLine
            Next

            Return strScript
        End Function

        Private Function SetServerScript(ByVal strScript As String, cls As VO.UserSelection) As String
            If cls.FormType = VO.UserSelection.eFormType.MasterForm Then
                strScript +=
                "            BL.Server.ServerDefault() " & vbNewLine
            Else
                strScript +=
                "            BL.Server.SetServer(strCompanyID) " & vbNewLine
            End If
            Return strScript
        End Function

#End Region

#Region "BL"

#Region "ListData"

        Private Function BL_ScriptListData(ByVal dtColumn As DataTable, ByVal strTableName As String, ByVal strFileName As String, ByVal cls As VO.UserSelection, ByVal bolIsHeader As Boolean)
            Dim strScript As String = ""
            Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)

            strScript =
                "        " & strFuncAccessType & " Shared Function ListData("

            If cls.FormType = VO.UserSelection.eFormType.TransactionForm Then strScript += "ByVal strCompanyID As String"

            If bolIsHeader Then
                '# If ComLocDivSubDIvID is not exists
                Dim drSelected() As DataRow = dtColumnPK.Select("ColumnName='ComLocDivSubDIvID'")
                If drSelected.Count = 0 Then
                    strScript += ", intComLocDivSubDIvID As Integer"
                End If

                strScript += ", dtmDateFrom As DateTime, dtmDateTo As DateTime, bytStatus As Byte"
            End If

            With dtColumnPK
                If dtColumnPK.Rows.Count > 1 Then
                    If cls.FormType = VO.UserSelection.eFormType.TransactionForm Then strScript += ", "
                    strScript += "ByVal " & pubGetVBInit(.Rows(0).Item("DataType")) & .Rows(0).Item("ColumnName") & " As " & pubGetVBType(.Rows(0).Item("DataType"))
                End If
            End With

            strScript +=
                ") As DataTable" & vbNewLine

            If cls.FormType = VO.UserSelection.eFormType.TransactionForm And bolIsHeader = False Then strScript += "' --------------- Add your refrences key as parameter --------------- " & vbNewLine

            If cls.FormType = VO.UserSelection.eFormType.TransactionForm Then
                strScript +=
                "            BL.Server.SetServer(strCompanyID) " & vbNewLine
            Else
                strScript +=
                "            BL.Server.ServerDefault() " & vbNewLine
            End If

            If cls.ConnectionType = eConnectionType.SelfConnection Then strScript += QuTab3 & "Using sqlCon As SqlConnection = DL.SQL.OpenConnection" & vbNewLine

            strScript += QuTab4 & "Return DL." & strFileName & ".ListData(" & IIf(cls.ConnectionType = eConnectionType.SelfConnection, "sqlCon, Nothing", "")
            If cls.FormType = VO.UserSelection.eFormType.TransactionForm And bolIsHeader And cls.ConnectionType = eConnectionType.SelfConnection Then strScript += ", "
            If cls.FormType = VO.UserSelection.eFormType.TransactionForm And bolIsHeader Then strScript += "intComLocDivSubDIvID, dtmDateFrom, dtmDateTo, bytStatus"

            With dtColumnPK
                '# If ComLocDivSubDIvID is not exists
                Dim drSelected() As DataRow = dtColumnPK.Select("ColumnName='ComLocDivSubDIvID'")
                If drSelected.Count = 0 Then
                    If dtColumnPK.Rows.Count > 1 Then
                        If cls.ConnectionType = eConnectionType.SelfConnection Then strScript += ", "
                        If cls.FormType = VO.UserSelection.eFormType.TransactionForm And bolIsHeader Then strScript += ", "
                        strScript += pubGetVBInit(.Rows(0).Item("DataType")) & .Rows(0).Item("ColumnName")
                    End If
                End If
            End With

            strScript += ") " & vbNewLine

            If cls.ConnectionType = eConnectionType.SelfConnection Then strScript += QuTab3 & "End Using" & vbNewLine

            strScript +=
                "        End Function" & vbNewLine & vbNewLine

            Return strScript
        End Function

#End Region

#Region "SaveData"

        Private Function BL_ScriptSaveData(ByVal dtColumn As DataTable, ByVal strTableName As String, ByVal strFileName As String, ByVal cls As VO.UserSelection)
            Dim strScript As String = ""
            Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)
            Dim strPK As String = BL.ColumnList.GetTop1PK(strTableName, cls)
            Dim strPKType As String = ""

            With dtColumnPK
                For i As Integer = 0 To .Rows.Count - 1
                    If strPK = .Rows(i).Item("ColumnName") Then
                        strPKType = .Rows(i).Item("DataType")
                    End If
                Next
            End With

            strScript = "        " & strFuncAccessType & " Shared Function SaveData("

            If cls.FormType = VO.UserSelection.eFormType.TransactionForm Then strScript += "ByVal strCompanyID As String, "

            strScript += "ByVal bolNew as Boolean, ByVal clsData As VO." & strFileName.Trim & ") As " & pubGetVBType(strPKType) & vbNewLine

            If cls.FormType = VO.UserSelection.eFormType.TransactionForm Then
                strScript +=
                QuTab3 & "BL.Server.SetServer(strCompanyID) " & vbNewLine
            Else
                strScript +=
                QuTab3 & "BL.Server.ServerDefault() " & vbNewLine
            End If

            If cls.ConnectionType = eConnectionType.SelfConnection Then
                strScript +=
                    QuTab3 & "Using sqlCon As SqlConnection = DL.SQL.OpenConnection" & vbNewLine &
                    QuTab4 & "Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction" & vbNewLine
            ElseIf cls.ConnectionType = eConnectionType.SharedConnection Then
                strScript +=
                    QuTab3 & "DL.SQL.OpenConnection() " & vbNewLine &
                    QuTab3 & "DL.SQL.BeginTransaction() " & vbNewLine
            End If
            strScript +=
                QuTab4 & "Try" & vbNewLine &
                "" & vbNewLine &
                "                If bolNew Then " & vbNewLine
            strScript +=
                "                    clsData." & strPK & " = DL." & strFileName & ".GetMaxID(" & IIf(cls.ConnectionType = eConnectionType.SelfConnection, "sqlCon, sqlTrans", "") & ")" & vbNewLine & vbNewLine
            If cls.FormType = VO.UserSelection.eFormType.TransactionForm And cls.IsIncludeStatus Then
                strScript +=
                "                    SaveHistory(" & IIf(cls.ConnectionType = eConnectionType.SelfConnection, "sqlCon, sqlTrans, ", "") & "clsData." & strPK & ", ""DRAFT - NEW"", clsData.LogBy, """")" & vbNewLine &
                "                Else" & vbNewLine &
                "                    SaveHistory(" & IIf(cls.ConnectionType = eConnectionType.SelfConnection, "sqlCon, sqlTrans, ", "") & "clsData." & strPK & ", ""DRAFT - EDIT"", clsData.LogBy, """")" & vbNewLine
            End If

            strScript += "                End If " & vbNewLine & vbNewLine
            strScript += "                DL." & strFileName & ".SaveData(" & IIf(cls.ConnectionType = eConnectionType.SelfConnection, "sqlCon, sqlTrans, ", "") & "bolNew, clsData) " & vbNewLine & vbNewLine

            If cls.ConnectionType = eConnectionType.SelfConnection Then
                strScript += "                sqlTrans.Commit()" & vbNewLine
            ElseIf cls.ConnectionType = eConnectionType.SharedConnection Then
                strScript += "                DL.SQL.CommitTransaction() " & vbNewLine
            End If
            strScript += "            Catch ex As Exception" & vbNewLine

            If cls.ConnectionType = eConnectionType.SelfConnection Then
                strScript += "                sqlTrans.Rollback()" & vbNewLine
            ElseIf cls.ConnectionType = eConnectionType.SharedConnection Then
                strScript += "                DL.SQL.RollBackTransaction() " & vbNewLine
            End If

            strScript += "                Throw ex " & vbNewLine

            If cls.ConnectionType = eConnectionType.SharedConnection Then
                strScript +=
                    "            Finally " & vbNewLine &
                    "                DL.SQL.CloseConnection() " & vbNewLine
            End If

            strScript += "            End Try" & vbNewLine
            If cls.ConnectionType = eConnectionType.SelfConnection Then strScript += QuTab3 & "End Using" & vbNewLine
            strScript +=
                "            Return clsData." & strPK & vbNewLine &
                "        End Function" & vbNewLine & vbNewLine

            Return strScript
        End Function

#End Region

#Region "GetDetail"

        Private Function BL_ScriptGetDetail(ByVal dtColumn As DataTable, ByVal strTableName As String, ByVal strFileName As String, ByVal cls As VO.UserSelection)
            Dim strScript As String = ""
            Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)

            strScript =
                "        " & strFuncAccessType & " Shared Function GetDetail("

            If cls.FormType = VO.UserSelection.eFormType.TransactionForm Then strScript += "ByVal strCompanyID As String, "

            With dtColumnPK
                For i As Integer = 0 To .Rows.Count - 1
                    strScript += "ByVal " & pubGetVBInit(.Rows(i).Item("DataType")) & .Rows(i).Item("ColumnName") & " As " & pubGetVBType(.Rows(i).Item("DataType"))
                    If i = .Rows.Count - 1 Then
                        strScript += ")"
                    Else
                        strScript += ", "
                    End If
                Next
                strScript += " As VO." & strFileName & vbNewLine
            End With

            If cls.FormType = VO.UserSelection.eFormType.TransactionForm Then
                strScript +=
                "            BL.Server.SetServer(strCompanyID) " & vbNewLine
            Else
                strScript +=
                "            BL.Server.ServerDefault() " & vbNewLine
            End If

            If cls.ConnectionType = eConnectionType.SelfConnection Then strScript += QuTab3 & "Using sqlCon As SqlConnection = DL.SQL.OpenConnection" & vbNewLine

            strScript += QuTab4 & "Return DL." & strFileName & ".GetDetail(" & IIf(cls.ConnectionType = eConnectionType.SelfConnection, "sqlCon, Nothing, ", "")

            With dtColumnPK
                For i As Integer = 0 To .Rows.Count - 1
                    strScript += pubGetVBInit(.Rows(i).Item("DataType")) & .Rows(i).Item("ColumnName")
                    If i = .Rows.Count - 1 Then
                        strScript += ")" & vbNewLine
                    Else
                        strScript += ", "
                    End If
                Next
            End With

            If cls.ConnectionType = eConnectionType.SelfConnection Then strScript += QuTab3 & "End Using" & vbNewLine

            strScript += "        End Function " & vbNewLine & vbNewLine

            Return strScript
        End Function

#End Region

#Region "DeleteData"

        Private Function BL_ScriptDeleteData(ByVal strTableName As String, ByVal strFileName As String, ByVal cls As VO.UserSelection)
            Dim strScript As String = ""
            Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)
            Dim strPK As String = BL.ColumnList.GetTop1PK(strTableName, cls)
            Dim strVariablePK As String = ""

            With dtColumnPK
                For i As Integer = 0 To .Rows.Count - 1
                    strVariablePK += pubGetVBInit(.Rows(i).Item("DataType")) & .Rows(i).Item("ColumnName")
                    If i <> .Rows.Count - 1 Then
                        strVariablePK += ", "
                    End If
                Next
            End With

            strScript =
                "        " & strFuncAccessType & " Shared Sub DeleteData("

            If cls.FormType = VO.UserSelection.eFormType.TransactionForm Then strScript += "ByVal strCompanyID As String, "

            With dtColumnPK
                For i As Integer = 0 To .Rows.Count - 1
                    strScript += "ByVal " & pubGetVBInit(.Rows(i).Item("DataType")) & .Rows(i).Item("ColumnName") & " As " & pubGetVBType(.Rows(i).Item("DataType"))
                    If i < .Rows.Count - 1 Then
                        strScript += ", "
                    End If
                Next
            End With

            If cls.FormType = VO.UserSelection.eFormType.TransactionForm Then strScript += ", ByVal strLogBy As String, ByVal strRemarks As String"

            strScript += ")" & vbNewLine

            If cls.FormType = VO.UserSelection.eFormType.TransactionForm Then
                strScript +=
                "            BL.Server.SetServer(strCompanyID) " & vbNewLine
            Else
                strScript +=
                "            BL.Server.ServerDefault() " & vbNewLine
            End If


            If cls.ConnectionType = eConnectionType.SelfConnection Then
                strScript +=
                    QuTab3 & "Using sqlCon As SqlConnection = DL.SQL.OpenConnection" & vbNewLine &
                    QuTab4 & "Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction" & vbNewLine
            ElseIf cls.ConnectionType = eConnectionType.SharedConnection Then
                strScript +=
                    QuTab3 & "DL.SQL.OpenConnection() " & vbNewLine &
                    QuTab3 & "DL.SQL.BeginTransaction() " & vbNewLine
            End If

            strScript +=
                QuTab4 & "Try" & vbNewLine &
                "" & vbNewLine

            If cls.FormType = VO.UserSelection.eFormType.TransactionForm Then
                strScript +=
                "                If Not DL." & strFileName & ".IsDraft(" & IIf(cls.ConnectionType = eConnectionType.SelfConnection, "sqlCon, sqlTrans, ", "")
                With dtColumnPK
                    For j As Integer = 0 To .Rows.Count - 1
                        strScript += pubGetVBInit(.Rows(j).Item("DataType")) & .Rows(j).Item("ColumnName")
                        If j = .Rows.Count - 1 Then
                            strScript += ") Then" & vbNewLine
                        Else
                            strScript += ", "
                        End If
                    Next
                End With

                strScript +=
                "                    Err.Raise(515, """", ""Cannot Delete. " & strFileName & " must be in draft status"")" & vbNewLine &
                "                End If" & vbNewLine & vbNewLine
            Else
                strScript +=
                "                'If DL." & strFileName & ".XXX(" & IIf(cls.ConnectionType = eConnectionType.SelfConnection, "sqlCon, sqlTrans", "") & strVariablePK & ") Then " & vbNewLine &
                "                '    Err.Raise(515," & Qu2 & "," & Qu1 & "Cannot Delete. Data already used at XXX" & Qu1 & ") " & vbNewLine &
                "                'End If " & vbNewLine & vbNewLine
            End If


            strScript +=
                "                DL." & strFileName & ".DeleteData(" & IIf(cls.ConnectionType = eConnectionType.SelfConnection, "sqlCon, sqlTrans, ", "") & strVariablePK & IIf(cls.FormType = VO.UserSelection.eFormType.TransactionForm, ", strLogBy", "") & ") " & vbNewLine

            If cls.FormType = VO.UserSelection.eFormType.TransactionForm And cls.IsIncludeStatus Then
                strScript += "                SaveHistory(" & IIf(cls.ConnectionType = eConnectionType.SelfConnection, "sqlCon, sqlTrans, ", "")

                With dtColumnPK
                    For k As Integer = 0 To .Rows.Count - 1
                        strScript += pubGetVBInit(.Rows(k).Item("DataType")) & .Rows(k).Item("ColumnName")
                        If k = .Rows.Count - 1 Then
                            strScript += ", ""DELETED"", strLogBy, strRemarks)" & vbNewLine
                        Else
                            strScript += ", "
                        End If
                    Next
                End With
            End If

            strScript += "" & vbNewLine
            If cls.ConnectionType = eConnectionType.SelfConnection Then
                strScript += "                sqlTrans.Commit()" & vbNewLine
            ElseIf cls.ConnectionType = eConnectionType.SharedConnection Then
                strScript += "                DL.SQL.CommitTransaction() " & vbNewLine
            End If
            strScript += "            Catch ex As Exception" & vbNewLine
            If cls.ConnectionType = eConnectionType.SelfConnection Then
                strScript += "                sqlTrans.Rollback()" & vbNewLine
            ElseIf cls.ConnectionType = eConnectionType.SharedConnection Then
                strScript += "                DL.SQL.RollBackTransaction() " & vbNewLine
            End If
            strScript += "                Throw ex " & vbNewLine
            If cls.ConnectionType = eConnectionType.SharedConnection Then
                strScript +=
                    "            Finally " & vbNewLine &
                    "                DL.SQL.CloseConnection() " & vbNewLine
            End If
            strScript += "            End Try" & vbNewLine

            If cls.ConnectionType = eConnectionType.SelfConnection Then strScript += QuTab3 & "End Using" & vbNewLine

            strScript += "        End Sub" & vbNewLine & vbNewLine

            Return strScript
        End Function

#End Region

#Region "Update Status"

        'Private Function BL_ScriptUpdateStatus(ByVal strTableName As String, ByVal strFileName As String, ByVal cls As VO.UserSelection)
        '    Dim strScript As String = ""
        '    Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)
        '    Dim strPK As String = BL.ColumnList.GetTop1PK(strTableName, cls)
        '    Dim strVariablePK As String = ""
        '    Dim drPK As DataRow

        '    drPK = dtColumnPK.NewRow
        '    drPK.BeginEdit()
        '    drPK.Item("ColumnName") = "LogBy"
        '    drPK.Item("DataType") = "varchar"
        '    drPK.Item("MaxLength") = 20
        '    drPK.Item("precision") = 0
        '    drPK.Item("scale") = 0
        '    drPK.Item("is_nullable") = 0
        '    drPK.Item("PrimaryKey") = 0
        '    drPK.Item("is_identity") = 0
        '    drPK.EndEdit()
        '    dtColumnPK.Rows.Add(drPK)
        '    dtColumnPK.AcceptChanges()

        '    With dtColumnPK
        '        For i As Integer = 0 To .Rows.Count - 1
        '            strVariablePK += pubGetVBInit(.Rows(i).Item("DataType")) & .Rows(i).Item("ColumnName")
        '            If i <> .Rows.Count - 1 Then
        '                strVariablePK += ", "
        '            End If
        '        Next
        '    End With

        '    strScript = _
        '        "        " & strFuncAccessType & " Shared Sub DeleteData(ByVal strCompanyID As String, "

        '    With dtColumnPK
        '        For i As Integer = 0 To .Rows.Count - 1
        '            strScript += "ByVal " & pubGetVBInit(.Rows(i).Item("DataType")) & .Rows(i).Item("ColumnName") & " As " & pubGetVBType(.Rows(i).Item("DataType"))
        '            If i = .Rows.Count - 1 Then
        '                strScript += ")" & vbNewLine
        '            Else
        '                strScript += ", "
        '            End If
        '        Next
        '    End With

        '    strScript += _
        '        "            BL.Server.SetServer(strCompanyID) " & vbNewLine & _
        '        "            Try" & vbNewLine & _
        '        "                DL.SQL.OpenConnection() " & vbNewLine & _
        '        "                DL.SQL.BeginTransaction() " & vbNewLine & _
        '        "" & vbNewLine & _
        '        "                'If DL." & strFileName & ".XXX(" & strVariablePK & ") Then " & vbNewLine & _
        '        "                '    Err.Raise(515," & Qu2 & "," & Qu1 & "Cannot Delete. Data already used at XXX" & Qu1 & ") " & vbNewLine & _
        '        "                'Else " & vbNewLine & _
        '        "                    DL." & strFileName & ".DeleteData(" & strVariablePK & ") " & vbNewLine & _
        '        "                'End If " & vbNewLine & _
        '        "" & vbNewLine & _
        '        "                DL.SQL.CommitTransaction() " & vbNewLine & _
        '        "            Catch ex As Exception" & vbNewLine & _
        '        "                DL.SQL.RollBackTransaction() " & vbNewLine & _
        '        "                Throw ex " & vbNewLine & _
        '        "            Finally " & vbNewLine & _
        '        "                DL.SQL.CloseConnection() " & vbNewLine & _
        '        "            End Try" & vbNewLine & _
        '        "        End Sub" & vbNewLine & vbNewLine

        '    Return strScript
        'End Function

#End Region

#Region "SubmitData"

        Private Function BL_ScriptSubmitData(ByVal strTableName As String, ByVal strFileName As String, ByVal cls As VO.UserSelection)
            Dim strScript As String = ""
            Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)

            strScript =
                "        " & strFuncAccessType & " Shared Sub SubmitData(ByVal strCompanyID As String, "

            With dtColumnPK
                For i As Integer = 0 To .Rows.Count - 1
                    strScript += "ByVal " & pubGetVBInit(.Rows(i).Item("DataType")) & .Rows(i).Item("ColumnName") & " As " & pubGetVBType(.Rows(i).Item("DataType")) & ", "
                Next
            End With

            strScript += "strLogBy As String, strRemarks As String)" & vbNewLine &
                         "            BL.Server.SetServer(strCompanyID)" & vbNewLine

            If cls.ConnectionType = eConnectionType.SelfConnection Then
                strScript +=
                    QuTab3 & "Using sqlCon As SqlConnection = DL.SQL.OpenConnection" & vbNewLine &
                    QuTab4 & "Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction" & vbNewLine
            ElseIf cls.ConnectionType = eConnectionType.SharedConnection Then
                strScript +=
                    QuTab3 & "DL.SQL.OpenConnection() " & vbNewLine &
                    QuTab3 & "DL.SQL.BeginTransaction() " & vbNewLine
            End If

            strScript +=
                "                Try" & vbNewLine &
                "                      If Not DL." & strFileName & ".IsDraft(" & IIf(cls.ConnectionType = eConnectionType.SelfConnection, "sqlCon, sqlTrans, ", "")

            With dtColumnPK
                For j As Integer = 0 To .Rows.Count - 1
                    strScript += pubGetVBInit(.Rows(j).Item("DataType")) & .Rows(j).Item("ColumnName")
                    If j = .Rows.Count - 1 Then
                        strScript += ") Then" & vbNewLine
                    Else
                        strScript += ", "
                    End If
                Next
            End With

            strScript +=
                "                    Err.Raise(515, """", ""Cannot Submit. " & strFileName & " must be in draft status"")" & vbNewLine &
                "                End If" & vbNewLine &
                "" & vbNewLine &
                "                DL." & strFileName & ".SubmitData(" & IIf(cls.ConnectionType = eConnectionType.SelfConnection, "sqlCon, sqlTrans, ", "")

            With dtColumnPK
                For k As Integer = 0 To .Rows.Count - 1
                    strScript += pubGetVBInit(.Rows(k).Item("DataType")) & .Rows(k).Item("ColumnName")
                    If k = .Rows.Count - 1 Then
                        strScript += ", strLogBy)" & vbNewLine
                    Else
                        strScript += ", "
                    End If
                Next
            End With


            strScript += "                SaveHistory(" & IIf(cls.ConnectionType = eConnectionType.SelfConnection, "sqlCon, sqlTrans, ", "")

            With dtColumnPK
                For k As Integer = 0 To .Rows.Count - 1
                    strScript += pubGetVBInit(.Rows(k).Item("DataType")) & .Rows(k).Item("ColumnName")
                    If k = .Rows.Count - 1 Then
                        strScript += ", ""SUBMITTED"", strLogBy, strRemarks)" & vbNewLine & vbNewLine
                    Else
                        strScript += ", "
                    End If
                Next
            End With

            If cls.ConnectionType = eConnectionType.SelfConnection Then
                strScript += "                sqlTrans.Commit()" & vbNewLine
            ElseIf cls.ConnectionType = eConnectionType.SharedConnection Then
                strScript += "                DL.SQL.CommitTransaction() " & vbNewLine
            End If
            strScript += "            Catch ex As Exception" & vbNewLine
            If cls.ConnectionType = eConnectionType.SelfConnection Then
                strScript += "                sqlTrans.Rollback()" & vbNewLine
            ElseIf cls.ConnectionType = eConnectionType.SharedConnection Then
                strScript += "                DL.SQL.RollBackTransaction() " & vbNewLine
            End If

            strScript += "                Throw ex " & vbNewLine

            If cls.ConnectionType = eConnectionType.SharedConnection Then
                strScript +=
                    "            Finally " & vbNewLine &
                    "                DL.SQL.CloseConnection() " & vbNewLine
            End If

            strScript += "            End Try " & vbNewLine
            If cls.ConnectionType = eConnectionType.SelfConnection Then strScript += QuTab3 & "End Using" & vbNewLine
            strScript +=
                "        End Sub " & vbNewLine & vbNewLine

            Return strScript
        End Function

#End Region

#Region "UnsubmitData"

        Private Function BL_ScriptUnsubmitData(ByVal strTableName As String, ByVal strFileName As String, ByVal cls As VO.UserSelection)
            Dim strScript As String = ""
            Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)

            strScript =
                "        " & strFuncAccessType & " Shared Sub UnsubmitData(ByVal strCompanyID As String, "

            With dtColumnPK
                For i As Integer = 0 To .Rows.Count - 1
                    strScript += "ByVal " & pubGetVBInit(.Rows(i).Item("DataType")) & .Rows(i).Item("ColumnName") & " As " & pubGetVBType(.Rows(i).Item("DataType")) & ", "
                Next

            End With

            strScript += "strLogBy As String, strRemarks As String)" & vbNewLine &
                         "            BL.Server.SetServer(strCompanyID)" & vbNewLine

            If cls.ConnectionType = eConnectionType.SelfConnection Then
                strScript +=
                    QuTab3 & "Using sqlCon As SqlConnection = DL.SQL.OpenConnection" & vbNewLine &
                    QuTab4 & "Dim sqlTrans As SqlTransaction = sqlCon.BeginTransaction" & vbNewLine
            ElseIf cls.ConnectionType = eConnectionType.SharedConnection Then
                strScript +=
                    QuTab3 & "DL.SQL.OpenConnection() " & vbNewLine &
                    QuTab3 & "DL.SQL.BeginTransaction() " & vbNewLine
            End If

            strScript +=
                QuTab4 & "Try" & vbNewLine &
                QuTab5 & "If Not DL." & strFileName & ".IsSubmit(" & IIf(cls.ConnectionType = eConnectionType.SelfConnection, "sqlCon, sqlTrans, ", "")

            With dtColumnPK
                For j As Integer = 0 To .Rows.Count - 1
                    strScript += pubGetVBInit(.Rows(j).Item("DataType")) & .Rows(j).Item("ColumnName")
                    If j = .Rows.Count - 1 Then
                        strScript += ") Then" & vbNewLine
                    Else
                        strScript += ", "
                    End If
                Next
            End With

            strScript += "                    Err.Raise(515, """", ""Cannot Unsubmit. " & strFileName & " must be in submitted status"")" & vbNewLine &
                         "                End If" & vbNewLine &
                         "" & vbNewLine &
                         "                DL." & strFileName & ".UnsubmitData(" & IIf(cls.ConnectionType = eConnectionType.SelfConnection, "sqlCon, sqlTrans, ", "")

            With dtColumnPK
                For k As Integer = 0 To .Rows.Count - 1
                    strScript += pubGetVBInit(.Rows(k).Item("DataType")) & .Rows(k).Item("ColumnName")
                    If k = .Rows.Count - 1 Then
                        strScript += ")" & vbNewLine
                    Else
                        strScript += ", "
                    End If
                Next
            End With


            strScript += "                SaveHistory(" & IIf(cls.ConnectionType = eConnectionType.SelfConnection, "sqlCon, sqlTrans, ", "")

            With dtColumnPK
                For k As Integer = 0 To .Rows.Count - 1
                    strScript += pubGetVBInit(.Rows(k).Item("DataType")) & .Rows(k).Item("ColumnName")
                    If k = .Rows.Count - 1 Then
                        strScript += ", ""UNSUBMITTED"", strLogBy, strRemarks)" & vbNewLine & vbNewLine
                    Else
                        strScript += ", "
                    End If
                Next
            End With

            If cls.ConnectionType = eConnectionType.SelfConnection Then
                strScript += "                sqlTrans.Commit()" & vbNewLine
            ElseIf cls.ConnectionType = eConnectionType.SharedConnection Then
                strScript += "                DL.SQL.CommitTransaction() " & vbNewLine
            End If
            strScript += "            Catch ex As Exception " & vbNewLine

            If cls.ConnectionType = eConnectionType.SelfConnection Then
                strScript += "                sqlTrans.Rollback()" & vbNewLine
            ElseIf cls.ConnectionType = eConnectionType.SharedConnection Then
                strScript += "                DL.SQL.RollBackTransaction() " & vbNewLine
            End If

            strScript += "                Throw ex " & vbNewLine

            If cls.ConnectionType = eConnectionType.SharedConnection Then
                strScript +=
                    "            Finally " & vbNewLine &
                    "                DL.SQL.CloseConnection() " & vbNewLine
            End If

            strScript += QuTab4 & "End Try " & vbNewLine
            If cls.ConnectionType = eConnectionType.SelfConnection Then strScript += QuTab3 & "End Using" & vbNewLine
            strScript += "        End Sub " & vbNewLine & vbNewLine
            Return strScript
        End Function

#End Region

#Region "ListDataHistory"

        Private Function BL_ScriptListDataHistory(ByVal dtColumn As DataTable, ByVal strTableName As String, ByVal strFileName As String, ByVal cls As VO.UserSelection)
            Dim strScript As String = ""
            Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)
            If dtColumnPK.Rows.Count = 0 Then Return strScript & vbNewLine

            strScript =
                "        " & strFuncAccessType & " Shared Function ListHistory(ByVal strCompanyID As String, "

            If cls.FormType = VO.UserSelection.eFormType.TransactionForm Then strScript += ""

            With dtColumnPK
                strScript += "ByVal " & pubGetVBInit(.Rows(0).Item("DataType")) & .Rows(0).Item("ColumnName") & " As " & pubGetVBType(.Rows(0).Item("DataType"))
            End With

            strScript +=
                ") As DataTable" & vbNewLine &
                "            BL.Server.SetServer(strCompanyID) " & vbNewLine

            If cls.ConnectionType = eConnectionType.SelfConnection Then strScript += QuTab3 & "Using sqlCon As SqlConnection = DL.SQL.OpenConnection" & vbNewLine

            strScript += "            Return DL." & strFileName & ".ListHistory(" & IIf(cls.ConnectionType = eConnectionType.SelfConnection, "sqlCon, Nothing, ", "")

            strScript += pubGetVBInit(dtColumnPK.Rows(0).Item("DataType")) & dtColumnPK.Rows(0).Item("ColumnName")

            strScript +=
                ") " & vbNewLine

            If cls.ConnectionType = eConnectionType.SelfConnection Then strScript += QuTab3 & "End Using" & vbNewLine

            strScript +=
                "        End Function" & vbNewLine & vbNewLine

            Return strScript
        End Function

#End Region

#Region "SaveDataHistory"

        Private Function BL_ScriptSaveDataHistory(ByVal dtColumn As DataTable, ByVal strTableName As String, ByVal strFileName As String, ByVal cls As VO.UserSelection)
            Dim strScript As String = ""
            Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)
            If dtColumnPK.Rows.Count = 0 Then Return strScript & vbNewLine

            strScript =
                "        " & strFuncAccessType & " Shared Sub SaveHistory(" & IIf(cls.ConnectionType = eConnectionType.SelfConnection, "ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction, ", "")
            With dtColumn
                For i As Integer = 0 To .Rows.Count - 1
                    If .Rows(i).Item("ColumnName") <> "AutoNumber" And .Rows(i).Item("ColumnName") <> "StatusDate" Then
                        strScript += "ByVal " & pubGetVBInit(.Rows(i).Item("DataType")) & .Rows(i).Item("ColumnName") & " As " & pubGetVBType(.Rows(i).Item("DataType"))
                        If i = .Rows.Count - 1 Then
                            strScript += ")" & vbNewLine
                        Else
                            strScript += ", "
                        End If
                    End If
                Next
            End With
            strScript +=
                "            Dim intAutoNumber As Integer = DL." & strFileName & ".GetMaxHistoryID(" & IIf(cls.ConnectionType = eConnectionType.SelfConnection, "sqlCon, sqlTrans, ", "") & (pubGetVBInit(dtColumnPK.Rows(0).Item("DataType")) & dtColumnPK.Rows(0).Item("ColumnName")) & ")" & vbNewLine &
                "            DL." & strFileName & ".SaveHistory(" & IIf(cls.ConnectionType = eConnectionType.SelfConnection, "sqlCon, sqlTrans, ", "")

            With dtColumn
                For i As Integer = 0 To .Rows.Count - 1
                    If .Rows(i).Item("ColumnName") <> "StatusDate" Then
                        strScript += pubGetVBInit(.Rows(i).Item("DataType")) & .Rows(i).Item("ColumnName")
                        If i = .Rows.Count - 1 Then
                            strScript += ")" & vbNewLine
                        Else
                            strScript += ", "
                        End If
                    End If
                Next
            End With

            strScript +=
                "        End Sub" & vbNewLine

            Return strScript
        End Function

#End Region

        Public Sub pubGenerateBL(ByVal strTableName As String, ByVal strFolderName As String, ByVal cls As VO.UserSelection, ByVal bolIsHeader As Boolean)
            Dim bolIsTrans As Boolean = IIf(strTableName.Trim.Contains("_tra"), True, False)
            Dim strFileName As String = Replace(strTableName.Trim, cls.TextToReplace, "")

            VO.ColumnList.ColumnList = New DataTable
            VO.ColumnList.ColumnList = BL.ColumnList.ListData(strTableName, cls)

            Dim strScript As String =
                "Namespace BL" & vbNewLine &
                " " & vbNewLine &
                "    " & strClassAccessType & " Class " & strFileName.Trim & vbNewLine &
                " " & vbNewLine

            'List Data
            strScript += BL_ScriptListData(VO.ColumnList.ColumnList, strTableName, strFileName, cls, bolIsHeader)

            'SaveData
            strScript += BL_ScriptSaveData(VO.ColumnList.ColumnList, strTableName, strFileName, cls)

            'GetDetail
            strScript += BL_ScriptGetDetail(VO.ColumnList.ColumnList, strTableName, strFileName, cls)

            'DeleteData
            strScript += BL_ScriptDeleteData(strTableName, strFileName, cls)

            If bolIsTrans Then
                ''DeleteData_UpdateStatus
                'strScript += BL_ScriptUpdateStatus(strTableName, strFileName, cls)

                'SubmitData
                strScript += BL_ScriptSubmitData(strTableName, strFileName, cls)

                'UnsubmitData
                strScript += BL_ScriptUnsubmitData(strTableName, strFileName, cls)

                If cls.IsIncludeStatus Then
                    'HISTORY
                    strTableName += "Status"
                    VO.ColumnList.ColumnList = BL.ColumnList.ListData(strTableName, cls)
                    'List Data
                    strScript += BL_ScriptListDataHistory(VO.ColumnList.ColumnList, strTableName, strFileName, cls)

                    'SaveData
                    strScript += BL_ScriptSaveDataHistory(VO.ColumnList.ColumnList, strTableName, strFileName, cls)
                End If
            Else
                ''DeleteData
                'strScript += BL_ScriptDeleteData(strTableName, strFileName, cls)
            End If

            strScript +=
                "    End Class " & vbNewLine &
                "" & vbNewLine &
                "End Namespace" & vbNewLine

            UI.usForm.AppendText_txt(strFolderName, strFileName, ".vb", strScript)
        End Sub

#End Region

#Region "DL"

#Region "ListData"

        Private Function DL_ScriptListData(ByVal dtColumn As DataTable, ByVal strTableName As String, ByVal strFileName As String, ByVal cls As VO.UserSelection, ByVal bolIsHeader As Boolean)
            Dim strScript As String = ""
            Dim strColStatusName As String = "StatusID"
            Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)

            strScript =
                "        " & strFuncAccessType & " Shared Function ListData("

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then strScript += "ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction"

            With dtColumnPK
                If dtColumnPK.Rows.Count > 1 Then
                    If cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then strScript += ", "
                    strScript += "ByVal " & pubGetVBInit(.Rows(0).Item("DataType")) & .Rows(0).Item("ColumnName") & " As " & pubGetVBType(.Rows(0).Item("DataType"))
                End If
            End With

            If cls.FormType = VO.UserSelection.eFormType.TransactionForm And bolIsHeader Then
                If dtColumnPK.Rows.Count > 1 Or VO.UserSelection.eConnectionType.SelfConnection Then strScript += ", "

                '# If ComLocDivSubDIvID is not exists
                Dim drSelected() As DataRow = dtColumnPK.Select("ColumnName='ComLocDivSubDIvID'")
                If drSelected.Count = 0 Then
                    strScript += "ByVal intComLocDivSubDIvID As Integer, "
                End If
                strScript += "ByVal dtmDateFrom As DateTime, ByVal dtmDateTo As DateTime, ByVal bytStatusID As VO.Status.Values"
            End If

            strScript +=
                ") As DataTable" & vbNewLine

            If cls.FormType = VO.UserSelection.eFormType.TransactionForm And bolIsHeader = False Then strScript += "' --------------- Add your refrences key as parameter --------------- " & vbNewLine

            strScript +=
                "            Dim sqlcmdExecute As New SqlCommand" & vbNewLine &
                "            With sqlcmdExecute" & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then
                strScript +=
                "                .Connection = sqlCon" & vbNewLine &
                "                .Transaction = sqlTrans" & vbNewLine
            End If

            strScript += "                .CommandText = " & vbNewLine

            Dim strBodyScript As String = ""
            With dtColumn
                For i As Integer = 0 To .Rows.Count - 1
                    If .Rows(i).Item("ColumnName") = "StatusID" Or .Rows(i).Item("ColumnName") = "IDStatus" Then
                        If .Rows(i).Item("ColumnName") <> strColStatusName Then strColStatusName = .Rows(i).Item("ColumnName")
                        strBodyScript += "A." & .Rows(i).Item("ColumnName") & ", StatusInfo='Join to tour Master Status'"
                        'strBodyScript += "A.Status, StatusInfo=CASE A." & .Rows(i).Item("ColumnName")
                        'If cls.FormType = VO.UserSelection.eFormType.MasterForm Then
                        '    strBodyScript += " WHEN 0 THEN 'ACTIVE' ELSE 'IN-ACTIVE' END"
                        'Else
                        '    strBodyScript += " WHEN 0 THEN 'DRAFT' WHEN 1 THEN 'SUBMITTED' WHEN 255 THEN 'DELETED' ELSE 'UNDEFINED' END"
                        'End If
                    Else
                        strBodyScript += "A." & .Rows(i).Item("ColumnName")
                    End If

                    If i <> .Rows.Count - 1 Then
                        strBodyScript += ", "
                    End If

                    If i Mod 6 = 0 And i <> 0 And i <> .Rows.Count - 1 Then strBodyScript += vbNewLine & QuTab1
                Next
            End With

            strScript +=
                """" & vbNewLine &
                "SELECT " & vbNewLine &
                QuTab1 & strBodyScript & vbNewLine &
                "FROM " & strTableName.Trim & " A" & vbNewLine &
                "WHERE " & vbNewLine &
                QuTab1 & "1=1 " & vbNewLine

            If dtColumnPK.Rows.Count > 1 And cls.FormType = VO.UserSelection.eFormType.MasterForm Then
                strScript +=
                QuTab1 & "AND A." & dtColumnPK.Rows(0).Item("ColumnName") & "=@" & dtColumnPK.Rows(0).Item("ColumnName") & vbNewLine
            End If

            If cls.FormType = VO.UserSelection.eFormType.TransactionForm And bolIsHeader Then
                strScript +=
                QuTab1 & "AND A.ComLocDivSubDivID=@ComLocDivSubDivID" & vbNewLine &
                QuTab1 & "AND A." & strFileName & "Date>=@DateFrom AND A." & strFileName & "<=@DateTo" & vbNewLine
            End If

            strScript += """" & vbNewLine

            If cls.FormType = VO.UserSelection.eFormType.TransactionForm And bolIsHeader Then
                strScript += QuTab4 & "If bytStatusID > 0 Then .CommandText += " & """" & QuTab1 & "AND A." & strColStatusName & "=@" & strColStatusName & """" & vbNewLine & vbNewLine
            End If

            If dtColumnPK.Rows.Count > 1 And cls.FormType = VO.UserSelection.eFormType.MasterForm Then
                strScript += SetupParameters(BL.ColumnList.ListDataPK(strTableName, cls), True)
            End If

            If cls.FormType = VO.UserSelection.eFormType.TransactionForm And bolIsHeader Then
                strScript +=
                QuTab4 & ".Parameters.Add(""@ComLocDivSubDivID"", SqlDbType.Int).Value = intComLocDivSubDIvID " & vbNewLine &
                QuTab4 & ".Parameters.Add(""@DateFrom"", SqlDbType.DateTime).Value = dtmDateFrom " & vbNewLine &
                QuTab4 & ".Parameters.Add(""@DateTo"", SqlDbType.DateTime).Value = dtmDateTo.AddHours(23).AddMinutes(59).AddSeconds(59) " & vbNewLine &
                QuTab4 & ".Parameters.Add(""@" & strColStatusName & """, SqlDbType.Int).Value = bytStatusID"
            End If

            strScript +=
            "" & vbNewLine &
            QuTab3 & "End With" & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then
                strScript += QuTab3 & "Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)" & vbNewLine
            Else
                strScript += QuTab3 & "Return SQL.QueryDataTable(sqlcmdExecute)" & vbNewLine
            End If

            strScript +=
            "        End Function" & vbNewLine & vbNewLine
            Return strScript
        End Function

#End Region

#Region "SaveData"

        Private Function DL_ScriptSaveData(ByVal strTableName As String, ByVal strFileName As String, ByVal cls As VO.UserSelection)
            Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)

            Dim strScript As String = "        " & strFuncAccessType & " Shared Sub SaveData("

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then strScript += "ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction, "

            strScript += "ByVal bolNew as Boolean, ByVal clsData As VO." & strFileName.Trim & ")" & vbNewLine

            strScript +=
                "            Dim sqlcmdExecute As New SqlCommand" & vbNewLine &
                "            With sqlcmdExecute" & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then
                strScript +=
                "                .Connection = sqlCon" & vbNewLine &
                "                .Transaction = sqlTrans" & vbNewLine
            End If

            strScript +=
                "                If bolNew Then" & vbNewLine &
                "                    .CommandText = " & vbNewLine &
                "" & DL_ScriptInsert(BL.ColumnList.ListData(strTableName, cls), strTableName) &
                "                Else" & vbNewLine &
                "                    .CommandText = " & vbNewLine &
                "" & DL_ScriptUpdate(BL.ColumnList.ListData(strTableName, cls), strTableName, BL.ColumnList.ListDataPK(strTableName, cls)) &
                "                End If" & vbNewLine & vbNewLine &
                "" & SetupParameters(BL.ColumnList.ListData(strTableName, cls), False) & vbNewLine &
                "            End With" & vbNewLine &
                "            Try" & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then
                strScript += "                SQL.ExecuteNonQuery(sqlcmdExecute)" & vbNewLine
            ElseIf cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then
                strScript += "                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)" & vbNewLine
            End If

            strScript +=
                "            Catch ex As SqlException" & vbNewLine &
                "                Throw ex" & vbNewLine &
                "            End Try" & vbNewLine &
                "        End Sub" & vbNewLine & vbNewLine

            Return strScript
        End Function

        Private Function DL_ScriptInsert(ByVal dtColumn As DataTable, ByVal strTableName As String)
            Dim strScript As String =
                """" & vbCrLf &
                "INSERT INTO " & strTableName & vbCrLf &
                QuTab1 & "("
            With dtColumn
                For i As Integer = 0 To .Rows.Count - 1
                    If .Rows(i).Item("ColumnName") = "Status" Or .Rows(i).Item("ColumnName") = "LogInc" Or
                        .Rows(i).Item("ColumnName") = "IsSync" Then
                        .Rows(i).BeginEdit()
                        .Rows(i).Delete()
                        .Rows(i).EndEdit()
                    End If
                Next
                .AcceptChanges()

                For i As Integer = 0 To .Rows.Count - 1
                    strScript += .Rows(i).Item("ColumnName")

                    If i <> .Rows.Count - 1 Then
                        strScript += ", "
                    Else
                        strScript += ")" & vbNewLine
                    End If

                    If i Mod 6 = 0 And i <> 0 And i <> .Rows.Count - 1 Then strScript += vbNewLine & QuTab1 & " "
                Next
            End With

            strScript +=
                "VALUES " & vbCrLf &
                QuTab1 & "("

            With dtColumn
                For i As Integer = 0 To .Rows.Count - 1

                    If .Rows(i).Item("ColumnName") = "LogDate" Or .Rows(i).Item("ColumnName") = "CreateDate" Or .Rows(i).Item("ColumnName") = "CreatedDate" Or .Rows(i).Item("ColumnName") = "StatusDate" Then
                        strScript += "GETDATE()"
                    ElseIf .Rows(i).Item("ColumnName") = "CreateBy" Or .Rows(i).Item("ColumnName") = "CreatedBy" Or .Rows(i).Item("ColumnName") = "StatusBy" Then
                        strScript += "@LogBy"
                    Else
                        strScript += "@" & .Rows(i).Item("ColumnName") & ""
                    End If

                    If i <> .Rows.Count - 1 Then
                        strScript += ", "
                    End If

                    If i = .Rows.Count - 1 Then
                        strScript += ")" & vbNewLine
                    ElseIf i Mod 6 = 0 And i <> 0 Then
                        strScript += vbCrLf & QuTab1 & " "
                    End If
                Next
            End With
            strScript += """" & vbCrLf
            Return strScript
        End Function

        Private Function DL_ScriptUpdate(ByVal dtColumn As DataTable, ByVal strTableName As String, ByVal dtColumnPK As DataTable)
            Dim strScript As String =
                """" & vbCrLf &
                "UPDATE " & strTableName & " SET " & vbCrLf

            With dtColumn
                For i As Integer = 0 To .Rows.Count - 1
                    If .Rows(i).Item("ColumnName") = "CreateBy" Or .Rows(i).Item("ColumnName") = "CreateDate" Or
                        .Rows(i).Item("ColumnName") = "CreatedBy" Or .Rows(i).Item("ColumnName") = "CreatedDate" Then
                        .Rows(i).BeginEdit()
                        .Rows(i).Delete()
                        .Rows(i).EndEdit()
                    End If
                Next
                .AcceptChanges()

                For i As Integer = 0 To .Rows.Count - 1
                    If .Rows(i).Item("PrimaryKey") <> "1" Then
                        If .Rows(i).Item("ColumnName") = "LogInc" Then
                            strScript += QuTab1 & "LogInc=LogInc+1"
                        ElseIf .Rows(i).Item("ColumnName") = "LogDate" Then
                            strScript += QuTab1 & "LogDate=GETDATE()"
                        ElseIf .Rows(i).Item("ColumnName") = "IsSync" Then
                            strScript += QuTab1 & "IsSync=0"
                        Else
                            strScript += QuTab1 & .Rows(i).Item("ColumnName") & "=@" & .Rows(i).Item("ColumnName")
                        End If

                        If i = .Rows.Count - 1 Then
                            strScript += vbNewLine
                        Else
                            strScript += ", " & vbNewLine
                        End If
                    End If
                Next

            End With

            strScript += "WHERE" & vbNewLine

            With dtColumnPK
                For i As Integer = 0 To .Rows.Count - 1
                    If i = 0 Then
                        strScript += QuTab1 & .Rows(i).Item("ColumnName") & "=@" & .Rows(i).Item("ColumnName") & vbNewLine
                    Else
                        strScript += QuTab1 & "AND " & .Rows(i).Item("ColumnName") & "=@" & .Rows(i).Item("ColumnName") & vbNewLine
                    End If
                Next
            End With
            strScript += """" & vbNewLine
            Return strScript
        End Function

#End Region

#Region "GetDetail"

        Private Function DL_ScriptGetDetail(ByVal dtColumn As DataTable, ByVal strTableName As String, ByVal strFileName As String, ByVal cls As VO.UserSelection)
            Dim strScript As String = ""
            Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)

            strScript = "        " & strFuncAccessType & " Shared Function GetDetail("

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then strScript += "ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction"

            With dtColumnPK
                If .Rows.Count > 0 Then If cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then strScript += ", "

                For i As Integer = 0 To .Rows.Count - 1
                    strScript += "ByVal " & pubGetVBInit(.Rows(i).Item("DataType")) & .Rows(i).Item("ColumnName") & " As " & pubGetVBType(.Rows(i).Item("DataType"))
                    If i = .Rows.Count - 1 Then
                        strScript += ")"
                    Else
                        strScript += ", "
                    End If
                Next
                strScript += " As VO." & strFileName & vbNewLine
            End With

            strScript +=
                "            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing" & vbNewLine &
                "            Dim voReturn As New VO." & strFileName & vbNewLine &
                "            Try" & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then strScript += "                If Not SQL.bolUseTrans Then SQL.OpenConnection()" & vbNewLine

            strScript += "                With sqlcmdExecute" & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then
                strScript += "                    .Connection = SQL.sqlConn " & vbNewLine
            ElseIf cls.ConnectionType = eConnectionType.SelfConnection Then
                strScript += "                    .Connection = sqlCon " & vbNewLine
                strScript += "                    .Transaction = sqlTrans " & vbNewLine
            End If

            strScript +=
                "                    .CommandText =  " & vbNewLine

            strScript +=
                """" & vbNewLine &
                "SELECT TOP 1 " & vbNewLine &
                QuTab1

            With dtColumn
                For i As Integer = 0 To .Rows.Count - 1
                    strScript += "A." & .Rows(i).Item("ColumnName")

                    If i <> .Rows.Count - 1 Then
                        strScript += ", "
                    End If

                    If i Mod 6 = 0 And i <> 0 Then
                        strScript += vbNewLine & QuTab1
                    End If
                Next
            End With
            strScript +=
                vbNewLine &
                "FROM " & strTableName & " A" & vbNewLine &
                "WHERE" & vbNewLine

            With dtColumnPK
                For i As Integer = 0 To .Rows.Count - 1
                    If i = 0 Then
                        strScript += QuTab1 & .Rows(i).Item("ColumnName") & "=@" & .Rows(i).Item("ColumnName")
                    Else
                        strScript += QuTab1 & "AND " & .Rows(i).Item("ColumnName") & "=@" & .Rows(i).Item("ColumnName")
                    End If

                    strScript += vbNewLine
                Next
            End With

            strScript += """" & vbNewLine

            strScript += "" & SetupParameters(BL.ColumnList.ListDataPK(strTableName, cls), True) & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then strScript += "                    If SQL.bolUseTrans Then .Transaction = SQL.sqlTrans " & vbNewLine

            strScript += "                End With" & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then
                strScript += "                sqlrdData = sqlcmdExecute.ExecuteReader(CommandBehavior.SingleRow) " & vbNewLine
            ElseIf cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then
                strScript += "                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute) " & vbNewLine
            End If

            strScript +=
                "                With sqlrdData " & vbNewLine &
                "                    If .HasRows Then " & vbNewLine &
                "                        .Read() " & vbNewLine &
                "" & SetupReturn(dtColumn) &
                "                    End If " & vbNewLine &
                "                End With " & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then strScript += "                If Not SQL.bolUseTrans Then SQL.CloseConnection() " & vbNewLine

            strScript +=
                "            Catch ex As Exception " & vbNewLine &
                "                Throw ex " & vbNewLine &
                "            Finally " & vbNewLine &
                "                If sqlrdData IsNot Nothing Then sqlrdData.Close() " & vbNewLine &
                "            End Try " & vbNewLine &
                "            Return voReturn " & vbNewLine &
                "        End Function " & vbNewLine & vbNewLine

            Return strScript
        End Function

#End Region

#Region "DeleteData"

        Private Function DL_ScriptDeleteData(ByVal strTableName As String, ByVal strFileName As String, ByVal cls As VO.UserSelection)
            Dim strScript As String = ""
            Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)

            strScript =
                "        " & strFuncAccessType & " Shared Sub DeleteData("

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then
                strScript += "ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction, "
            End If

            With dtColumnPK
                For i As Integer = 0 To .Rows.Count - 1
                    strScript += "ByVal " & pubGetVBInit(.Rows(i).Item("DataType")) & .Rows(i).Item("ColumnName") & " As " & pubGetVBType(.Rows(i).Item("DataType"))
                    If i = .Rows.Count - 1 Then
                        strScript += ")" & vbNewLine
                    Else
                        strScript += ", "
                    End If
                Next
            End With

            strScript +=
                "            Dim sqlcmdExecute As New SqlCommand" & vbNewLine &
                "            With sqlcmdExecute" & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then
                strScript +=
                "                .Connection = sqlCon" & vbNewLine &
                "                .Transaction = sqlTrans" & vbNewLine
            End If

            strScript +=
                "                .CommandText = " & vbNewLine &
                """" & vbNewLine &
                "DELETE FROM " & strTableName & vbNewLine &
                "WHERE" & vbNewLine

            With dtColumnPK
                For i As Integer = 0 To .Rows.Count - 1
                    If i = 0 Then
                        strScript += QuTab1 & .Rows(i).Item("ColumnName") & "=@" & .Rows(i).Item("ColumnName")
                    Else
                        strScript += QuTab1 & "AND " & .Rows(i).Item("ColumnName") & "=@" & .Rows(i).Item("ColumnName")
                    End If

                    strScript += vbNewLine
                Next
            End With

            strScript += """" & vbNewLine

            strScript +=
                "" & SetupParameters(BL.ColumnList.ListDataPK(strTableName, cls), True) & vbNewLine &
                "            End With" & vbNewLine &
                "            Try" & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then
                strScript += "                SQL.ExecuteNonQuery(sqlcmdExecute) " & vbNewLine
            ElseIf cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then
                strScript += "                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans) " & vbNewLine
            End If

            strScript +=
                "            Catch ex As SqlException" & vbNewLine &
                "                Throw ex" & vbNewLine &
                "            End Try" & vbNewLine &
                "        End Sub" & vbNewLine & vbNewLine

            Return strScript
        End Function

#End Region

#Region "Update Status"
        Private Function DL_ScriptUpdateStatus(ByVal strTableName As String, ByVal strFileName As String, ByVal cls As VO.UserSelection)
            Dim strScript As String = ""
            Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)
            Dim drPK As DataRow

            drPK = dtColumnPK.NewRow
            drPK.BeginEdit()
            drPK.Item("ColumnName") = "LogBy"
            drPK.Item("DataType") = "varchar"
            drPK.Item("MaxLength") = 20
            drPK.Item("precision") = 0
            drPK.Item("scale") = 0
            drPK.Item("is_nullable") = 0
            drPK.Item("PrimaryKey") = 0
            drPK.Item("is_identity") = 0
            drPK.EndEdit()
            dtColumnPK.Rows.Add(drPK)
            dtColumnPK.BeginInit()

            strScript =
                "        " & strFuncAccessType & " Shared Sub DeleteData("

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then
                strScript += "ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction, "
            End If

            With dtColumnPK
                For i As Integer = 0 To .Rows.Count - 1
                    strScript += "ByVal " & pubGetVBInit(.Rows(i).Item("DataType")) & .Rows(i).Item("ColumnName") & " As " & pubGetVBType(.Rows(i).Item("DataType"))
                    If i = .Rows.Count - 1 Then
                        strScript += ")" & vbNewLine
                    Else
                        strScript += ", "
                    End If
                Next
            End With

            strScript +=
                "            Dim sqlcmdExecute As New SqlCommand" & vbNewLine &
                "            With sqlcmdExecute" & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then
                strScript +=
                QuTab4 & ".Connection = sqlCon" & vbNewLine &
                QuTab4 & ".Transaction = sqlTrans" & vbNewLine
            End If

            strScript +=
                QuTab4 & ".CommandText = " & vbNewLine &
                """" & vbNewLine &
                "UPDATE " & strTableName & vbNewLine &
                QuTab1 & "SET " & strFileName & "Status=255, LogBy=@LogBy, LogDate=GETDATE(), LogInc=LogInc+1" & vbNewLine &
                "WHERE" & vbNewLine

            Dim drTemp() As DataRow = dtColumnPK.Select("PrimaryKey=1")
            Dim dtTemp As DataTable = drTemp.CopyToDataTable

            With dtTemp
                For i As Integer = 0 To .Rows.Count - 1
                    If i = 0 Then
                        strScript += QuTab1 & .Rows(i).Item("ColumnName") & "=@" & .Rows(i).Item("ColumnName")
                    Else
                        strScript += QuTab1 & "AND " & .Rows(i).Item("ColumnName") & "=@" & .Rows(i).Item("ColumnName")
                    End If
                    strScript += vbNewLine
                Next
            End With

            strScript += """" & vbNewLine

            strScript +=
                "" & SetupParameters(dtColumnPK, True) & vbNewLine &
                "            End With" & vbNewLine &
                "            Try" & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then
                strScript += "                SQL.ExecuteNonQuery(sqlcmdExecute) " & vbNewLine
            ElseIf cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then
                strScript += "                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans) " & vbNewLine
            End If

            strScript +=
                "            Catch ex As SqlException" & vbNewLine &
                "                Throw ex" & vbNewLine &
                "            End Try" & vbNewLine &
                "        End Sub" & vbNewLine & vbNewLine

            Return strScript
        End Function
#End Region

#Region "GetMaxID"
        Private Function DL_ScriptGetMaxID(ByVal dtColumn As DataTable, ByVal strTableName As String, ByVal strFileName As String, ByVal cls As VO.UserSelection)
            Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)
            Dim strPK As String = BL.ColumnList.GetTop1PK(strTableName, cls)

            Dim strScript As String = "        " & strFuncAccessType & " Shared Function GetMaxID("

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then
                strScript += "ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction"
            End If

            strScript += ") AS Integer" & vbNewLine

            strScript +=
                "            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing " & vbNewLine &
                "            Dim intReturn As Integer = 0 " & vbNewLine &
                "            Try " & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then strScript += "                If Not SQL.bolUseTrans Then SQL.OpenConnection() " & vbNewLine

            strScript +=
                "                With sqlcmdExecute " & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then
                strScript += QuTab5 & ".Connection = SQL.sqlConn " & vbNewLine
            ElseIf cls.ConnectionType = eConnectionType.SelfConnection Then
                strScript += QuTab5 & ".Connection = sqlCon " & vbNewLine
                strScript += QuTab5 & ".Transaction = sqlTrans " & vbNewLine
            End If

            strScript +=
                QuTab5 & ".CommandText = " & vbNewLine &
                """" & vbNewLine &
                "SELECT TOP 1" & vbNewLine &
                QuTab1 & "ID=ISNULL(MAX(" & strPK & "),0)" & vbNewLine &
                "FROM " & strTableName & vbNewLine &
                """" & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then strScript += "                    If SQL.bolUseTrans Then .Transaction = SQL.sqlTrans " & vbNewLine

            strScript += "                End With" & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then
                strScript += "                sqlrdData = sqlcmdExecute.ExecuteReader(CommandBehavior.SingleRow) " & vbNewLine
            ElseIf cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then
                strScript += "                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute) " & vbNewLine
            End If

            strScript +=
            "                With sqlrdData " & vbNewLine &
            "                    If .HasRows Then " & vbNewLine &
            "                        .Read() " & vbNewLine &
            "                        intReturn = .Item(" & Qu1 & "ID" & Qu1 & ") + 1" & vbNewLine &
            "                    End If " & vbNewLine &
            "                End With " & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then strScript += "                If Not SQL.bolUseTrans Then SQL.CloseConnection() " & vbNewLine

            strScript +=
            "            Catch ex As Exception " & vbNewLine &
            "                Throw ex " & vbNewLine &
            "            Finally " & vbNewLine &
            "                If sqlrdData IsNot Nothing Then sqlrdData.Close() " & vbNewLine &
            "            End Try " & vbNewLine &
            "            Return intReturn " & vbNewLine &
            "        End Function " & vbNewLine & vbNewLine

            Return strScript
        End Function
#End Region

#Region "DataExists"
        Private Function DL_ScriptDataExists(ByVal dtColumn As DataTable, ByVal strTableName As String, ByVal strFileName As String, ByVal cls As VO.UserSelection)
            Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)
            Dim strPK As String = BL.ColumnList.GetTop1PK(strTableName, cls)

            Dim strScript As String =
                "        " & strFuncAccessType & " Shared Function DataExists("

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then
                strScript += "ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction"
            End If

            With dtColumnPK
                If .Rows.Count > 0 Then
                    If cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then strScript += ", "
                End If

                For i As Integer = 0 To .Rows.Count - 1
                    strScript += "ByVal " & pubGetVBInit(.Rows(i).Item("DataType")) & .Rows(i).Item("ColumnName") & " As " & pubGetVBType(.Rows(i).Item("DataType"))
                    If i = .Rows.Count - 1 Then
                        strScript += ")"
                    Else
                        strScript += ", "
                    End If
                Next
                strScript += " As Boolean" & vbNewLine
            End With

            strScript +=
                "            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing" & vbNewLine &
                "            Dim bolExists As Boolean = False " & vbNewLine &
                "            Try " & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then strScript += "                If Not SQL.bolUseTrans Then SQL.OpenConnection() " & vbNewLine

            strScript +=
                "                With sqlcmdExecute " & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then
                strScript += "                    .Connection = SQL.sqlConn " & vbNewLine
            ElseIf cls.ConnectionType = eConnectionType.SelfConnection Then
                strScript += "                    .Connection = sqlCon " & vbNewLine
                strScript += "                    .Transaction = sqlTrans " & vbNewLine
            End If

            strScript +=
                QuTab5 & ".CommandText = " & vbNewLine &
                """" & vbNewLine &
                "SELECT TOP 1" & vbNewLine &
                QuTab1 & strPK & vbNewLine &
                "FROM " & strTableName & vbNewLine &
                "WHERE " & vbNewLine


            With dtColumnPK
                For i As Integer = 0 To .Rows.Count - 1
                    If i = 0 Then
                        strScript += QuTab1 & .Rows(i).Item("ColumnName") & "=@" & .Rows(i).Item("ColumnName")
                    Else
                        strScript += QuTab1 & "AND " & .Rows(i).Item("ColumnName") & "=@" & .Rows(i).Item("ColumnName")
                    End If
                    strScript += vbNewLine
                Next
            End With

            strScript += """" & vbNewLine

            strScript += "" & SetupParameters(BL.ColumnList.ListDataPK(strTableName, cls), True) & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then strScript += "                If Not SQL.bolUseTrans Then SQL.CloseConnection() " & vbNewLine

            strScript += "                End With" & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then
                strScript += "                sqlrdData = sqlcmdExecute.ExecuteReader(CommandBehavior.SingleRow) " & vbNewLine
            ElseIf cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then
                strScript += "                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute) " & vbNewLine
            End If

            strScript +=
                "                With sqlrdData " & vbNewLine &
                "                    If .HasRows Then " & vbNewLine &
                "                        .Read() " & vbNewLine &
                "                        bolExists = True" & vbNewLine &
                "                    End If " & vbNewLine &
                "                End With " & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then strScript += "                If Not SQL.bolUseTrans Then SQL.CloseConnection() " & vbNewLine

            strScript +=
                "            Catch ex As Exception " & vbNewLine &
                "                Throw ex " & vbNewLine &
                "            Finally " & vbNewLine &
                "                If sqlrdData IsNot Nothing Then sqlrdData.Close() " & vbNewLine &
                "            End Try " & vbNewLine &
                "            Return bolExists " & vbNewLine &
                "        End Function " & vbNewLine & vbNewLine

            Return strScript
        End Function
#End Region

#Region "IsDraftSubmit"
        Private Function DL_ScriptIsDraftSubmit(ByVal strTableName As String, ByVal strFileName As String, ByVal bytDataStatus As Byte, ByVal cls As VO.UserSelection)
            Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)

            Dim strScript As String = "        " & strFuncAccessType & " Shared Function Is" & IIf(bytDataStatus = 0, "Draft", "Submit") & "("

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then
                strScript += "ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction"
            End If

            With dtColumnPK
                If .Rows.Count > 0 Then If cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then strScript += ", "

                For i As Integer = 0 To .Rows.Count - 1
                    strScript += "ByVal " & pubGetVBInit(.Rows(i).Item("DataType")) & .Rows(i).Item("ColumnName") & " As " & pubGetVBType(.Rows(i).Item("DataType"))
                    If i = .Rows.Count - 1 Then
                        strScript += ") As Boolean" & vbNewLine
                    Else
                        strScript += ", "
                    End If
                Next
            End With

            strScript +=
            "            Dim bolReturn As Boolean = False " & vbNewLine &
            "            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing" & vbNewLine &
            "            Try " & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then strScript += "                If Not SQL.bolUseTrans Then SQL.OpenConnection()" & vbNewLine

            strScript += "                With sqlcmdExecute " & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then
                strScript += "                    .Connection = SQL.sqlConn " & vbNewLine
            ElseIf cls.ConnectionType = eConnectionType.SelfConnection Then
                strScript += "                    .Connection = sqlCon " & vbNewLine
                strScript += "                    .Transaction = sqlTrans " & vbNewLine
            End If

            strScript +=
            QuTab5 & ".CommandText = " & vbNewLine &
            """" & vbNewLine &
            "SELECT" & vbNewLine &
            QuTab1 & strFileName & "Status" & vbNewLine &
            "FROM " & strTableName & vbNewLine &
            "WHERE" & vbNewLine

            With dtColumnPK
                For i As Integer = 0 To .Rows.Count - 1
                    If i = 0 Then
                        strScript += QuTab1 & .Rows(i).Item("ColumnName") & "=@" & .Rows(i).Item("ColumnName")
                    Else
                        strScript += QuTab1 & "AND " & .Rows(i).Item("ColumnName") & "=@" & .Rows(i).Item("ColumnName")
                    End If
                    strScript += vbNewLine
                Next
            End With

            strScript +=
                QuTab1 & "AND StatusID=@StatusID" & vbNewLine &
                """" & vbNewLine &
                QuTab4 & ".Parameters.Add(""@StatusID"", SqlDbType.Int).Value = VO.Status.Values.Draft" & vbNewLine &
                SetupParameters(BL.ColumnList.ListDataPK(strTableName, cls), True) & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then strScript += "                    If SQL.bolUseTrans Then .Transaction = SQL.sqlTrans" & vbNewLine

            strScript += "            End With" & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then
                strScript += "                sqlrdData = sqlcmdExecute.ExecuteReader(CommandBehavior.SingleRow) " & vbNewLine
            ElseIf cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then
                strScript += "                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute) " & vbNewLine
            End If

            strScript +=
                "                With sqlrdData " & vbNewLine &
                "                    If .HasRows Then " & vbNewLine &
                "                        .Read() " & vbNewLine &
                "                        bolReturn = True " & vbNewLine &
                "                    End If " & vbNewLine &
                "                End With " & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then strScript += "                If Not SQL.bolUseTrans Then SQL.CloseConnection() " & vbNewLine

            strScript +=
                "            Catch ex As Exception " & vbNewLine &
                "                Throw ex " & vbNewLine &
                "            Finally " & vbNewLine &
                "                If sqlrdData IsNot Nothing Then sqlrdData.Close() " & vbNewLine &
                "            End Try " & vbNewLine &
                "            Return bolReturn " & vbNewLine &
                "        End Function" & vbNewLine & vbNewLine

            Return strScript
        End Function

#End Region

#Region "SubmitData"

        Private Function DL_ScriptSubmitData(ByVal strTableName As String, ByVal strFileName As String, ByVal cls As VO.UserSelection)
            Dim strScript As String = ""
            Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)
            Dim drPK As DataRow

            drPK = dtColumnPK.NewRow
            drPK.BeginEdit()
            drPK.Item("ColumnName") = "LogBy"
            drPK.Item("DataType") = "varchar"
            drPK.Item("MaxLength") = 20
            drPK.Item("precision") = 0
            drPK.Item("scale") = 0
            drPK.Item("is_nullable") = 0
            drPK.Item("PrimaryKey") = 0
            drPK.Item("is_identity") = 0
            drPK.EndEdit()
            dtColumnPK.Rows.Add(drPK)
            dtColumnPK.BeginInit()

            strScript =
                "        " & strFuncAccessType & " Shared Sub SubmitData("

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then strScript += "ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction, "

            With dtColumnPK
                For i As Integer = 0 To .Rows.Count - 1
                    strScript += "ByVal " & pubGetVBInit(.Rows(i).Item("DataType")) & .Rows(i).Item("ColumnName") & " As " & pubGetVBType(.Rows(i).Item("DataType"))
                    If i = .Rows.Count - 1 Then
                        strScript += ")" & vbNewLine
                    Else
                        strScript += ", "
                    End If
                Next
            End With

            strScript +=
                "            Dim sqlcmdExecute As New SqlCommand" & vbNewLine &
                "            With sqlcmdExecute" & vbNewLine

            If cls.ConnectionType = eConnectionType.SelfConnection Then
                strScript += "                    .Connection = sqlCon " & vbNewLine
                strScript += "                    .Transaction = sqlTrans " & vbNewLine
            End If

            strScript +=
                "                .CommandText = " & vbNewLine &
                """" & vbNewLine &
                "UPDATE " & strTableName & vbNewLine &
                QuTab1 & "SET StatusID=@StatusID, SubmitBy=@LogBy, SubmitDate=GETDATE()" & vbNewLine &
                "WHERE" & vbNewLine

            Dim drTemp() As DataRow = dtColumnPK.Select("PrimaryKey=1")
            Dim dtTemp As DataTable = drTemp.CopyToDataTable

            With dtTemp
                For i As Integer = 0 To .Rows.Count - 1
                    If i = 0 Then
                        strScript += QuTab1 & .Rows(i).Item("ColumnName") & "=@" & .Rows(i).Item("ColumnName")
                    Else
                        strScript += QuTab1 & "AND " & .Rows(i).Item("ColumnName") & "=@" & .Rows(i).Item("ColumnName")
                    End If
                    strScript += vbNewLine
                Next
            End With

            strScript += """" & vbNewLine

            strScript +=
                QuTab4 & ".Parameters.Add(""@StatusID"", SqlDbType.Int).Value = VO.Status.Values.Submit" & vbNewLine &
                "" & SetupParameters(dtColumnPK, True) & vbNewLine &
                "            End With" & vbNewLine &
                "            Try" & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then
                strScript += "                SQL.ExecuteNonQuery(sqlcmdExecute)" & vbNewLine
            ElseIf cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then
                strScript += "                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)" & vbNewLine
            End If

            strScript +=
                "            Catch ex As SqlException" & vbNewLine &
                "                Throw ex" & vbNewLine &
                "            End Try" & vbNewLine &
                "        End Sub" & vbNewLine & vbNewLine

            Return strScript
        End Function

#End Region

#Region "UnsubmitData"

        Private Function DL_ScriptUnsubmitData(ByVal strTableName As String, ByVal strFileName As String, ByVal cls As VO.UserSelection)
            Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)

            Dim strScript As String = "        " & strFuncAccessType & " Shared Sub UnsubmitData("
            If cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then strScript += "ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction"

            With dtColumnPK
                If .Rows.Count > 0 Then If cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then strScript += ", "
                For i As Integer = 0 To .Rows.Count - 1
                    strScript += "ByVal " & pubGetVBInit(.Rows(i).Item("DataType")) & .Rows(i).Item("ColumnName") & " As " & pubGetVBType(.Rows(i).Item("DataType"))
                    If i = .Rows.Count - 1 Then
                        strScript += ")" & vbNewLine
                    Else
                        strScript += ", "
                    End If
                Next
            End With

            strScript +=
                "            Dim sqlcmdExecute As New SqlCommand" & vbNewLine &
                "            With sqlcmdExecute" & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then
                strScript +=
                "                .Connection = sqlCon" & vbNewLine &
                "                .Transaction = sqlTrans" & vbNewLine
            End If

            strScript +=
                "                .CommandText = " & vbNewLine &
                """" & vbNewLine &
                "UPDATE " & strTableName & vbNewLine &
                QuTab1 & "SET StatusID=@StatusID, SubmitBy='', SubmitDate=GETDATE()" & vbNewLine &
                "WHERE" & vbNewLine


            With dtColumnPK
                For i As Integer = 0 To .Rows.Count - 1
                    If i = 0 Then
                        strScript += QuTab1 & .Rows(i).Item("ColumnName") & "=@" & .Rows(i).Item("ColumnName")
                    Else
                        strScript += QuTab1 & "AND " & .Rows(i).Item("ColumnName") & "=@" & .Rows(i).Item("ColumnName")
                    End If
                    strScript += vbNewLine
                Next
            End With

            strScript += """" & vbNewLine

            strScript +=
                QuTab4 & ".Parameters.Add(""@StatusID"", SqlDbType.Int).Value = VO.Status.Values.Draft" & vbNewLine &
                "" & SetupParameters(dtColumnPK, True) & vbNewLine &
                "            End With" & vbNewLine &
                "            Try" & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then
                strScript += "                SQL.ExecuteNonQuery(sqlcmdExecute)" & vbNewLine
            ElseIf cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then
                strScript += "                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)" & vbNewLine
            End If

            strScript +=
                "            Catch ex As SqlException" & vbNewLine &
                "                Throw ex" & vbNewLine &
                "            End Try" & vbNewLine &
                "        End Sub" & vbNewLine & vbNewLine

            Return strScript
        End Function

#End Region

#Region "ListDataHistory"

        Private Function DL_ScriptListDataHistory(ByVal dtColumn As DataTable, ByVal strTableName As String, ByVal strFileName As String, ByVal cls As VO.UserSelection)
            Dim strScript As String = ""
            Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)
            If dtColumn.Rows.Count = 0 Then Return strScript & vbNewLine

            strScript =
                "        " & strFuncAccessType & " Shared Function ListHistory("

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then strScript += "ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction"

            With dtColumnPK
                If .Rows.Count > 0 And cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then strScript += ", "
                If .Rows.Count > 0 Then strScript += "ByVal " & pubGetVBInit(.Rows(0).Item("DataType")) & .Rows(0).Item("ColumnName") & " As " & pubGetVBType(.Rows(0).Item("DataType"))
            End With

            strScript += ") As DataTable" & vbNewLine


            strScript +=
                "            Dim sqlcmdExecute As New SqlCommand" & vbNewLine &
                "            With sqlcmdExecute" & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then
                strScript +=
                "                .Connection = sqlCon" & vbNewLine &
                "                .Transaction = sqlTrans" & vbNewLine
            End If

            strScript +=
                "                .CommandText = " & vbNewLine &
                """" & vbNewLine &
                "SELECT" & vbNewLine &
                QuTab1 & "Status, StatusBy, StatusDate, Remarks" & vbNewLine &
                "FROM " & strTableName & vbNewLine &
                "WHERE " & vbNewLine &
                QuTab1 & dtColumnPK.Rows(0).Item("ColumnName") & "=@" & dtColumnPK.Rows(0).Item("ColumnName") & vbNewLine &
                """" & vbNewLine &
                SetupParameters(BL.ColumnList.ListDataTop1PK(strTableName, cls), True) & vbNewLine

            strScript += "            End With" & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then
                strScript += "            Return SQL.QueryDataTable(sqlcmdExecute, sqlTrans)" & vbNewLine
            Else
                strScript += "            Return SQL.QueryDataTable(sqlcmdExecute)" & vbNewLine
            End If

            strScript += "        End Function" & vbNewLine & vbNewLine
            Return strScript
        End Function

#End Region

#Region "SaveDataHistory"

        Private Function DL_ScriptSaveDataHistory(ByVal dtColumn As DataTable, ByVal strTableName As String, ByVal strFileName As String, ByVal cls As VO.UserSelection)
            Dim strScript As String = ""
            If dtColumn.Rows.Count = 0 Then Return strScript & vbNewLine
            strScript =
                "        " & strFuncAccessType & " Shared Sub SaveHistory("

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then strScript += "ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction"

            With dtColumn
                If .Rows.Count > 0 And cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then strScript += ", "
                For i As Integer = 0 To .Rows.Count - 1
                    If .Rows(i).Item("ColumnName") <> "StatusDate" Then
                        strScript += "ByVal " & pubGetVBInit(.Rows(i).Item("DataType")) & .Rows(i).Item("ColumnName") & " As " & pubGetVBType(.Rows(i).Item("DataType"))
                        If i = .Rows.Count - 1 Then
                            strScript += ")" & vbNewLine
                        Else
                            strScript += ", "
                        End If
                    End If
                Next
            End With
            strScript +=
                "            Dim sqlcmdExecute As New SqlCommand" & vbNewLine &
                "            With sqlcmdExecute" & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then
                strScript +=
                "                .Connection = sqlCon" & vbNewLine &
                "                .Transaction = sqlTrans" & vbNewLine
            End If

            strScript +=
                "                    .CommandText = _" & vbNewLine &
                "" & DL_ScriptInsert(BL.ColumnList.ListData(strTableName, cls), strTableName) & vbNewLine &
                "" & SetupParameters(BL.ColumnList.ListDataTop1PK(strTableName, cls), True) & vbNewLine &
                "            End With" & vbNewLine &
                "            Try" & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then
                strScript += "                SQL.ExecuteNonQuery(sqlcmdExecute)" & vbNewLine
            ElseIf cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then
                strScript += "                SQL.ExecuteNonQuery(sqlcmdExecute, sqlTrans)" & vbNewLine
            End If

            strScript +=
                "            Catch ex As SqlException" & vbNewLine &
                "                Throw ex" & vbNewLine &
                "            End Try" & vbNewLine &
                "        End Sub" & vbNewLine & vbNewLine

            Return strScript
        End Function

#End Region

#Region "GetMaxHistoryID"

        Private Function DL_ScriptGetMaxHistoryID(ByVal dtColumn As DataTable, ByVal strTableName As String, ByVal strFileName As String, ByVal cls As VO.UserSelection)
            Dim strScript As String = ""
            If dtColumn.Rows.Count = 0 Then Return strScript & vbNewLine
            Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)
            Dim strPK As String = BL.ColumnList.GetTop1PK(strTableName, cls)

            strScript =
                "        " & strFuncAccessType & " Shared Function GetMaxHistoryID("

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then strScript += "ByRef sqlCon As SqlConnection, ByRef sqlTrans As SqlTransaction"

            With dtColumnPK
                If .Rows.Count > 0 Then If cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then strScript += ", "
                strScript += "ByVal " & pubGetVBInit(.Rows(0).Item("DataType")) & .Rows(0).Item("ColumnName") & " As " & pubGetVBType(.Rows(0).Item("DataType")) & ") As Integer" & vbNewLine
            End With

            strScript +=
                "            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader = Nothing " & vbNewLine &
                "            Dim intReturn As Integer = 0 " & vbNewLine &
                "            Try " & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then strScript += "                If Not SQL.bolUseTrans Then SQL.OpenConnection() " & vbNewLine

            strScript += "                With sqlcmdExecute " & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then
                strScript += "                    .Connection = SQL.sqlConn " & vbNewLine
            ElseIf cls.ConnectionType = eConnectionType.SelfConnection Then
                strScript += "                    .Connection = sqlCon " & vbNewLine
                strScript += "                    .Transaction = sqlTrans " & vbNewLine
            End If

            strScript +=
                "                    .CommandText = " & vbNewLine &
                """" & vbNewLine &
                "SELECT TOP 1" & vbNewLine &
                QuTab1 & "ID=ISNULL(MAX(AutoNumber),0)" & vbNewLine &
                "FROM " & strTableName & vbNewLine &
                "WHERE" & vbNewLine

            strScript += QuTab1 & dtColumnPK.Rows(0).Item("ColumnName") & "=@" & dtColumnPK.Rows(0).Item("ColumnName") & vbNewLine
            strScript += """" & vbNewLine

            strScript += SetupParameters(BL.ColumnList.ListDataTop1PK(strTableName, cls), True) & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then strScript += "                    If SQL.bolUseTrans Then .Transaction = SQL.sqlTrans " & vbNewLine

            strScript += "                End With" & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then
                strScript += "                sqlrdData = sqlcmdExecute.ExecuteReader(CommandBehavior.SingleRow) " & vbNewLine
            ElseIf cls.ConnectionType = VO.UserSelection.eConnectionType.SelfConnection Then
                strScript += "                sqlrdData = SQL.ExecuteReader(sqlCon, sqlcmdExecute) " & vbNewLine
            End If

            strScript +=
                "                With sqlrdData " & vbNewLine &
                "                    If .HasRows Then " & vbNewLine &
                "                        .Read() " & vbNewLine &
                "                        intReturn = .Item(" & Qu1 & "ID" & Qu1 & ") + 1" & vbNewLine &
                "                    End If " & vbNewLine &
                "                End With " & vbNewLine

            If cls.ConnectionType = VO.UserSelection.eConnectionType.SharedConnection Then strScript += "                If Not SQL.bolUseTrans Then SQL.CloseConnection() " & vbNewLine

            strScript +=
                "            Catch ex As Exception " & vbNewLine &
                "                Throw ex " & vbNewLine &
                "            Finally " & vbNewLine &
                "                If sqlrdData IsNot Nothing Then sqlrdData.Close() " & vbNewLine &
                "            End Try " & vbNewLine &
                "            Return intReturn " & vbNewLine &
                "        End Function " & vbNewLine & vbNewLine

            Return strScript
        End Function

#End Region

        Public Sub pubGenerateDL(ByVal strTableName As String, ByVal strFolderName As String, ByVal cls As VO.UserSelection, ByVal bolIsHeader As Boolean)
            Dim strFileName As String = Replace(strTableName.Trim, cls.TextToReplace, "")

            VO.ColumnList.ColumnList = New DataTable
            VO.ColumnList.ColumnList = BL.ColumnList.ListData(strTableName, cls)

            Dim strScript As String =
                "Namespace DL" & vbNewLine &
                " " & vbNewLine &
                "    " & strClassAccessType & " Class " & strFileName.Trim & vbNewLine &
                " " & vbNewLine

            'List Data
            strScript += DL_ScriptListData(VO.ColumnList.ColumnList, strTableName, strFileName, cls, bolIsHeader)

            'SaveData
            strScript += DL_ScriptSaveData(strTableName, strFileName, cls)

            'GetDetail
            strScript += DL_ScriptGetDetail(VO.ColumnList.ColumnList, strTableName, strFileName, cls)

            If cls.FormType = VO.UserSelection.eFormType.MasterForm Then
                'DeleteData
                strScript += DL_ScriptDeleteData(strTableName, strFileName, cls)
            Else
                'DeleteData_UpdateStatus
                strScript += DL_ScriptUpdateStatus(strTableName, strFileName, cls)
            End If

            'GetMaxID
            strScript += DL_ScriptGetMaxID(VO.ColumnList.ColumnList, strTableName, strFileName, cls)

            'DataExists
            strScript += DL_ScriptDataExists(VO.ColumnList.ColumnList, strTableName, strFileName, cls)

            If cls.FormType = VO.UserSelection.eFormType.TransactionForm Then
                'IsDraft
                strScript += DL_ScriptIsDraftSubmit(strTableName, strFileName, 1, cls)

                'SubmitData
                strScript += DL_ScriptSubmitData(strTableName, strFileName, cls)

                'UnsubmitData
                strScript += DL_ScriptUnsubmitData(strTableName, strFileName, cls)

                'IsSubmit
                strScript += DL_ScriptIsDraftSubmit(strTableName, strFileName, 0, cls)

                If cls.IsIncludeStatus Then
                    'Add History Info
                    strTableName += "Status"
                    VO.ColumnList.ColumnList = BL.ColumnList.ListData(strTableName, cls)

                    strScript += "#Region ""History""" & vbNewLine & vbNewLine

                    'List Data
                    strScript += DL_ScriptListDataHistory(VO.ColumnList.ColumnList, strTableName, strFileName, cls)

                    'SaveData
                    strScript += DL_ScriptSaveDataHistory(VO.ColumnList.ColumnList, strTableName, strFileName, cls)

                    'GetMaxID
                    strScript += DL_ScriptGetMaxHistoryID(VO.ColumnList.ColumnList, strTableName, strFileName, cls)

                    strScript += "#End Region" & vbNewLine & vbNewLine

                End If
            End If

            strScript +=
                "    End Class " & vbNewLine &
                "" & vbNewLine &
                "End Namespace" & vbNewLine

            UI.usForm.AppendText_txt(strFolderName, strFileName, ".vb", strScript)
        End Sub

#End Region

#Region "VO"

        Public Sub pubGenerateVO(ByVal strTableName As String, ByVal strFolderName As String, ByVal cls As VO.UserSelection)
            Dim strScript As String = ""
            Dim strFileName As String = Replace(strTableName.Trim, cls.TextToReplace, "")

            VO.ColumnList.ColumnList = New DataTable
            VO.ColumnList.ColumnList = BL.ColumnList.ListData(strTableName, cls)

            strScript =
                "Namespace VO" & vbNewLine &
                " " & vbNewLine &
                "    " & strClassAccessType & " Class " & strFileName.Trim & vbNewLine &
                " " & vbNewLine &
                "        Inherits Common" & vbNewLine &
                " " & vbNewLine

            For Each drColumn As DataRow In VO.ColumnList.ColumnList.Rows
                If drColumn.Item("ColumnName") <> "LogBy" And drColumn.Item("ColumnName") <> "LogInc" And
                   drColumn.Item("ColumnName") <> "LogDate" And drColumn.Item("ColumnName") <> "IsDeleted" And drColumn.Item("ColumnName") <> "ComLocDivSubDivID" And
                   drColumn.Item("ColumnName") <> "Status" And drColumn.Item("ColumnName") <> "IsSync" And drColumn.Item("ColumnName") <> "StatusRemarks" Then
                    strScript +=
                    "        Property " & drColumn.Item("ColumnName") & " As " & pubGetVBType(drColumn.Item("DataType")) & vbNewLine
                End If
            Next

            strScript +=
                " " & vbNewLine &
                "    End Class " & vbNewLine &
                " " & vbNewLine &
                "End Namespace" & vbNewLine

            UI.usForm.AppendText_txt(strFolderName, strFileName, ".vb", strScript)
        End Sub

#End Region

    End Module

End Namespace



