﻿
Imports System.Text.RegularExpressions

Namespace FormFunction

    Module modGenerateFormFunction

        Public Function FunctPrivateConst(ByVal bolfrmDetail As Boolean, ByVal cls As VO.UserSelection) As String
            Dim strScript As String = ""
            If bolfrmDetail Then
                strScript = _
                   "    Private Const _" & vbNewLine & _
                   "       cSave = 0, cClose = 1 " & vbNewLine & _
                   "" & vbNewLine
            Else
                If cls.FormType = VO.UserSelection.eFormType.MasterForm Then
                    strScript = _
                    "    Private Const _" & vbNewLine & _
                    "       cGet = 0, cSep1 = 1, cNew = 2, cDetail = 3, cDelete = 4, cSep2 = 5, cRefresh = 6, cClose = 7 " & vbNewLine & _
                    "" & vbNewLine

                ElseIf cls.FormType = VO.UserSelection.eFormType.TransactionForm Then
                    strScript = _
                    "    Private Const _" & vbNewLine & _
                    "       cNew = 0, cDetail = 1, cDelete = 2, cSep1 = 3, cSubmit = 4, cUnsubmit = 5, cSep2 = 6, cRefresh = 7, cClose = 8 " & vbNewLine & _
                    "" & vbNewLine
                End If
            End If

            Return strScript
        End Function

        Public Function FunctSetIcon(ByVal bolfrmDetail As Boolean, ByVal cls As VO.UserSelection) As String
            Dim strScript As String = ""
            If bolfrmDetail Then
                strScript = _
                   "    Private Sub prvSetIcon()" & vbNewLine & _
                   "        UI.usForm.SetToolBar(Me, ToolBar, " & """0,Save,1,Close" & """)" & vbNewLine & _
                   "    End Sub" & vbNewLine & _
                   "" & vbNewLine
            Else
                If cls.FormType = VO.UserSelection.eFormType.MasterForm Then
                    strScript = _
                   "    Private Sub prvSetIcon()" & vbNewLine & _
                   "        UI.usForm.SetToolBar(Me, ToolBar, " & """0,Get,2,New,3,Detail,4,Delete,6,Refresh,7,Close" & """)" & vbNewLine & _
                   "    End Sub" & vbNewLine & _
                   "" & vbNewLine
                ElseIf cls.FormType = VO.UserSelection.eFormType.TransactionForm Then
                    strScript = _
                    "    Private Sub prvSetIcon()" & vbNewLine & _
                    "        UI.usForm.SetToolBar(Me, ToolBar, " & """0,New,1,Detail,2,Delete,4,Approved,5,Unapproved,7,Refresh,8,Close" & """)" & vbNewLine & _
                    "    End Sub" & vbNewLine & _
                    "" & vbNewLine
                End If
            End If

            Return strScript
        End Function

        Private Function FuncSplitColName(ByVal strSource As String) As String
            Dim bolHasID As Boolean = False
            If strSource.Contains("ID") Then bolHasID = True
            Dim strList As MatchCollection = Regex.Matches(strSource, "[A-Z][a-z]+")
            Dim intPos As Integer = 0
            Dim strResult As String = ""
            For Each m As Match In strList
                If intPos > 0 Then strResult += " "
                strResult += m.ToString
                intPos += 1
            Next
            If bolHasID Then strResult += " ID"
            Return strResult
        End Function

        Public Function FunctSetGrid(ByVal strTableName As String, ByVal cls As VO.UserSelection) As String
            Dim Qu1 As String = """"
            Dim strScript As String = ""

            VO.ColumnList.ColumnList = BL.ColumnList.ListData(strTableName, cls)

            Dim dtColumn As DataTable = BL.ColumnList.ListData(strTableName, cls)
            Dim drCol As DataRow
            drCol = dtColumn.NewRow
            drCol.BeginEdit()
            drCol.Item("ColumnName") = "StatusInfo"
            drCol.Item("DataType") = "varchar"
            drCol.Item("MaxLength") = 20
            drCol.Item("precision") = 0
            drCol.Item("scale") = 0
            drCol.Item("is_nullable") = 0
            drCol.Item("PrimaryKey") = 0
            drCol.Item("is_identity") = 0
            drCol.EndEdit()
            dtColumn.Rows.Add(drCol)
            dtColumn.AcceptChanges()

            strScript = _
               "    Private Sub prvSetGrid()" & vbNewLine

            For Each drColumn As DataRow In dtColumn.Rows
                If drColumn.Item("ColumnName") <> "IsSync" Then
                    strScript &= _
                   "        UI.usForm.SetGrid(grdView, " & Qu1 & drColumn.Item("ColumnName") & Qu1 & ", " & Qu1 & FuncSplitColName(drColumn.Item("ColumnName")) & Qu1 & ", 100, "

                    Select Case drColumn.Item("DataType")
                        Case "varchar"
                            strScript &= "UI.usDefGrid.gString"
                        Case "nvarchar"
                            strScript &= "UI.usDefGrid.gString"
                        Case "bigint"
                            strScript &= "UI.usDefGrid.gIntNum"
                        Case "int"
                            strScript &= "UI.usDefGrid.gIntNum"
                        Case "tinyint"
                            strScript &= "UI.usDefGrid.gIntNum"
                        Case "smallint"
                            strScript &= "UI.usDefGrid.gIntNum"
                        Case "numeric"
                            strScript &= "UI.usDefGrid.gIntNum"
                        Case "datetime"
                            strScript &= "UI.usDefGrid.gFullDate"
                        Case "smalldatetime"
                            strScript &= "UI.usDefGrid.gSmallDate"
                        Case "bit"
                            strScript &= "UI.usDefGrid.gBoolean"
                        Case "decimal"
                            strScript &= "UI.usDefGrid.gReal2Num"
                        Case "money"
                            strScript &= "UI.usDefGrid.gReal2Num"
                        Case "smallmoney"
                            strScript &= "UI.usDefGrid.gReal2Num"
                    End Select

                    strScript &= ") " & vbNewLine
                End If
            Next

            strScript &= _
               "    End Sub" & vbNewLine & _
               "" & vbNewLine

            Return strScript
        End Function

        Public Function FunctSetButton(ByVal cls As VO.UserSelection) As String
            Dim strScript As String = ""
            strScript = _
               "    Private Sub prvSetButton()" & vbNewLine & _
               "        Dim bolEnable As Boolean = IIf(grdView.RowCount > 0, True, False)" & vbNewLine & _
               "        With ToolBar.Buttons" & vbNewLine

            If cls.FormType = VO.UserSelection.eFormType.MasterForm Then
                strScript += _
               "            .Item(cGet).Visible = pubIsLookUp" & vbNewLine & _
               "            .Item(cSep1).Visible = pubIsLookUp" & vbNewLine & _
               "            .Item(cGet).Enabled = bolEnable" & vbNewLine
            End If

            strScript += _
               "            .Item(cDetail).Enabled = bolEnable" & vbNewLine & _
               "            .Item(cDelete).Enabled = bolEnable" & vbNewLine

            If cls.FormType = VO.UserSelection.eFormType.TransactionForm Then
                strScript += _
                "            .Item(cSubmit).Enabled = bolEnable" & vbNewLine & _
                "            .Item(cUnsubmit).Enabled = bolEnable" & vbNewLine
            End If

                strScript += _
               "        End With" & vbNewLine & _
               "    End Sub" & vbNewLine & _
               "" & vbNewLine

            Return strScript
        End Function

        Public Function FunctQuery(ByVal strTableName As String, ByVal cls As VO.UserSelection) As String
            Dim strScript As String = ""
            Dim strFunctionName As String = Replace(strTableName, cls.TextToReplace, "")
            strScript = _
                "    Private Sub prvQuery()" & vbNewLine & _
                "        Try" & vbNewLine & _
                "            grdMain.DataSource = BL." & strFunctionName & ".ListData(" & IIf(cls.FormType = VO.UserSelection.eFormType.TransactionForm, "txtCompanyID.Text.Trim, txtComLocDivSubDivID.Text, dtpDateFrom.Value, dtpDateTo.Value, cboStatus.SelectedIndex", "") & ")" & vbNewLine & _
                "            grdView.BestFitColumns()" & vbNewLine & _
                "        Catch ex As Exception" & vbNewLine & _
                "            UI.usForm.frmMessageBox(ex.Message)" & vbNewLine & _
                "        End Try" & vbNewLine & _
                "        prvSetButton()" & vbNewLine & _
                "    End Sub" & vbNewLine & _
                "" & vbNewLine

            Return strScript
        End Function

        Public Function FunctRefresh(ByVal strTableName As String, ByVal cls As VO.UserSelection) As String
            Dim strScript As String = ""
            Dim strPK As String = BL.ColumnList.GetTop1PK(strTableName, cls)

            strScript = _
                "    Public Sub pubRefresh(Optional ByVal strSearch As String = """"" & ")" & vbNewLine & _
                "        With grdView" & vbNewLine & _
                "            If Not grdView.FocusedValue Is Nothing And strSearch = """" Then" & vbNewLine & _
                "                strSearch = grdView.GetDataRow(grdView.FocusedRowHandle).Item(""" & strPK & """)" & vbNewLine & _
                "            End If" & vbNewLine & _
                "            prvQuery()" & vbNewLine & _
                "            If grdView.RowCount > 0 Then UI.usForm.GridMoveRow(grdView, """ & strPK & """, strSearch)" & vbNewLine & _
                "        End With" & vbNewLine & _
                "    End Sub" & vbNewLine & _
                "" & vbNewLine

            Return strScript
        End Function

        Public Function FunctSetTittleForm(ByVal bolIsDetail As Boolean) As String
            Dim strScript As String = ""
            strScript = _
                "    Private Sub prvSetTitleForm()" & vbNewLine
            If Not bolIsDetail Then
                strScript += _
                "        If pubIsLookUp Then" & vbNewLine & _
                "            Me.Text += """ & " [Lookup] """ & vbNewLine & _
                "        End If" & vbNewLine
            Else
                strScript += _
                "        If pubIsNew Then" & vbNewLine & _
                "            Me.Text += """ & " [new] """ & vbNewLine & _
                "        Else" & vbNewLine & _
                "            Me.Text += """ & " [edit] """ & vbNewLine & _
                "        End If" & vbNewLine
            End If

            strScript += _
                "    End Sub" & vbNewLine & _
                "" & vbNewLine


            Return strScript
        End Function

        Public Function FunctFillForm(ByVal strTableName As String, ByVal strFileName As String, ByVal strFillLine As String, ByVal cls As VO.UserSelection) As String
            Dim strScript As String = ""
            Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)
            Dim dtColumn As DataTable = BL.ColumnList.ListData(strTableName, cls)

            strScript = _
                "    Private Sub prvFillForm()" & vbNewLine & _
                "        Try" & vbNewLine & _
                "            If pubIsNew Then" & vbNewLine & _
                "                prvClear()" & vbNewLine & _
                "            Else" & vbNewLine & _
                "                clsData = New VO." & strFileName & vbNewLine & _
                "                clsData = BL." & strFileName & ".GetDetail("

            If cls.FormType = VO.UserSelection.eFormType.TransactionForm Then
                strScript += _
                    "pubCS.CompanyID, "
            End If

            With dtColumnPK
                For i As Integer = 0 To .Rows.Count - 1
                    strScript += "pub" & .Rows(i).Item("ColumnName")
                    If i = .Rows.Count - 1 Then
                        strScript += ")" & vbNewLine
                    Else
                        strScript += ", "
                    End If
                Next
            End With

            With dtColumn
                For i As Integer = 0 To .Rows.Count - 1
                    Dim strCName As String = .Rows(i).Item("ColumnName")
                    Dim strCType As String = .Rows(i).Item("DataType")
                    If strCName.Trim <> "IsSync" And strCName.Trim <> "CreateBy" And strCName.Trim <> "CreateDate" And _
                        strCName.Trim <> "CreatedBy" And strCName.Trim <> "CreatedDate" And _
                        strCName.Trim <> "LogDate" And strCName.Trim <> "LogInc" And strCName.Trim <> "LogBy" Then

                        If strCName.Trim = "Status" And (strCType.Trim = "tinyint" Or strCType.Trim = "smallint" Or strCType.Trim = "int" Or strCType.Trim = "bit") Then
                            strScript += strFillLine & "                cbo" & .Rows(i).Item("ColumnName") & ".SelectedIndex"
                        ElseIf strCType.Trim = "date" Or strCType.Trim = "datetime2" Or strCType.Trim = "smalldatetime" Or strCType.Trim = "datetime" Then
                            strScript += strFillLine & "                dtp" & .Rows(i).Item("ColumnName") & ".Value"
                        Else
                            strScript += strFillLine & "                txt" & .Rows(i).Item("ColumnName") & ".Text"
                        End If

                        strScript += " = clsData." & .Rows(i).Item("ColumnName") & vbNewLine
                    End If
                Next

                strScript += _
                    "                ToolStripLogInc.Text = " & """Log Inc : "" & clsData.LogInc" & vbNewLine & _
                    "                ToolStripLogBy.Text = " & """Last Log : -"" & clsData.LogBy" & vbNewLine & _
                    "                ToolStripLogDate.Text = Format(clsData.LogDate, UI.usDefCons.DateFull)" & vbNewLine
            End With

            strScript += _
                "            End If" & vbNewLine & _
                "        Catch ex As Exception" & vbNewLine & _
                "            UI.usForm.frmMessageBox(ex.Message)" & vbNewLine & _
                "        End Try" & vbNewLine & _
                "    End Sub" & vbNewLine & _
                "" & vbNewLine

            Return strScript
        End Function

        Public Function FunctGet() As String
            Dim strScript As String = ""
            strScript = _
                "    Private Sub prvGet()" & vbNewLine & _
                "        Dim intPos As Integer = grdView.FocusedRowHandle" & vbNewLine & _
                "        If intPos < 0 Then Exit Sub" & vbNewLine & _
                "        If Not pubIsLookUp Then Exit Sub" & vbNewLine & _
                "        If grdView.GetRowCellValue(intPos,""StatusInfo"") = ""IN-ACTIVE"" Then" & vbNewLine & _
                "            UI.usForm.frmMessageBox(""Cannot choose this data because data is not active"")" & vbNewLine & _
                "            Exit Sub" & vbNewLine & _
                "        Else" & vbNewLine & _
                "            pubLUdtRow = grdView.GetDataRow(grdView.FocusedRowHandle)" & vbNewLine & _
                "            pubIsLookUpGet = True" & vbNewLine & _
                "            Me.Close()" & vbNewLine & _
                "        End If" & vbNewLine & _
                "    End Sub" & vbNewLine & _
                "" & vbNewLine

            Return strScript
        End Function

        Public Function FunctNew(ByVal strTableName As String, ByVal strFormName As String, ByVal cls As VO.UserSelection) As String
            Dim strScript As String = ""

            strScript = _
                "    Private Sub prvNew()" & vbNewLine

            If cls.FormType = VO.UserSelection.eFormType.TransactionForm Then
                strScript += _
                "        prvGetCS()" & vbNewLine

            End If

            strScript += _
                "        Dim frmDetail As New " & strFormName & vbNewLine & _
                "        With frmDetail" & vbNewLine & _
                "            .pubIsNew = True" & vbNewLine

            If cls.FormType = VO.UserSelection.eFormType.TransactionForm Then
                strScript += _
                "            .pubCS = clsCS" & vbNewLine

            End If

            strScript += _
                "            .StartPosition = FormStartPosition.CenterScreen" & vbNewLine & _
                "            .pubShowDialog(Me) " & vbNewLine & _
                "        End With" & vbNewLine & _
                "    End Sub" & vbNewLine & _
                "" & vbNewLine

            Return strScript
        End Function

        Public Function FunctDetail(ByVal strTableName As String, ByVal strFormName As String, ByVal cls As VO.UserSelection) As String
            Dim strScript As String = ""
            Dim strPK As String = BL.ColumnList.GetTop1PK(strTableName, cls)
            Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)

            strScript = _
                "    Private Sub prvDetail()" & vbNewLine

            If cls.FormType = VO.UserSelection.eFormType.TransactionForm Then
                strScript += _
                "        prvGetCS()" & vbNewLine

            End If

            strScript += _
                "        intPos = grdView.FocusedRowHandle" & vbNewLine & _
                "        If intPos < 0 Then Exit Sub" & vbNewLine & _
                "        Dim frmDetail As New " & strFormName & vbNewLine & _
                "        With frmDetail" & vbNewLine & _
                "            .pubIsNew = False" & vbNewLine

            If cls.FormType = VO.UserSelection.eFormType.TransactionForm Then
                strScript += _
                "            .pubCS = clsCS" & vbNewLine

            End If

            For Each drColumn As DataRow In dtColumnPK.Rows
                strScript += _
                "            .pub" & drColumn.Item("ColumnName") & " = grdView.GetRowCellValue(intPos, """ & drColumn.Item("ColumnName") & """)" & vbNewLine
            Next

            strScript += _
                "            .StartPosition = FormStartPosition.CenterScreen" & vbNewLine & _
                "            .pubShowDialog(Me) " & vbNewLine & _
                "            If .pubIsSave Then pubRefresh() " & vbNewLine & _
                "        End With" & vbNewLine & _
                "    End Sub" & vbNewLine & _
                "" & vbNewLine

            Return strScript
        End Function

        Public Function FunctDelete(ByVal strTableName As String, ByVal strFileName As String, ByVal cls As VO.UserSelection) As String
            Dim strScript As String = ""
            Dim strPK As String = BL.ColumnList.GetTop1PK(strTableName, cls)
            Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)

            strScript = _
                "    Private Sub prvDelete()" & vbNewLine

            If cls.FormType = VO.UserSelection.eFormType.TransactionForm Then
                strScript += _
                "        prvGetCS()" & vbNewLine
            End If

            strScript += _
                "        intPos = grdView.FocusedRowHandle" & vbNewLine & _
                "        If intPos < 0 Then Exit Sub" & vbNewLine & _
                "        If Not UI.usForm.frmAskQuestion(""Delete " & strPK & " "" & grdView.GetRowCellValue(intPos, """ & strPK & """) & ""?"") Then Exit Sub " & vbNewLine & _
                "        Try" & vbNewLine

            If cls.FormType = VO.UserSelection.eFormType.MasterForm Then
                strScript += _
                "            BL." & strFileName.Trim & ".DeleteData(grdView.GetRowCellValue(intPos, """ & strPK & """))" & vbNewLine
            Else
                strScript += _
                "            BL." & strFileName.Trim & ".DeleteData(clsCS.CompanyID, grdView.GetRowCellValue(intPos, """ & strPK & """), UI.usUserApp.UserID, """")" & vbNewLine
            End If

            strScript += _
                "            UI.usForm.frmMessageBox(""Delete data success."")" & vbNewLine & _
                "            pubRefresh(grdView.GetRowCellValue(intPos, """ & strPK & """))" & vbNewLine & _
                "        Catch ex As Exception" & vbNewLine & _
                "            UI.usForm.frmMessageBox(ex.Message)" & vbNewLine & _
                "        End Try" & vbNewLine & _
                "    End Sub" & vbNewLine & _
                "" & vbNewLine

            Return strScript
        End Function

        Public Function FunctSubmit(ByVal strTableName As String, ByVal strFileName As String, ByVal cls As VO.UserSelection) As String
            Dim strScript As String = ""
            Dim strPK As String = BL.ColumnList.GetTop1PK(strTableName, cls)
            Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)

            strScript = _
                "    Private Sub prvSubmit()" & vbNewLine & _
                "        prvGetCS()" & vbNewLine & _
                "        intPos = grdView.FocusedRowHandle" & vbNewLine & _
                "        If intPos < 0 Then Exit Sub" & vbNewLine & _
                "        If Not UI.usForm.frmAskQuestion(""Submit " & strPK & " "" & grdView.GetRowCellValue(intPos, """ & strPK & """) & ""?"") Then Exit Sub " & vbNewLine & _
                "        Try" & vbNewLine & _
                "            BL." & strFileName.Trim & ".SubmitData(clsCS.CompanyID, grdView.GetRowCellValue(intPos, """ & strPK & """), UI.usUserApp.UserID, """")" & vbNewLine & _
                "            UI.usForm.frmMessageBox(""Submit data success."")" & vbNewLine & _
                "            pubRefresh(grdView.GetRowCellValue(intPos, """ & strPK & """))" & vbNewLine & _
                "        Catch ex As Exception" & vbNewLine & _
                "            UI.usForm.frmMessageBox(ex.Message)" & vbNewLine & _
                "        End Try" & vbNewLine & _
                "    End Sub" & vbNewLine & _
                "" & vbNewLine

            Return strScript
        End Function

        Public Function FunctUnSubmit(ByVal strTableName As String, ByVal strFileName As String, ByVal cls As VO.UserSelection) As String
            Dim strScript As String = ""
            Dim strPK As String = BL.ColumnList.GetTop1PK(strTableName, cls)
            Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)

            strScript = _
                "    Private Sub prvUnsubmit()" & vbNewLine & _
                "        prvGetCS()" & vbNewLine & _
                "        intPos = grdView.FocusedRowHandle" & vbNewLine & _
                "        If intPos < 0 Then Exit Sub" & vbNewLine & _
                "        If Not UI.usForm.frmAskQuestion(""Unsubmit " & strPK & " "" & grdView.GetRowCellValue(intPos, """ & strPK & """) & ""?"") Then Exit Sub " & vbNewLine & _
                "        Try" & vbNewLine & _
                "            BL." & strFileName.Trim & ".UnsubmitData(clsCS.CompanyID, grdView.GetRowCellValue(intPos, """ & strPK & """), UI.usUserApp.UserID, """")" & vbNewLine & _
                "            UI.usForm.frmMessageBox(""Submit data success."")" & vbNewLine & _
                "            pubRefresh(grdView.GetRowCellValue(intPos, """ & strPK & """))" & vbNewLine & _
                "        Catch ex As Exception" & vbNewLine & _
                "            UI.usForm.frmMessageBox(ex.Message)" & vbNewLine & _
                "        End Try" & vbNewLine & _
                "    End Sub" & vbNewLine & _
                "" & vbNewLine

            Return strScript
        End Function

        Public Function FunctUserAccess(ByVal bolIsDetail As Boolean, ByVal cls As VO.UserSelection) As String
            Dim strScript As String = ""

            strScript = _
                "    Private Sub prvUserAccess()" & vbNewLine & _
                "        With ToolBar.Buttons" & vbNewLine

            If Not bolIsDetail Then
                strScript += _
                "            .Item(cNew).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, UI.usUserApp.ComLocDivSubDivID, ""XXXX"", ""ADD"")" & vbNewLine & _
                "            .Item(cDelete).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, UI.usUserApp.ComLocDivSubDivID, ""XXXX"", ""DELETE"")" & vbNewLine

                If cls.FormType = VO.UserSelection.eFormType.TransactionForm Then
                    strScript += _
                "            .Item(cSubmit).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, UI.usUserApp.ComLocDivSubDivID, ""XXXX"", ""SUBMIT"")" & vbNewLine & _
                "            .Item(cUnsubmit).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, UI.usUserApp.ComLocDivSubDivID, ""XXXX"", ""UNSUBMIT"")" & vbNewLine
                End If

            Else
                strScript += _
                "            .Item(cSave).Visible = BL.UserAccess.CheckAccess(UI.usUserApp.UserID, UI.usUserApp.DelegateUserID, UI.usUserApp.ProgramID, UI.usUserApp.ComLocDivSubDivID, ""XXXX"", " & " IIf(pubIsNew,""ADD"",""EDIT""))" & vbNewLine
            End If

            strScript += _
                "        End With" & vbNewLine & _
                "    End Sub" & vbNewLine & _
                "" & vbNewLine

            Return strScript
        End Function

        Public Function FunctSave(ByVal strTableName As String, ByVal strFileName As String, _
                                  ByVal bolUseParentTools As Boolean, ByVal strFillLine As String, _
                                  ByVal cls As VO.UserSelection) As String

            Dim strScript As String = ""
            Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)
            Dim dtColumn As DataTable = BL.ColumnList.ListData(strTableName, cls)

            If bolUseParentTools Then
                strScript += _
                "    Public Sub prvSave()" & vbNewLine
            Else
                strScript += _
                "    Private Sub prvSave()" & vbNewLine
            End If

            strScript += _
                "        clsData = New VO." & strFileName.Trim & vbNewLine

            With dtColumn
                For i As Integer = 0 To .Rows.Count - 1
                    Dim strCName As String = .Rows(i).Item("ColumnName")
                    Dim strCType As String = .Rows(i).Item("DataType")

                    If strCName.Trim <> "IsSync" And strCName.Trim <> "CreateBy" And strCName.Trim <> "CreateDate" And _
                        strCName.Trim <> "LogDate" And strCName.Trim <> "LogInc" Then
                        If strCName.Trim = "Status" And (strCType.Trim = "tinyint" Or strCType.Trim = "smallint" Or strCType.Trim = "int" Or strCType.Trim = "bit") Then
                            strScript += strFillLine & "        clsData." & .Rows(i).Item("ColumnName") & " = cbo" & .Rows(i).Item("ColumnName") & ".SelectedIndex" & vbNewLine
                        ElseIf strCType.Trim = "date" Or strCType.Trim = "datetime2" Or strCType.Trim = "smalldatetime" Or strCType.Trim = "datetime" Then
                            strScript += strFillLine & "        clsData." & .Rows(i).Item("ColumnName") & " = dtp" & .Rows(i).Item("ColumnName") & ".Value" & vbNewLine
                        ElseIf strCName.Trim = "LogBy" Then
                            strScript += strFillLine & "        clsData." & .Rows(i).Item("ColumnName") & " = UI.usUserApp.UserID" & vbNewLine
                        Else
                            strScript += strFillLine & "        clsData." & .Rows(i).Item("ColumnName") & " = txt" & .Rows(i).Item("ColumnName") & ".Text.Trim" & vbNewLine
                        End If
                    End If
                Next

                strScript += vbNewLine & _
                    "        Try" & vbNewLine & _
                    "            pub" & dtColumnPK.Rows(0).Item("ColumnName") & " = BL." & strFileName.Trim & ".SaveData(" & IIf(cls.FormType = VO.UserSelection.eFormType.TransactionForm, "pubCS.CompanyID, ", "") & "pubIsNew, clsData)" & vbNewLine & _
                    "            If pubIsNew Then " & vbNewLine & _
                    "                UI.usForm.frmMessageBox(""Save data success."")" & vbNewLine & _
                    "                frmParent.pubRefresh(pub" & dtColumnPK.Rows(0).Item("ColumnName") & ")" & vbNewLine & _
                    "                prvClear()" & vbNewLine & _
                    "            Else" & vbNewLine & _
                    "                pubIsSave = True" & vbNewLine & _
                    "                Me.Close()" & vbNewLine & _
                    "            End If" & vbNewLine & _
                    "        Catch ex As Exception" & vbNewLine & _
                    "            UI.usForm.frmMessageBox(ex.Message)" & vbNewLine & _
                    "        End Try" & vbNewLine & _
                    "    End Sub" & vbNewLine & _
                    "" & vbNewLine

            End With

            Return strScript
        End Function

        Public Function FunctClear(ByVal strTableName As String, ByVal strFileName As String, ByVal strFillLine As String, ByVal cls As VO.UserSelection) As String
            Dim strScript As String = ""
            Dim dtColumn As DataTable = BL.ColumnList.ListData(strTableName, cls)

            strScript = _
                "    Private Sub prvClear()" & vbNewLine

            With dtColumn
                For i As Integer = 0 To .Rows.Count - 1
                    Dim strCName As String = .Rows(i).Item("ColumnName")
                    Dim strCType As String = .Rows(i).Item("DataType")
                    If strCName.Trim <> "IsSync" And strCName.Trim <> "CreateBy" And strCName.Trim <> "CreateDate" And _
                        strCName.Trim <> "CreatedBy" And strCName.Trim <> "CreatedDate" And _
                        strCName.Trim <> "LogDate" And strCName.Trim <> "LogInc" And strCName.Trim <> "LogBy" Then

                        If strCName.Trim = "Status" And (strCType.Trim = "tinyint" Or strCType.Trim = "smallint" Or strCType.Trim = "int" Or strCType.Trim = "bit") Then
                            strScript += strFillLine & "        cbo" & .Rows(i).Item("ColumnName") & ".SelectedIndex = 0" & vbNewLine
                        ElseIf strCType.Trim = "date" Or strCType.Trim = "datetime2" Or strCType.Trim = "smalldatetime" Or strCType.Trim = "datetime" Then
                            strScript += strFillLine & "        dtp" & .Rows(i).Item("ColumnName") & ".Value = Today" & vbNewLine
                        Else
                            strScript += strFillLine & "        txt" & .Rows(i).Item("ColumnName") & ".Text = """ & IIf(.Rows(i).Item("ColumnName").ToString.EndsWith("ID"), "0", "") & """" & vbNewLine
                        End If

                    End If
                Next

                strScript += _
                    "        ToolStripLogInc.Text = " & """Log Inc : -""" & vbNewLine & _
                    "        ToolStripLogBy.Text = " & """Last Log : -""" & vbNewLine & _
                    "        ToolStripLogDate.Text = Format(Now, UI.usDefCons.DateFull)" & vbNewLine & _
                    "    End Sub" & vbNewLine & _
                    "" & vbNewLine

            End With

            Return strScript
        End Function

        Public Function FunctSetDefaultFilter() As String
            Dim strScript As String = ""

            strScript = _
                "    Private Sub prvSetDefaultFilter() " & vbNewLine & _
                "        txtComLocDivSubDivID.Text = UI.usUserApp.ComLocDivSubDivID " & vbNewLine & _
                "        txtCompanyID.Text = UI.usUserApp.CompanyID " & vbNewLine & _
                "        txtCompanyName.Text = UI.usUserApp.CompanyName " & vbNewLine & _
                "        txtLocationID.Text = UI.usUserApp.LocationID " & vbNewLine & _
                "        txtLocationName.Text = UI.usUserApp.LocationName " & vbNewLine & _
                "        txtDivisionName.Text = UI.usUserApp.DivisionName " & vbNewLine & _
                "        txtSubDivisionName.Text = UI.usUserApp.SubDivisionName " & vbNewLine & _
                "    End Sub" & vbNewLine & _
                "" & vbNewLine

            Return strScript
        End Function

        Public Function FunctGetCS() As String
            Dim strScript As String = ""

            strScript = _
                "    Private Sub prvGetCS() " & vbNewLine & _
                "        clsCS.ComLocDivSubDivID = txtComLocDivSubDivID.Text.Trim " & vbNewLine & _
                "        clsCS.CompanyID = txtCompanyID.Text.Trim " & vbNewLine & _
                "        clsCS.CompanyName = txtCompanyName.Text.Trim " & vbNewLine & _
                "        clsCS.LocationID = txtLocationID.Text.Trim " & vbNewLine & _
                "        clsCS.LocationName = txtLocationName.Text.Trim " & vbNewLine & _
                "        clsCS.DivisionName = txtDivisionName.Text.Trim " & vbNewLine & _
                "        clsCS.SubDivisionName = txtSubDivisionName.Text.Trim " & vbNewLine & _
                "        clsCS.ProgramID = UI.usUserApp.ProgramID " & vbNewLine & _
                "    End Sub" & vbNewLine & _
                "" & vbNewLine

            Return strScript
        End Function

        Public Function FunctSetGridHistory() As String
            Dim strScript As String = ""
            strScript = _
               "    Private Sub prvSetGrid()" & vbNewLine & _
               "        'UI.usForm.SetGrid(grdHistoryView, ""Status"", ""Status"", 200, UI.usDefGrid.gString)" & vbNewLine & _
               "        'UI.usForm.SetGrid(grdHistoryView, ""StatusBy"", ""Status By"", 150, UI.usDefGrid.gString)" & vbNewLine & _
               "        'UI.usForm.SetGrid(grdHistoryView, ""StatusDate"", ""Status Date"", 180, UI.usDefGrid.gFullDate)" & vbNewLine & _
               "        'UI.usForm.SetGrid(grdHistoryView, ""Remarks"", ""Remarks"", 600, UI.usDefGrid.gString)" & vbNewLine & _
               "    End Sub" & vbNewLine & vbNewLine
            Return strScript
        End Function

        Public Function FunctHistoryQuery(ByVal strTableName As String, ByVal strFileName As String, ByVal cls As VO.UserSelection) As String
            Dim strScript As String = ""
            Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)
            strScript = _
               "    Private Sub prvHistoryQuery()" & vbNewLine & _
               "        Try" & vbNewLine & _
               "            'grdHistory.DataSource = BL." & strFileName & ".ListHistory(pubCS.CompanyID, pub" & dtColumnPK.Rows(0).Item("ColumnName") & ")" & vbNewLine & _
               "            'grdHistoryView.BestFitColumns()" & vbNewLine & _
               "        Catch ex As Exception" & vbNewLine & _
               "            UI.usForm.frmMessageBox(ex.Message)" & vbNewLine & _
               "        End Try" & vbNewLine & _
               "    End Sub" & vbNewLine & vbNewLine
            Return strScript
        End Function

    End Module

End Namespace

