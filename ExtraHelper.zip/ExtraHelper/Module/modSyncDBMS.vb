﻿Namespace SyncDBMS
    Module modSyncDBMS
        Public Function pubGetDefaultConstraint(ByVal strType As String, Optional ByVal strColumnName As String = "")
            Dim strScript As String = ""
            Select Case strType.Trim
                Case "varchar", "nvarchar"
                    strScript += "''"
                Case "bigint", "int", "smallint", "tinyint", "numeric", "decimal", "money", "smallmoney", "bit", "varbinary"
                    strScript += "(0)"
                Case "datetime", "smalldatetime"
                    If strColumnName.Trim = "LogDate" Or strColumnName.Trim = "CreateDate" Or strColumnName.Trim = "CreatedAt" Or strColumnName.Trim = "ModifiedAt" Then
                        strScript += "GETDATE()"
                    Else
                        strScript += "'2000/01/01'"
                    End If
            End Select
            Return strScript
        End Function

        Public Function pubGenerateTableScipt(ByVal strTableName As String, ByVal cls As VO.UserSelection) As String
            Dim strResult As String = ""
            Dim strDefaultValue As String = ""
            VO.ColumnList.ColumnList = BL.ColumnList.ListData(strTableName, cls)
            With VO.ColumnList.ColumnList
                strResult += _
                    "IF NOT EXISTS" & vbNewLine & _
                    "(" & vbNewLine & _
                    "	SELECT * FROM INFORMATION_SCHEMA.TABLES" & vbNewLine & _
                    "	WHERE " & vbNewLine & _
                    "	TABLE_NAME = '" & strTableName.Trim & "'" & vbNewLine & _
                    ") " & vbNewLine & vbNewLine & _
                    "BEGIN " & vbNewLine & vbNewLine & _
                    "CREATE TABLE [dbo].[" & strTableName.Trim & "](" & vbNewLine

                For i As Integer = 0 To .Rows.Count - 1
                    strDefaultValue = pubGetDefaultConstraint(.Rows(i).Item("DataType"), .Rows(i).Item("ColumnName"))
                    strResult += _
                        "	[" & .Rows(i).Item("ColumnName") & "] [" & .Rows(i).Item("DataType") & "] "

                    If .Rows(i).Item("DataType") = "varchar" Or .Rows(i).Item("DataType") = "nvarchar" Then
                        strResult += _
                            "(" & .Rows(i).Item("MaxLength") & ")"
                    End If

                    If .Rows(i).Item("is_identity") Then
                        strResult += _
                            " IDENTITY(1,1) NOT FOR REPLICATION "
                    End If

                    strResult += _
                        " NOT NULL, " & vbNewLine
                Next

                Dim dtColumnPK As DataTable = BL.ColumnList.ListDataPK(strTableName, cls)

                With dtColumnPK
                    For i As Integer = 0 To .Rows.Count - 1
                        If i = 0 Then
                            strResult += _
                                " CONSTRAINT [PK_" & strTableName.Trim & "] PRIMARY KEY CLUSTERED " & vbNewLine & _
                                "(" & vbNewLine
                        End If

                        strResult += _
                            "	[" & .Rows(i).Item("ColumnName") & "] ASC"

                        If i <> .Rows.Count - 1 Then
                            strResult += ", "
                        End If

                        strResult += vbNewLine

                        If i = .Rows.Count - 1 Then
                            strResult += _
                                ")WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY] " & vbNewLine
                        End If
                    Next
                End With

                strResult += _
                    ") ON [PRIMARY]" & vbNewLine & vbNewLine

                For i As Integer = 0 To .Rows.Count - 1
                    If .Rows(i).Item("is_identity") Then
                        .Rows(i).BeginEdit()
                        .Rows(i).Delete()
                        .Rows(i).EndEdit()
                    End If
                Next
                .AcceptChanges()

                For i As Integer = 0 To .Rows.Count - 1
                    strDefaultValue = pubGetDefaultConstraint(.Rows(i).Item("DataType"), .Rows(i).Item("ColumnName"))
                    strResult += _
                        "ALTER TABLE [dbo].[" & strTableName.Trim & "] ADD CONSTRAINT [DF_" & strTableName.Trim & "_" & .Rows(i).Item("ColumnName") & "] DEFAULT (" & strDefaultValue & ") FOR [" & .Rows(i).Item("ColumnName") & "]" & vbNewLine & vbNewLine
                Next

                strResult += _
                    "END " & vbNewLine & vbNewLine

            End With
            Return strResult
        End Function

        Public Function pubGenerateColumnScipt(ByVal strTableName As String, ByVal cls As VO.UserSelection) As String
            Dim strResult As String = ""
            Dim strDefaultValue As String = ""
            VO.ColumnList.ColumnList = BL.ColumnList.ListData(strTableName, cls)
            With VO.ColumnList.ColumnList
                For i As Integer = 0 To .Rows.Count - 1
                    strDefaultValue = pubGetDefaultConstraint(.Rows(i).Item("DataType"), .Rows(i).Item("ColumnName"))
                    strResult += _
                        "GO " & vbNewLine & _
                        "IF NOT EXISTS" & vbNewLine & _
                        "(" & vbNewLine & _
                        "	SELECT * FROM INFORMATION_SCHEMA.COLUMNS" & vbNewLine & _
                        "	WHERE " & vbNewLine & _
                        "	TABLE_NAME = '" & strTableName.Trim & "'" & vbNewLine & _
                        "	AND COLUMN_NAME ='" & .Rows(i).Item("ColumnName") & "'" & vbNewLine & _
                        ") " & vbNewLine & _
                        "ALTER TABLE " & strTableName.Trim & vbNewLine & _
                        "ADD [" & .Rows(i).Item("ColumnName") & "] " & .Rows(i).Item("DataType")

                    If .Rows(i).Item("DataType") = "varchar" Or .Rows(i).Item("DataType") = "nvarchar" Then
                        strResult += _
                            "(" & .Rows(i).Item("MaxLength") & ")"
                    End If

                    strResult += _
                        " CONSTRAINT DF_" & strTableName.Trim & "_" & .Rows(i).Item("ColumnName") & " DEFAULT (" & strDefaultValue & ") NOT NULL" & vbNewLine & _
                        "GO" & vbNewLine & vbNewLine
                Next
            End With
            Return strResult
        End Function
    End Module
End Namespace

