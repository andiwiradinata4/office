﻿Namespace FormHandle

    Module modGenerateFormHandle

        Public Function FunctFormKeyDown(ByVal strFormName As String, ByVal bolfrmDetail As Boolean, ByVal cls As VO.UserSelection) As String
            Dim strScript As String = ""

            strScript = _
                "    Private Sub " & strFormName.Trim & "_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown" & vbNewLine

            If Not bolfrmDetail Then
                strScript += _
                "        If e.KeyCode = Keys.F5 Then" & vbNewLine & _
                "            pubRefresh()" & vbNewLine & _
                "        ElseIf e.KeyCode = Keys.Enter Then" & vbNewLine & _
                "            prvQuery()" & vbNewLine
            End If

            If cls.FormType = VO.UserSelection.eFormType.MasterForm Or (cls.FormType = VO.UserSelection.eFormType.TransactionForm And bolfrmDetail) Then

                If Not bolfrmDetail Then
                    strScript += _
                "        Else"
                End If

                strScript +=
                "        If e.KeyCode = Keys.Escape"

                If Not bolfrmDetail Then
                    If cls.FormType = VO.UserSelection.eFormType.MasterForm Then
                        strScript += _
                " And pubIsLookUp"
                    End If
                    strScript += _
                " Then" & vbNewLine & _
                "            Me.Close()" & vbNewLine
                Else
                    strScript += _
                " Then" & vbNewLine & _
                "            If UI.usForm.frmAskQuestion(""Close this form?"") Then Me.Close()" & vbNewLine

                    If cls.FormType = VO.UserSelection.eFormType.TransactionForm Then
                        strScript += _
                "        ElseIf e.KeyCode = Keys.F1 Then" & vbNewLine & _
                "            'Me.tbcData.SelectedIndex = 0" & vbNewLine & _
                "        ElseIf e.KeyCode = Keys.F1 Then" & vbNewLine & _
                "            'Me.tbcData.SelectedIndex = 1" & vbNewLine
                    End If
                End If

            End If

            strScript += _
               "        End If" & vbNewLine & _
               "    End Sub" & vbNewLine & _
               "" & vbNewLine

            Return strScript
        End Function

        Public Function FunctFormLoad(ByVal strFormName As String, ByVal bolfrmDetail As Boolean, ByVal bolUseParentTools As Boolean, ByVal cls As VO.UserSelection) As String
            Dim strScript As String = ""

            strScript = _
                "    Private Sub " & strFormName.Trim & "_Load(sender As Object, e As EventArgs) Handles MyBase.Load" & vbNewLine

            If bolUseParentTools Then
                strScript += _
                "        Me.Controls.Add(New usLabelDetailMaster(""" & strFormName & """))" & vbNewLine & _
                "        Me.Controls.Add(New usToolBar(Me, ""0,Save,1,Close"", UI.usUserApp.ProgramID, UI.usUserApp.ComLocDivSubDivID, ""XXXX"", ""ADD""))" & vbNewLine

            Else
                strScript += _
                "        prvSetIcon()" & vbNewLine

            End If

            If Not bolUseParentTools Then
                strScript += _
                "        prvUserAccess()" & vbNewLine
            End If

            If cls.FormType = VO.UserSelection.eFormType.MasterForm Or (cls.FormType = VO.UserSelection.eFormType.TransactionForm And bolfrmDetail = True) Then
                strScript += _
                    "        prvSetTitleForm()" & vbNewLine
            End If

            If Not bolfrmDetail Then
                If cls.FormType = VO.UserSelection.eFormType.TransactionForm Then
                    strScript += _
                "        prvSetDefaultFilter()" & vbNewLine
                End If

                strScript += _
                "        prvSetGrid()" & vbNewLine
            Else
                strScript += _
                "        prvFillForm()" & vbNewLine
            End If

            If Not bolfrmDetail Then
                If cls.FormType = VO.UserSelection.eFormType.TransactionForm Then
                    strScript += _
                "        cboStatus.SelectedIndex = 0" & vbNewLine & _
                "        dtpDateFrom.Value = Today.Year & ""/"" & Today.Month & ""/01""" & vbNewLine & _
                "        dtpDateTo.Value = dtpDateFrom.Value.AddMonths(1).AddDays(-1)" & vbNewLine
                End If
                strScript += _
                "        prvQuery()" & vbNewLine & _
                "        prvSetButton()" & vbNewLine
            End If

            strScript += _
                "    End Sub" & vbNewLine & _
                "" & vbNewLine
            Return strScript
        End Function

        Public Function FunctToolBarButton(ByVal bolFrmDetail As Boolean, ByVal cls As VO.UserSelection) As String
            Dim strScript As String = ""
            strScript = _
                "    Private Sub ToolBar_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles ToolBar.ButtonClick" & vbNewLine & _
                "        If e.Button.Text = " & """Close"" Then" & vbNewLine & _
                "            Me.Close()" & vbNewLine

            If bolFrmDetail Then
                strScript += _
                "        ElseIf e.Button.Text = " & """Save"" Then" & vbNewLine & _
                "            prvSave()" & vbNewLine
            Else
                strScript += _
                "        ElseIf e.Button.Text = " & """New"" Then" & vbNewLine & _
                "            prvNew()" & vbNewLine & _
                "        ElseIf grdView.FocusedRowHandle >= 0 Then" & vbNewLine & _
                "            Select Case e.Button.Text" & vbNewLine

                If cls.FormType = VO.UserSelection.eFormType.MasterForm Then
                    strScript += _
                "                Case ""Get"" : prvGet()" & vbNewLine
                End If

                strScript += _
                "                Case ""Detail"" : prvDetail()" & vbNewLine & _
                "                Case ""Delete"" : prvDelete()" & vbNewLine

                If cls.FormType = VO.UserSelection.eFormType.MasterForm Then
                    strScript += _
                "                'Case ""Sync"" : prvSync()" & vbNewLine
                Else
                    strScript += _
                "                Case ""Submit"" : prvSubmit()" & vbNewLine & _
                "                Case ""Unsubmit"" : prvUnsubmit()" & vbNewLine
                End If

                strScript += _
                "            End Select" & vbNewLine
            End If

            strScript += _
                "        End If" & vbNewLine & _
                "    End Sub" & vbNewLine & _
                "" & vbNewLine
            Return strScript
        End Function

        Public Function FunctGridRowStyle(ByVal cls As VO.UserSelection) As String
            Dim strScript As String = ""
            strScript = _
                "    Private Sub grdView_RowStyle(ByVal sender As Object, ByVal e As DevExpress.XtraGrid.Views.Grid.RowStyleEventArgs) Handles grdView.RowStyle" & vbNewLine & _
                "        Dim View As DevExpress.XtraGrid.Views.Grid.GridView = sender" & vbNewLine & _
                "        If (e.RowHandle >= 0) Then" & vbNewLine & _
                "            Dim strResult As String = View.GetRowCellDisplayText(e.RowHandle, View.Columns(""StatusInfo""))" & vbNewLine & _
                "            If strResult = """ & IIf(cls.FormType = VO.UserSelection.eFormType.MasterForm, "IN-ACTIVE", "DELETED") & """ And e.Appearance.BackColor <> Color.Salmon Then" & vbNewLine & _
                "                e.Appearance.BackColor = Color.Salmon" & vbNewLine & _
                "                e.Appearance.BackColor2 = Color.SeaShell" & vbNewLine & _
                "            End If" & vbNewLine & _
                "        End If" & vbNewLine & _
                "    End Sub" & vbNewLine & _
                "" & vbNewLine
            Return strScript
        End Function

        Public Function FuncGridDoubleClick() As String
            Dim strScript As String = ""
            strScript = _
                "    Private Sub grdMain_DoubleClick(sender As Object, e As System.EventArgs) Handles grdMain.DoubleClick" & vbNewLine & _
                "        prvGet()" & vbNewLine & _
                "    End Sub" & vbNewLine & _
                "" & vbNewLine
            Return strScript
        End Function

        Public Function FuncBtnCompanyOnClick() As String
            Dim strScript As String = ""
            strScript = _
            "    Private Sub btnCompany_Click(sender As Object, e As EventArgs) Handles btnCompany.Click " & vbNewLine & _
            "        'Dim frmDetail As New frmSysUserCompanyFilter " & vbNewLine & _
            "        '            With frmDetail    " & vbNewLine & _
            "        '                .pubIsLookUp = True    " & vbNewLine & _
            "        '                .pubLUCompanyID = txtCompanyID.Text.Trim    " & vbNewLine & _
            "        '                .StartPosition = FormStartPosition.CenterScreen    " & vbNewLine & _
            "        '                .ShowDialog()    " & vbNewLine & _
            "        '                If .pubIsLookUpGet Then    " & vbNewLine & _
            "        '                    txtCompanyID.Text = .pubLUCompanyID    " & vbNewLine & _
            "        '                    txtCompanyName.Text = .pubLUDataRow(CompanyName)    " & vbNewLine & _
            " " & vbNewLine & _
            "        'Dim voCS As New VO.CS " & vbNewLine & _
            "        '                    voCS = BL.UserAccess.GetTop1(UI.usUserApp.UserID, txtCompanyID.Text.Trim)    " & vbNewLine & _
            "        '                    txtLocationID.Text = voCS.LocationID    " & vbNewLine & _
            "        '                    txtLocationName.Text = voCS.LocationName    " & vbNewLine & _
            "        '                    txtDivisionName.Text = voCS.DivisionName    " & vbNewLine & _
            "        '                    txtSubDivisionName.Text = voCS.SubDivisionName    " & vbNewLine & _
            "        '                    txtComLocDivSubDivID.Text = voCS.ComLocDivSubDivID    " & vbNewLine & _
            " " & vbNewLine & _
            "        '                    grdMain.DataSource = Nothing    " & vbNewLine & _
            "        '                    prvSetButton()    " & vbNewLine & _
            "        '                    prvUserAccess()    " & vbNewLine & _
            "        '                    cboStatus.SelectedIndex = 0    " & vbNewLine & _
            "        '                End If    " & vbNewLine & _
            "        '            End With    " & vbNewLine & _
            "    End Sub " & vbNewLine & _
                "" & vbNewLine
            Return strScript
        End Function

        Public Function FuncBtnSubDivOnClick() As String
            Dim strScript As String = ""
            strScript = _
            "Private Sub btnSubDiv_Click(sender As Object, e As EventArgs) Handles btnSubDiv.Click " & vbNewLine & _
            "'Dim frmDetail As New frmSysUserSubdivisionFilter " & vbNewLine & _
            "            'With frmDetail " & vbNewLine & _
            "            '    .pubIsLookUp = True " & vbNewLine & _
            "            '    .pubLUCompanyID = txtCompanyID.Text.Trim " & vbNewLine & _
            "            '    .StartPosition = FormStartPosition.CenterScreen " & vbNewLine & _
            "            '    .ShowDialog() " & vbNewLine & _
            "            '    If .pubIsLookUpGet Then " & vbNewLine & _
            "            '        txtLocationID.Text = .pubLUDataRow(LocationID) " & vbNewLine & _
            "            '        txtLocationName.Text = .pubLUDataRow(LocationName) " & vbNewLine & _
            "            '        txtDivisionName.Text = .pubLUDataRow(DivisionName) " & vbNewLine & _
            "            '        txtSubDivisionName.Text = .pubLUDataRow(SubdivisionName) " & vbNewLine & _
            "            '        txtComLocDivSubDivID.Text = .pubLUDataRow(ComLocDivSubDivID) " & vbNewLine & _
            " " & vbNewLine & _
            "            '        grdMain.DataSource = Nothing " & vbNewLine & _
            "            '        prvSetButton() " & vbNewLine & _
            "            '        prvUserAccess() " & vbNewLine & _
            "            '        cboStatus.SelectedIndex = 0 " & vbNewLine & _
            "            '    End If " & vbNewLine & _
            "            'End With " & vbNewLine & _
            "    End Sub " & vbNewLine & _
            "" & vbNewLine
            Return strScript
        End Function

        Public Function FuncBtnQueryOnClick() As String
            Dim strScript As String = ""
            strScript = _
            "    Private Sub btnQuery_Click(sender As Object, e As EventArgs) Handles btnQuery.Click " & vbNewLine & _
            "        prvQuery() " & vbNewLine & _
            "    End Sub " & vbNewLine & _
            "" & vbNewLine
            Return strScript
        End Function

    End Module
End Namespace

