﻿Namespace FormTransaction

    Module modGenerateFormTransaction

        Public Sub pubGenerateFormDesignerHeader(ByVal strFormName As String, ByVal strFolderName As String, ByVal strDataName As String)
            Dim strValue As String = ""
            strValue = _
                "<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _" & vbNewLine & _
                "Partial Class " & strFormName & vbNewLine & _
                "    Inherits System.Windows.Forms.Form" & vbNewLine & _
                "" & vbNewLine & _
                "    'Form overrides dispose to clean up the component list." & vbNewLine & _
                "    <System.Diagnostics.DebuggerNonUserCode()> _" & vbNewLine & _
                "    Protected Overrides Sub Dispose(ByVal disposing As Boolean)" & vbNewLine & _
                "        Try" & vbNewLine & _
                "            If disposing AndAlso components IsNot Nothing Then" & vbNewLine & _
                "                components.Dispose()" & vbNewLine & _
                "            End If" & vbNewLine & _
                "        Finally" & vbNewLine & _
                "            MyBase.Dispose(disposing)" & vbNewLine & _
                "        End Try" & vbNewLine & _
                "    End Sub" & vbNewLine & _
                "" & vbNewLine & _
                "    'Required by the Windows Form Designer" & vbNewLine & _
                "    Private components As System.ComponentModel.IContainer" & vbNewLine & _
                "" & vbNewLine & _
                "    'NOTE: The following procedure is required by the Windows Form Designer" & vbNewLine & _
                "    'It can be modified using the Windows Form Designer.  " & vbNewLine & _
                "    'Do not modify it using the code editor." & vbNewLine & _
                "    <System.Diagnostics.DebuggerStepThrough()> _" & vbNewLine & _
                "    Private Sub InitializeComponent()" & vbNewLine & _
                "        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(" & strFormName & ")) " & vbNewLine & _
                "        Me.ToolBar = New System.Windows.Forms.ToolBar()" & vbNewLine & _
                "        Me.BarNew = New System.Windows.Forms.ToolBarButton()" & vbNewLine & _
                "        Me.BarDetail = New System.Windows.Forms.ToolBarButton()" & vbNewLine & _
                "        Me.BarDelete = New System.Windows.Forms.ToolBarButton()" & vbNewLine & _
                "        Me.BarSep1 = New System.Windows.Forms.ToolBarButton()" & vbNewLine & _
                "        Me.BarSubmit = New System.Windows.Forms.ToolBarButton()" & vbNewLine & _
                "        Me.BarUnsubmit = New System.Windows.Forms.ToolBarButton()" & vbNewLine & _
                "        Me.BarSep2 = New System.Windows.Forms.ToolBarButton()" & vbNewLine & _
                "        Me.BarRefresh = New System.Windows.Forms.ToolBarButton()" & vbNewLine & _
                "        Me.BarClose = New System.Windows.Forms.ToolBarButton()" & vbNewLine & _
                "        Me.pnlMain = New System.Windows.Forms.Panel() " & vbNewLine & _
                "        Me.Label1 = New System.Windows.Forms.Label() " & vbNewLine & _
                "        Me.txtCompanyID = New usTextBox() " & vbNewLine & _
                "        Me.txtCompanyName = New usTextBox() " & vbNewLine & _
                "        Me.btnCompany = New System.Windows.Forms.Button() " & vbNewLine & _
                "        Me.Label2 = New System.Windows.Forms.Label() " & vbNewLine & _
                "        Me.txtLocationID = New usTextBox() " & vbNewLine & _
                "        Me.txtLocationName = New usTextBox() " & vbNewLine & _
                "        Me.Label3 = New System.Windows.Forms.Label() " & vbNewLine & _
                "        Me.txtDivisionName = New usTextBox() " & vbNewLine & _
                "        Me.Label4 = New System.Windows.Forms.Label() " & vbNewLine & _
                "        Me.txtComLocDivSubDivID = New usTextBox() " & vbNewLine & _
                "        Me.txtSubDivisionName = New usTextBox() " & vbNewLine & _
                "        Me.btnSubDiv = New System.Windows.Forms.Button() " & vbNewLine & _
                "        Me.Label5 = New System.Windows.Forms.Label() " & vbNewLine & _
                "        Me.dtpDateFrom = New System.Windows.Forms.DateTimePicker() " & vbNewLine & _
                "        Me.Label6 = New System.Windows.Forms.Label() " & vbNewLine & _
                "        Me.dtpDateTo = New System.Windows.Forms.DateTimePicker() " & vbNewLine & _
                "        Me.Label7 = New System.Windows.Forms.Label() " & vbNewLine & _
                "        Me.cboStatus = New System.Windows.Forms.ComboBox() " & vbNewLine & _
                "        Me.btnQuery = New System.Windows.Forms.Button() " & vbNewLine & _
                "        Me.grdMain = New DevExpress.XtraGrid.GridControl()" & vbNewLine & _
                "        Me.grdView = New DevExpress.XtraGrid.Views.Grid.GridView()" & vbNewLine & _
                "        CType(Me.grdMain, System.ComponentModel.ISupportInitialize).BeginInit()" & vbNewLine & _
                "        CType(Me.grdView, System.ComponentModel.ISupportInitialize).BeginInit()" & vbNewLine & _
                "        Me.pnlMain.SuspendLayout() " & vbNewLine & _
                "        Me.SuspendLayout()" & vbNewLine & _
                "        ' " & vbNewLine & _
                "        'ToolBar" & vbNewLine & _
                "        '" & vbNewLine & _
                "        Me.ToolBar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat" & vbNewLine & _
                "        Me.ToolBar.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.BarNew, Me.BarDetail, Me.BarDelete, Me.BarSep1, Me.BarSubmit, Me.BarUnsubmit, Me.BarSep2, Me.BarRefresh, Me.BarClose})" & vbNewLine & _
                "        Me.ToolBar.DropDownArrows = True" & vbNewLine & _
                "        Me.ToolBar.Location = New System.Drawing.Point(0, 0)" & vbNewLine & _
                "        Me.ToolBar.Name = " & """ToolBar""" & vbNewLine & _
                "        Me.ToolBar.ShowToolTips = True" & vbNewLine & _
                "        Me.ToolBar.Size = New System.Drawing.Size(984, 28)" & vbNewLine & _
                "        Me.ToolBar.TabIndex = 0" & vbNewLine & _
                "        Me.ToolBar.TextAlign = System.Windows.Forms.ToolBarTextAlign.Right" & vbNewLine & _
                "        '" & vbNewLine & _
                "        'BarNew" & vbNewLine & _
                "        '" & vbNewLine & _
                "        Me.BarNew.Name = " & """BarNew""" & vbNewLine & _
                "        Me.BarNew.Text = " & """New""" & vbNewLine & _
                "        '" & vbNewLine & _
                "        'BarDetail" & vbNewLine & _
                "        '" & vbNewLine & _
                "        Me.BarDetail.Name = " & """BarDetail""" & vbNewLine & _
                "        Me.BarDetail.Text = " & """Detail""" & vbNewLine & _
                "        '" & vbNewLine & _
                "        'BarDelete" & vbNewLine & _
                "        '" & vbNewLine & _
                "        Me.BarDelete.Name = " & """BarDelete""" & vbNewLine & _
                "        Me.BarDelete.Text = " & """Delete""" & vbNewLine & _
                "        '" & vbNewLine & _
                "        'BarSep1" & vbNewLine & _
                "        '" & vbNewLine & _
                "        Me.BarSep1.Name = " & """BarSep1""" & vbNewLine & _
                "        Me.BarSep1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator" & vbNewLine & _
                "        '" & vbNewLine & _
                "        'BarSubmit" & vbNewLine & _
                "        '" & vbNewLine & _
                "        Me.BarSubmit.Name = " & """BarSubmit""" & vbNewLine & _
                "        Me.BarSubmit.Text = " & """Submit""" & vbNewLine & _
                "        '" & vbNewLine & _
                "        'BarUnsubmit" & vbNewLine & _
                "        '" & vbNewLine & _
                "        Me.BarUnsubmit.Name = " & """BarUnsubmit""" & vbNewLine & _
                "        Me.BarUnsubmit.Text = " & """Unsubmit""" & vbNewLine & _
                "        '" & vbNewLine & _
                "        'BarSep2" & vbNewLine & _
                "        '" & vbNewLine & _
                "        Me.BarSep2.Name = " & """BarSep2""" & vbNewLine & _
                "        Me.BarSep2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator" & vbNewLine & _
                "        '" & vbNewLine & _
                "        'BarRefresh" & vbNewLine & _
                "        '" & vbNewLine & _
                "        Me.BarRefresh.Name = " & """BarRefresh""" & vbNewLine & _
                "        Me.BarRefresh.Text = " & """Refresh""" & vbNewLine & _
                "        '" & vbNewLine & _
                "        'BarClose" & vbNewLine & _
                "        '" & vbNewLine & _
                "        Me.BarClose.Name = " & """BarClose""" & vbNewLine & _
                "        Me.BarClose.Text = " & """Close""" & vbNewLine & _
                "        ' " & vbNewLine & _
                "        'pnlMain " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        Me.pnlMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D " & vbNewLine & _
                "        Me.pnlMain.Controls.Add(Me.txtLocationID) " & vbNewLine & _
                "        Me.pnlMain.Controls.Add(Me.txtComLocDivSubDivID) " & vbNewLine & _
                "        Me.pnlMain.Controls.Add(Me.btnSubDiv) " & vbNewLine & _
                "        Me.pnlMain.Controls.Add(Me.Label4) " & vbNewLine & _
                "        Me.pnlMain.Controls.Add(Me.Label3) " & vbNewLine & _
                "        Me.pnlMain.Controls.Add(Me.txtSubDivisionName) " & vbNewLine & _
                "        Me.pnlMain.Controls.Add(Me.txtDivisionName) " & vbNewLine & _
                "        Me.pnlMain.Controls.Add(Me.txtCompanyID) " & vbNewLine & _
                "        Me.pnlMain.Controls.Add(Me.btnCompany) " & vbNewLine & _
                "        Me.pnlMain.Controls.Add(Me.Label7) " & vbNewLine & _
                "        Me.pnlMain.Controls.Add(Me.cboStatus) " & vbNewLine & _
                "        Me.pnlMain.Controls.Add(Me.Label2) " & vbNewLine & _
                "        Me.pnlMain.Controls.Add(Me.Label1) " & vbNewLine & _
                "        Me.pnlMain.Controls.Add(Me.txtLocationName) " & vbNewLine & _
                "        Me.pnlMain.Controls.Add(Me.txtCompanyName) " & vbNewLine & _
                "        Me.pnlMain.Controls.Add(Me.dtpDateTo) " & vbNewLine & _
                "        Me.pnlMain.Controls.Add(Me.Label6) " & vbNewLine & _
                "        Me.pnlMain.Controls.Add(Me.dtpDateFrom) " & vbNewLine & _
                "        Me.pnlMain.Controls.Add(Me.btnQuery) " & vbNewLine & _
                "        Me.pnlMain.Controls.Add(Me.Label5) " & vbNewLine & _
                "        Me.pnlMain.Dock = System.Windows.Forms.DockStyle.Top " & vbNewLine & _
                "        Me.pnlMain.Location = New System.Drawing.Point(0, 28) " & vbNewLine & _
                "        Me.pnlMain.Name = ""pnlMain"" " & vbNewLine & _
                "        Me.pnlMain.Size = New System.Drawing.Size(834, 119) " & vbNewLine & _
                "        Me.pnlMain.TabIndex = 128 " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        'Label1 " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        Me.Label1.AutoSize = True " & vbNewLine & _
                "        Me.Label1.Font = New System.Drawing.Font(""Tahoma"", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte)) " & vbNewLine & _
                "        Me.Label1.ForeColor = System.Drawing.Color.Gray " & vbNewLine & _
                "        Me.Label1.Location = New System.Drawing.Point(10, 12) " & vbNewLine & _
                "        Me.Label1.Name = ""Label1"" " & vbNewLine & _
                "        Me.Label1.Size = New System.Drawing.Size(60, 13) " & vbNewLine & _
                "        Me.Label1.TabIndex = 85 " & vbNewLine & _
                "        Me.Label1.Text = ""Company"" " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        'txtCompanyID " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        Me.txtCompanyID.BackColor = System.Drawing.Color.LightYellow " & vbNewLine & _
                "        Me.txtCompanyID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper " & vbNewLine & _
                "        Me.txtCompanyID.Location = New System.Drawing.Point(291, 9) " & vbNewLine & _
                "        Me.txtCompanyID.Name = ""txtCompanyID"" " & vbNewLine & _
                "        Me.txtCompanyID.ReadOnly = True " & vbNewLine & _
                "        Me.txtCompanyID.Size = New System.Drawing.Size(27, 21) " & vbNewLine & _
                "        Me.txtCompanyID.TabIndex = 1 " & vbNewLine & _
                "        Me.txtCompanyID.Visible = False " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        'txtCompanyName " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        Me.txtCompanyName.BackColor = System.Drawing.Color.LightYellow " & vbNewLine & _
                "        Me.txtCompanyName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper " & vbNewLine & _
                "        Me.txtCompanyName.Location = New System.Drawing.Point(81, 9) " & vbNewLine & _
                "        Me.txtCompanyName.Name = ""txtCompanyName"" " & vbNewLine & _
                "        Me.txtCompanyName.ReadOnly = True " & vbNewLine & _
                "        Me.txtCompanyName.Size = New System.Drawing.Size(239, 21) " & vbNewLine & _
                "        Me.txtCompanyName.TabIndex = 0 " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        'btnCompany " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        Me.btnCompany.BackColor = System.Drawing.Color.Transparent " & vbNewLine & _
                "        Me.btnCompany.Cursor = System.Windows.Forms.Cursors.Hand " & vbNewLine & _
                "        Me.btnCompany.FlatStyle = System.Windows.Forms.FlatStyle.Flat " & vbNewLine & _
                "        Me.btnCompany.Font = New System.Drawing.Font(""Tahoma"", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte)) " & vbNewLine & _
                "        Me.btnCompany.ForeColor = System.Drawing.Color.WhiteSmoke " & vbNewLine & _
                "        Me.btnCompany.Image = My.Resources.Resources.btnSearch " & vbNewLine & _
                "        Me.btnCompany.Location = New System.Drawing.Point(324, 9) " & vbNewLine & _
                "        Me.btnCompany.Name = ""btnCompany"" " & vbNewLine & _
                "        Me.btnCompany.Size = New System.Drawing.Size(19, 20) " & vbNewLine & _
                "        Me.btnCompany.TabIndex = 2 " & vbNewLine & _
                "        Me.btnCompany.TabStop = False " & vbNewLine & _
                "        Me.btnCompany.UseVisualStyleBackColor = False " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        'Label2 " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        Me.Label2.AutoSize = True " & vbNewLine & _
                "        Me.Label2.Font = New System.Drawing.Font(""Tahoma"", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte)) " & vbNewLine & _
                "        Me.Label2.ForeColor = System.Drawing.Color.Gray " & vbNewLine & _
                "        Me.Label2.Location = New System.Drawing.Point(10, 35) " & vbNewLine & _
                "        Me.Label2.Name = ""Label2"" " & vbNewLine & _
                "        Me.Label2.Size = New System.Drawing.Size(55, 13) " & vbNewLine & _
                "        Me.Label2.TabIndex = 86 " & vbNewLine & _
                "        Me.Label2.Text = ""Location"" " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        'txtLocationID " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        Me.txtLocationID.BackColor = System.Drawing.Color.LightYellow " & vbNewLine & _
                "        Me.txtLocationID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper " & vbNewLine & _
                "        Me.txtLocationID.Location = New System.Drawing.Point(291, 32) " & vbNewLine & _
                "        Me.txtLocationID.Name = ""txtLocationID"" " & vbNewLine & _
                "        Me.txtLocationID.ReadOnly = True " & vbNewLine & _
                "        Me.txtLocationID.Size = New System.Drawing.Size(27, 21) " & vbNewLine & _
                "        Me.txtLocationID.TabIndex = 97 " & vbNewLine & _
                "        Me.txtLocationID.Visible = False " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        'txtLocationName " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        Me.txtLocationName.BackColor = System.Drawing.Color.LightYellow " & vbNewLine & _
                "        Me.txtLocationName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper " & vbNewLine & _
                "        Me.txtLocationName.Location = New System.Drawing.Point(81, 32) " & vbNewLine & _
                "        Me.txtLocationName.Name = ""txtLocationName"" " & vbNewLine & _
                "        Me.txtLocationName.ReadOnly = True " & vbNewLine & _
                "        Me.txtLocationName.Size = New System.Drawing.Size(239, 21) " & vbNewLine & _
                "        Me.txtLocationName.TabIndex = 3 " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        'Label3 " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        Me.Label3.AutoSize = True " & vbNewLine & _
                "        Me.Label3.Font = New System.Drawing.Font(""Tahoma"", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte)) " & vbNewLine & _
                "        Me.Label3.ForeColor = System.Drawing.Color.Gray " & vbNewLine & _
                "        Me.Label3.Location = New System.Drawing.Point(382, 12) " & vbNewLine & _
                "        Me.Label3.Name = ""Label3"" " & vbNewLine & _
                "        Me.Label3.Size = New System.Drawing.Size(51, 13) " & vbNewLine & _
                "        Me.Label3.TabIndex = 95 " & vbNewLine & _
                "        Me.Label3.Text = ""Division"" " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        'txtDivisionName " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        Me.txtDivisionName.BackColor = System.Drawing.Color.LightYellow " & vbNewLine & _
                "        Me.txtDivisionName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper " & vbNewLine & _
                "        Me.txtDivisionName.Location = New System.Drawing.Point(462, 9) " & vbNewLine & _
                "        Me.txtDivisionName.Name = ""txtDivisionName"" " & vbNewLine & _
                "        Me.txtDivisionName.ReadOnly = True " & vbNewLine & _
                "        Me.txtDivisionName.Size = New System.Drawing.Size(217, 21) " & vbNewLine & _
                "        Me.txtDivisionName.TabIndex = 7 " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        'Label4 " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        Me.Label4.AutoSize = True " & vbNewLine & _
                "        Me.Label4.Font = New System.Drawing.Font(""Tahoma"", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte)) " & vbNewLine & _
                "        Me.Label4.ForeColor = System.Drawing.Color.Gray " & vbNewLine & _
                "        Me.Label4.Location = New System.Drawing.Point(382, 35) " & vbNewLine & _
                "        Me.Label4.Name = ""Label4"" " & vbNewLine & _
                "        Me.Label4.Size = New System.Drawing.Size(75, 13) " & vbNewLine & _
                "        Me.Label4.TabIndex = 96 " & vbNewLine & _
                "        Me.Label4.Text = ""Sub Division"" " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        'txtComLocDivSubDivID " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        Me.txtComLocDivSubDivID.BackColor = System.Drawing.Color.LightYellow " & vbNewLine & _
                "        Me.txtComLocDivSubDivID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper " & vbNewLine & _
                "        Me.txtComLocDivSubDivID.Location = New System.Drawing.Point(652, 32) " & vbNewLine & _
                "        Me.txtComLocDivSubDivID.Name = ""txtComLocDivSubDivID"" " & vbNewLine & _
                "        Me.txtComLocDivSubDivID.ReadOnly = True " & vbNewLine & _
                "        Me.txtComLocDivSubDivID.Size = New System.Drawing.Size(27, 21) " & vbNewLine & _
                "        Me.txtComLocDivSubDivID.TabIndex = 9 " & vbNewLine & _
                "        Me.txtComLocDivSubDivID.Visible = False " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        'txtSubDivisionName " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        Me.txtSubDivisionName.BackColor = System.Drawing.Color.LightYellow " & vbNewLine & _
                "        Me.txtSubDivisionName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper " & vbNewLine & _
                "        Me.txtSubDivisionName.Location = New System.Drawing.Point(462, 32) " & vbNewLine & _
                "        Me.txtSubDivisionName.Name = ""txtSubDivisionName"" " & vbNewLine & _
                "        Me.txtSubDivisionName.ReadOnly = True " & vbNewLine & _
                "        Me.txtSubDivisionName.Size = New System.Drawing.Size(217, 21) " & vbNewLine & _
                "        Me.txtSubDivisionName.TabIndex = 8 " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        'btnSubDiv " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        Me.btnSubDiv.BackColor = System.Drawing.Color.Transparent " & vbNewLine & _
                "        Me.btnSubDiv.Cursor = System.Windows.Forms.Cursors.Hand " & vbNewLine & _
                "        Me.btnSubDiv.FlatStyle = System.Windows.Forms.FlatStyle.Flat " & vbNewLine & _
                "        Me.btnSubDiv.Font = New System.Drawing.Font(""Tahoma"", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte)) " & vbNewLine & _
                "        Me.btnSubDiv.ForeColor = System.Drawing.Color.WhiteSmoke " & vbNewLine & _
                "        Me.btnSubDiv.Image = My.Resources.Resources.btnSearch " & vbNewLine & _
                "        Me.btnSubDiv.Location = New System.Drawing.Point(682, 32) " & vbNewLine & _
                "        Me.btnSubDiv.Name = ""btnSubDiv"" " & vbNewLine & _
                "        Me.btnSubDiv.Size = New System.Drawing.Size(19, 20) " & vbNewLine & _
                "        Me.btnSubDiv.TabIndex = 10 " & vbNewLine & _
                "        Me.btnSubDiv.TabStop = False " & vbNewLine & _
                "        Me.btnSubDiv.UseVisualStyleBackColor = False " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        'Label5 " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        Me.Label5.AutoSize = True " & vbNewLine & _
                "        Me.Label5.Font = New System.Drawing.Font(""Tahoma"", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte)) " & vbNewLine & _
                "        Me.Label5.ForeColor = System.Drawing.Color.Gray " & vbNewLine & _
                "        Me.Label5.Location = New System.Drawing.Point(10, 58) " & vbNewLine & _
                "        Me.Label5.Name = ""Label5"" " & vbNewLine & _
                "        Me.Label5.Size = New System.Drawing.Size(43, 13) " & vbNewLine & _
                "        Me.Label5.TabIndex = 0 " & vbNewLine & _
                "        Me.Label5.Text = ""Period"" " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        'dtpDateFrom " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        Me.dtpDateFrom.CustomFormat = ""dd/MM/yyyyy"" " & vbNewLine & _
                "        Me.dtpDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom " & vbNewLine & _
                "        Me.dtpDateFrom.Location = New System.Drawing.Point(81, 55) " & vbNewLine & _
                "        Me.dtpDateFrom.Name = ""dtpDateFrom"" " & vbNewLine & _
                "        Me.dtpDateFrom.Size = New System.Drawing.Size(104, 21) " & vbNewLine & _
                "        Me.dtpDateFrom.TabIndex = 4 " & vbNewLine & _
                "        Me.dtpDateFrom.Value = New Date(2016, 1, 1, 0, 0, 0, 0) " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        'Label6 " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        Me.Label6.AutoSize = True " & vbNewLine & _
                "        Me.Label6.Font = New System.Drawing.Font(""Tahoma"", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte)) " & vbNewLine & _
                "        Me.Label6.ForeColor = System.Drawing.Color.Gray " & vbNewLine & _
                "        Me.Label6.Location = New System.Drawing.Point(191, 59) " & vbNewLine & _
                "        Me.Label6.Name = ""Label6"" " & vbNewLine & _
                "        Me.Label6.Size = New System.Drawing.Size(21, 13) " & vbNewLine & _
                "        Me.Label6.TabIndex = 81 " & vbNewLine & _
                "        Me.Label6.Text = ""To"" " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        'dtpDateTo " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        Me.dtpDateTo.CustomFormat = ""dd/MM/yyyyy"" " & vbNewLine & _
                "        Me.dtpDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom " & vbNewLine & _
                "        Me.dtpDateTo.Location = New System.Drawing.Point(216, 55) " & vbNewLine & _
                "        Me.dtpDateTo.Name = ""dtpDateTo"" " & vbNewLine & _
                "        Me.dtpDateTo.Size = New System.Drawing.Size(104, 21) " & vbNewLine & _
                "        Me.dtpDateTo.TabIndex = 5 " & vbNewLine & _
                "        Me.dtpDateTo.Value = New Date(2016, 1, 1, 0, 0, 0, 0) " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        'Label7 " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        Me.Label7.AutoSize = True " & vbNewLine & _
                "        Me.Label7.Font = New System.Drawing.Font(""Tahoma"", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte)) " & vbNewLine & _
                "        Me.Label7.ForeColor = System.Drawing.Color.Gray " & vbNewLine & _
                "        Me.Label7.Location = New System.Drawing.Point(10, 81) " & vbNewLine & _
                "        Me.Label7.Name = ""Label7"" " & vbNewLine & _
                "        Me.Label7.Size = New System.Drawing.Size(44, 13) " & vbNewLine & _
                "        Me.Label7.TabIndex = 88 " & vbNewLine & _
                "        Me.Label7.Text = ""Status"" " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        'cboStatus " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        Me.cboStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList " & vbNewLine & _
                "        Me.cboStatus.FormattingEnabled = True " & vbNewLine & _
                "        Me.cboStatus.Items.AddRange(New Object() {""ALL"", ""DRAFT"", ""SUBMITTED""}) " & vbNewLine & _
                "        Me.cboStatus.Location = New System.Drawing.Point(81, 78) " & vbNewLine & _
                "        Me.cboStatus.Name = ""cboStatus"" " & vbNewLine & _
                "        Me.cboStatus.Size = New System.Drawing.Size(166, 21) " & vbNewLine & _
                "        Me.cboStatus.TabIndex = 6 " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        'btnQuery " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        Me.btnQuery.FlatStyle = System.Windows.Forms.FlatStyle.Popup " & vbNewLine & _
                "        Me.btnQuery.Font = New System.Drawing.Font(""Tahoma"", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte)) " & vbNewLine & _
                "        Me.btnQuery.Location = New System.Drawing.Point(261, 78) " & vbNewLine & _
                "        Me.btnQuery.Name = ""btnQuery"" " & vbNewLine & _
                "        Me.btnQuery.Size = New System.Drawing.Size(59, 21) " & vbNewLine & _
                "        Me.btnQuery.TabIndex = 11 " & vbNewLine & _
                "        Me.btnQuery.Text = ""Query"" " & vbNewLine & _
                "        Me.btnQuery.UseVisualStyleBackColor = True " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        'grdMain " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        Me.grdMain.Dock = System.Windows.Forms.DockStyle.Fill " & vbNewLine & _
                "        Me.grdMain.Location = New System.Drawing.Point(0, 147) " & vbNewLine & _
                "        Me.grdMain.LookAndFeel.SkinName = ""Caramel"" " & vbNewLine & _
                "        Me.grdMain.MainView = Me.grdView " & vbNewLine & _
                "        Me.grdMain.Name = ""grdMain"" " & vbNewLine & _
                "        Me.grdMain.Size = New System.Drawing.Size(834, 415) " & vbNewLine & _
                "        Me.grdMain.TabIndex = 127 " & vbNewLine & _
                "        Me.grdMain.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.grdView}) " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        'grdView " & vbNewLine & _
                "        ' " & vbNewLine & _
                "        Me.grdView.GridControl = Me.grdMain " & vbNewLine & _
                "        Me.grdView.Name = ""grdView"" " & vbNewLine & _
                "        Me.grdView.OptionsView.ColumnAutoWidth = False " & vbNewLine & _
                "        Me.grdView.OptionsView.ShowAutoFilterRow = True " & vbNewLine & _
                "        '" & vbNewLine & _
                "        '" & strFormName.Trim & vbNewLine & _
                "        '" & vbNewLine & _
                "        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)" & vbNewLine & _
                "        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font" & vbNewLine & _
                "        Me.ClientSize = New System.Drawing.Size(984, 612)" & vbNewLine & _
                "        Me.Controls.Add(Me.grdMain)" & vbNewLine & _
                "        Me.Controls.Add(Me.pnlMain)" & vbNewLine & _
                "        Me.Controls.Add(Me.ToolBar)" & vbNewLine & _
                "        Me.Font = New System.Drawing.Font(""Tahoma"", 8.25!)" & vbNewLine & _
                "        Me.KeyPreview = True" & vbNewLine & _
                "        Me.Name = """ & strFormName.Trim & """" & vbNewLine & _
                "        Me.Text = """ & strDataName.Trim & """" & vbNewLine & _
                "        CType(Me.grdMain, System.ComponentModel.ISupportInitialize).EndInit()" & vbNewLine & _
                "        CType(Me.grdView, System.ComponentModel.ISupportInitialize).EndInit()" & vbNewLine & _
                "        Me.pnlMain.ResumeLayout(False)" & vbNewLine & _
                "        Me.pnlMain.PerformLayout()" & vbNewLine & _
                "        Me.ResumeLayout(False)" & vbNewLine & _
                "        Me.PerformLayout()" & vbNewLine & _
                "" & vbNewLine & _
                "    End Sub" & vbNewLine & _
                "    Friend WithEvents ToolBar As System.Windows.Forms.ToolBar" & vbNewLine & _
                "    Friend WithEvents BarNew As System.Windows.Forms.ToolBarButton" & vbNewLine & _
                "    Friend WithEvents BarDetail As System.Windows.Forms.ToolBarButton" & vbNewLine & _
                "    Friend WithEvents BarDelete As System.Windows.Forms.ToolBarButton" & vbNewLine & _
                "    Friend WithEvents BarSep1 As System.Windows.Forms.ToolBarButton" & vbNewLine & _
                "    Friend WithEvents BarSubmit As System.Windows.Forms.ToolBarButton" & vbNewLine & _
                "    Friend WithEvents BarUnsubmit As System.Windows.Forms.ToolBarButton" & vbNewLine & _
                "    Friend WithEvents BarSep2 As System.Windows.Forms.ToolBarButton" & vbNewLine & _
                "    Friend WithEvents BarRefresh As System.Windows.Forms.ToolBarButton" & vbNewLine & _
                "    Friend WithEvents BarClose As System.Windows.Forms.ToolBarButton" & vbNewLine & _
                "    Friend WithEvents pnlMain As System.Windows.Forms.Panel " & vbNewLine & _
                "    Friend WithEvents Label1 As System.Windows.Forms.Label " & vbNewLine & _
                "    Friend WithEvents txtCompanyID As usTextBox " & vbNewLine & _
                "    Friend WithEvents txtCompanyName As usTextBox " & vbNewLine & _
                "    Friend WithEvents btnCompany As System.Windows.Forms.Button " & vbNewLine & _
                "    Friend WithEvents Label2 As System.Windows.Forms.Label " & vbNewLine & _
                "    Friend WithEvents txtLocationID As usTextBox " & vbNewLine & _
                "    Friend WithEvents txtLocationName As usTextBox " & vbNewLine & _
                "    Friend WithEvents Label3 As System.Windows.Forms.Label " & vbNewLine & _
                "    Friend WithEvents txtDivisionName As usTextBox " & vbNewLine & _
                "    Friend WithEvents Label4 As System.Windows.Forms.Label " & vbNewLine & _
                "    Friend WithEvents txtComLocDivSubDivID As usTextBox " & vbNewLine & _
                "    Friend WithEvents txtSubDivisionName As usTextBox " & vbNewLine & _
                "    Friend WithEvents btnSubDiv As System.Windows.Forms.Button " & vbNewLine & _
                "    Friend WithEvents Label5 As System.Windows.Forms.Label " & vbNewLine & _
                "    Friend WithEvents dtpDateFrom As System.Windows.Forms.DateTimePicker " & vbNewLine & _
                "    Friend WithEvents Label6 As System.Windows.Forms.Label " & vbNewLine & _
                "    Friend WithEvents dtpDateTo As System.Windows.Forms.DateTimePicker " & vbNewLine & _
                "    Friend WithEvents Label7 As System.Windows.Forms.Label " & vbNewLine & _
                "    Friend WithEvents cboStatus As System.Windows.Forms.ComboBox " & vbNewLine & _
                "    Friend WithEvents btnQuery As System.Windows.Forms.Button " & vbNewLine & _
                "    Friend WithEvents grdMain As DevExpress.XtraGrid.GridControl" & vbNewLine & _
                "    Friend WithEvents grdView As DevExpress.XtraGrid.Views.Grid.GridView" & vbNewLine & _
                "End Class" & vbNewLine & _
                "" & vbNewLine

            UI.usForm.AppendText_txt(strFolderName, strFormName, ".Designer.vb", strValue)
        End Sub

        Public Sub pubGenerateFormVBHeader(ByVal strFormName As String, ByVal strTableName As String, ByVal strFolderName As String, ByVal bolUseParentTools As Boolean, cls As VO.UserSelection)
            Dim strScript As String = ""
            strScript = _
                "Public Class " & strFormName & vbNewLine & _
                "" & vbNewLine

            strScript += FormFunction.modGenerateFormFunction.FunctPrivateConst(False, cls)

            strScript += _
                "    Private intPos As Integer " & vbNewLine & _
                "    Private clsCS As New VO.CS " & vbNewLine & vbNewLine

            strScript += FormFunction.modGenerateFormFunction.FunctSetIcon(False, cls)

            strScript += FormFunction.modGenerateFormFunction.FunctUserAccess(False, cls)

            strScript += FormFunction.modGenerateFormFunction.FunctSetDefaultFilter()

            strScript += FormFunction.modGenerateFormFunction.FunctSetGrid(strTableName, cls)

            strScript += FormFunction.modGenerateFormFunction.FunctQuery(strTableName, cls)

            strScript += FormFunction.modGenerateFormFunction.FunctSetButton(cls)

            strScript += FormFunction.modGenerateFormFunction.FunctGetCS()

            strScript += FormFunction.modGenerateFormFunction.FunctNew(strTableName, strFormName & "Det", cls)

            strScript += FormFunction.modGenerateFormFunction.FunctDetail(strTableName, strFormName & "Det", cls)

            strScript += FormFunction.modGenerateFormFunction.FunctDelete(strTableName, Replace(strTableName, cls.TextToReplace, ""), cls)

            strScript += FormFunction.modGenerateFormFunction.FunctSubmit(strTableName, Replace(strTableName, cls.TextToReplace, ""), cls)

            strScript += FormFunction.modGenerateFormFunction.FunctUnSubmit(strTableName, Replace(strTableName, cls.TextToReplace, ""), cls)

            strScript += FormFunction.modGenerateFormFunction.FunctRefresh(strTableName, cls)

            strScript += _
                "#Region " & """Form Handle""" & vbNewLine & vbNewLine

            strScript += FormHandle.modGenerateFormHandle.FunctFormLoad(strFormName, False, bolUseParentTools, cls)

            strScript += FormHandle.modGenerateFormHandle.FunctFormKeyDown(strFormName, False, cls)

            strScript += FormHandle.modGenerateFormHandle.FunctToolBarButton(False, cls)

            strScript += FormHandle.modGenerateFormHandle.FunctGridRowStyle(cls)

            'btnCompany
            strScript += FormHandle.modGenerateFormHandle.FuncBtnCompanyOnClick()

            'btnSubDiv
            strScript += FormHandle.modGenerateFormHandle.FuncBtnSubDivOnClick()
            'btnQuery
            strScript += FormHandle.modGenerateFormHandle.FuncBtnQueryOnClick()

            strScript += _
                "#End Region " & vbNewLine

            strScript += _
                "" & vbNewLine & _
                "End Class" & vbNewLine & _
                "" & vbNewLine

            UI.usForm.AppendText_txt(strFolderName, strFormName, ".vb", strScript)
        End Sub

        Public Sub pubGenerateFormDesignerDetail(ByVal strFormName As String, ByVal strTableName As String, ByVal strFolderName As String, ByVal bolUseParentTools As Boolean, ByVal strDataName As String, ByVal cls As VO.UserSelection)
            Dim strValue As String = ""
            Dim intCount As Integer = 0
            VO.ColumnList.ColumnList = BL.ColumnList.ListData(strTableName, cls)
            strValue = _
                "<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _" & vbNewLine & _
                "Partial Class " & strFormName & vbNewLine & _
                "    Inherits System.Windows.Forms.Form" & vbNewLine & _
                "" & vbNewLine & _
                "    'Form overrides dispose to clean up the component list." & vbNewLine & _
                "    <System.Diagnostics.DebuggerNonUserCode()> _" & vbNewLine & _
                "    Protected Overrides Sub Dispose(ByVal disposing As Boolean)" & vbNewLine & _
                "        Try" & vbNewLine & _
                "            If disposing AndAlso components IsNot Nothing Then" & vbNewLine & _
                "                components.Dispose()" & vbNewLine & _
                "            End If" & vbNewLine & _
                "        Finally" & vbNewLine & _
                "            MyBase.Dispose(disposing)" & vbNewLine & _
                "        End Try" & vbNewLine & _
                "    End Sub" & vbNewLine & _
                "" & vbNewLine & _
                "    'Required by the Windows Form Designer" & vbNewLine & _
                "    Private components As System.ComponentModel.IContainer" & vbNewLine & _
                "" & vbNewLine & _
                "    'NOTE: The following procedure is required by the Windows Form Designer" & vbNewLine & _
                "    'It can be modified using the Windows Form Designer.  " & vbNewLine & _
                "    'Do not modify it using the code editor." & vbNewLine & _
                "    <System.Diagnostics.DebuggerStepThrough()> _" & vbNewLine & _
                "    Private Sub InitializeComponent()" & vbNewLine & _
                "        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(" & strFormName & "))" & vbNewLine

            If Not bolUseParentTools Then
                strValue += _
                "        Me.ToolBar = New System.Windows.Forms.ToolBar()" & vbNewLine & _
                "        Me.BarSave = New System.Windows.Forms.ToolBarButton()" & vbNewLine & _
                "        Me.BarClose = New System.Windows.Forms.ToolBarButton()" & vbNewLine & _
                "        Me.lblInfo = New System.Windows.Forms.Label()" & vbNewLine
            End If

            strValue += _
                "        Me.StatusStrip = New System.Windows.Forms.StatusStrip()" & vbNewLine & _
                "        Me.ToolStripEmpty = New System.Windows.Forms.ToolStripStatusLabel()" & vbNewLine & _
                "        Me.ToolStripLogInc = New System.Windows.Forms.ToolStripStatusLabel()" & vbNewLine & _
                "        Me.ToolStripLogBy = New System.Windows.Forms.ToolStripStatusLabel()" & vbNewLine & _
                "        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()" & vbNewLine & _
                "        Me.ToolStripLogDate = New System.Windows.Forms.ToolStripStatusLabel()" & vbNewLine & _
                "        Me.pnlDetail = New System.Windows.Forms.Panel()" & vbNewLine

            strValue += _
            "        Me.StatusStrip.SuspendLayout()" & vbNewLine & _
            "        Me.pnlDetail.SuspendLayout()" & vbNewLine

            strValue += _
            "        Me.SuspendLayout()" & vbNewLine

            If Not bolUseParentTools Then
                strValue += _
            "        '" & vbNewLine & _
            "        'ToolBar" & vbNewLine & _
            "        '" & vbNewLine & _
            "        Me.ToolBar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat" & vbNewLine & _
            "        Me.ToolBar.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.BarSave, Me.BarClose})" & vbNewLine & _
            "        Me.ToolBar.DropDownArrows = True" & vbNewLine & _
            "        Me.ToolBar.Font = New System.Drawing.Font(" & """Tahoma""" & ", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))" & vbNewLine & _
            "        Me.ToolBar.Location = New System.Drawing.Point(0, 0)" & vbNewLine & _
            "        Me.ToolBar.Name = " & """ToolBar""" & vbNewLine & _
            "        Me.ToolBar.ShowToolTips = True" & vbNewLine & _
            "        Me.ToolBar.Size = New System.Drawing.Size(484, 28)" & vbNewLine & _
            "        Me.ToolBar.TabIndex = 0" & vbNewLine & _
            "        Me.ToolBar.TextAlign = System.Windows.Forms.ToolBarTextAlign.Right" & vbNewLine & _
            "        '" & vbNewLine & _
            "        'BarSave" & vbNewLine & _
            "        '" & vbNewLine & _
            "        Me.BarSave.Name = " & """BarSave""" & vbNewLine & _
            "        Me.BarSave.Text = " & """Save""" & vbNewLine & _
            "        '" & vbNewLine & _
            "        'BarClose" & vbNewLine & _
            "        '" & vbNewLine & _
            "        Me.BarClose.Name = " & """BarClose""" & vbNewLine & _
            "        Me.BarClose.Text = " & """Close""" & vbNewLine & _
            "        '" & vbNewLine & _
            "        'lblInfo" & vbNewLine & _
            "        '" & vbNewLine & _
            "        Me.lblInfo.BackColor = System.Drawing.Color.CadetBlue" & vbNewLine & _
            "        Me.lblInfo.Dock = System.Windows.Forms.DockStyle.Top" & vbNewLine & _
            "        Me.lblInfo.Font = New System.Drawing.Font(" & """Tahoma""" & ", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))" & vbNewLine & _
            "        Me.lblInfo.ForeColor = System.Drawing.Color.White" & vbNewLine & _
            "        Me.lblInfo.Location = New System.Drawing.Point(0, 28)" & vbNewLine & _
            "        Me.lblInfo.Name = " & """lblInfo""" & vbNewLine & _
            "        Me.lblInfo.Size = New System.Drawing.Size(484, 22)" & vbNewLine & _
            "        Me.lblInfo.TabIndex = 1" & vbNewLine & _
            "        Me.lblInfo.Text = """ & "« " & strDataName & """" & vbNewLine & _
            "        Me.lblInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft" & vbNewLine
            End If

            strValue += _
            "        '" & vbNewLine & _
            "        'StatusStrip" & vbNewLine & _
            "        '" & vbNewLine & _
            "        Me.StatusStrip.Font = New System.Drawing.Font(" & """Tahoma""" & ", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))" & vbNewLine & _
            "        Me.StatusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripEmpty, Me.ToolStripLogInc, Me.ToolStripLogBy, Me.ToolStripStatusLabel1, Me.ToolStripLogDate})" & vbNewLine & _
            "        Me.StatusStrip.Location = New System.Drawing.Point(0, 320)" & vbNewLine & _
            "        Me.StatusStrip.Name = " & """StatusStrip""" & vbNewLine & _
            "        Me.StatusStrip.Size = New System.Drawing.Size(484, 22)" & vbNewLine & _
            "        Me.StatusStrip.TabIndex = 0" & vbNewLine & _
            "        Me.StatusStrip.Text = " & """StatusStrip1""" & vbNewLine & _
            "        '" & vbNewLine & _
            "        'ToolStripEmpty" & vbNewLine & _
            "        '" & vbNewLine & _
            "        Me.ToolStripEmpty.Name = " & """ToolStripEmpty""" & vbNewLine & _
            "        Me.ToolStripEmpty.Size = New System.Drawing.Size(361, 17)" & vbNewLine & _
            "        Me.ToolStripEmpty.Spring = True" & vbNewLine & _
            "        '" & vbNewLine & _
            "        'ToolStripLogInc" & vbNewLine & _
            "        '" & vbNewLine & _
            "        Me.ToolStripLogInc.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _" & vbNewLine & _
            "            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _" & vbNewLine & _
            "            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)" & vbNewLine & _
            "        Me.ToolStripLogInc.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter" & vbNewLine & _
            "        Me.ToolStripLogInc.Name = " & """ToolStripLogInc""" & vbNewLine & _
            "        Me.ToolStripLogInc.Size = New System.Drawing.Size(48, 17)" & vbNewLine & _
            "        Me.ToolStripLogInc.Text = " & """Log Inc : """ & vbNewLine & _
            "        '" & vbNewLine & _
            "        'ToolStripLogBy" & vbNewLine & _
            "        '" & vbNewLine & _
            "        Me.ToolStripLogBy.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _" & vbNewLine & _
            "            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _" & vbNewLine & _
            "            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)" & vbNewLine & _
            "        Me.ToolStripLogBy.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter" & vbNewLine & _
            "        Me.ToolStripLogBy.Name = " & """ToolStripLogBy""" & vbNewLine & _
            "        Me.ToolStripLogBy.Size = New System.Drawing.Size(48, 17)" & vbNewLine & _
            "        Me.ToolStripLogBy.Text = " & """Last Log :""" & vbNewLine & _
            "        '" & vbNewLine & _
            "        'ToolStripStatusLabel1" & vbNewLine & _
            "        '" & vbNewLine & _
            "        Me.ToolStripStatusLabel1.Name = " & """ToolStripStatusLabel1""" & vbNewLine & _
            "        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(0, 17)" & vbNewLine & _
            "        '" & vbNewLine & _
            "        'ToolStripLogDate" & vbNewLine & _
            "        '" & vbNewLine & _
            "        Me.ToolStripLogDate.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _" & vbNewLine & _
            "            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _" & vbNewLine & _
            "            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)" & vbNewLine & _
            "        Me.ToolStripLogDate.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter" & vbNewLine & _
            "        Me.ToolStripLogDate.Name = " & """ToolStripLogDate""" & vbNewLine & _
            "        Me.ToolStripLogDate.Size = New System.Drawing.Size(12, 17)" & vbNewLine & _
            "        Me.ToolStripLogDate.Text = " & """-""" & vbNewLine & _
            "        '" & vbNewLine & _
            "        'pnlDetail" & vbNewLine & _
            "        '" & vbNewLine & _
            "        Me.pnlDetail.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D" & vbNewLine

            strValue += _
                "        Me.pnlDetail.Dock = System.Windows.Forms.DockStyle.Fill" & vbNewLine & _
                "        Me.pnlDetail.Location = New System.Drawing.Point(0, 50)" & vbNewLine & _
                "        Me.pnlDetail.Name = """ & "pnlDetail""" & vbNewLine & _
                "        Me.pnlDetail.Size = New System.Drawing.Size(484, 290)" & vbNewLine & _
                "        Me.pnlDetail.TabIndex = 2" & vbNewLine

            Dim intPoint As Integer = 18, intTabIndex As Integer = 0, intHeight As Integer = 0, intWidth As Integer = 0, _
                intAllHeight As Integer = 0

            strValue += _
                "        Me.pnlDetail.Dock = System.Windows.Forms.DockStyle.Fill" & vbNewLine & _
                "        Me.pnlDetail.Location = New System.Drawing.Point(0, 50)" & vbNewLine & _
                "        Me.pnlDetail.Name = " & """pnlDetail""" & vbNewLine & _
                "        Me.pnlDetail.Size = New System.Drawing.Size(484, 270)" & vbNewLine & _
                "        Me.pnlDetail.TabIndex = 2" & vbNewLine & _
                "        '" & vbNewLine & _
                "        '" & strFormName & vbNewLine & _
                "        '" & vbNewLine & _
                "        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)" & vbNewLine & _
                "        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font" & vbNewLine & _
                "        Me.ClientSize = New System.Drawing.Size(484, " & intAllHeight + 105 & ")" & vbNewLine & _
                "        Me.Controls.Add(Me.pnlDetail)" & vbNewLine & _
                "        Me.Controls.Add(Me.StatusStrip)" & vbNewLine

            If Not bolUseParentTools Then
                strValue += _
                "        Me.Controls.Add(Me.lblInfo)" & vbNewLine & _
                "        Me.Controls.Add(Me.ToolBar)" & vbNewLine
            End If

            strValue += _
                "        Me.Font = New System.Drawing.Font(" & """Tahoma""" & ", 8.25!)" & vbNewLine & _
                "        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle" & vbNewLine & _
                "        Me.KeyPreview = True" & vbNewLine & _
                "        Me.MaximizeBox = False" & vbNewLine & _
                "        Me.MinimizeBox = False" & vbNewLine & _
                "        Me.Name = """ & strFormName & """" & vbNewLine & _
                "        Me.Text = """ & strDataName & """" & vbNewLine & _
                "        Me.StatusStrip.ResumeLayout(False)" & vbNewLine & _
                "        Me.StatusStrip.PerformLayout()" & vbNewLine & _
                "        Me.pnlDetail.ResumeLayout(False)" & vbNewLine & _
                "        Me.pnlDetail.PerformLayout()" & vbNewLine & _
                "        'CType(Me.cboStatus.Properties, System.ComponentModel.ISupportInitialize).EndInit()" & vbNewLine & _
                "        Me.ResumeLayout(False)" & vbNewLine & _
                "        Me.PerformLayout()" & vbNewLine & _
                "" & vbNewLine & _
                "    End Sub" & vbNewLine

            If Not bolUseParentTools Then
                strValue += _
                "    Friend WithEvents ToolBar As System.Windows.Forms.ToolBar" & vbNewLine & _
                "    Friend WithEvents BarSave As System.Windows.Forms.ToolBarButton" & vbNewLine & _
                "    Friend WithEvents BarClose As System.Windows.Forms.ToolBarButton" & vbNewLine & _
                "    Friend WithEvents lblInfo As System.Windows.Forms.Label" & vbNewLine

            End If

            strValue += _
                "    Friend WithEvents StatusStrip As System.Windows.Forms.StatusStrip" & vbNewLine & _
                "    Friend WithEvents ToolStripEmpty As System.Windows.Forms.ToolStripStatusLabel" & vbNewLine & _
                "    Friend WithEvents ToolStripLogInc As System.Windows.Forms.ToolStripStatusLabel" & vbNewLine & _
                "    Friend WithEvents ToolStripLogBy As System.Windows.Forms.ToolStripStatusLabel" & vbNewLine & _
                "    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel" & vbNewLine & _
                "    Friend WithEvents ToolStripLogDate As System.Windows.Forms.ToolStripStatusLabel" & vbNewLine & _
                "    Friend WithEvents pnlDetail As System.Windows.Forms.Panel" & vbNewLine

            strValue += _
                "End Class" & vbNewLine & _
                "" & vbNewLine

            UI.usForm.AppendText_txt(strFolderName, strFormName, ".Designer.vb", strValue)
        End Sub

        Public Sub pubGenerateFormVBDetail(ByVal strFormName As String, _
                                            ByVal strTableName As String, ByVal strFolderName As String, ByVal strFileName As String, _
                                            ByVal bolUseParentTools As Boolean, ByVal cls As VO.UserSelection)
            Dim strScript As String = ""
            Dim frmFormNameOri As String = strFormName
            strFormName = strFormName & "Det"
            Dim dtColumnPK As New DataTable
            Dim strTypeVar As String = "", strType As String = ""

            dtColumnPK = BL.ColumnList.ListDataPK(strTableName, cls)

            strScript = _
                "Public Class " & strFormName & vbNewLine & _
                " " & vbNewLine & _
                "#Region """ & "Property""" & vbNewLine & _
                " " & vbNewLine & _
                "    Private frmParent As " & frmFormNameOri & vbNewLine & _
                "    Private clsData As VO." & strFileName & vbNewLine

            For Each drColumn As DataRow In dtColumnPK.Rows
                strScript += _
                "    Property pub" & drColumn.Item("ColumnName") & " As " & _LIB.modGenerateLib.pubGetVBType(drColumn.Item("DataType")) & vbNewLine
            Next

            strScript += _
                "    Property pubIsNew As Boolean = False " & vbNewLine & _
                "    Property pubIsSave As Boolean = False " & vbNewLine & _
                "    Property pubCS As New VO.CS " & vbNewLine & _
                "" & vbNewLine & _
                "#End Region " & vbNewLine & vbNewLine


            strScript += FormFunction.modGenerateFormFunction.FunctPrivateConst(True, cls)

            strScript += _
               "    Public Sub pubShowDialog(ByVal frmGetParent As Form) " & vbNewLine & _
               "        frmParent = frmGetParent" & vbNewLine & _
               "        Me.ShowDialog()" & vbNewLine & _
               "    End Sub " & vbNewLine & vbNewLine


            If Not bolUseParentTools Then
                strScript += FormFunction.modGenerateFormFunction.FunctSetIcon(True, cls)
            End If

            If Not bolUseParentTools Then
                strScript += FormFunction.modGenerateFormFunction.FunctUserAccess(True, cls)
            End If

            strScript += FormFunction.modGenerateFormFunction.FunctSetTittleForm(True)

            strScript += FormFunction.modGenerateFormFunction.FunctSave(strTableName, strFileName, bolUseParentTools, "'", cls)

            strScript += FormFunction.modGenerateFormFunction.FunctFillForm(strTableName, strFileName, "'", cls)

            strScript += FormFunction.modGenerateFormFunction.FunctClear(strTableName, strFileName, "'", cls)


            If cls.IsIncludeStatus Then
                strScript += _
            "#Region " & """History""" & vbNewLine & vbNewLine
                strScript += FormFunction.modGenerateFormFunction.FunctSetGridHistory()
                strScript += FormFunction.modGenerateFormFunction.FunctHistoryQuery(strTableName, strFileName, cls)
                strScript += _
            "#End Region " & vbNewLine & vbNewLine
            End If

            strScript += _
            "#Region " & """Form Handle""" & vbNewLine & vbNewLine

            strScript += FormHandle.modGenerateFormHandle.FunctFormLoad(strFormName, True, bolUseParentTools, cls)

            strScript += FormHandle.modGenerateFormHandle.FunctFormKeyDown(strFormName, True, cls)

            If Not bolUseParentTools Then
                strScript += FormHandle.modGenerateFormHandle.FunctToolBarButton(True, cls)
            End If

            strScript += _
            "#End Region " & vbNewLine

            strScript += _
                "" & vbNewLine & _
                "End Class" & vbNewLine & _
                "" & vbNewLine

            UI.usForm.AppendText_txt(strFolderName, strFormName, ".vb", strScript)
        End Sub

    End Module

End Namespace

