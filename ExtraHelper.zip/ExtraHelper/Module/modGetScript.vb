﻿Namespace GetScript
    Module modGetScript
        Public Sub pubGenerateScipt(ByVal strFolderName As String, ByVal cls As VO.UserSelection)
            Dim strResult As String = ""
            Dim strDefaultValue As String = ""
            Dim dtObject As DataTable = BL.ColumnList.ListDataScript(cls)
            With dtObject
                For i As Integer = 0 To .Rows.Count - 1
                    strResult = _
                        "USE " & cls.Database & vbNewLine & vbNewLine & _
                        "IF EXISTS(SELECT so.name FROM sys.objects so WHERE so.name='" & .Rows(i).Item("name") & "') " & vbNewLine & _
                        "DROP " & .Rows(i).Item("types") & " " & .Rows(i).Item("name") & vbNewLine & vbNewLine & _
                        "GO " & vbNewLine & _
                        .Rows(i).Item("definition") & vbNewLine & _
                        "GO " & vbNewLine
                    UI.usForm.AppendText_txt(strFolderName, .Rows(i).Item("name"), ".txt", strResult)
                Next
            End With
        End Sub
    End Module
End Namespace

