Namespace UI

    Public Class usUserApp

        Public Shared AppVersion As String = "version 1.0"

        Public Shared OFUserID As String = "user.cpsof"
        Public Shared OFUserPassword As String = "cpsof!23"
        Public Shared OFUserDomain As String = "local.com"

        Public Shared UserID As String = ""
        Public Shared UserCompanyID As String = ""
        Public Shared DelegateUserID As String = ""

        Public Shared AccessList As DataTable

        Public Shared ProgramID, ProgramName As String

        Public Shared CompanyID, CompanyName As String
        Public Shared LocationID, LocationName As String
        Public Shared DivisionID, DivisionName As String
        Public Shared SubDivisionID, SubDivisionName As String
        Public Shared SubCategory2ID As String

        Public Shared ComLocDivSubDivID As Integer
        Public Shared IsLinkCFM, IsLinkInventory, IsProject, IsBondedZone As Boolean

        Public Shared UserEmail As String
        Public Shared ProgramType As Integer
        Public Shared IsLocalPurchaseBudget As Boolean
        Public Shared IsSplitPRUsingWhiteList As Boolean
        'HG, 24 Sept 2014
        Public Shared HQPurchasePaymentBy As Boolean
        Public Shared LocalPurchasePaymentBy As Boolean
        Public Shared BUType As Integer
        Public Shared IsImportirPLB As Boolean
        Public Shared ServerName As String
    End Class

End Namespace
