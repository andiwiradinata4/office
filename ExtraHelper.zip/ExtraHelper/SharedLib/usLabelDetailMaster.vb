﻿Public Class usLabelDetailMaster : Inherits Label

    Public Sub New(ByVal strText As String)
        With Me
            .BackColor = Color.CadetBlue
            .Dock = DockStyle.Top
            .Font = New Font("Tahoma", 8.25!, FontStyle.Bold, GraphicsUnit.Point, CType(0, Byte))
            .ForeColor = Color.White
            .Location = New System.Drawing.Point(0, 28)
            .Name = "lblInfo"
            .TabIndex = 1
            .Text = "« " & strText.Trim
            .TextAlign = ContentAlignment.MiddleLeft
            .BringToFront()
        End With
    End Sub


End Class
