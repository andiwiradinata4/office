﻿Imports DevExpress.XtraPrinting
Namespace SharedLib
    Public Class ExcelExporter

        Public Const cETDataAware = 0, cETWYSIWYG = 1
        Public Const cTEMValue = 0, cTEMText = 1
        Public Enum Format
            xls
            xlsx
        End Enum

        Public MyReportTitle As String = ""

        Public Sub ExportToExcel(frmMe As Form, grdMain As DevExpress.XtraGrid.GridControl, strFileName As String, strSheetName As String, Optional ByVal bolShowGroupSummary As Boolean = False, Optional ByVal bolShowTotalSummary As Boolean = False, _
                                 Optional ByVal bytExportType As Byte = cETDataAware, Optional ByVal bytTextExportMode As Byte = cTEMValue, Optional ByVal format As Format = Format.xls)

            Dim ofdExport As New FolderBrowserDialog
            Dim strPath As String = ""
            With ofdExport
                If .ShowDialog() = Windows.Forms.DialogResult.OK Then
                    strPath = _
                        .SelectedPath & "\Result_" & strFileName & "_" & _
                        Now.Year.ToString & Now.Month.ToString & Now.Day.ToString & Now.Hour.ToString & Now.Minute.ToString & Now.Second.ToString

                    If format = ExcelExporter.Format.xls Then
                        strPath += ".xls"
                    ElseIf format = ExcelExporter.Format.xlsx Then
                        strPath += ".xlsx"
                    End If

                    If Not UI.usForm.frmAskQuestion("Save data to " & strPath & "?") Then Exit Sub
                    Try
                        frmMe.Cursor = Cursors.WaitCursor
                        If format = ExcelExporter.Format.xls Then
                            Dim advOption As New XlsExportOptionsEx()
                            advOption.AllowGrouping = DevExpress.Utils.DefaultBoolean.True
                            If bolShowGroupSummary Then advOption.ShowGroupSummaries = DevExpress.Utils.DefaultBoolean.True
                            If bolShowTotalSummary Then advOption.ShowTotalSummaries = DevExpress.Utils.DefaultBoolean.True
                            advOption.ExportType = bytExportType 'DevExpress.Export.ExportType.DataAware
                            advOption.SheetName = strSheetName
                            advOption.TextExportMode = bytTextExportMode 'TextExportMode.Value
                            grdMain.ExportToXls(strPath.Trim, advOption)
                        ElseIf format = ExcelExporter.Format.xlsx Then
                            Dim advOption As New XlsxExportOptionsEx()
                            advOption.AllowGrouping = DevExpress.Utils.DefaultBoolean.True
                            If bolShowGroupSummary Then advOption.ShowGroupSummaries = DevExpress.Utils.DefaultBoolean.True
                            If bolShowTotalSummary Then advOption.ShowTotalSummaries = DevExpress.Utils.DefaultBoolean.True
                            advOption.ExportType = bytExportType 'DevExpress.Export.ExportType.DataAware
                            advOption.SheetName = strSheetName
                            advOption.TextExportMode = bytTextExportMode 'TextExportMode.Value
                            grdMain.ExportToXlsx(strPath.Trim, advOption)
                        End If
                        UI.usForm.frmMessageBox("Export data success. " & strPath)
                    Catch ex As Exception
                        UI.usForm.frmMessageBox(ex.Message)
                    End Try
                End If
            End With
            frmMe.Cursor = Cursors.Default
            ofdExport.Dispose()
        End Sub

    End Class
End Namespace