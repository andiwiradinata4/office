Namespace UI

    Public Class usForm

        Public Shared Sub SetIcon(ByVal frmMe As Form, ByVal strIconName As String)
            frmMe.Icon = New Icon(frmMe.GetType(), strIconName & ".ico")
        End Sub

        Public Shared Sub frmMessageBox(ByVal strMessage As String, Optional ByVal strTitle As String = "Message")
            MessageBox.Show(strMessage, strTitle, MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End Sub

        Public Shared Function frmAskQuestion(ByVal strQuestion As String) As Boolean
            If MessageBox.Show(strQuestion, "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) = Windows.Forms.DialogResult.Yes Then
                Return True
            Else
                Return False
            End If
        End Function

        Public Shared Sub frmOpen(ByRef f As Object, ByVal fT As String, ByRef fMe As Form)
            Dim s_fT As String = fMe.GetType.Namespace & "." & fT
            fMe.Cursor = Cursors.WaitCursor
            If Not IsNothing(f) Then
                If Not f.IsDisposed Then
                    f.WindowState = FormWindowState.Normal
                    f.BringToFront()
                Else
                    f = Activator.CreateInstance(Type.GetType(s_fT))
                    f.MdiParent = fMe
                    f.Show()
                End If
            Else
                f = Activator.CreateInstance(Type.GetType(s_fT))
                f.MdiParent = fMe
                f.Show()
            End If
            fMe.Cursor = Cursors.Arrow
        End Sub

        Public Shared Sub SetToolBar(ByRef frmMe As Form, ByVal tobToolBar As ToolBar, ByVal strIcon As String)
            Dim iltImageList As New ImageList
            Dim Icon() = Split(strIcon, ",")
            Dim bteI, bteJ As Byte
            tobToolBar.ImageList = iltImageList
            With iltImageList
                .ImageSize = New Size(20, 20)
                .ColorDepth = ColorDepth.Depth32Bit
                bteI = 1
                While bteI <= UBound(Icon)
                    .Images.Add(New Icon(frmMe.GetType(), Icon(bteI) + ".ico"))
                    bteI += 2
                End While
                bteI = 0 : bteJ = 0
                While bteI < UBound(Icon)
                    tobToolBar.Buttons(CByte(Icon(bteI))).ImageIndex = bteJ
                    bteI += 2 : bteJ += 1
                End While
            End With
        End Sub

        Public Shared Sub SetGrid(ByVal grdView As DevExpress.XtraGrid.Views.Grid.GridView, _
                                  ByVal strFieldName As String, _
                                  ByVal strCaption As String, _
                                  ByVal intColoumnWidth As Integer, _
                                  ByVal intColoumnType As Integer, _
                                  Optional ByVal bolVisible As Boolean = True, _
                                  Optional ByVal bolReadonly As Boolean = True)

            Dim grdNewColumn As New DevExpress.XtraGrid.Columns.GridColumn
            With grdNewColumn
                .Name = strFieldName
                .FieldName = strFieldName
                .Caption = strCaption
                .Width = intColoumnWidth

                .DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom
                .AppearanceCell.Options.UseTextOptions = True


                Select Case intColoumnType
                    Case usDefGrid.gBoolean
                        .DisplayFormat.FormatType = DevExpress.Utils.FormatType.None
                        .AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
                    Case usDefGrid.gFullDate
                        .DisplayFormat.FormatString = usDefCons.DateFull
                        .AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near
                    Case usDefGrid.gIntNum
                        .DisplayFormat.FormatString = usDefCons.IntNum
                        .AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far
                    Case usDefGrid.gReal1Num
                        .DisplayFormat.FormatString = usDefCons.Real1Num
                        .AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far
                    Case usDefGrid.gReal2Num
                        .DisplayFormat.FormatString = usDefCons.Real2Num
                        .AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far
                    Case usDefGrid.gReal3Num
                        .DisplayFormat.FormatString = usDefCons.Real3Num
                        .AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far
                    Case usDefGrid.gReal4Num
                        .DisplayFormat.FormatString = usDefCons.Real4Num
                        .AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far
                    Case usDefGrid.gReal5Num
                        .DisplayFormat.FormatString = usDefCons.Real5Num
                        .AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far
                    Case usDefGrid.gReal6Num
                        .DisplayFormat.FormatString = usDefCons.Real6Num
                        .AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far
                    Case usDefGrid.gSmallDate
                        .DisplayFormat.FormatString = usDefCons.DateSmall
                        .AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near
                    Case usDefGrid.gString
                        .DisplayFormat.FormatType = DevExpress.Utils.FormatType.None
                        .AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near
                End Select

                .Visible = bolVisible
                .VisibleIndex = IIf(bolVisible, grdView.Columns.Count, -1)

                .OptionsColumn.AllowEdit = Not bolReadonly
                .OptionsColumn.ReadOnly = bolReadonly

            End With
            grdView.Columns.Add(grdNewColumn)
            grdView.OptionsNavigation.AutoMoveRowFocus = False
            grdView.OptionsSelection.EnableAppearanceFocusedCell = False
            grdView.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus

        End Sub

        Public Shared Sub GridMoveRow(ByVal grdView As DevExpress.XtraGrid.Views.Grid.GridView, ByVal strColoumnName As String, ByVal strSearch As Object)
            Dim Col As DevExpress.XtraGrid.Columns.GridColumn = grdView.Columns(strColoumnName)
            Dim Pos As Integer = grdView.LocateByValue(0, Col, strSearch)
            grdView.MoveBy(Pos)
        End Sub

        Public Shared Sub GridFocusedRow(ByVal grdView As DevExpress.XtraGrid.Views.Grid.GridView, ByVal strColoumnName As String, ByVal strSearch As Object)
            Dim Col As DevExpress.XtraGrid.Columns.GridColumn = grdView.Columns(strColoumnName)
            Dim Pos As Integer = grdView.LocateByValue(0, Col, strSearch)
            grdView.FocusedRowHandle = Pos
        End Sub

        Public Shared Sub MakeDirectory(ByVal strKeyFolder As String, ByRef strFolderName As String)
            strFolderName = (".\Result\" & strKeyFolder & strFolderName)
            MkDir(strFolderName)
        End Sub

        Public Shared Sub AppendText_txt(ByVal strFolderName As String, ByVal strFileName As String, ByVal strExt As String, ByVal strText As String)
            Using w As StreamWriter = File.AppendText(strFolderName & "\" & strFileName & strExt)
                w.Write(strText & vbCrLf)
                w.Close()
            End Using
        End Sub

        Public Shared Sub AddToolBarButtons(ByRef tobToolBar As ToolBar, ByVal strButtons As String)
            Dim Buttons() = Split(strButtons, ",")
            Dim Button As ToolBarButton

            For i As Integer = 1 To Buttons.Count - 1 Step 2
                Button = New ToolBarButton
                Button.Style = ToolBarButtonStyle.PushButton
                Button.Text = Buttons.GetValue(i)
                Button.Name = "Bar" & Buttons.GetValue(i)
                tobToolBar.Buttons.Add(Button)
            Next
        End Sub

        Public Shared Sub CreateToolBar(ByVal frmMe As Form, ByVal strIcon As String)
            Dim _ToolBar As New ToolBar
            With _ToolBar
                .Name = "ToolBarHeader"
                AddToolBarButtons(_ToolBar, strIcon)
                .Dock = DockStyle.Top
                .BringToFront()
                .TabIndex = 0
                .Visible = True
                SetToolBar(frmMe, _ToolBar, strIcon)
            End With
            frmMe.Controls.Add(_ToolBar)
        End Sub

    End Class

End Namespace

