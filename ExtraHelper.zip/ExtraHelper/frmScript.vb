﻿Public Class frmScript

    Property pubDBMSName As String = ""
    Property pubFolderName As String = ""
    Property pubGenerate As Boolean = False

    Private Sub prvFillCombo()
        Dim dtCompany As DataTable = BL.Server.CompanyIDForRFC(pubDBMSName.Trim)

        For Each drCompany As DataRow In dtCompany.Rows
            cboCompanyID.Properties.Items.Add(drCompany.Item("CompanyID"))
        Next
    End Sub

    Private Sub prvGenerate()
        If txtScript.Text.Trim = "" Then
            UI.usForm.frmMessageBox("Script not allow blank.")
            txtScript.Focus()
            Exit Sub
        End If

        Dim strKeyFolder As String = ""
        strKeyFolder = Now.Year.ToString & Now.Month.ToString & Now.Day.ToString & Now.Hour.ToString & Now.Minute.ToString & Now.Second.ToString
        Try
            UI.usForm.MakeDirectory(strKeyFolder, pubFolderName)
            'GenerateScript.modGenerateScript.ScriptRFC(txtScript.Text, pubFolderName, pubDBMSName, IIf(cboCompanyID.SelectedItem = "ALL", "", cboCompanyID.SelectedItem))
            pubGenerate = True
            Me.Close()
        Catch ex As Exception
            UI.usForm.frmMessageBox(ex.Message)
        End Try
    End Sub

#Region "Form Handle"
    Private Sub frmScript_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            If UI.usForm.frmAskQuestion("Close this form?") Then Me.Close()
        End If
    End Sub

    Private Sub frmScript_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtScript.Text = ""
        prvFillCombo()
    End Sub

    Private Sub btnGenerate_Click(sender As Object, e As EventArgs) Handles btnGenerate.Click
        prvGenerate()
    End Sub
#End Region

    
End Class