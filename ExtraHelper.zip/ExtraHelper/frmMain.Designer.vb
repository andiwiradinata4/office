﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim SerializableAppearanceObject1 As DevExpress.Utils.SerializableAppearanceObject = New DevExpress.Utils.SerializableAppearanceObject()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.LabelControl1 = New DevExpress.XtraEditors.LabelControl()
        Me.pnlMain = New DevExpress.XtraEditors.PanelControl()
        Me.txtReplaceText = New DevExpress.XtraEditors.TextEdit()
        Me.LabelControl3 = New DevExpress.XtraEditors.LabelControl()
        Me.txtServer = New DevExpress.XtraEditors.TextEdit()
        Me.LabelControl2 = New DevExpress.XtraEditors.LabelControl()
        Me.btnReloadTable = New DevExpress.XtraEditors.SimpleButton()
        Me.cboDBMS = New DevExpress.XtraEditors.ComboBoxEdit()
        Me.btnReloadDBMS = New DevExpress.XtraEditors.SimpleButton()
        Me.gboToolsType = New DevExpress.XtraEditors.GroupControl()
        Me.rdNotShareTools = New System.Windows.Forms.RadioButton()
        Me.rdShareTools = New System.Windows.Forms.RadioButton()
        Me.gboAction = New DevExpress.XtraEditors.GroupControl()
        Me.chkGenerateVO = New DevExpress.XtraEditors.CheckEdit()
        Me.chkGenerateDL = New DevExpress.XtraEditors.CheckEdit()
        Me.chkGenerateBL = New DevExpress.XtraEditors.CheckEdit()
        Me.chkGenerateForm = New DevExpress.XtraEditors.CheckEdit()
        Me.gboFormType = New DevExpress.XtraEditors.GroupControl()
        Me.chkTransStatus = New DevExpress.XtraEditors.CheckEdit()
        Me.rdFormTypeTransaction = New System.Windows.Forms.RadioButton()
        Me.rdFormTypeMaster = New System.Windows.Forms.RadioButton()
        Me.PanelControl2 = New DevExpress.XtraEditors.PanelControl()
        Me.btnGetScript = New DevExpress.XtraEditors.SimpleButton()
        Me.btnSyncTable = New DevExpress.XtraEditors.SimpleButton()
        Me.btnSyncColumn = New DevExpress.XtraEditors.SimpleButton()
        Me.btnGenerate = New DevExpress.XtraEditors.SimpleButton()
        Me.grdMain = New DevExpress.XtraGrid.GridControl()
        Me.grdView = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.tpGenerateFormAndLib = New System.Windows.Forms.TabPage()
        Me.pnlGridF1 = New System.Windows.Forms.Panel()
        Me.ToolBar = New System.Windows.Forms.ToolBar()
        Me.BarCheckAll = New System.Windows.Forms.ToolBarButton()
        Me.BarUncheckAll = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton1 = New System.Windows.Forms.ToolBarButton()
        Me.BarRefreshF1 = New System.Windows.Forms.ToolBarButton()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.gboConnectionType = New DevExpress.XtraEditors.GroupControl()
        Me.rdSelfConnection = New System.Windows.Forms.RadioButton()
        Me.rdSharedConnection = New System.Windows.Forms.RadioButton()
        Me.gbAccessType = New DevExpress.XtraEditors.GroupControl()
        Me.rdProtected = New System.Windows.Forms.RadioButton()
        Me.rdPublic = New System.Windows.Forms.RadioButton()
        Me.tpGenerateRFCFile = New System.Windows.Forms.TabPage()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.txtScript = New System.Windows.Forms.TextBox()
        Me.ToolBarGenerateRFCFileGenerate = New System.Windows.Forms.ToolBar()
        Me.BarGenerate = New System.Windows.Forms.ToolBarButton()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.grdServerList = New DevExpress.XtraGrid.GridControl()
        Me.grdServerListView = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.ToolBarGenerateRFCFile = New System.Windows.Forms.ToolBar()
        Me.BarCheckAllServer = New System.Windows.Forms.ToolBarButton()
        Me.BarUncheckAllServer = New System.Windows.Forms.ToolBarButton()
        Me.BarSep1 = New System.Windows.Forms.ToolBarButton()
        Me.BarRefresh = New System.Windows.Forms.ToolBarButton()
        Me.TabHelper = New System.Windows.Forms.TabControl()
        Me.tpCreateTable = New System.Windows.Forms.TabPage()
        Me.grdMainF3 = New DevExpress.XtraGrid.GridControl()
        Me.grdViewF3 = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.cboGrdDataTypeF3 = New DevExpress.XtraEditors.Repository.RepositoryItemComboBox()
        Me.rpiAutoNumber = New DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit()
        Me.ToolBarCreateTable = New System.Windows.Forms.ToolBar()
        Me.BarGenerateF3 = New System.Windows.Forms.ToolBarButton()
        Me.BarSep1F3 = New System.Windows.Forms.ToolBarButton()
        Me.BarDelete = New System.Windows.Forms.ToolBarButton()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.chkIsPrimaryKey = New DevExpress.XtraEditors.CheckEdit()
        Me.chkViewAllDataTypeF3 = New DevExpress.XtraEditors.CheckEdit()
        Me.chkSetDefaultF3 = New DevExpress.XtraEditors.CheckEdit()
        Me.btnAddColumnF3 = New DevExpress.XtraEditors.SimpleButton()
        Me.txtLength2F3 = New DevExpress.XtraEditors.TextEdit()
        Me.txtLength1F3 = New DevExpress.XtraEditors.TextEdit()
        Me.LabelControl7 = New DevExpress.XtraEditors.LabelControl()
        Me.cboDataTypeF3 = New DevExpress.XtraEditors.ComboBoxEdit()
        Me.LabelControl6 = New DevExpress.XtraEditors.LabelControl()
        Me.txtColumnName = New DevExpress.XtraEditors.TextEdit()
        Me.LabelControl5 = New DevExpress.XtraEditors.LabelControl()
        Me.txtTableName = New DevExpress.XtraEditors.TextEdit()
        Me.LabelControl4 = New DevExpress.XtraEditors.LabelControl()
        Me.tpConvert = New System.Windows.Forms.TabPage()
        Me.tlpConvert = New System.Windows.Forms.TableLayoutPanel()
        Me.txtResultConvert_F4 = New System.Windows.Forms.TextBox()
        Me.txtValueToConvert_F4 = New System.Windows.Forms.TextBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.btnExecuteConvert = New DevExpress.XtraEditors.SimpleButton()
        Me.cboConvertType = New DevExpress.XtraEditors.ComboBoxEdit()
        Me.LabelControl8 = New DevExpress.XtraEditors.LabelControl()
        Me.tpQConvert = New System.Windows.Forms.TabPage()
        Me.txtResult = New System.Windows.Forms.TextBox()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.btnCopy = New System.Windows.Forms.Button()
        Me.btnImportExcel = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnInsert = New System.Windows.Forms.Button()
        Me.btnRemove = New System.Windows.Forms.Button()
        Me.tpExportDataToExcel = New System.Windows.Forms.TabPage()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.rtbQueryF6 = New System.Windows.Forms.RichTextBox()
        Me.grdMainF6 = New DevExpress.XtraGrid.GridControl()
        Me.grdViewMainF6 = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.LabelControl10 = New DevExpress.XtraEditors.LabelControl()
        Me.cboServerTypeF6 = New System.Windows.Forms.ComboBox()
        Me.lblFormatF6 = New DevExpress.XtraEditors.LabelControl()
        Me.cboFormatF6 = New System.Windows.Forms.ComboBox()
        Me.btnReloadCompanyF6 = New DevExpress.XtraEditors.SimpleButton()
        Me.cboCompanyF6 = New System.Windows.Forms.ComboBox()
        Me.btnExportToExcelF6 = New DevExpress.XtraEditors.SimpleButton()
        Me.btnExecuteF6 = New DevExpress.XtraEditors.SimpleButton()
        Me.LabelControl9 = New DevExpress.XtraEditors.LabelControl()
        Me.OpenFileImport = New System.Windows.Forms.OpenFileDialog()
        CType(Me.pnlMain, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlMain.SuspendLayout()
        CType(Me.txtReplaceText.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtServer.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboDBMS.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gboToolsType, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gboToolsType.SuspendLayout()
        CType(Me.gboAction, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gboAction.SuspendLayout()
        CType(Me.chkGenerateVO.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkGenerateDL.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkGenerateBL.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkGenerateForm.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gboFormType, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gboFormType.SuspendLayout()
        CType(Me.chkTransStatus.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PanelControl2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl2.SuspendLayout()
        CType(Me.grdMain, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpGenerateFormAndLib.SuspendLayout()
        Me.pnlGridF1.SuspendLayout()
        Me.Panel5.SuspendLayout()
        CType(Me.gboConnectionType, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gboConnectionType.SuspendLayout()
        CType(Me.gbAccessType, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbAccessType.SuspendLayout()
        Me.tpGenerateRFCFile.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.grdServerList, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdServerListView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabHelper.SuspendLayout()
        Me.tpCreateTable.SuspendLayout()
        CType(Me.grdMainF3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdViewF3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboGrdDataTypeF3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.rpiAutoNumber, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.chkIsPrimaryKey.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkViewAllDataTypeF3.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkSetDefaultF3.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtLength2F3.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtLength1F3.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboDataTypeF3.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtColumnName.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTableName.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpConvert.SuspendLayout()
        Me.tlpConvert.SuspendLayout()
        Me.Panel4.SuspendLayout()
        CType(Me.cboConvertType.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpQConvert.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.tpExportDataToExcel.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.grdMainF6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdViewMainF6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel7.SuspendLayout()
        Me.SuspendLayout()
        '
        'LabelControl1
        '
        Me.LabelControl1.Location = New System.Drawing.Point(367, 18)
        Me.LabelControl1.Name = "LabelControl1"
        Me.LabelControl1.Size = New System.Drawing.Size(27, 13)
        Me.LabelControl1.TabIndex = 1
        Me.LabelControl1.Text = "DBMS"
        '
        'pnlMain
        '
        Me.pnlMain.Controls.Add(Me.txtReplaceText)
        Me.pnlMain.Controls.Add(Me.LabelControl3)
        Me.pnlMain.Controls.Add(Me.txtServer)
        Me.pnlMain.Controls.Add(Me.LabelControl2)
        Me.pnlMain.Controls.Add(Me.btnReloadTable)
        Me.pnlMain.Controls.Add(Me.cboDBMS)
        Me.pnlMain.Controls.Add(Me.btnReloadDBMS)
        Me.pnlMain.Controls.Add(Me.LabelControl1)
        Me.pnlMain.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlMain.Location = New System.Drawing.Point(0, 0)
        Me.pnlMain.Name = "pnlMain"
        Me.pnlMain.Size = New System.Drawing.Size(1104, 57)
        Me.pnlMain.TabIndex = 0
        '
        'txtReplaceText
        '
        Me.txtReplaceText.Location = New System.Drawing.Point(774, 14)
        Me.txtReplaceText.Name = "txtReplaceText"
        Me.txtReplaceText.Size = New System.Drawing.Size(163, 20)
        Me.txtReplaceText.TabIndex = 4
        '
        'LabelControl3
        '
        Me.LabelControl3.Location = New System.Drawing.Point(702, 17)
        Me.LabelControl3.Name = "LabelControl3"
        Me.LabelControl3.Size = New System.Drawing.Size(63, 13)
        Me.LabelControl3.TabIndex = 6
        Me.LabelControl3.Text = "Replace Text"
        '
        'txtServer
        '
        Me.txtServer.Location = New System.Drawing.Point(68, 15)
        Me.txtServer.Name = "txtServer"
        Me.txtServer.Size = New System.Drawing.Size(282, 20)
        Me.txtServer.TabIndex = 0
        '
        'LabelControl2
        '
        Me.LabelControl2.Location = New System.Drawing.Point(28, 18)
        Me.LabelControl2.Name = "LabelControl2"
        Me.LabelControl2.Size = New System.Drawing.Size(32, 13)
        Me.LabelControl2.TabIndex = 3
        Me.LabelControl2.Text = "Server"
        '
        'btnReloadTable
        '
        Me.btnReloadTable.Location = New System.Drawing.Point(601, 13)
        Me.btnReloadTable.Name = "btnReloadTable"
        Me.btnReloadTable.Size = New System.Drawing.Size(85, 23)
        Me.btnReloadTable.TabIndex = 3
        Me.btnReloadTable.Text = "Reload Table"
        '
        'cboDBMS
        '
        Me.cboDBMS.Location = New System.Drawing.Point(404, 15)
        Me.cboDBMS.Name = "cboDBMS"
        Me.cboDBMS.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.cboDBMS.Properties.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.cboDBMS.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor
        Me.cboDBMS.Size = New System.Drawing.Size(100, 20)
        Me.cboDBMS.TabIndex = 1
        '
        'btnReloadDBMS
        '
        Me.btnReloadDBMS.Location = New System.Drawing.Point(510, 13)
        Me.btnReloadDBMS.Name = "btnReloadDBMS"
        Me.btnReloadDBMS.Size = New System.Drawing.Size(85, 23)
        Me.btnReloadDBMS.TabIndex = 2
        Me.btnReloadDBMS.Text = "Reload DBMS"
        '
        'gboToolsType
        '
        Me.gboToolsType.Controls.Add(Me.rdNotShareTools)
        Me.gboToolsType.Controls.Add(Me.rdShareTools)
        Me.gboToolsType.Location = New System.Drawing.Point(286, 13)
        Me.gboToolsType.Name = "gboToolsType"
        Me.gboToolsType.Size = New System.Drawing.Size(156, 52)
        Me.gboToolsType.TabIndex = 1
        Me.gboToolsType.Text = "Tools Type"
        '
        'rdNotShareTools
        '
        Me.rdNotShareTools.AutoSize = True
        Me.rdNotShareTools.Location = New System.Drawing.Point(72, 25)
        Me.rdNotShareTools.Name = "rdNotShareTools"
        Me.rdNotShareTools.Size = New System.Drawing.Size(73, 17)
        Me.rdNotShareTools.TabIndex = 1
        Me.rdNotShareTools.Text = "Not Share"
        Me.rdNotShareTools.UseVisualStyleBackColor = True
        '
        'rdShareTools
        '
        Me.rdShareTools.AutoSize = True
        Me.rdShareTools.Checked = True
        Me.rdShareTools.Location = New System.Drawing.Point(15, 25)
        Me.rdShareTools.Name = "rdShareTools"
        Me.rdShareTools.Size = New System.Drawing.Size(53, 17)
        Me.rdShareTools.TabIndex = 0
        Me.rdShareTools.TabStop = True
        Me.rdShareTools.Text = "Share"
        Me.rdShareTools.UseVisualStyleBackColor = True
        '
        'gboAction
        '
        Me.gboAction.Controls.Add(Me.chkGenerateVO)
        Me.gboAction.Controls.Add(Me.chkGenerateDL)
        Me.gboAction.Controls.Add(Me.chkGenerateBL)
        Me.gboAction.Controls.Add(Me.chkGenerateForm)
        Me.gboAction.Location = New System.Drawing.Point(610, 13)
        Me.gboAction.Name = "gboAction"
        Me.gboAction.Size = New System.Drawing.Size(375, 52)
        Me.gboAction.TabIndex = 3
        Me.gboAction.Text = "Action"
        '
        'chkGenerateVO
        '
        Me.chkGenerateVO.Location = New System.Drawing.Point(283, 25)
        Me.chkGenerateVO.Name = "chkGenerateVO"
        Me.chkGenerateVO.Properties.Caption = "Value Object"
        Me.chkGenerateVO.Size = New System.Drawing.Size(86, 19)
        Me.chkGenerateVO.TabIndex = 4
        '
        'chkGenerateDL
        '
        Me.chkGenerateDL.Location = New System.Drawing.Point(205, 25)
        Me.chkGenerateDL.Name = "chkGenerateDL"
        Me.chkGenerateDL.Properties.Caption = "Data Layer"
        Me.chkGenerateDL.Size = New System.Drawing.Size(86, 19)
        Me.chkGenerateDL.TabIndex = 3
        '
        'chkGenerateBL
        '
        Me.chkGenerateBL.Location = New System.Drawing.Point(105, 25)
        Me.chkGenerateBL.Name = "chkGenerateBL"
        Me.chkGenerateBL.Properties.Caption = "Bussiness Layer"
        Me.chkGenerateBL.Size = New System.Drawing.Size(103, 19)
        Me.chkGenerateBL.TabIndex = 2
        '
        'chkGenerateForm
        '
        Me.chkGenerateForm.Location = New System.Drawing.Point(9, 25)
        Me.chkGenerateForm.Name = "chkGenerateForm"
        Me.chkGenerateForm.Properties.Caption = "Generate Form"
        Me.chkGenerateForm.Size = New System.Drawing.Size(103, 19)
        Me.chkGenerateForm.TabIndex = 0
        '
        'gboFormType
        '
        Me.gboFormType.Controls.Add(Me.chkTransStatus)
        Me.gboFormType.Controls.Add(Me.rdFormTypeTransaction)
        Me.gboFormType.Controls.Add(Me.rdFormTypeMaster)
        Me.gboFormType.Location = New System.Drawing.Point(13, 13)
        Me.gboFormType.Name = "gboFormType"
        Me.gboFormType.Size = New System.Drawing.Size(267, 52)
        Me.gboFormType.TabIndex = 0
        Me.gboFormType.Text = "Form Type"
        '
        'chkTransStatus
        '
        Me.chkTransStatus.Enabled = False
        Me.chkTransStatus.Location = New System.Drawing.Point(185, 24)
        Me.chkTransStatus.Name = "chkTransStatus"
        Me.chkTransStatus.Properties.Caption = "Status"
        Me.chkTransStatus.Size = New System.Drawing.Size(64, 19)
        Me.chkTransStatus.TabIndex = 4
        '
        'rdFormTypeTransaction
        '
        Me.rdFormTypeTransaction.AutoSize = True
        Me.rdFormTypeTransaction.Location = New System.Drawing.Point(85, 25)
        Me.rdFormTypeTransaction.Name = "rdFormTypeTransaction"
        Me.rdFormTypeTransaction.Size = New System.Drawing.Size(81, 17)
        Me.rdFormTypeTransaction.TabIndex = 1
        Me.rdFormTypeTransaction.Text = "Transaction"
        Me.rdFormTypeTransaction.UseVisualStyleBackColor = True
        '
        'rdFormTypeMaster
        '
        Me.rdFormTypeMaster.AutoSize = True
        Me.rdFormTypeMaster.Checked = True
        Me.rdFormTypeMaster.Location = New System.Drawing.Point(12, 25)
        Me.rdFormTypeMaster.Name = "rdFormTypeMaster"
        Me.rdFormTypeMaster.Size = New System.Drawing.Size(58, 17)
        Me.rdFormTypeMaster.TabIndex = 0
        Me.rdFormTypeMaster.TabStop = True
        Me.rdFormTypeMaster.Text = "Master"
        Me.rdFormTypeMaster.UseVisualStyleBackColor = True
        '
        'PanelControl2
        '
        Me.PanelControl2.Controls.Add(Me.btnGetScript)
        Me.PanelControl2.Controls.Add(Me.btnSyncTable)
        Me.PanelControl2.Controls.Add(Me.btnSyncColumn)
        Me.PanelControl2.Controls.Add(Me.btnGenerate)
        Me.PanelControl2.Dock = System.Windows.Forms.DockStyle.Right
        Me.PanelControl2.Location = New System.Drawing.Point(909, 0)
        Me.PanelControl2.Name = "PanelControl2"
        Me.PanelControl2.Size = New System.Drawing.Size(179, 454)
        Me.PanelControl2.TabIndex = 3
        '
        'btnGetScript
        '
        Me.btnGetScript.Location = New System.Drawing.Point(12, 93)
        Me.btnGetScript.Name = "btnGetScript"
        Me.btnGetScript.Size = New System.Drawing.Size(155, 23)
        Me.btnGetScript.TabIndex = 3
        Me.btnGetScript.TabStop = False
        Me.btnGetScript.Text = "Get Script"
        '
        'btnSyncTable
        '
        Me.btnSyncTable.Location = New System.Drawing.Point(12, 64)
        Me.btnSyncTable.Name = "btnSyncTable"
        Me.btnSyncTable.Size = New System.Drawing.Size(155, 23)
        Me.btnSyncTable.TabIndex = 2
        Me.btnSyncTable.TabStop = False
        Me.btnSyncTable.Text = "Sync Table"
        '
        'btnSyncColumn
        '
        Me.btnSyncColumn.Location = New System.Drawing.Point(12, 35)
        Me.btnSyncColumn.Name = "btnSyncColumn"
        Me.btnSyncColumn.Size = New System.Drawing.Size(155, 23)
        Me.btnSyncColumn.TabIndex = 1
        Me.btnSyncColumn.TabStop = False
        Me.btnSyncColumn.Text = "Sync Column"
        '
        'btnGenerate
        '
        Me.btnGenerate.Location = New System.Drawing.Point(12, 6)
        Me.btnGenerate.Name = "btnGenerate"
        Me.btnGenerate.Size = New System.Drawing.Size(155, 23)
        Me.btnGenerate.TabIndex = 0
        Me.btnGenerate.TabStop = False
        Me.btnGenerate.Text = "Generate"
        '
        'grdMain
        '
        Me.grdMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grdMain.Location = New System.Drawing.Point(0, 28)
        Me.grdMain.MainView = Me.grdView
        Me.grdMain.Name = "grdMain"
        Me.grdMain.Size = New System.Drawing.Size(909, 426)
        Me.grdMain.TabIndex = 2
        Me.grdMain.UseEmbeddedNavigator = True
        Me.grdMain.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.grdView})
        '
        'grdView
        '
        Me.grdView.GridControl = Me.grdMain
        Me.grdView.Name = "grdView"
        Me.grdView.OptionsView.ColumnAutoWidth = False
        Me.grdView.OptionsView.ShowAutoFilterRow = True
        Me.grdView.OptionsView.ShowGroupPanel = False
        '
        'tpGenerateFormAndLib
        '
        Me.tpGenerateFormAndLib.AutoScroll = True
        Me.tpGenerateFormAndLib.BackColor = System.Drawing.SystemColors.Control
        Me.tpGenerateFormAndLib.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tpGenerateFormAndLib.Controls.Add(Me.pnlGridF1)
        Me.tpGenerateFormAndLib.Controls.Add(Me.Panel5)
        Me.tpGenerateFormAndLib.Location = New System.Drawing.Point(4, 25)
        Me.tpGenerateFormAndLib.Name = "tpGenerateFormAndLib"
        Me.tpGenerateFormAndLib.Size = New System.Drawing.Size(1096, 606)
        Me.tpGenerateFormAndLib.TabIndex = 0
        Me.tpGenerateFormAndLib.Text = "Generate Form and Lib - F1"
        '
        'pnlGridF1
        '
        Me.pnlGridF1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pnlGridF1.Controls.Add(Me.grdMain)
        Me.pnlGridF1.Controls.Add(Me.ToolBar)
        Me.pnlGridF1.Controls.Add(Me.PanelControl2)
        Me.pnlGridF1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlGridF1.Location = New System.Drawing.Point(0, 144)
        Me.pnlGridF1.Name = "pnlGridF1"
        Me.pnlGridF1.Size = New System.Drawing.Size(1092, 458)
        Me.pnlGridF1.TabIndex = 8
        '
        'ToolBar
        '
        Me.ToolBar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
        Me.ToolBar.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.BarCheckAll, Me.BarUncheckAll, Me.ToolBarButton1, Me.BarRefreshF1})
        Me.ToolBar.DropDownArrows = True
        Me.ToolBar.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolBar.Location = New System.Drawing.Point(0, 0)
        Me.ToolBar.Name = "ToolBar"
        Me.ToolBar.ShowToolTips = True
        Me.ToolBar.Size = New System.Drawing.Size(909, 28)
        Me.ToolBar.TabIndex = 2
        Me.ToolBar.TextAlign = System.Windows.Forms.ToolBarTextAlign.Right
        '
        'BarCheckAll
        '
        Me.BarCheckAll.Name = "BarCheckAll"
        Me.BarCheckAll.Text = "Check All"
        '
        'BarUncheckAll
        '
        Me.BarUncheckAll.Name = "BarUncheckAll"
        Me.BarUncheckAll.Text = "Uncheck All"
        '
        'ToolBarButton1
        '
        Me.ToolBarButton1.Name = "ToolBarButton1"
        Me.ToolBarButton1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'BarRefreshF1
        '
        Me.BarRefreshF1.Name = "BarRefreshF1"
        Me.BarRefreshF1.Text = "Refresh"
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.gboConnectionType)
        Me.Panel5.Controls.Add(Me.gboFormType)
        Me.Panel5.Controls.Add(Me.gbAccessType)
        Me.Panel5.Controls.Add(Me.gboToolsType)
        Me.Panel5.Controls.Add(Me.gboAction)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel5.Location = New System.Drawing.Point(0, 0)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(1092, 144)
        Me.Panel5.TabIndex = 10
        '
        'gboConnectionType
        '
        Me.gboConnectionType.Controls.Add(Me.rdSelfConnection)
        Me.gboConnectionType.Controls.Add(Me.rdSharedConnection)
        Me.gboConnectionType.Location = New System.Drawing.Point(13, 71)
        Me.gboConnectionType.Name = "gboConnectionType"
        Me.gboConnectionType.Size = New System.Drawing.Size(267, 52)
        Me.gboConnectionType.TabIndex = 4
        Me.gboConnectionType.Text = "Connection Type"
        '
        'rdSelfConnection
        '
        Me.rdSelfConnection.AutoSize = True
        Me.rdSelfConnection.Location = New System.Drawing.Point(149, 24)
        Me.rdSelfConnection.Name = "rdSelfConnection"
        Me.rdSelfConnection.Size = New System.Drawing.Size(100, 17)
        Me.rdSelfConnection.TabIndex = 1
        Me.rdSelfConnection.Text = "Self Connection"
        Me.rdSelfConnection.UseVisualStyleBackColor = True
        '
        'rdSharedConnection
        '
        Me.rdSharedConnection.AutoSize = True
        Me.rdSharedConnection.Checked = True
        Me.rdSharedConnection.Location = New System.Drawing.Point(15, 25)
        Me.rdSharedConnection.Name = "rdSharedConnection"
        Me.rdSharedConnection.Size = New System.Drawing.Size(116, 17)
        Me.rdSharedConnection.TabIndex = 0
        Me.rdSharedConnection.TabStop = True
        Me.rdSharedConnection.Text = "Shared Connection"
        Me.rdSharedConnection.UseVisualStyleBackColor = True
        '
        'gbAccessType
        '
        Me.gbAccessType.Controls.Add(Me.rdProtected)
        Me.gbAccessType.Controls.Add(Me.rdPublic)
        Me.gbAccessType.Location = New System.Drawing.Point(448, 13)
        Me.gbAccessType.Name = "gbAccessType"
        Me.gbAccessType.Size = New System.Drawing.Size(156, 52)
        Me.gbAccessType.TabIndex = 2
        Me.gbAccessType.Text = "Access Type"
        '
        'rdProtected
        '
        Me.rdProtected.AutoSize = True
        Me.rdProtected.Location = New System.Drawing.Point(72, 25)
        Me.rdProtected.Name = "rdProtected"
        Me.rdProtected.Size = New System.Drawing.Size(72, 17)
        Me.rdProtected.TabIndex = 1
        Me.rdProtected.Text = "Protected"
        Me.rdProtected.UseVisualStyleBackColor = True
        '
        'rdPublic
        '
        Me.rdPublic.AutoSize = True
        Me.rdPublic.Checked = True
        Me.rdPublic.Location = New System.Drawing.Point(15, 25)
        Me.rdPublic.Name = "rdPublic"
        Me.rdPublic.Size = New System.Drawing.Size(52, 17)
        Me.rdPublic.TabIndex = 0
        Me.rdPublic.TabStop = True
        Me.rdPublic.Text = "Public"
        Me.rdPublic.UseVisualStyleBackColor = True
        '
        'tpGenerateRFCFile
        '
        Me.tpGenerateRFCFile.AutoScroll = True
        Me.tpGenerateRFCFile.BackColor = System.Drawing.SystemColors.Control
        Me.tpGenerateRFCFile.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tpGenerateRFCFile.Controls.Add(Me.Panel2)
        Me.tpGenerateRFCFile.Controls.Add(Me.Panel1)
        Me.tpGenerateRFCFile.Location = New System.Drawing.Point(4, 25)
        Me.tpGenerateRFCFile.Name = "tpGenerateRFCFile"
        Me.tpGenerateRFCFile.Size = New System.Drawing.Size(1096, 606)
        Me.tpGenerateRFCFile.TabIndex = 1
        Me.tpGenerateRFCFile.Text = "Generate RFC File - F2"
        Me.tpGenerateRFCFile.Visible = False
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.txtScript)
        Me.Panel2.Controls.Add(Me.ToolBarGenerateRFCFileGenerate)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(441, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(651, 602)
        Me.Panel2.TabIndex = 10
        '
        'txtScript
        '
        Me.txtScript.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtScript.Location = New System.Drawing.Point(0, 28)
        Me.txtScript.MaxLength = 999999999
        Me.txtScript.Multiline = True
        Me.txtScript.Name = "txtScript"
        Me.txtScript.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtScript.Size = New System.Drawing.Size(647, 570)
        Me.txtScript.TabIndex = 7
        '
        'ToolBarGenerateRFCFileGenerate
        '
        Me.ToolBarGenerateRFCFileGenerate.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
        Me.ToolBarGenerateRFCFileGenerate.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.BarGenerate})
        Me.ToolBarGenerateRFCFileGenerate.DropDownArrows = True
        Me.ToolBarGenerateRFCFileGenerate.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolBarGenerateRFCFileGenerate.Location = New System.Drawing.Point(0, 0)
        Me.ToolBarGenerateRFCFileGenerate.Name = "ToolBarGenerateRFCFileGenerate"
        Me.ToolBarGenerateRFCFileGenerate.ShowToolTips = True
        Me.ToolBarGenerateRFCFileGenerate.Size = New System.Drawing.Size(647, 28)
        Me.ToolBarGenerateRFCFileGenerate.TabIndex = 8
        Me.ToolBarGenerateRFCFileGenerate.TextAlign = System.Windows.Forms.ToolBarTextAlign.Right
        '
        'BarGenerate
        '
        Me.BarGenerate.Name = "BarGenerate"
        Me.BarGenerate.Text = "Generate"
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.grdServerList)
        Me.Panel1.Controls.Add(Me.ToolBarGenerateRFCFile)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(441, 602)
        Me.Panel1.TabIndex = 9
        '
        'grdServerList
        '
        Me.grdServerList.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grdServerList.Location = New System.Drawing.Point(0, 28)
        Me.grdServerList.MainView = Me.grdServerListView
        Me.grdServerList.Name = "grdServerList"
        Me.grdServerList.Size = New System.Drawing.Size(437, 570)
        Me.grdServerList.TabIndex = 6
        Me.grdServerList.UseEmbeddedNavigator = True
        Me.grdServerList.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.grdServerListView})
        '
        'grdServerListView
        '
        Me.grdServerListView.GridControl = Me.grdServerList
        Me.grdServerListView.Name = "grdServerListView"
        Me.grdServerListView.OptionsView.ColumnAutoWidth = False
        Me.grdServerListView.OptionsView.ShowAutoFilterRow = True
        Me.grdServerListView.OptionsView.ShowGroupPanel = False
        '
        'ToolBarGenerateRFCFile
        '
        Me.ToolBarGenerateRFCFile.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
        Me.ToolBarGenerateRFCFile.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.BarCheckAllServer, Me.BarUncheckAllServer, Me.BarSep1, Me.BarRefresh})
        Me.ToolBarGenerateRFCFile.DropDownArrows = True
        Me.ToolBarGenerateRFCFile.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolBarGenerateRFCFile.Location = New System.Drawing.Point(0, 0)
        Me.ToolBarGenerateRFCFile.Name = "ToolBarGenerateRFCFile"
        Me.ToolBarGenerateRFCFile.ShowToolTips = True
        Me.ToolBarGenerateRFCFile.Size = New System.Drawing.Size(437, 28)
        Me.ToolBarGenerateRFCFile.TabIndex = 6
        Me.ToolBarGenerateRFCFile.TextAlign = System.Windows.Forms.ToolBarTextAlign.Right
        '
        'BarCheckAllServer
        '
        Me.BarCheckAllServer.Name = "BarCheckAllServer"
        Me.BarCheckAllServer.Text = "Check All"
        '
        'BarUncheckAllServer
        '
        Me.BarUncheckAllServer.Name = "BarUncheckAllServer"
        Me.BarUncheckAllServer.Text = "Uncheck All"
        '
        'BarSep1
        '
        Me.BarSep1.Name = "BarSep1"
        Me.BarSep1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'BarRefresh
        '
        Me.BarRefresh.Name = "BarRefresh"
        Me.BarRefresh.Text = "Refresh"
        '
        'TabHelper
        '
        Me.TabHelper.Appearance = System.Windows.Forms.TabAppearance.FlatButtons
        Me.TabHelper.Controls.Add(Me.tpGenerateFormAndLib)
        Me.TabHelper.Controls.Add(Me.tpGenerateRFCFile)
        Me.TabHelper.Controls.Add(Me.tpCreateTable)
        Me.TabHelper.Controls.Add(Me.tpConvert)
        Me.TabHelper.Controls.Add(Me.tpQConvert)
        Me.TabHelper.Controls.Add(Me.tpExportDataToExcel)
        Me.TabHelper.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabHelper.Location = New System.Drawing.Point(0, 57)
        Me.TabHelper.Name = "TabHelper"
        Me.TabHelper.SelectedIndex = 0
        Me.TabHelper.Size = New System.Drawing.Size(1104, 635)
        Me.TabHelper.TabIndex = 1
        '
        'tpCreateTable
        '
        Me.tpCreateTable.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tpCreateTable.Controls.Add(Me.grdMainF3)
        Me.tpCreateTable.Controls.Add(Me.ToolBarCreateTable)
        Me.tpCreateTable.Controls.Add(Me.Panel3)
        Me.tpCreateTable.Location = New System.Drawing.Point(4, 25)
        Me.tpCreateTable.Name = "tpCreateTable"
        Me.tpCreateTable.Size = New System.Drawing.Size(1096, 606)
        Me.tpCreateTable.TabIndex = 2
        Me.tpCreateTable.Text = "Create Table - F3"
        Me.tpCreateTable.UseVisualStyleBackColor = True
        '
        'grdMainF3
        '
        Me.grdMainF3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grdMainF3.Location = New System.Drawing.Point(0, 28)
        Me.grdMainF3.MainView = Me.grdViewF3
        Me.grdMainF3.Name = "grdMainF3"
        Me.grdMainF3.RepositoryItems.AddRange(New DevExpress.XtraEditors.Repository.RepositoryItem() {Me.cboGrdDataTypeF3, Me.rpiAutoNumber})
        Me.grdMainF3.Size = New System.Drawing.Size(709, 574)
        Me.grdMainF3.TabIndex = 2
        Me.grdMainF3.UseEmbeddedNavigator = True
        Me.grdMainF3.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.grdViewF3})
        '
        'grdViewF3
        '
        Me.grdViewF3.GridControl = Me.grdMainF3
        Me.grdViewF3.Name = "grdViewF3"
        Me.grdViewF3.OptionsView.ColumnAutoWidth = False
        Me.grdViewF3.OptionsView.ShowAutoFilterRow = True
        Me.grdViewF3.OptionsView.ShowGroupPanel = False
        '
        'cboGrdDataTypeF3
        '
        Me.cboGrdDataTypeF3.AutoHeight = False
        Me.cboGrdDataTypeF3.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.cboGrdDataTypeF3.Name = "cboGrdDataTypeF3"
        '
        'rpiAutoNumber
        '
        Me.rpiAutoNumber.AutoHeight = False
        Me.rpiAutoNumber.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Up, "", -1, True, True, True, DevExpress.XtraEditors.ImageLocation.MiddleCenter, Nothing, New DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), SerializableAppearanceObject1, "", Nothing, Nothing, True), New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Down)})
        Me.rpiAutoNumber.Name = "rpiAutoNumber"
        '
        'ToolBarCreateTable
        '
        Me.ToolBarCreateTable.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
        Me.ToolBarCreateTable.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.BarGenerateF3, Me.BarSep1F3, Me.BarDelete})
        Me.ToolBarCreateTable.DropDownArrows = True
        Me.ToolBarCreateTable.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolBarCreateTable.Location = New System.Drawing.Point(0, 0)
        Me.ToolBarCreateTable.Name = "ToolBarCreateTable"
        Me.ToolBarCreateTable.ShowToolTips = True
        Me.ToolBarCreateTable.Size = New System.Drawing.Size(709, 28)
        Me.ToolBarCreateTable.TabIndex = 1
        Me.ToolBarCreateTable.TextAlign = System.Windows.Forms.ToolBarTextAlign.Right
        '
        'BarGenerateF3
        '
        Me.BarGenerateF3.Name = "BarGenerateF3"
        Me.BarGenerateF3.Text = "Generate"
        '
        'BarSep1F3
        '
        Me.BarSep1F3.Name = "BarSep1F3"
        Me.BarSep1F3.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'BarDelete
        '
        Me.BarDelete.Name = "BarDelete"
        Me.BarDelete.Text = "Delete"
        '
        'Panel3
        '
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel3.Controls.Add(Me.chkIsPrimaryKey)
        Me.Panel3.Controls.Add(Me.chkViewAllDataTypeF3)
        Me.Panel3.Controls.Add(Me.chkSetDefaultF3)
        Me.Panel3.Controls.Add(Me.btnAddColumnF3)
        Me.Panel3.Controls.Add(Me.txtLength2F3)
        Me.Panel3.Controls.Add(Me.txtLength1F3)
        Me.Panel3.Controls.Add(Me.LabelControl7)
        Me.Panel3.Controls.Add(Me.cboDataTypeF3)
        Me.Panel3.Controls.Add(Me.LabelControl6)
        Me.Panel3.Controls.Add(Me.txtColumnName)
        Me.Panel3.Controls.Add(Me.LabelControl5)
        Me.Panel3.Controls.Add(Me.txtTableName)
        Me.Panel3.Controls.Add(Me.LabelControl4)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel3.Location = New System.Drawing.Point(709, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(383, 602)
        Me.Panel3.TabIndex = 0
        '
        'chkIsPrimaryKey
        '
        Me.chkIsPrimaryKey.Location = New System.Drawing.Point(169, 94)
        Me.chkIsPrimaryKey.Name = "chkIsPrimaryKey"
        Me.chkIsPrimaryKey.Properties.Caption = "Primary Key"
        Me.chkIsPrimaryKey.Size = New System.Drawing.Size(82, 19)
        Me.chkIsPrimaryKey.TabIndex = 5
        '
        'chkViewAllDataTypeF3
        '
        Me.chkViewAllDataTypeF3.Location = New System.Drawing.Point(257, 67)
        Me.chkViewAllDataTypeF3.Name = "chkViewAllDataTypeF3"
        Me.chkViewAllDataTypeF3.Properties.Caption = "All Data Type"
        Me.chkViewAllDataTypeF3.Size = New System.Drawing.Size(84, 19)
        Me.chkViewAllDataTypeF3.TabIndex = 6
        '
        'chkSetDefaultF3
        '
        Me.chkSetDefaultF3.Location = New System.Drawing.Point(257, 94)
        Me.chkSetDefaultF3.Name = "chkSetDefaultF3"
        Me.chkSetDefaultF3.Properties.Caption = "Set Default Value"
        Me.chkSetDefaultF3.Size = New System.Drawing.Size(106, 19)
        Me.chkSetDefaultF3.TabIndex = 7
        '
        'btnAddColumnF3
        '
        Me.btnAddColumnF3.Location = New System.Drawing.Point(13, 147)
        Me.btnAddColumnF3.Name = "btnAddColumnF3"
        Me.btnAddColumnF3.Size = New System.Drawing.Size(350, 23)
        Me.btnAddColumnF3.TabIndex = 8
        Me.btnAddColumnF3.Text = "Add Column"
        '
        'txtLength2F3
        '
        Me.txtLength2F3.EditValue = "0"
        Me.txtLength2F3.Location = New System.Drawing.Point(86, 120)
        Me.txtLength2F3.Name = "txtLength2F3"
        Me.txtLength2F3.Properties.DisplayFormat.FormatString = "n0"
        Me.txtLength2F3.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric
        Me.txtLength2F3.Properties.Mask.EditMask = "n0"
        Me.txtLength2F3.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric
        Me.txtLength2F3.Size = New System.Drawing.Size(77, 20)
        Me.txtLength2F3.TabIndex = 4
        '
        'txtLength1F3
        '
        Me.txtLength1F3.EditValue = "0"
        Me.txtLength1F3.Location = New System.Drawing.Point(86, 94)
        Me.txtLength1F3.Name = "txtLength1F3"
        Me.txtLength1F3.Properties.DisplayFormat.FormatString = "n0"
        Me.txtLength1F3.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric
        Me.txtLength1F3.Properties.Mask.EditMask = "n0"
        Me.txtLength1F3.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric
        Me.txtLength1F3.Size = New System.Drawing.Size(77, 20)
        Me.txtLength1F3.TabIndex = 3
        '
        'LabelControl7
        '
        Me.LabelControl7.Location = New System.Drawing.Point(13, 98)
        Me.LabelControl7.Name = "LabelControl7"
        Me.LabelControl7.Size = New System.Drawing.Size(33, 13)
        Me.LabelControl7.TabIndex = 10
        Me.LabelControl7.Text = "Length"
        '
        'cboDataTypeF3
        '
        Me.cboDataTypeF3.Location = New System.Drawing.Point(86, 67)
        Me.cboDataTypeF3.Name = "cboDataTypeF3"
        Me.cboDataTypeF3.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.cboDataTypeF3.Properties.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.cboDataTypeF3.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor
        Me.cboDataTypeF3.Size = New System.Drawing.Size(165, 20)
        Me.cboDataTypeF3.TabIndex = 2
        '
        'LabelControl6
        '
        Me.LabelControl6.Location = New System.Drawing.Point(13, 71)
        Me.LabelControl6.Name = "LabelControl6"
        Me.LabelControl6.Size = New System.Drawing.Size(50, 13)
        Me.LabelControl6.TabIndex = 9
        Me.LabelControl6.Text = "Data Type"
        '
        'txtColumnName
        '
        Me.txtColumnName.Location = New System.Drawing.Point(86, 41)
        Me.txtColumnName.Name = "txtColumnName"
        Me.txtColumnName.Size = New System.Drawing.Size(277, 20)
        Me.txtColumnName.TabIndex = 1
        '
        'LabelControl5
        '
        Me.LabelControl5.Location = New System.Drawing.Point(13, 44)
        Me.LabelControl5.Name = "LabelControl5"
        Me.LabelControl5.Size = New System.Drawing.Size(65, 13)
        Me.LabelControl5.TabIndex = 7
        Me.LabelControl5.Text = "Column Name"
        '
        'txtTableName
        '
        Me.txtTableName.Location = New System.Drawing.Point(86, 15)
        Me.txtTableName.Name = "txtTableName"
        Me.txtTableName.Size = New System.Drawing.Size(277, 20)
        Me.txtTableName.TabIndex = 0
        '
        'LabelControl4
        '
        Me.LabelControl4.Location = New System.Drawing.Point(13, 18)
        Me.LabelControl4.Name = "LabelControl4"
        Me.LabelControl4.Size = New System.Drawing.Size(56, 13)
        Me.LabelControl4.TabIndex = 5
        Me.LabelControl4.Text = "Table Name"
        '
        'tpConvert
        '
        Me.tpConvert.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tpConvert.Controls.Add(Me.tlpConvert)
        Me.tpConvert.Controls.Add(Me.Panel4)
        Me.tpConvert.Location = New System.Drawing.Point(4, 25)
        Me.tpConvert.Name = "tpConvert"
        Me.tpConvert.Padding = New System.Windows.Forms.Padding(3)
        Me.tpConvert.Size = New System.Drawing.Size(1096, 606)
        Me.tpConvert.TabIndex = 3
        Me.tpConvert.Text = "Convert - F4"
        Me.tpConvert.UseVisualStyleBackColor = True
        '
        'tlpConvert
        '
        Me.tlpConvert.ColumnCount = 2
        Me.tlpConvert.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tlpConvert.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tlpConvert.Controls.Add(Me.txtResultConvert_F4, 1, 0)
        Me.tlpConvert.Controls.Add(Me.txtValueToConvert_F4, 0, 0)
        Me.tlpConvert.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpConvert.Location = New System.Drawing.Point(3, 50)
        Me.tlpConvert.Name = "tlpConvert"
        Me.tlpConvert.RowCount = 1
        Me.tlpConvert.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpConvert.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 465.0!))
        Me.tlpConvert.Size = New System.Drawing.Size(1086, 549)
        Me.tlpConvert.TabIndex = 0
        '
        'txtResultConvert_F4
        '
        Me.txtResultConvert_F4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtResultConvert_F4.Location = New System.Drawing.Point(546, 3)
        Me.txtResultConvert_F4.MaxLength = 999999999
        Me.txtResultConvert_F4.Multiline = True
        Me.txtResultConvert_F4.Name = "txtResultConvert_F4"
        Me.txtResultConvert_F4.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtResultConvert_F4.Size = New System.Drawing.Size(537, 543)
        Me.txtResultConvert_F4.TabIndex = 9
        '
        'txtValueToConvert_F4
        '
        Me.txtValueToConvert_F4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtValueToConvert_F4.Location = New System.Drawing.Point(3, 3)
        Me.txtValueToConvert_F4.MaxLength = 999999999
        Me.txtValueToConvert_F4.Multiline = True
        Me.txtValueToConvert_F4.Name = "txtValueToConvert_F4"
        Me.txtValueToConvert_F4.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtValueToConvert_F4.Size = New System.Drawing.Size(537, 543)
        Me.txtValueToConvert_F4.TabIndex = 8
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.btnExecuteConvert)
        Me.Panel4.Controls.Add(Me.cboConvertType)
        Me.Panel4.Controls.Add(Me.LabelControl8)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.Location = New System.Drawing.Point(3, 3)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(1086, 47)
        Me.Panel4.TabIndex = 1
        '
        'btnExecuteConvert
        '
        Me.btnExecuteConvert.Image = CType(resources.GetObject("btnExecuteConvert.Image"), System.Drawing.Image)
        Me.btnExecuteConvert.ImageLocation = DevExpress.XtraEditors.ImageLocation.MiddleRight
        Me.btnExecuteConvert.Location = New System.Drawing.Point(301, 10)
        Me.btnExecuteConvert.Name = "btnExecuteConvert"
        Me.btnExecuteConvert.Size = New System.Drawing.Size(84, 23)
        Me.btnExecuteConvert.TabIndex = 5
        Me.btnExecuteConvert.TabStop = False
        Me.btnExecuteConvert.Text = "Execute"
        '
        'cboConvertType
        '
        Me.cboConvertType.EditValue = "SQL QUERIES TO VB.NET"
        Me.cboConvertType.Location = New System.Drawing.Point(105, 12)
        Me.cboConvertType.Name = "cboConvertType"
        Me.cboConvertType.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.cboConvertType.Properties.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.cboConvertType.Properties.Items.AddRange(New Object() {"SQL QUERIES TO VB.NET", "SQL QUERIES TO C#", "VB.NET TO SQL QUERIES", "C# TO SQL QUERIES"})
        Me.cboConvertType.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor
        Me.cboConvertType.Size = New System.Drawing.Size(178, 20)
        Me.cboConvertType.TabIndex = 1
        '
        'LabelControl8
        '
        Me.LabelControl8.Location = New System.Drawing.Point(19, 15)
        Me.LabelControl8.Name = "LabelControl8"
        Me.LabelControl8.Size = New System.Drawing.Size(66, 13)
        Me.LabelControl8.TabIndex = 0
        Me.LabelControl8.Text = "Convert Type"
        '
        'tpQConvert
        '
        Me.tpQConvert.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tpQConvert.Controls.Add(Me.txtResult)
        Me.tpQConvert.Controls.Add(Me.Panel6)
        Me.tpQConvert.Location = New System.Drawing.Point(4, 25)
        Me.tpQConvert.Name = "tpQConvert"
        Me.tpQConvert.Size = New System.Drawing.Size(1096, 606)
        Me.tpQConvert.TabIndex = 4
        Me.tpQConvert.Text = "QConvert - F5"
        Me.tpQConvert.UseVisualStyleBackColor = True
        '
        'txtResult
        '
        Me.txtResult.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtResult.Location = New System.Drawing.Point(0, 0)
        Me.txtResult.MaxLength = 100000000
        Me.txtResult.Multiline = True
        Me.txtResult.Name = "txtResult"
        Me.txtResult.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtResult.Size = New System.Drawing.Size(973, 602)
        Me.txtResult.TabIndex = 7
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.btnCopy)
        Me.Panel6.Controls.Add(Me.btnImportExcel)
        Me.Panel6.Controls.Add(Me.btnClear)
        Me.Panel6.Controls.Add(Me.btnInsert)
        Me.Panel6.Controls.Add(Me.btnRemove)
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel6.Location = New System.Drawing.Point(973, 0)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(119, 602)
        Me.Panel6.TabIndex = 40
        '
        'btnCopy
        '
        Me.btnCopy.Location = New System.Drawing.Point(13, 12)
        Me.btnCopy.Name = "btnCopy"
        Me.btnCopy.Size = New System.Drawing.Size(93, 25)
        Me.btnCopy.TabIndex = 35
        Me.btnCopy.Text = "Copy"
        Me.btnCopy.UseVisualStyleBackColor = True
        '
        'btnImportExcel
        '
        Me.btnImportExcel.Location = New System.Drawing.Point(14, 244)
        Me.btnImportExcel.Name = "btnImportExcel"
        Me.btnImportExcel.Size = New System.Drawing.Size(93, 25)
        Me.btnImportExcel.TabIndex = 39
        Me.btnImportExcel.Text = "Import .xls"
        Me.btnImportExcel.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(13, 43)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(93, 25)
        Me.btnClear.TabIndex = 36
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnInsert
        '
        Me.btnInsert.Location = New System.Drawing.Point(13, 74)
        Me.btnInsert.Name = "btnInsert"
        Me.btnInsert.Size = New System.Drawing.Size(93, 42)
        Me.btnInsert.TabIndex = 38
        Me.btnInsert.Text = "Insert           (SQL -->VB)"
        Me.btnInsert.UseVisualStyleBackColor = True
        '
        'btnRemove
        '
        Me.btnRemove.Location = New System.Drawing.Point(13, 123)
        Me.btnRemove.Name = "btnRemove"
        Me.btnRemove.Size = New System.Drawing.Size(93, 42)
        Me.btnRemove.TabIndex = 37
        Me.btnRemove.Text = "Remove          (VB --> SQL)"
        Me.btnRemove.UseVisualStyleBackColor = True
        '
        'tpExportDataToExcel
        '
        Me.tpExportDataToExcel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tpExportDataToExcel.Controls.Add(Me.TableLayoutPanel1)
        Me.tpExportDataToExcel.Controls.Add(Me.Panel7)
        Me.tpExportDataToExcel.Location = New System.Drawing.Point(4, 25)
        Me.tpExportDataToExcel.Name = "tpExportDataToExcel"
        Me.tpExportDataToExcel.Size = New System.Drawing.Size(1096, 606)
        Me.tpExportDataToExcel.TabIndex = 5
        Me.tpExportDataToExcel.Text = "Export to Excel - F6"
        Me.tpExportDataToExcel.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.rtbQueryF6, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.grdMainF6, 1, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 50)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1092, 552)
        Me.TableLayoutPanel1.TabIndex = 4
        '
        'rtbQueryF6
        '
        Me.rtbQueryF6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.rtbQueryF6.Location = New System.Drawing.Point(3, 3)
        Me.rtbQueryF6.Name = "rtbQueryF6"
        Me.rtbQueryF6.Size = New System.Drawing.Size(540, 546)
        Me.rtbQueryF6.TabIndex = 0
        Me.rtbQueryF6.Text = ""
        '
        'grdMainF6
        '
        Me.grdMainF6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grdMainF6.Location = New System.Drawing.Point(549, 3)
        Me.grdMainF6.MainView = Me.grdViewMainF6
        Me.grdMainF6.Name = "grdMainF6"
        Me.grdMainF6.Size = New System.Drawing.Size(540, 546)
        Me.grdMainF6.TabIndex = 1
        Me.grdMainF6.UseEmbeddedNavigator = True
        Me.grdMainF6.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.grdViewMainF6})
        '
        'grdViewMainF6
        '
        Me.grdViewMainF6.GridControl = Me.grdMainF6
        Me.grdViewMainF6.Name = "grdViewMainF6"
        Me.grdViewMainF6.OptionsView.ColumnAutoWidth = False
        Me.grdViewMainF6.OptionsView.ShowAutoFilterRow = True
        Me.grdViewMainF6.OptionsView.ShowGroupPanel = False
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.LabelControl10)
        Me.Panel7.Controls.Add(Me.cboServerTypeF6)
        Me.Panel7.Controls.Add(Me.lblFormatF6)
        Me.Panel7.Controls.Add(Me.cboFormatF6)
        Me.Panel7.Controls.Add(Me.btnReloadCompanyF6)
        Me.Panel7.Controls.Add(Me.cboCompanyF6)
        Me.Panel7.Controls.Add(Me.btnExportToExcelF6)
        Me.Panel7.Controls.Add(Me.btnExecuteF6)
        Me.Panel7.Controls.Add(Me.LabelControl9)
        Me.Panel7.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel7.Location = New System.Drawing.Point(0, 0)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(1092, 50)
        Me.Panel7.TabIndex = 0
        '
        'LabelControl10
        '
        Me.LabelControl10.Location = New System.Drawing.Point(498, 17)
        Me.LabelControl10.Name = "LabelControl10"
        Me.LabelControl10.Size = New System.Drawing.Size(59, 13)
        Me.LabelControl10.TabIndex = 11
        Me.LabelControl10.Text = "Server Type"
        '
        'cboServerTypeF6
        '
        Me.cboServerTypeF6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboServerTypeF6.FormattingEnabled = True
        Me.cboServerTypeF6.Items.AddRange(New Object() {"All", "RDC", "Location"})
        Me.cboServerTypeF6.Location = New System.Drawing.Point(575, 13)
        Me.cboServerTypeF6.Name = "cboServerTypeF6"
        Me.cboServerTypeF6.Size = New System.Drawing.Size(79, 21)
        Me.cboServerTypeF6.TabIndex = 2
        '
        'lblFormatF6
        '
        Me.lblFormatF6.Location = New System.Drawing.Point(310, 17)
        Me.lblFormatF6.Name = "lblFormatF6"
        Me.lblFormatF6.Size = New System.Drawing.Size(34, 13)
        Me.lblFormatF6.TabIndex = 9
        Me.lblFormatF6.Text = "Format"
        '
        'cboFormatF6
        '
        Me.cboFormatF6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFormatF6.FormattingEnabled = True
        Me.cboFormatF6.Items.AddRange(New Object() {"xls", "xlsx"})
        Me.cboFormatF6.Location = New System.Drawing.Point(361, 13)
        Me.cboFormatF6.Name = "cboFormatF6"
        Me.cboFormatF6.Size = New System.Drawing.Size(79, 21)
        Me.cboFormatF6.TabIndex = 1
        '
        'btnReloadCompanyF6
        '
        Me.btnReloadCompanyF6.Location = New System.Drawing.Point(979, 13)
        Me.btnReloadCompanyF6.Name = "btnReloadCompanyF6"
        Me.btnReloadCompanyF6.Size = New System.Drawing.Size(98, 23)
        Me.btnReloadCompanyF6.TabIndex = 5
        Me.btnReloadCompanyF6.Text = "Reload Company"
        '
        'cboCompanyF6
        '
        Me.cboCompanyF6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCompanyF6.FormattingEnabled = True
        Me.cboCompanyF6.Location = New System.Drawing.Point(86, 13)
        Me.cboCompanyF6.Name = "cboCompanyF6"
        Me.cboCompanyF6.Size = New System.Drawing.Size(182, 21)
        Me.cboCompanyF6.TabIndex = 0
        '
        'btnExportToExcelF6
        '
        Me.btnExportToExcelF6.Location = New System.Drawing.Point(879, 13)
        Me.btnExportToExcelF6.Name = "btnExportToExcelF6"
        Me.btnExportToExcelF6.Size = New System.Drawing.Size(94, 23)
        Me.btnExportToExcelF6.TabIndex = 4
        Me.btnExportToExcelF6.Text = "Export To Excel"
        '
        'btnExecuteF6
        '
        Me.btnExecuteF6.Location = New System.Drawing.Point(788, 13)
        Me.btnExecuteF6.Name = "btnExecuteF6"
        Me.btnExecuteF6.Size = New System.Drawing.Size(85, 23)
        Me.btnExecuteF6.TabIndex = 3
        Me.btnExecuteF6.Text = "Execute"
        '
        'LabelControl9
        '
        Me.LabelControl9.Location = New System.Drawing.Point(22, 17)
        Me.LabelControl9.Name = "LabelControl9"
        Me.LabelControl9.Size = New System.Drawing.Size(45, 13)
        Me.LabelControl9.TabIndex = 7
        Me.LabelControl9.Text = "Company"
        '
        'OpenFileImport
        '
        Me.OpenFileImport.FileName = "OpenFileDialog1"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1104, 692)
        Me.Controls.Add(Me.TabHelper)
        Me.Controls.Add(Me.pnlMain)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Extra Helper"
        CType(Me.pnlMain, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlMain.ResumeLayout(False)
        Me.pnlMain.PerformLayout()
        CType(Me.txtReplaceText.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtServer.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboDBMS.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gboToolsType, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gboToolsType.ResumeLayout(False)
        Me.gboToolsType.PerformLayout()
        CType(Me.gboAction, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gboAction.ResumeLayout(False)
        CType(Me.chkGenerateVO.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkGenerateDL.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkGenerateBL.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkGenerateForm.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gboFormType, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gboFormType.ResumeLayout(False)
        Me.gboFormType.PerformLayout()
        CType(Me.chkTransStatus.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PanelControl2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl2.ResumeLayout(False)
        CType(Me.grdMain, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpGenerateFormAndLib.ResumeLayout(False)
        Me.pnlGridF1.ResumeLayout(False)
        Me.pnlGridF1.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        CType(Me.gboConnectionType, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gboConnectionType.ResumeLayout(False)
        Me.gboConnectionType.PerformLayout()
        CType(Me.gbAccessType, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbAccessType.ResumeLayout(False)
        Me.gbAccessType.PerformLayout()
        Me.tpGenerateRFCFile.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.grdServerList, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdServerListView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabHelper.ResumeLayout(False)
        Me.tpCreateTable.ResumeLayout(False)
        Me.tpCreateTable.PerformLayout()
        CType(Me.grdMainF3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdViewF3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboGrdDataTypeF3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.rpiAutoNumber, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.chkIsPrimaryKey.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkViewAllDataTypeF3.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkSetDefaultF3.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtLength2F3.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtLength1F3.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboDataTypeF3.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtColumnName.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTableName.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpConvert.ResumeLayout(False)
        Me.tlpConvert.ResumeLayout(False)
        Me.tlpConvert.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        CType(Me.cboConvertType.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpQConvert.ResumeLayout(False)
        Me.tpQConvert.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.tpExportDataToExcel.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        CType(Me.grdMainF6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdViewMainF6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents LabelControl1 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents pnlMain As DevExpress.XtraEditors.PanelControl
    Friend WithEvents cboDBMS As DevExpress.XtraEditors.ComboBoxEdit
    Friend WithEvents btnReloadDBMS As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents PanelControl2 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents btnGenerate As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents grdMain As DevExpress.XtraGrid.GridControl
    Friend WithEvents grdView As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents btnReloadTable As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents txtServer As DevExpress.XtraEditors.TextEdit
    Friend WithEvents LabelControl2 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents gboFormType As DevExpress.XtraEditors.GroupControl
    Friend WithEvents rdFormTypeTransaction As System.Windows.Forms.RadioButton
    Friend WithEvents rdFormTypeMaster As System.Windows.Forms.RadioButton
    Friend WithEvents txtReplaceText As DevExpress.XtraEditors.TextEdit
    Friend WithEvents LabelControl3 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents gboAction As DevExpress.XtraEditors.GroupControl
    Friend WithEvents chkGenerateVO As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents chkGenerateDL As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents chkGenerateBL As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents chkGenerateForm As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents btnSyncColumn As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnSyncTable As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents gboToolsType As DevExpress.XtraEditors.GroupControl
    Friend WithEvents rdNotShareTools As System.Windows.Forms.RadioButton
    Friend WithEvents rdShareTools As System.Windows.Forms.RadioButton
    Friend WithEvents btnGetScript As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents tpGenerateFormAndLib As System.Windows.Forms.TabPage
    Friend WithEvents pnlGridF1 As System.Windows.Forms.Panel
    Friend WithEvents ToolBar As System.Windows.Forms.ToolBar
    Friend WithEvents BarCheckAll As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarUncheckAll As System.Windows.Forms.ToolBarButton
    Friend WithEvents tpGenerateRFCFile As System.Windows.Forms.TabPage
    Friend WithEvents TabHelper As System.Windows.Forms.TabControl
    Friend WithEvents grdServerList As DevExpress.XtraGrid.GridControl
    Friend WithEvents grdServerListView As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents txtScript As System.Windows.Forms.TextBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents ToolBarGenerateRFCFileGenerate As System.Windows.Forms.ToolBar
    Friend WithEvents BarGenerate As System.Windows.Forms.ToolBarButton
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents ToolBarGenerateRFCFile As System.Windows.Forms.ToolBar
    Friend WithEvents BarSep1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarRefresh As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarCheckAllServer As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarUncheckAllServer As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarSep1F1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarRefreshF1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents tpCreateTable As System.Windows.Forms.TabPage
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents txtLength2F3 As DevExpress.XtraEditors.TextEdit
    Friend WithEvents txtLength1F3 As DevExpress.XtraEditors.TextEdit
    Friend WithEvents LabelControl7 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents cboDataTypeF3 As DevExpress.XtraEditors.ComboBoxEdit
    Friend WithEvents LabelControl6 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents txtColumnName As DevExpress.XtraEditors.TextEdit
    Friend WithEvents LabelControl5 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents txtTableName As DevExpress.XtraEditors.TextEdit
    Friend WithEvents LabelControl4 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents btnAddColumnF3 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents ToolBarCreateTable As System.Windows.Forms.ToolBar
    Friend WithEvents BarDelete As System.Windows.Forms.ToolBarButton
    Friend WithEvents grdMainF3 As DevExpress.XtraGrid.GridControl
    Friend WithEvents grdViewF3 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents BarGenerateF3 As System.Windows.Forms.ToolBarButton
    Friend WithEvents BarSep1F3 As System.Windows.Forms.ToolBarButton
    Friend WithEvents chkSetDefaultF3 As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents chkViewAllDataTypeF3 As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents chkIsPrimaryKey As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents cboGrdDataTypeF3 As DevExpress.XtraEditors.Repository.RepositoryItemComboBox
    Friend WithEvents rpiAutoNumber As DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit
    Friend WithEvents tpConvert As System.Windows.Forms.TabPage
    Friend WithEvents tlpConvert As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents txtResultConvert_F4 As System.Windows.Forms.TextBox
    Friend WithEvents txtValueToConvert_F4 As System.Windows.Forms.TextBox
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents btnExecuteConvert As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents cboConvertType As DevExpress.XtraEditors.ComboBoxEdit
    Friend WithEvents LabelControl8 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents tpQConvert As System.Windows.Forms.TabPage
    Friend WithEvents btnImportExcel As System.Windows.Forms.Button
    Friend WithEvents btnInsert As System.Windows.Forms.Button
    Friend WithEvents btnRemove As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnCopy As System.Windows.Forms.Button
    Friend WithEvents txtResult As System.Windows.Forms.TextBox
    Friend WithEvents OpenFileImport As System.Windows.Forms.OpenFileDialog
    Friend WithEvents gbAccessType As DevExpress.XtraEditors.GroupControl
    Friend WithEvents rdProtected As System.Windows.Forms.RadioButton
    Friend WithEvents rdPublic As System.Windows.Forms.RadioButton
    Friend WithEvents chkTransStatus As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents tpExportDataToExcel As System.Windows.Forms.TabPage
    Friend WithEvents grdMainF6 As DevExpress.XtraGrid.GridControl
    Friend WithEvents grdViewMainF6 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents rtbQueryF6 As System.Windows.Forms.RichTextBox
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents btnExportToExcelF6 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnExecuteF6 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents LabelControl9 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents cboCompanyF6 As System.Windows.Forms.ComboBox
    Friend WithEvents btnReloadCompanyF6 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents lblFormatF6 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents cboFormatF6 As System.Windows.Forms.ComboBox
    Friend WithEvents LabelControl10 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents cboServerTypeF6 As System.Windows.Forms.ComboBox
    Friend WithEvents gboConnectionType As DevExpress.XtraEditors.GroupControl
    Friend WithEvents rdSelfConnection As RadioButton
    Friend WithEvents rdSharedConnection As RadioButton
End Class
