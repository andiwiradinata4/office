﻿Namespace DL
    Public Class DatabaseList
        Public Shared Function ListData() As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "SELECT name FROM sys.DATABASES " & vbNewLine & _
                    "WHERE " & vbNewLine & _
                    "	owner_sid<>0x01 " & vbNewLine & _
                    "	AND name NOT IN ('ReportServer$SQLSERVER','ReportServer$SQLSERVERTempDB','HRdb_MB_Des2014','123test') " & vbNewLine & _
                    "	AND RIGHT(name,6)<>'_Audit'" & vbNewLine & _
                    "ORDER BY " & vbNewLine & _
                    "   name ASC " & vbNewLine

            End With
            Return SQL.QueryDataTable(sqlcmdExecute)
        End Function
    End Class
End Namespace

