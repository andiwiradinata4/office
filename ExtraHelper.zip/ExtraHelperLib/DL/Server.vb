﻿Namespace DL
    Public Class Server
        Public Shared Function ServerListForRFC(ByVal strDBMS As String) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "SELECT " & vbNewLine & _
                    "   CAST(0 AS BIT) AS Pick, AutoNo, ServerName=Server " & vbNewLine & _
                    "--FROM My_sysAllServers " & vbNewLine & _
                    "FROM SWHelper " & vbNewLine & _
                    "WHERE " & vbNewLine & _
                    "   IsNeedRFC=1 " & vbNewLine & _
                    "   AND DBMS=@DBMS " & vbNewLine & _
                    "GROUP BY AutoNo, Server " & vbNewLine & _
                    "ORDER BY AutoNo ASC " & vbNewLine

                .Parameters.Add("@DBMS", SqlDbType.VarChar, 50).Value = strDBMS.Trim
            End With
            Return SQL.QueryDataTable(sqlcmdExecute)
        End Function

        Public Shared Function CompanyIDForRFC() As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "SELECT " & vbNewLine & _
                    "   CompanyID " & vbNewLine & _
                    "FROM My_sysAllServers " & vbNewLine & _
                    "WHERE " & vbNewLine & _
                    "   IsNeedRFC=1 " & vbNewLine & _
                    "   AND CompanyID<>'' " & vbNewLine & _
                    "GROUP BY CompanyID " & vbNewLine
            End With
            Return SQL.QueryDataTable(sqlcmdExecute)
        End Function

        Public Shared Function ServerList(Optional ByVal strCompanyID As String = "") As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "SELECT DISTINCT " & vbNewLine & _
                    "   Number, ServerName=Server " & vbNewLine & _
                    "FROM My_sysAllServers " & vbNewLine & _
                    "WHERE " & vbNewLine & _
                    "   IsNeedRFC=1 " & vbNewLine

                If strCompanyID.Trim <> "" Then
                    .CommandText += _
                        "   AND CompanyID=@CompanyID " & vbNewLine
                End If

                .CommandText += _
                    "ORDER BY Number ASC " & vbNewLine

                .Parameters.Add("@CompanyID", SqlDbType.VarChar, 20).Value = strCompanyID.Trim

            End With
            Return SQL.QueryDataTable(sqlcmdExecute)
        End Function
    End Class

End Namespace
