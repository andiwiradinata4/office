﻿Namespace DL
    Public Class ColumnList
        Public Shared Function ListData(ByVal strTableName As String) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "SELECT " & vbNewLine & _
                    "   c.name 'ColumnName'," & vbNewLine & _
                    "   t.Name 'DataType', " & vbNewLine & _
                    "   c.max_length 'MaxLength', " & vbNewLine & _
                    "   c.precision, " & vbNewLine & _
                    "   c.scale, " & vbNewLine & _
                    "   c.is_nullable, " & vbNewLine & _
                    "   ISNULL(i.is_primary_key, 0) 'PrimaryKey', " & vbNewLine & _
                    "   c.is_identity " & vbNewLine & _
                    "FROM sys.columns c " & vbNewLine & _
                    "INNER JOIN sys.types t ON c.user_type_id = t.user_type_id " & vbNewLine & _
                    "LEFT OUTER JOIN sys.index_columns ic ON ic.object_id = c.object_id AND ic.column_id = c.column_id " & vbNewLine & _
                    "LEFT OUTER JOIN sys.indexes i ON ic.object_id = i.object_id AND ic.index_id = i.index_id " & vbNewLine & _
                    "WHERE c.object_id = OBJECT_ID('" & strTableName & "') " & vbNewLine
            End With
            Return SQL.QueryDataTable(sqlcmdExecute)
        End Function

        Public Shared Function ListDataPK(ByVal strTableName As String) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                        "SELECT " & vbNewLine & _
                        "   c.name 'ColumnName'," & vbNewLine & _
                        "   t.Name 'DataType', " & vbNewLine & _
                        "   c.max_length 'MaxLength', " & vbNewLine & _
                        "   c.precision, " & vbNewLine & _
                        "   c.scale, " & vbNewLine & _
                        "   c.is_nullable, " & vbNewLine & _
                        "   ISNULL(i.is_primary_key, 0) 'PrimaryKey', " & vbNewLine & _
                        "   c.is_identity " & vbNewLine & _
                        "FROM sys.columns c " & vbNewLine & _
                        "INNER JOIN sys.types t ON c.user_type_id = t.user_type_id " & vbNewLine & _
                        "LEFT OUTER JOIN sys.index_columns ic ON ic.object_id = c.object_id AND ic.column_id = c.column_id " & vbNewLine & _
                        "LEFT OUTER JOIN sys.indexes i ON ic.object_id = i.object_id AND ic.index_id = i.index_id " & vbNewLine & _
                        "WHERE i.is_primary_key=1 and c.object_id = OBJECT_ID('" & strTableName & "') " & vbNewLine
            End With

            Return DL.SQL.QueryDataTable(sqlcmdExecute)
        End Function

        Public Shared Function ListDataTop1PK(ByVal strTableName As String) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                        "SELECT TOP 1 " & vbNewLine & _
                        "   c.name 'ColumnName'," & vbNewLine & _
                        "   t.Name 'DataType', " & vbNewLine & _
                        "   c.max_length 'MaxLength', " & vbNewLine & _
                        "   c.precision, " & vbNewLine & _
                        "   c.scale, " & vbNewLine & _
                        "   c.is_nullable, " & vbNewLine & _
                        "   ISNULL(i.is_primary_key, 0) 'PrimaryKey', " & vbNewLine & _
                        "   c.is_identity " & vbNewLine & _
                        "FROM sys.columns c " & vbNewLine & _
                        "INNER JOIN sys.types t ON c.user_type_id = t.user_type_id " & vbNewLine & _
                        "LEFT OUTER JOIN sys.index_columns ic ON ic.object_id = c.object_id AND ic.column_id = c.column_id " & vbNewLine & _
                        "LEFT OUTER JOIN sys.indexes i ON ic.object_id = i.object_id AND ic.index_id = i.index_id " & vbNewLine & _
                        "WHERE i.is_primary_key=1 and c.object_id = OBJECT_ID('" & strTableName & "') " & vbNewLine
            End With

            Return DL.SQL.QueryDataTable(sqlcmdExecute)
        End Function

        Public Shared Function GetTop1PK(ByVal strTableName As String) As String
            Dim sqlcmdExecute As New SqlCommand
            Dim sqlrdData As SqlDataReader
            Dim strValue As String = ""
            Try
                If Not SQL.bolUseTrans Then SQL.OpenConnection()
                With sqlcmdExecute
                    .Connection = SQL.sqlConn
                    .CommandText = _
                        "SELECT TOP 1 " & vbNewLine & _
                        "   c.name 'ColumnName'," & vbNewLine & _
                        "   t.Name 'DataType', " & vbNewLine & _
                        "   c.max_length 'MaxLength', " & vbNewLine & _
                        "   c.precision, " & vbNewLine & _
                        "   c.scale, " & vbNewLine & _
                        "   c.is_nullable, " & vbNewLine & _
                        "   ISNULL(i.is_primary_key, 0) 'PrimaryKey', " & vbNewLine & _
                        "   c.is_identity " & vbNewLine & _
                        "FROM sys.columns c " & vbNewLine & _
                        "INNER JOIN sys.types t ON c.user_type_id = t.user_type_id " & vbNewLine & _
                        "LEFT OUTER JOIN sys.index_columns ic ON ic.object_id = c.object_id AND ic.column_id = c.column_id " & vbNewLine & _
                        "LEFT OUTER JOIN sys.indexes i ON ic.object_id = i.object_id AND ic.index_id = i.index_id " & vbNewLine & _
                        "WHERE i.is_primary_key=1 and c.object_id = OBJECT_ID('" & strTableName & "') " & vbNewLine

                    If SQL.bolUseTrans Then .Transaction = SQL.sqlTrans
                End With
                sqlrdData = sqlcmdExecute.ExecuteReader(CommandBehavior.SingleRow)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        strValue = .Item("ColumnName")
                    End If
                    .Close()
                End With
                If Not SQL.bolUseTrans Then SQL.CloseConnection()
            Catch ex As Exception
                Throw ex
            End Try
            Return strValue
        End Function

        Public Shared Function ListDataDesc(ByVal strTableName As String) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "SELECT TOP 1 " & vbNewLine & _
                    "   c.name 'ColumnName'," & vbNewLine & _
                    "   t.Name 'DataType', " & vbNewLine & _
                    "   c.max_length 'MaxLength', " & vbNewLine & _
                    "   c.precision, " & vbNewLine & _
                    "   c.scale, " & vbNewLine & _
                    "   c.is_nullable, " & vbNewLine & _
                    "   ISNULL(i.is_primary_key, 0) 'PrimaryKey', " & vbNewLine & _
                    "   c.is_identity " & vbNewLine & _
                    "FROM sys.columns c " & vbNewLine & _
                    "INNER JOIN sys.types t ON c.user_type_id = t.user_type_id " & vbNewLine & _
                    "LEFT OUTER JOIN sys.index_columns ic ON ic.object_id = c.object_id AND ic.column_id = c.column_id " & vbNewLine & _
                    "LEFT OUTER JOIN sys.indexes i ON ic.object_id = i.object_id AND ic.index_id = i.index_id " & vbNewLine & _
                    "WHERE ISNULL(i.is_primary_key, 0)=0 and c.object_id = OBJECT_ID('" & strTableName & "') " & vbNewLine
            End With
            Return SQL.QueryDataTable(sqlcmdExecute)
        End Function

        Public Shared Function ListDataScript() As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "SELECT " & vbNewLine & _
                    "	so.name, sm.definition, CASE so.type WHEN 'V' THEN 'VIEW' WHEN 'P' THEN 'PROCEDURE' ELSE 'FUNCTION' END AS types " & vbNewLine & _
                    "FROM SYS.sql_modules sm " & vbNewLine & _
                    "INNER JOIN sys.objects so ON " & vbNewLine & _
                    "	sm.object_id=so.object_id " & vbNewLine & _
                    "WHERE " & vbNewLine & _
                    "   so.type<>'TR' "
            End With
            Return SQL.QueryDataTable(sqlcmdExecute)
        End Function
        
    End Class
End Namespace

