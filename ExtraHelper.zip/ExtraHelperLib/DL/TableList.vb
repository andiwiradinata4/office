﻿Namespace DL
    Public Class TableList
        Public Shared Function ListData() As DataTable
            Using sqlcmdExecute As New SqlCommand
                sqlcmdExecute.CommandText = _
                    "SELECT Pick=CAST(0 AS BIT), IsHeader=CAST(0 AS BIT), name as TableName " & vbNewLine & _
                    "FROM sys.tables " & vbNewLine & _
                    "WHERE name NOT IN ('ExclObject','sysdiagrams') " & vbNewLine & _
                    "ORDER BY name " & vbNewLine
                Return SQL.QueryDataTable(sqlcmdExecute)
            End Using

        End Function

        Public Shared Function ExecuteScriptF6(ByVal strScripts As String) As DataTable
            Using sqlcmdExecute As New SqlCommand
                sqlcmdExecute.CommandText = strScripts
                Return SQL.QueryDataTable(sqlcmdExecute)
            End Using
        End Function
    End Class
End Namespace
