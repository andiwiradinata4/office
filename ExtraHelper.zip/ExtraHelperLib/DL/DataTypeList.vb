﻿Namespace DL
    Public Class DataTypeList
        Public Shared Function ListData(ByVal bolViewAll As Boolean) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "SELECT " & vbNewLine & _
                    "	name " & vbNewLine & _
                    "FROM SYS.TYPES " & vbNewLine & _
                    "WHERE " & vbNewLine & _
                    "	1=1 " & vbNewLine

                If Not bolViewAll Then
                    .CommandText += _
                    "	AND name NOT IN " & vbNewLine & _
                    "	(" & vbNewLine & _
                    "		'binary','datetime2','datetimeoffset','float','geography','geometry','hierarchyid','image','ItemTable','nchar','ntext'," & vbNewLine & _
                    "		'real','sql_variant','sysname','time','timestamp','varbinary','xml'" & vbNewLine & _
                    "	)" & vbNewLine
                End If
                
            End With
            Return SQL.QueryDataTable(sqlcmdExecute)
        End Function
    End Class
End Namespace

