﻿Public Class usEmail


    Public Shared Function SendEmail(strSMTPHost As String, intSMTPPort As Integer, strSenderEmail As String, ByVal strEmailAddress As String,
                                     ByVal strSubject As String, ByVal strMessage As String, Optional ByVal bolAttachment As Boolean = False,
                                     Optional ByVal strFilePath As String = "", Optional ByVal strCopyCarbonAddress As String = "",
                                     Optional ByVal strBlindCopyCarbonAddress As String = "", Optional ByVal bolHtml As Boolean = False) As Boolean
        Dim Success As Boolean = False

        Dim EMail As New System.Net.Mail.MailMessage
        Dim SMTPServer As New System.Net.Mail.SmtpClient
        Dim Authentication As New Net.NetworkCredential("login name/email", "password")

        If bolAttachment = True Then
            Dim Attachment As New System.Net.Mail.Attachment(strFilePath)
            EMail.Attachments.Add(Attachment)
        End If

        EMail.To.Add(strEmailAddress)
        If strCopyCarbonAddress.Trim <> "" Then
            EMail.CC.Add(strCopyCarbonAddress)
        End If
        If strBlindCopyCarbonAddress.Trim <> "" Then
            EMail.Bcc.Add(strBlindCopyCarbonAddress)
        End If
        EMail.From = New System.Net.Mail.MailAddress(strSenderEmail)
        EMail.Body = strMessage
        EMail.Subject = strSubject


        SMTPServer.Host = strSMTPHost
        SMTPServer.Port = intSMTPPort
        SMTPServer.Credentials = Authentication

        EMail.IsBodyHtml = bolHtml

        SMTPServer.Send(EMail)

        If bolAttachment = True Then
            EMail.Attachments.Dispose()
        End If

        Return Success
    End Function

End Class
