﻿Public Class Converter

    Enum ConvertType
        SQLQueriesToVB_NET
        SQLQueriesToCSharp
        VB_NETToSQLQueries
        CSharpToSQLQueries
    End Enum

    Public Shared Function ConvertTo(convertType As ConvertType, strValue As String) As String
        Dim strReturn As String = ""
        Dim strSplit() = strValue.Split(vbCrLf)
        Dim strArray As ArrayList = New ArrayList()

        For i As Integer = 0 To strSplit.Length - 1
            strSplit(i) = strSplit(i).Replace(vbCrLf, "")
            strSplit(i) = strSplit(i).Replace(vbLf, "")
            strSplit(i) = strSplit(i).Replace("& vbNewLine & _", "")
            strSplit(i) = strSplit(i).Replace(" & VbNewLine & _", "")
            strSplit(i) = strSplit(i).Replace("& vbNewLine", "")
            strSplit(i) = strSplit(i).Replace("& vbNewLine ", "")
            strSplit(i) = strSplit(i).Replace("+ Environment.NewLine +", "")
            strSplit(i) = strSplit(i).Replace("+ Environment.NewLine", "")
            strSplit(i) = strSplit(i).Replace("+ Environment.NewLine ", "")
            strSplit(i) = strSplit(i).Replace("""", "")
        Next

        If convertType = Converter.ConvertType.SQLQueriesToVB_NET Then
            For Each value In strSplit
                strReturn += """" & value & """ & vbNewLine & _" & vbNewLine
            Next
            strReturn = strReturn.Trim
            strReturn = strReturn.Substring(0, strReturn.Length - 4)
        ElseIf convertType = Converter.ConvertType.SQLQueriesToCSharp Then
            For Each value In strSplit
                strReturn += """" & value & """ + Environment.NewLine +" & vbNewLine
            Next
            strReturn = strReturn.Trim
            strReturn = strReturn.Substring(0, strReturn.Length - 1)
            strReturn = strReturn & ";"
        ElseIf convertType = Converter.ConvertType.VB_NETToSQLQueries Or convertType = Converter.ConvertType.CSharpToSQLQueries Then
            For Each value In strSplit
                strReturn += value & vbNewLine
            Next
        End If

        Return strReturn
    End Function

End Class
