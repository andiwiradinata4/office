﻿Namespace VO

    Public Class CS

        Private intComLocDivSubDivID As Integer
        Private strProgramID, strProgramName, strCompanyID, strLocationID As String
        Private strCompanyName, strLocationName, strDivisionName, strSubDivisionName As String

        Public Property ComLocDivSubDivID() As Integer
            Get
                Return intComLocDivSubDivID
            End Get
            Set(value As Integer)
                intComLocDivSubDivID = value
            End Set
        End Property

        Public Property ProgramID() As String
            Get
                Return strProgramID
            End Get
            Set(value As String)
                strProgramID = value
            End Set
        End Property

        Public Property ProgramName() As String
            Get
                Return strProgramName
            End Get
            Set(value As String)
                strProgramName = value
            End Set
        End Property

        Public Property CompanyID() As String
            Get
                Return strCompanyID
            End Get
            Set(value As String)
                strCompanyID = value
            End Set
        End Property

        Public Property CompanyName() As String
            Get
                Return strCompanyName
            End Get
            Set(value As String)
                strCompanyName = value
            End Set
        End Property

        Public Property LocationID() As String
            Get
                Return strLocationID
            End Get
            Set(value As String)
                strLocationID = value
            End Set
        End Property

        Public Property LocationName() As String
            Get
                Return strLocationName
            End Get
            Set(value As String)
                strLocationName = value
            End Set
        End Property

        Public Property DivisionName() As String
            Get
                Return strDivisionName
            End Get
            Set(value As String)
                strDivisionName = value
            End Set
        End Property

        Public Property SubDivisionName() As String
            Get
                Return strSubDivisionName
            End Get
            Set(value As String)
                strSubDivisionName = value
            End Set
        End Property

    End Class

End Namespace
