﻿Namespace VO
    Public Class TableList
        Public Shared TableList As DataTable
    End Class
End Namespace

