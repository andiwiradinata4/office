﻿Namespace VO

    Public Class UserSelection

        Property Server As String
        Property Database As String
        Property TextToReplace As String
        Property FormType As eFormType
        Property IsIncludeStatus As Boolean
        Property ToolType As eToolType
        Property AccessType As eAccessType
        Property IsGenerateForm As Boolean
        Property IsGenerateBL As Boolean
        Property IsGenerateDL As Boolean
        Property IsGenerateVO As Boolean
        Property ConnectionType As eConnectionType

        Enum eFormType
            MasterForm = 0
            TransactionForm = 1
        End Enum

        Enum eToolType
            Share = 0
            NotShare = 1
        End Enum

        Enum eAccessType
            PublicAccessType = 0
            ProtectedAccessType = 1
        End Enum

        Enum eConnectionType
            SharedConnection
            SelfConnection
        End Enum
    End Class

End Namespace
