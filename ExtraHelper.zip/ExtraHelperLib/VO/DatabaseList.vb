﻿Namespace VO
    Public Class DatabaseList
        Public Shared DatabaseList As DataTable
    End Class
End Namespace
