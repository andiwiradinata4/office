﻿Namespace VO

    Public Class Common

        Private intComLocDivSubDivID As Integer
        Private strProgramID As String
        Private strCompanyID As String
        Private strServerName As String
        Private bolDeleted As Boolean
        Private intLogInc As Integer, strLogBy As String, dtLogDate As DateTime

        Public Property ComLocDivSubDivID() As Integer
            Get
                Return intComLocDivSubDivID
            End Get
            Set(ByVal value As Integer)
                intComLocDivSubDivID = value
            End Set
        End Property

        Public Property ProgramID As String
            Get
                Return strProgramID
            End Get
            Set(ByVal value As String)
                strProgramID = value
            End Set
        End Property

        Public Property CompanyID As String
            Get
                Return strCompanyID
            End Get
            Set(ByVal value As String)
                strCompanyID = value
            End Set
        End Property

        Public Property ServerName() As String
            Get
                Return strServerName
            End Get
            Set(value As String)
                strServerName = value
            End Set
        End Property

        Public Property IsDeleted() As Boolean
            Get
                Return bolDeleted
            End Get
            Set(ByVal value As Boolean)
                bolDeleted = value
            End Set
        End Property

        Public Property LogInc() As Integer
            Get
                Return intLogInc
            End Get
            Set(ByVal value As Integer)
                intLogInc = value
            End Set
        End Property

        Public Property LogBy() As String
            Get
                Return strLogBy
            End Get
            Set(ByVal value As String)
                strLogBy = value
            End Set
        End Property

        Public Property LogDate() As DateTime
            Get
                Return dtLogDate
            End Get
            Set(ByVal value As DateTime)
                dtLogDate = value
            End Set
        End Property

    End Class

End Namespace
