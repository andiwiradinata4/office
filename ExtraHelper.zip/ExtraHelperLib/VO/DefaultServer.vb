﻿Namespace VO

    Public Class DefaultServer
        Public Shared Server, Database, CompID As String
        Public Shared ReportingServer As Integer
        Public Shared AllServers As New DataTable
    End Class

End Namespace
