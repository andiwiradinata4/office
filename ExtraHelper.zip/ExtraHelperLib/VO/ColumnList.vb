﻿Namespace VO
    Public Class ColumnList
        Public Shared ColumnList As DataTable
    End Class
End Namespace

