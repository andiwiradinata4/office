﻿Namespace VO
    Public Class DefaultFillForm
        Public Shared Database, ReplaceText, SelectedTable As String
    End Class
End Namespace