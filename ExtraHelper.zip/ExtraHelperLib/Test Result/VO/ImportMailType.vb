Namespace VO
    Public Class ImportMailType
        Inherits Common
        Property MailTypeID As Byte
        Property Description As String
        Property InitialDescription As String
        Property Status As Byte
        Property CreatedBy As String
        Property CreatedDate As DateTime
    End Class 
End Namespace

