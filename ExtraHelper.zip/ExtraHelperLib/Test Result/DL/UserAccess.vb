Namespace DL

    Public Class UserAccess

        Public Shared aRight(,) As String

        Public Shared Function UserList(Optional ByVal intComLocDivSubDivID As Integer = 0) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                If intComLocDivSubDivID = 0 Then
                    .CommandText = _
                        "SELECT " & _
                        "   UserID, UserName, UserPosition, Email, ExtNumber, HeadID " & _
                        "FROM CPS_vwUserList " & _
                        "ORDER BY UserID "
                ElseIf intComLocDivSubDivID > 0 Then
                    .CommandText = _
                        "SELECT " & _
                        "   A.UserID, A.UserName, A.UserPosition, A.Email, A.ExtNumber, A.HeadID " & _
                        "FROM CPS_vwUserList A " & _
                        "INNER JOIN CPS_vwUserListDtl B ON " & _
                        "   A.UserID = B.UserID " & _
                        "WHERE " & _
                        "   B.ComLocDivSubDivID = @ComLocDivSubDivID " & _
                        "ORDER BY A.UserID "
                End If
                .Parameters.Add("@ComLocDivSubDivID", SqlDbType.Int).Value = intComLocDivSubDivID
            End With
            Return SQL.QueryDataTable(sqlcmdExecute)
        End Function

        Public Shared Function AccessList(ByVal strUserID As String, strUserCompanyID As String) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "SELECT " & _
                    "   A.ProgramID, B.ProgramName, " & _
                    "   C.ComLocDivSubDivID, C.CompanyID, C.CompanyName, C.LocationID, C.LocationName, " & _
                    "   C.DivisionID, C.DivisionName, C.SubDivisionID, C.SubDivisionName, " & _
                    "   ISNULL(C.BUType,0) BUType, " & _
                    "   C.IsBondedZone, C.IsPLB, C.IsProject, D.Type AS ProgramType, " & _
                    "   E.IsLinkCFM, E.IsLinkInventory, " & _
                    "   E.IsLocalPurchaseNonBudget, E.IsSplitPRUsingItemList, " & _
                    "   E.HQPurchasePaymentBy, E.LocalPurchasePaymentBy, C.IsImportirPLB, E.[Server] ServerName " & _
                    "FROM CPS_vwUserListDtl A " & _
                    "INNER JOIN CPS_vwUserProgramList B ON " & _
                    "   A.ProgramID = B.ProgramID " & _
                    "INNER JOIN CPS_vwCompanyStructure C ON " & _
                    "   A.ComLocDivSubDivID = C.ComLocDivSubDivID " & _
                    "INNER JOIN CPS_sysProgramList D ON " & _
                    "   A.ProgramID = D.ProgramID " & _
                    "INNER JOIN CPS_sysServerList E ON " & _
                    "   C.CompanyID = E.CompanyID " & _
                    "WHERE " & _
                    "   A.UserID = @UserID " & _
                    "   AND E.IsActive = 1 "

                If strUserCompanyID <> "" Then
                    .CommandText += " AND C.CompanyID = @CompanyID "
                    .Parameters.Add("@CompanyID", SqlDbType.VarChar, 15).Value = strUserCompanyID
                End If

                .CommandText += "ORDER BY A.ProgramID, C.CompanyName, C.SubDivisionName "

                .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strUserID

            End With
            Return SQL.QueryDataTable(sqlcmdExecute)
        End Function

        Public Shared Function GetDetail(ByVal strUserID As String) As VO.User
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader
            Dim voUser As New VO.User
            Try
                If Not SQL.bolUseTrans Then SQL.OpenConnection()
                With sqlcmdExecute
                    .Connection = SQL.sqlConn
                    .CommandText = _
                        "SELECT TOP 1 " & _
                        "   UserID,UserName,Password,Email,ExtNumber,HeadID " & _
                        "FROM ABSNEW.dbo.Sys_UserList " & _
                        "WHERE " & _
                        "   UserID = @UserID " & _
                        "   AND Active = 1 "

                    .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strUserID
                    If SQL.bolUseTrans Then .Transaction = SQL.sqlTrans
                End With
                sqlrdData = sqlcmdExecute.ExecuteReader(CommandBehavior.SingleRow)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voUser.ID = .Item("UserID")
                        voUser.Name = .Item("UserName")
                        voUser.Password = .Item("Password")
                        voUser.Email = .Item("Email")
                        voUser.ExtNumber = .Item("ExtNumber")
                        voUser.HeadID = .Item("HeadID")
                    Else
                        voUser.ID = ""
                        voUser.Name = ""
                        voUser.Password = ""
                        voUser.Email = ""
                        voUser.ExtNumber = ""
                        voUser.HeadID = ""
                    End If
                    .Close()
                End With
                If Not SQL.bolUseTrans Then SQL.CloseConnection()
            Catch ex As Exception
                Throw (ex)
            End Try
            Return voUser
        End Function

        Public Shared Function GetDetailNE(ByVal strUserID As String) As VO.User
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader
            Dim voUser As New VO.User
            Try
                If Not SQL.bolUseTrans Then SQL.OpenConnection()
                With sqlcmdExecute
                    .Connection = SQL.sqlConn
                    .CommandText = _
                        "SELECT TOP 1 " & _
                        "   UserID,UserName,Password,Email,ExtNumber,HeadID " & _
                        "FROM ABSNEWNE.dbo.Sys_UserList " & _
                        "WHERE " & _
                        "   UserID = @UserID " & _
                        "   AND Active = 1 "

                    .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strUserID
                    If SQL.bolUseTrans Then .Transaction = SQL.sqlTrans
                End With
                sqlrdData = sqlcmdExecute.ExecuteReader(CommandBehavior.SingleRow)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        voUser.ID = .Item("UserID")
                        voUser.Name = .Item("UserName")
                        voUser.Password = .Item("Password")
                        voUser.Email = .Item("Email")
                        voUser.ExtNumber = .Item("ExtNumber")
                        voUser.HeadID = .Item("HeadID")
                    Else
                        voUser.ID = ""
                        voUser.Name = ""
                        voUser.Password = ""
                        voUser.Email = ""
                        voUser.ExtNumber = ""
                        voUser.HeadID = ""
                    End If
                    .Close()
                End With
                If Not SQL.bolUseTrans Then SQL.CloseConnection()
            Catch ex As Exception
                Throw (ex)
            End Try
            Return voUser
        End Function

        Public Shared Function GetPassword(ByVal strUserID As String) As String
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader
            Dim strPassword As String = ""
            Try
                If Not SQL.bolUseTrans Then SQL.OpenConnection()
                With sqlcmdExecute
                    .Connection = SQL.sqlConn
                    .CommandText = _
                        "SELECT TOP 1  " & _
                        "   Password " & _
                        "FROM CPS_vwUserList " & _
                        "WHERE " & _
                        "   UserID=@UserID "

                    .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strUserID
                    If SQL.bolUseTrans Then .Transaction = SQL.sqlTrans
                End With
                sqlrdData = sqlcmdExecute.ExecuteReader(CommandBehavior.SingleRow)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        strPassword = .Item("Password")
                    End If
                    .Close()
                End With
                If Not SQL.bolUseTrans Then SQL.CloseConnection()
            Catch ex As Exception
                Throw ex
            End Try
            Return strPassword
        End Function

        Public Shared Sub ChangePassword(ByVal strUserID As String, ByVal strNewPassword As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "UPDATE CPS_vwUserList SET " & _
                    "   Password=@NewPassword " & _
                    "WHERE " & _
                    "   UserID=@UserID "

                .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strUserID
                .Parameters.Add("@NewPassword", SqlDbType.NVarChar, 100).Value = strNewPassword
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Private Shared Function AccessRightCount(ByVal strProgramID As String) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader
            Dim intTotal As Integer = 0
            Try
                If Not SQL.bolUseTrans Then SQL.OpenConnection()
                With sqlcmdExecute
                    .Connection = SQL.sqlConn
                    .CommandText = _
                        "SELECT " & _
                        "   COUNT(AccessRight) AS AccessRightCount " & _
                        "FROM CPS_vwUserAccessLevel " & _
                        "WHERE " & _
                        "   ProgramID=@ProgramID "

                    .Parameters.Add("@ProgramID", SqlDbType.VarChar, 15).Value = strProgramID
                    If SQL.bolUseTrans Then .Transaction = SQL.sqlTrans
                End With
                sqlrdData = sqlcmdExecute.ExecuteReader(CommandBehavior.SingleRow)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        intTotal = .Item("AccessRightCount")
                    End If
                    .Close()
                End With
                If Not SQL.bolUseTrans Then SQL.CloseConnection()
            Catch ex As Exception
                Throw ex
            End Try
            Return intTotal
        End Function

        Public Shared Sub AccessFillRight(ByVal strProgramID As String)
            Dim intTotal As Integer = AccessRightCount(strProgramID)

            Dim intPos As Integer = 0
            ReDim aRight(intTotal, 1)

            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader
            Try
                If Not SQL.bolUseTrans Then SQL.OpenConnection()
                With sqlcmdExecute
                    .Connection = SQL.sqlConn
                    .CommandText = _
                        "SELECT " & _
                        "   AccessRight, AccessValue " & _
                        "FROM CPS_vwUserAccessLevel " & _
                        "WHERE " & _
                        "   ProgramID=@ProgramID " & _
                        "ORDER BY AccessValue "

                    .Parameters.Add("@ProgramID", SqlDbType.VarChar, 15).Value = strProgramID
                    If SQL.bolUseTrans Then .Transaction = SQL.sqlTrans
                End With
                sqlrdData = sqlcmdExecute.ExecuteReader(CommandBehavior.Default)
                With sqlrdData
                    If .HasRows Then
                        While .Read()
                            aRight(intPos, 0) = .Item("AccessRight")
                            aRight(intPos, 1) = .Item("AccessValue")
                            intPos += 1
                        End While
                    End If
                    .Close()
                End With
                If Not SQL.bolUseTrans Then SQL.CloseConnection()
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Private Shared Function GetAccessValue(ByVal strAccessRight As String) As Short
            Dim shtI As Short
            Dim shtReturn As Short = 0
            For shtI = 0 To aRight.GetUpperBound(0)
                If UCase(aRight(shtI, 0)) = UCase(strAccessRight) Then
                    shtReturn = aRight(shtI, 1)
                End If
            Next
            Return shtReturn
        End Function

        Public Shared Function CheckAccess(ByVal strUserID As String, ByVal strProgramID As String, ByVal intComLocDivSubDivID As Integer, ByVal strModuleID As String, ByVal strAccessCode As String) As Boolean
            Dim shtRightValue As Short = GetAccessValue(strAccessCode)
            Dim bolResult As Boolean = False

            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader
            Dim intTotal As Integer = 0
            Try
                If Not SQL.bolUseTrans Then SQL.OpenConnection()
                With sqlcmdExecute
                    .Connection = SQL.sqlConn
                    .CommandText = _
                        "SELECT TOP 1 " & _
                        "   AccessLevel " & _
                        "FROM CPS_vwUserListDtl A " & _
                        "INNER JOIN CPS_vwUserProgramMenu B ON " & _
                        "   A.ProgramID=B.ProgramID " & _
                        "   AND A.UserMenu=B.MenuID " & _
                        "INNER JOIN CPS_vwUserProgramMenuDtl C ON " & _
                        "   B.MenuID=C.MenuID " & _
                        "WHERE " & _
                        "   A.UserID=@UserID " & _
                        "   AND A.ComLocDivSubDivID = @ComLocDivSubDivID " & _
                        "   AND A.ProgramID=@ProgramID " & _
                        "   AND C.ModuleID=@ModuleID "

                    .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strUserID
                    .Parameters.Add("@ComLocDivSubDivID", SqlDbType.Int).Value = intComLocDivSubDivID
                    .Parameters.Add("@ProgramID", SqlDbType.VarChar, 15).Value = strProgramID
                    .Parameters.Add("@ModuleID", SqlDbType.VarChar, 50).Value = strModuleID
                    If SQL.bolUseTrans Then .Transaction = SQL.sqlTrans
                End With
                sqlrdData = sqlcmdExecute.ExecuteReader(CommandBehavior.SingleRow)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolResult = CType(.Item("AccessLevel"), Short) And shtRightValue
                    End If
                    .Close()
                End With
                If Not SQL.bolUseTrans Then SQL.CloseConnection()
            Catch ex As Exception
                Throw ex
            End Try
            Return bolResult
        End Function

        Public Shared Function GetDelegatedFrom(ByVal strUserID As String, ByVal dtmPeriod As DateTime) As String
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader
            Dim strGetDelegatedUserID As String = ""
            Try
                If Not SQL.bolUseTrans Then SQL.OpenConnection()
                With sqlcmdExecute
                    .Connection = SQL.sqlConn
                    .CommandText = _
                        "SELECT TOP 1 UserID " & _
                        "FROM CPS_sysDelegated " & _
                        "WHERE DelegatedUserID=@UserID " & _
                        "   AND @Period BETWEEN DateFrom AND DateTo "

                    .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strUserID
                    .Parameters.Add("@Period", SqlDbType.DateTime).Value = dtmPeriod
                    If SQL.bolUseTrans Then .Transaction = SQL.sqlTrans
                End With
                sqlrdData = sqlcmdExecute.ExecuteReader(CommandBehavior.SingleRow)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        strGetDelegatedUserID = .Item("UserID")
                    End If
                    .Close()
                End With
                If Not SQL.bolUseTrans Then SQL.CloseConnection()
            Catch ex As Exception
                Throw ex
            End Try
            Return strGetDelegatedUserID
        End Function

        Public Shared Function GetDelegatedUserID(ByVal strUserID As String, ByVal dtmPeriod As DateTime, ByVal strLogBy As String) As String
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader
            Dim strGetDelegatedUserID As String = ""
            Try
                If Not SQL.bolUseTrans Then SQL.OpenConnection()
                With sqlcmdExecute
                    .Connection = SQL.sqlConn
                    .CommandText = _
                        "SELECT TOP 1 DelegatedUserID " & _
                        "FROM CPS_sysDelegated " & _
                        "WHERE " & _
                        "   UserID=@UserID " & _
                        "   AND @Period BETWEEN DateFrom AND DateTo " & _
                        "   AND DelegatedUserID = @LogBy "

                    .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strUserID
                    .Parameters.Add("@Period", SqlDbType.DateTime).Value = dtmPeriod
                    .Parameters.Add("@LogBy", SqlDbType.VarChar, 20).Value = strLogBy
                    If SQL.bolUseTrans Then .Transaction = SQL.sqlTrans
                End With
                sqlrdData = sqlcmdExecute.ExecuteReader(CommandBehavior.SingleRow)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        strGetDelegatedUserID = .Item("DelegatedUserID")
                    End If
                    .Close()
                End With
                If Not SQL.bolUseTrans Then SQL.CloseConnection()
            Catch ex As Exception
                Throw ex
            End Try
            Return strGetDelegatedUserID
        End Function

        Public Shared Function IsValidDelegatedUserID(ByVal strUserID As String, ByVal strDelegatedUserID As String, ByVal dtmPeriod As DateTime) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader
            Dim bolValid As Boolean = False
            Try
                If Not SQL.bolUseTrans Then SQL.OpenConnection()
                With sqlcmdExecute
                    .Connection = SQL.sqlConn
                    .CommandText = _
                        "IF EXISTS " & _
                        "   (SELECT UserID " & _
                        "   FROM CPS_sysDelegated " & _
                        "   WHERE " & _
                        "       UserID = @UserID " & _
                        "       AND DelegatedUserID = @DelegatedUserID " & _
                        "       AND @Period BETWEEN DateFrom AND DateTo) " & _
                        "SELECT CAST(1 AS BIT) " & _
                        "ELSE " & _
                        "   SELECT CAST(0 AS BIT) "

                    .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strUserID
                    .Parameters.Add("@DelegatedUserID", SqlDbType.VarChar).Value = strDelegatedUserID
                    .Parameters.Add("@Period", SqlDbType.DateTime).Value = dtmPeriod
                    If SQL.bolUseTrans Then .Transaction = SQL.sqlTrans
                End With
                sqlrdData = sqlcmdExecute.ExecuteReader(CommandBehavior.SingleRow)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        bolValid = .Item(0)
                    End If
                    .Close()
                End With
                If Not SQL.bolUseTrans Then SQL.CloseConnection()
            Catch ex As Exception
                Throw ex
            End Try
            Return bolValid
        End Function

        Public Shared Function GetUserIDByLegacyUser(ByVal strLegacyUser As String) As String
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader
            Dim strUserID As String = ""
            Try
                If Not SQL.bolUseTrans Then SQL.OpenConnection()
                With sqlcmdExecute
                    .Connection = SQL.sqlConn
                    .CommandText = _
                        "SELECT TOP 1 UserID " & _
                        "FROM ABSNEW.dbo.sys_UserList " & _
                        "WHERE LegacyID = @LegacyID "
                    .Parameters.Add("@LegacyID", SqlDbType.VarChar, 20).Value = strLegacyUser

                    If SQL.bolUseTrans Then .Transaction = SQL.sqlTrans
                End With
                sqlrdData = sqlcmdExecute.ExecuteReader(CommandBehavior.SingleRow)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        strUserID = .Item(0)
                    End If
                    .Close()
                End With
                If Not SQL.bolUseTrans Then SQL.CloseConnection()
            Catch ex As Exception
                Throw ex
            End Try
            Return strUserID
        End Function

        Public Shared Function GetUserEmail(ByVal strUserID As String) As String
            Dim strEmail As String = ""
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader
            Try
                If Not SQL.bolUseTrans Then SQL.OpenConnection()
                With sqlcmdExecute
                    .Connection = SQL.sqlConn
                    .CommandText = _
                        "SELECT Email " & _
                        "FROM CPS_vwUserList " & _
                        "WHERE UserID = @UserID "
                    .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strUserID
                    If SQL.bolUseTrans Then .Transaction = SQL.sqlTrans
                End With
                sqlrdData = sqlcmdExecute.ExecuteReader(CommandBehavior.SingleRow)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        strEmail = .Item("Email")
                    End If
                    .Close()
                End With
                If Not SQL.bolUseTrans Then SQL.CloseConnection()
            Catch ex As Exception
                Throw ex
            End Try
            Return strEmail
        End Function

        Public Shared Function GetProgramList() As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "SELECT ProgramID, ProgramName " & _
                    "FROM ABSNEW.dbo.sys_ProgramList " & _
                    "WHERE ProgramID LIKE 'CPS%' "
            End With
            Return SQL.QueryDataTable(sqlcmdExecute)
        End Function

        Public Shared Sub CopyProgramList()
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "IF NOT EXISTS " & _
                    "   (SELECT ProgramID FROM ABSNEW.dbo.sys_ProgramList " & _
                    "   WHERE ProgramID LIKE 'CPS%') " & _
                    "INSERT INTO ABSNEW.dbo.sys_ProgramList " & _
                    "SELECT ProgramID, ProgramName " & _
                    "FROM ABSNEWNE.dbo.sysProgramList " & _
                    "WHERE ProgramID LIKE 'CPS%' "
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Public Shared Function GetModuleList() As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "SELECT ProgramID, ModuleID, ModuleName " & _
                    "FROM ABSNEW.dbo.sys_ModuleList " & _
                    "WHERE ProgramID LIKE 'CPS%' "
            End With
            Return SQL.QueryDataTable(sqlcmdExecute)
        End Function

        Public Shared Sub CopyModuleList()
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "IF NOT EXISTS " & _
                    "   (SELECT ProgramID FROM ABSNEW.dbo.sys_ModuleList " & _
                    "   WHERE ProgramID LIKE 'CPS%') " & _
                    "INSERT INTO ABSNEW.dbo.sys_ModuleList " & _
                    "SELECT ProgramID, ModuleID, ModuleName " & _
                    "FROM ABSNEWNE.dbo.sys_ModuleList " & _
                    "WHERE ProgramID LIKE 'CPS%' "
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Public Shared Function GetAccessLevel() As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "SELECT ProgramID, AccessRight, AccessValue " & _
                    "FROM ABSNEW.dbo.sys_AccessLevel " & _
                    "WHERE ProgramID LIKE 'CPS%' "
            End With
            Return SQL.QueryDataTable(sqlcmdExecute)
        End Function

        Public Shared Sub CopyAccessLevel()
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "IF NOT EXISTS " & _
                    "   (SELECT ProgramID FROM ABSNEW.dbo.sys_AccessLevel " & _
                    "   WHERE ProgramID LIKE 'CPS%') " & _
                    "INSERT INTO ABSNEW.dbo.sys_AccessLevel " & _
                    "SELECT ProgramID, AccessRight, AccessValue " & _
                    "FROM ABSNEWNE.dbo.sys_AccessLevel " & _
                    "WHERE ProgramID LIKE 'CPS%' "
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Public Shared Function GetProgramMenu() As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "SELECT MenuID, MenuName, ProgramID " & _
                    "FROM ABSNEW.dbo.sys_ProgramMenu " & _
                    "WHERE ProgramID LIKE 'CPS%' "
            End With
            Return SQL.QueryDataTable(sqlcmdExecute)
        End Function

        Public Shared Sub CopyProgramMenu()
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "IF NOT EXISTS " & _
                    "   (SELECT ProgramID FROM ABSNEW.dbo.sys_ProgramMenu " & _
                    "   WHERE ProgramID LIKE 'CPS%') " & _
                    "INSERT INTO ABSNEW.dbo.sys_ProgramMenu " & _
                    "SELECT MenuID, MenuName, ProgramID " & _
                    "FROM ABSNEWNE.dbo.sys_ProgramMenu " & _
                    "WHERE ProgramID LIKE 'CPS%' "
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Public Shared Function GetProgramMenuDetail() As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "SELECT MenuID, ModuleID, AccessLevel " & _
                    "FROM ABSNEW.dbo.sys_ProgramMenuDtl " & _
                    "WHERE MenuID LIKE 'CPS%' "
            End With
            Return SQL.QueryDataTable(sqlcmdExecute)
        End Function

        Public Shared Sub CopyProgramMenuDetail()
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "IF NOT EXISTS " & _
                    "   (SELECT MenuID FROM ABSNEW.dbo.sys_ProgramMenuDtl " & _
                    "   WHERE MenuID LIKE 'CPS%') " & _
                    "INSERT INTO ABSNEW.dbo.sys_ProgramMenuDtl " & _
                    "SELECT MenuID, ModuleID, AccessLevel " & _
                    "FROM ABSNEWNE.dbo.sys_ProgramMenuDtl " & _
                    "WHERE MenuID LIKE 'CPS%' "
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Public Shared Function GetUserListDetail(ByVal strUserID As String, ByVal strDBName As String) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                If UCase(Left(strDBName, 3)) <> "KPA" Then
                    .CommandText = _
                        "SELECT * " & _
                        "FROM ABSNEWNE.dbo.Sys_UserListDtl " & _
                        "WHERE UserID = @UserID AND ProgramID LIKE 'CPS%' "
                Else
                    .CommandText = _
                        "SELECT * " & _
                        "FROM KPA_ABSNEWNE.dbo.Sys_UserListDtl " & _
                        "WHERE UserID = @UserID AND ProgramID LIKE 'CPS%' "
                End If
              
                .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strUserID
            End With
            Return SQL.QueryDataTable(sqlcmdExecute)
        End Function

        Public Shared Function GetUserProgramMenu(ByVal strUserID As String, ByVal strProgramID As String) As String
            Dim strProgramMenu As String = ""
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader
            Try
                If Not SQL.bolUseTrans Then SQL.OpenConnection()
                With sqlcmdExecute
                    .Connection = SQL.sqlConn
                    .CommandText = _
                        "SELECT MAX(UserMenu) AS UserMenu " & _
                        "FROM ABSNEWNE.dbo.sys_UserListDtl " & _
                        "WHERE " & _
                        "   UserID = @UserID " & _
                        "   AND ProgramID = @ProgramID " & _
                        "GROUP BY UserID, ProgramID "

                    .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strUserID
                    .Parameters.Add("@ProgramID", SqlDbType.VarChar, 20).Value = strProgramID

                    If SQL.bolUseTrans Then .Transaction = SQL.sqlTrans
                End With
                sqlrdData = sqlcmdExecute.ExecuteReader(CommandBehavior.SingleRow)
                With sqlrdData
                    If .HasRows Then
                        .Read()
                        strProgramMenu = .Item(0)
                    End If
                    .Close()
                End With
                If Not SQL.bolUseTrans Then SQL.CloseConnection()
            Catch ex As Exception
                Throw ex
            End Try
            Return strProgramMenu
        End Function

        Public Shared Sub CopyUserListDetail(ByVal strUserID As String, ByVal strSubDivID As String, ByVal strComLocDivID As String, ByVal strProgramID As String, ByVal strUserMenu As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "IF NOT EXISTS " & _
                    "   (SELECT UserID " & _
                    "   FROM ABSNEW.dbo.Sys_UserListDtl " & _
                    "   WHERE " & _
                    "       UserID = @UserID " & _
                    "       AND Sub_Div_Id = @SubDivID " & _
                    "       AND Com_Loc_Div_Id = @ComLocDivID " & _
                    "       AND ProgramID = @ProgramID) " & _
                    "INSERT INTO ABSNEW.dbo.Sys_UserListDtl " & _
                    "   (UserID, Sub_Div_Id, Com_Loc_Div_Id, ProgramID, UserMenu) " & _
                    "VALUES " & _
                    "   (@UserID, @SubDivID, @ComLocDivID, @ProgramID, @UserMenu) "

                .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strUserID
                .Parameters.Add("@SubDivID", SqlDbType.VarChar, 50).Value = strSubDivID
                .Parameters.Add("@ComLocDivID", SqlDbType.VarChar, 50).Value = strComLocDivID
                .Parameters.Add("@ProgramID", SqlDbType.VarChar, 20).Value = strProgramID
                .Parameters.Add("@UserMenu", SqlDbType.VarChar, 50).Value = strUserMenu
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Public Shared Sub UpdateLegacyID(ByVal strNewUserID As String, ByVal strLegacyID As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "UPDATE ABSNEWNE.dbo.Sys_UserList " & _
                    "SET LegacyID = @UserID " & _
                    "WHERE UserID = @LegacyID "
                .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strNewUserID
                .Parameters.Add("@LegacyID", SqlDbType.VarChar, 20).Value = strLegacyID
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Public Shared Sub InsertPOLimit(ByVal strNewUserID As String, ByVal strLegacyID As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "IF EXISTS (SELECT UserID FROM CPS_sysPOLimit WHERE UserID = @LegacyID) " & _
                    "   BEGIN " & _
                    "   IF NOT EXISTS (SELECT UserID FROM CPS_sysPOLimit WHERE UserID = @UserID) " & _
                    "       BEGIN " & _
                    "           INSERT CPS_sysPOLimit " & _
                    "           SELECT @UserID, ProgramID, POLevel, LimitAmount, " & _
                    "           POCountPerMonth, POAmountPerMonth, 0, 'SPV', GETDATE() " & _
                    "           FROM CPS_sysPOLimit " & _
                    "           WHERE UserID = @LegacyID " & _
                    "       END " & _
                    "   END "

                .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strNewUserID
                .Parameters.Add("@LegacyID", SqlDbType.VarChar, 20).Value = strLegacyID
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Public Shared Sub InsertSCLimit(ByVal strNewUserID As String, ByVal strLegacyID As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "IF EXISTS (SELECT UserID FROM CPS_sysSCLimit WHERE UserID = @LegacyID) " & _
                    "   BEGIN " & _
                    "   IF NOT EXISTS (SELECT UserID FROM CPS_sysSCLimit WHERE UserID = @UserID) " & _
                    "       BEGIN " & _
                    "           INSERT CPS_sysSCLimit " & _
                    "           SELECT @UserID, ProgramID, SCLevel, LimitAmount, " & _
                    "           SCCountPerMonth, SCAmountPerMonth, 0, 'SPV', GETDATE() " & _
                    "           FROM CPS_sysSCLimit " & _
                    "           WHERE UserID = @LegacyID " & _
                    "       END " & _
                    "   END "

                .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strNewUserID
                .Parameters.Add("@LegacyID", SqlDbType.VarChar, 20).Value = strLegacyID
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Public Shared Sub InsertUserFilter(ByVal strNewUserID As String, ByVal strLegacyID As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "IF EXISTS (SELECT UserID FROM CPS_sysUserFilter WHERE UserID = @LegacyID) " & _
                    "   BEGIN " & _
                    "   IF NOT EXISTS (SELECT UserID FROM CPS_sysUserFilter WHERE UserID = @UserID) " & _
                    "       BEGIN " & _
                    "           INSERT CPS_sysUserFilter " & _
                    "           SELECT ProgramID, @UserID, SubCategory2ID, 0, 'SPV', GETDATE(), 1 " & _
                    "           FROM CPS_sysUserFilter " & _
                    "           WHERE UserID = @LegacyID " & _
                    "       END " & _
                    "   END "

                .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strNewUserID
                .Parameters.Add("@LegacyID", SqlDbType.VarChar, 20).Value = strLegacyID
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Public Shared Sub InsertCMPFilter(ByVal strNewUserID As String, ByVal strLegacyID As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "IF EXISTS (SELECT UserID FROM CPS_sysCMPFilter WHERE UserID = @LegacyID) " & _
                    "   BEGIN " & _
                    "   IF NOT EXISTS (SELECT UserID FROM CPS_sysCMPFilter WHERE UserID = @UserID) " & _
                    "       BEGIN " & _
                    "           INSERT CPS_sysCMPFilter " & _
                    "           SELECT @UserID, CompanyID, ComLocDivSubDivID, 0, 'SPV', GETDATE() " & _
                    "           FROM CPS_sysCMPFilter " & _
                    "           WHERE UserID = @LegacyID " & _
                    "       END " & _
                    "   END "

                .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strNewUserID
                .Parameters.Add("@LegacyID", SqlDbType.VarChar, 20).Value = strLegacyID
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Public Shared Sub InsertEDILimit(ByVal strNewUserID As String, ByVal strLegacyID As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "IF EXISTS (SELECT UserID FROM CPS_sysEDILimit WHERE UserID = @LegacyID) " & _
                    "   BEGIN " & _
                    "   IF NOT EXISTS (SELECT UserID FROM CPS_sysEDILimit WHERE UserID = @UserID) " & _
                    "       BEGIN " & _
                    "           INSERT CPS_sysEDILimit " & _
                    "           SELECT @UserID, ProgramID, EDILevel, LimitAmount, EDICountPerMonth, EDIAmountPerMonth, 0, 'SPV', GETDATE() " & _
                    "           FROM CPS_sysEDILimit " & _
                    "           WHERE UserID = @LegacyID " & _
                    "       END " & _
                    "   END "

                .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strNewUserID
                .Parameters.Add("@LegacyID", SqlDbType.VarChar, 20).Value = strLegacyID
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Public Shared Sub InsertPRApproveCategoryDet(ByVal strNewUserID As String, ByVal strLegacyID As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "IF EXISTS (SELECT UserID FROM CPS_sysPRApproveCategoryDet WHERE UserID = @LegacyID) " & _
                    "   BEGIN " & _
                    "   IF NOT EXISTS (SELECT UserID FROM CPS_sysPRApproveCategoryDet WHERE UserID = @UserID) " & _
                    "       BEGIN " & _
                    "           INSERT CPS_sysPRApproveCategoryDet " & _
                    "           SELECT CategoryType, @UserID, 0, 'SPV', GETDATE(), IsNotifySubmit, IsNotifyCheck, IsNotifyVerify, IsNeedCheck " & _
                    "           FROM CPS_sysPRApproveCategoryDet " & _
                    "           WHERE UserID = @LegacyID " & _
                    "       END " & _
                    "   END "

                .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strNewUserID
                .Parameters.Add("@LegacyID", SqlDbType.VarChar, 20).Value = strLegacyID
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Public Shared Sub InsertPRApproveStructure(ByVal strNewUserID As String, ByVal strLegacyID As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "IF EXISTS (SELECT UserID FROM CPS_sysPRApproveStructure WHERE UserID = @LegacyID) " & _
                    "   BEGIN " & _
                    "   IF NOT EXISTS (SELECT UserID FROM CPS_sysPRApproveStructure WHERE UserID = @UserID) " & _
                    "       BEGIN " & _
                    "           INSERT CPS_sysPRApproveStructure " & _
                    "           SELECT CompanyID, ComLocDivSubDivID, @UserID, IsActive, ApproveLevel, 0, 'SPV', GETDATE() " & _
                    "           FROM CPS_sysPRApproveStructure " & _
                    "           WHERE UserID = @LegacyID " & _
                    "       END " & _
                    "   END "

                .Parameters.Add("@UserID", SqlDbType.VarChar, 20).Value = strNewUserID
                .Parameters.Add("@LegacyID", SqlDbType.VarChar, 20).Value = strLegacyID
            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute)
            Catch ex As Exception
                Throw ex
            End Try
        End Sub

        Public Shared Function GetHeadID(ByVal strUserID As String) As String
            Dim strHeadID As String = ""
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader
            SQL.OpenConnection()
            With sqlcmdExecute
                .Connection = SQL.sqlConn
                .CommandText = _
                    "SELECT HeadID " & _
                    "FROM CPS_vwUserList " & _
                    "WHERE UserID = @UserID "
                .Parameters.Add("@UserID", SqlDbType.VarChar).Value = strUserID
            End With
            sqlrdData = sqlcmdExecute.ExecuteReader(CommandBehavior.SingleRow)
            With sqlrdData
                If .HasRows Then
                    .Read()
                    strHeadID = .Item("HeadID")
                End If
                .Close()
            End With
            SQL.CloseConnection()
            Return strHeadID
        End Function

        Public Shared Function GetUserEmailList(ByVal strUserIDList As String) As String
            Dim sqlcmdExecute As New SqlCommand
            Dim dtEmail As New DataTable
            Dim strEmailList As String = ""

            With sqlcmdExecute
                .CommandText = _
                    "SELECT Email " & _
                    "FROM CPS_vwUserList " & _
                    "WHERE UserID IN (" & strUserIDList & ") " & _
                    "GROUP BY Email "
            End With

            dtEmail = SQL.QueryDataTable(sqlcmdExecute)

            If dtEmail.Rows.Count > 0 Then
                For Each dr As DataRow In dtEmail.Rows
                    strEmailList += dr("Email") & ","
                Next
                strEmailList = Left(strEmailList, Len(strEmailList) - 1)
            End If

            Return strEmailList
        End Function

    End Class

End Namespace
