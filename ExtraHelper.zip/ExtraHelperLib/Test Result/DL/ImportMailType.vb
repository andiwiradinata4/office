Namespace DL
    Public Class ImportMailType
        Public Shared Function ListData(ByVal bytMailTypeID As Byte) As DataTable
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                   "SELECT " & vbNewLine & _ 
                   "    A.MailTypeID, A.Description, A.InitialDescription, A.Status, StatusInfo=CASE A.Status WHEN 0 THEN 'ACTIVE' ELSE 'IN-ACTIVE' END, A.CreatedBy, A.CreatedDate, A.LogBy,   " & vbNewLine & _ 
                   "    A.LogDate, A.LogInc  " & vbNewLine & _ 
                   "FROM CPS_sysImportMailType A " & vbNewLine & _ 
                   "WHERE  " & vbNewLine & _ 
                   "    A.MailTypeID=@MailTypeID" & VbNewLine 

                    .Parameters.Add("@MailTypeID", SqlDbType.tinyint).Value = bytMailTypeID

            End With
            Return SQL.QueryDataTable(sqlcmdExecute)
        End Function

        Public Shared Sub SaveData(ByVal bolNew as Boolean, ByVal clsData As VO.ImportMailType)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                If bolNew Then
                    .CommandText = _
                       "INSERT INTO CPS_sysImportMailType " & vbNewLine & _ 
                       "    (MailTypeID, Description, InitialDescription, CreatedBy, CreatedDate, LogBy, LogDate)   " & vbNewLine & _ 
                       "VALUES " & vbNewLine & _ 
                       "    (@MailTypeID, @Description, @InitialDescription, @LogBy, GETDATE(), @LogBy, GETDATE())  " & vbNewLine 
                Else
                    .CommandText = _
                       "UPDATE CPS_sysImportMailType SET " & vbNewLine & _ 
                       "    Description=@Description, " & vbNewLine & _ 
                       "    InitialDescription=@InitialDescription, " & vbNewLine & _ 
                       "    Status=@Status, " & vbNewLine & _ 
                       "    LogBy=@LogBy, " & vbNewLine & _ 
                       "    LogDate=GETDATE(), " & vbNewLine & _ 
                       "    LogInc=LogInc+1 " & vbNewLine & _ 
                       "WHERE " & vbNewLine & _ 
                       "    MailTypeID=@MailTypeID " & vbNewLine 
                End If

                    .Parameters.Add("@MailTypeID", SqlDbType.tinyint).Value = clsData.MailTypeID
                    .Parameters.Add("@Description", SqlDbType.varchar, 250).Value = clsData.Description
                    .Parameters.Add("@InitialDescription", SqlDbType.varchar, 250).Value = clsData.InitialDescription
                    .Parameters.Add("@Status", SqlDbType.tinyint).Value = clsData.Status
                    .Parameters.Add("@LogBy", SqlDbType.varchar, 20).Value = clsData.LogBy

            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Public Shared Function GetDetail(ByVal bytMailTypeID As Byte) As VO.ImportMailType
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader
            Dim voReturn As New VO.ImportMailType
            Try
                If Not SQL.bolUseTrans Then SQL.OpenConnection()
                With sqlcmdExecute
                    .Connection = SQL.sqlConn 
                    .CommandText = _ 
                       "SELECT TOP 1 " & vbNewLine & _ 
                       "    A.MailTypeID, A.Description, A.InitialDescription, A.Status, A.CreatedBy, A.CreatedDate, A.LogBy,   " & vbNewLine & _ 
                       "    A.LogDate, A.LogInc  " & vbNewLine & _ 
                       "FROM CPS_sysImportMailType A " & VbNewLine & _ 
                       "WHERE " & VbNewLine & _ 
                       "    MailTypeID=@MailTypeID " & vbNewLine 

                    .Parameters.Add("@MailTypeID", SqlDbType.tinyint).Value = bytMailTypeID

                    If SQL.bolUseTrans Then .Transaction = SQL.sqlTrans 
                End With
                sqlrdData = sqlcmdExecute.ExecuteReader(CommandBehavior.SingleRow) 
                With sqlrdData 
                    If .HasRows Then 
                        .Read() 
                        voReturn.MailTypeID = .Item("MailTypeID")
                        voReturn.Description = .Item("Description")
                        voReturn.InitialDescription = .Item("InitialDescription")
                        voReturn.Status = .Item("Status")
                        voReturn.CreatedBy = .Item("CreatedBy")
                        voReturn.CreatedDate = .Item("CreatedDate")
                        voReturn.LogBy = .Item("LogBy")
                        voReturn.LogDate = .Item("LogDate")
                        voReturn.LogInc = .Item("LogInc")
                    End If 
                    .Close() 
                End With 
                If Not SQL.bolUseTrans Then SQL.CloseConnection() 
            Catch ex As Exception 
                Throw ex 
            End Try 
            Return voReturn 
        End Function 

        Public Shared Sub DeleteData(ByVal bytMailTypeID As Byte)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "DELETE FROM CPS_sysImportMailType " & vbNewLine & _ 
                    "WHERE " & vbNewLine & _ 
                    "   MailTypeID=@MailTypeID " & vbNewLine 

                    .Parameters.Add("@MailTypeID", SqlDbType.tinyint).Value = bytMailTypeID

            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Public Shared Sub DeleteData_UpdateStatus(ByVal bytMailTypeID As Byte, ByVal strLogBy As String)
            Dim sqlcmdExecute As New SqlCommand
            With sqlcmdExecute
                .CommandText = _
                    "UPDATE CPS_sysImportMailType " & vbNewLine & _ 
                    "SET Status=1, LogBy=@LogBy, LogDate=GETDATE(), LogInc=LogInc+1  " & vbNewLine & _ 
                    "WHERE " & vbNewLine & _ 
                    "   MailTypeID=@MailTypeID " & vbNewLine 

                    .Parameters.Add("@MailTypeID", SqlDbType.tinyint).Value = bytMailTypeID
                    .Parameters.Add("@LogBy", SqlDbType.varchar, 20).Value = strLogBy

            End With
            Try
                SQL.ExecuteNonQuery(sqlcmdExecute)
            Catch ex As SqlException
                Throw ex
            End Try
        End Sub

        Public Shared Function GetMaxID(ByVal bytMailTypeID As Byte) As Integer
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader 
            Dim intReturn As Integer = 0 
            Try 
                If Not SQL.bolUseTrans Then SQL.OpenConnection() 
                With sqlcmdExecute 
                    .Connection = SQL.sqlConn 
                    .CommandText = _ 
                        "SELECT TOP 1 " & vbNewLine & _ 
                        "   ID=ISNULL(MAX(MailTypeID),0) " & vbNewLine & _ 
                        "FROM CPS_sysImportMailType " & VbNewLine & _ 
                        "WHERE  " & VbNewLine & _ 
                        "   MailTypeID=@MailTypeID " & vbNewLine 

                    .Parameters.Add("@MailTypeID", SqlDbType.tinyint).Value = bytMailTypeID

                    If SQL.bolUseTrans Then .Transaction = SQL.sqlTrans 
                End With
                sqlrdData = sqlcmdExecute.ExecuteReader(CommandBehavior.SingleRow) 
                With sqlrdData 
                    If .HasRows Then 
                        .Read() 
                        intReturn = .Item("ID") + 1
                    End If 
                    .Close() 
                End With 
                If Not SQL.bolUseTrans Then SQL.CloseConnection() 
            Catch ex As Exception 
                Throw ex 
            End Try 
            Return intReturn 
        End Function 

        Public Shared Function DataExists(ByVal bytMailTypeID As Byte) As Boolean
            Dim sqlcmdExecute As New SqlCommand, sqlrdData As SqlDataReader 
            Dim bolExists As Boolean = False 
            Try 
                If Not SQL.bolUseTrans Then SQL.OpenConnection() 
                With sqlcmdExecute 
                    .Connection = SQL.sqlConn 
                    .CommandText = _ 
                        "SELECT TOP 1 " & vbNewLine & _ 
                        "   MailTypeID " & vbNewLine & _ 
                        "FROM CPS_sysImportMailType " & VbNewLine & _ 
                        "WHERE  " & VbNewLine & _ 
                        "   MailTypeID=@MailTypeID " & vbNewLine 

                    .Parameters.Add("@MailTypeID", SqlDbType.tinyint).Value = bytMailTypeID

                    If SQL.bolUseTrans Then .Transaction = SQL.sqlTrans 
                End With
                sqlrdData = sqlcmdExecute.ExecuteReader(CommandBehavior.SingleRow) 
                With sqlrdData 
                    If .HasRows Then 
                        .Read() 
                        bolExists = True
                    End If 
                    .Close() 
                End With 
                If Not SQL.bolUseTrans Then SQL.CloseConnection() 
            Catch ex As Exception 
                Throw ex 
            End Try 
            Return bolExists 
        End Function 

    End Class 

End Namespace

