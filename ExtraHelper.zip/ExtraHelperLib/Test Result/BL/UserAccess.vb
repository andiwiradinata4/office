Namespace BL

    Public Class UserAccess

        Public Shared Function UserList(Optional ByVal intComLocDivSubDivID As Integer = 0) As DataTable
            BL.Server.ServerDefault()
            Return DL.UserAccess.UserList(intComLocDivSubDivID)
        End Function

        Public Shared Function AccessList(ByVal strUserID As String, ByVal strUserCompanyID As String) As DataTable
            BL.Server.ServerDefault()
            Return DL.UserAccess.AccessList(strUserID, strUserCompanyID)
        End Function

        Public Shared Function CheckUserLogin(ByVal strUserID As String, ByVal strUserPassword As String) As Boolean
            BL.Server.ServerDefault()

            Dim voUser As New VO.User
            Dim bolLogin As Boolean = False
            voUser = DL.UserAccess.GetDetailNE(strUserID)
            If PasswordDecrypt(voUser.Password) = strUserPassword Then
                bolLogin = True
            End If
            Return bolLogin
        End Function

        Public Shared Function GetPassword(ByVal strUserID As String) As String
            BL.Server.ServerDefault()
            Return PasswordDecrypt(DL.UserAccess.GetPassword(strUserID))
        End Function

        Public Shared Sub ChangePassword(ByVal strUserID As String, ByVal strCurrenctPassword As String, ByVal strNewPassword As String)
            If GetPassword(strUserID) <> strCurrenctPassword Then
                Err.Raise(515, "", "Cannot Save. Current Password Wrong")
            Else
                BL.Server.ServerDefault()
                DL.UserAccess.ChangePassword(strUserID, PasswordEncrypt(strNewPassword))

                Dim dtDB As New DataTable
                dtDB = DL.Server.ServerList
                For Each drDB As DataRow In dtDB.Rows
                    BL.Server.SetServer(drDB.Item("Server"), drDB.Item("DBName"), drDB.Item("UserID"), drDB.Item("UserPassword"))
                    DL.UserAccess.ChangePassword(strUserID, PasswordEncrypt(strNewPassword))
                Next
            End If
        End Sub

        Public Shared Function CheckAccess(ByVal strUserID As String, strDelegateUserID As String, ByVal strProgramID As String, ByVal intComLocDivSubDivID As Integer, ByVal strModuleID As String, ByVal strAccessCode As String) As Boolean
            BL.Server.ServerDefault()
            Dim bolAccess As Boolean
            'Dim strDelegatedUserID As String = ""
            bolAccess = DL.UserAccess.CheckAccess(strUserID, strProgramID, intComLocDivSubDivID, strModuleID, strAccessCode)

            If Not bolAccess And strDelegateUserID <> "" Then
                bolAccess = DL.UserAccess.CheckAccess(strDelegateUserID, strProgramID, intComLocDivSubDivID, strModuleID, strAccessCode)
            End If

            Return bolAccess
        End Function

        Public Shared Sub AccessFillRight()
            BL.Server.ServerDefault()
            DL.UserAccess.AccessFillRight("CPS.X.1")
        End Sub

        Public Shared Function IsValidDelegatedUserID(ByVal strUserID As String, ByVal strDelegatedUserID As String, ByVal dtmPeriod As DateTime) As Boolean
            BL.Server.ServerDefault()
            Return DL.UserAccess.IsValidDelegatedUserID(strUserID, strDelegatedUserID, dtmPeriod)
        End Function

        Public Shared Function GetDelegatedFrom(ByVal strUserID As String, ByVal dtmPeriod As DateTime) As String
            BL.Server.ServerDefault()
            Return DL.UserAccess.GetDelegatedFrom(strUserID, dtmPeriod)
        End Function

        Public Shared Function GetDelegatedUserID(ByVal strUserID As String, ByVal dtmPeriod As DateTime, ByVal strLogBy As String) As String
            BL.Server.ServerDefault()
            Return DL.UserAccess.GetDelegatedUserID(strUserID, dtmPeriod, strLogBy)
        End Function

        Public Shared Function GetUserIDByLegacyUser(ByVal strCompanyID As String, ByVal strLegacyUser As String) As String
            BL.Server.SetServer(strCompanyID)
            Return DL.UserAccess.GetUserIDByLegacyUser(strLegacyUser)
        End Function

        Public Shared Function GetUserEmail(ByVal strUserID As String) As String
            BL.Server.ServerDefault()
            Return DL.UserAccess.GetUserEmail(strUserID)
        End Function

        Private Shared Function PasswordDecrypt(ByVal strText As String) As String
            Dim strKey As String
            Dim intI As Integer
            Dim strResult As String = ""
            If Len(strText) < 50 Then Return ""
            strKey = Microsoft.VisualBasic.Right(strText, 50)
            For intI = 1 To Len(strKey)
                If intI > Len(strText) Then
                    strResult &= Chr(255 - Asc(Mid(strKey, intI, 1)))
                ElseIf Mid(strText, intI, 1) = Chr(255 - Asc(Mid(strKey, intI, 1))) Then
                    strResult &= ""
                Else
                    strResult &= Chr(Asc(Mid(strText, intI, 1)) - Asc(Mid(strKey, intI, 1)))
                End If
            Next
            Return strResult
        End Function

        Private Shared Function PasswordEncrypt(ByVal strText As String) As String
            Dim strKey As String = RandomBigString()
            Dim intI As Integer
            Dim strResult As String = ""
            For intI = 1 To Len(strKey)
                If intI <= Len(strText) Then
                    strResult &= Chr(Asc(Mid(strText, intI, 1)) + Asc(Mid(strKey, intI, 1)))
                Else
                    strResult &= Chr(255 - Asc(Mid(strKey, intI, 1)))
                End If
            Next
            strResult &= strKey
            Return strResult
        End Function

        Private Shared Function RandomBigString() As String
            Const Numcharacters As Integer = 50
            Dim intI As Integer
            Dim intRand As Integer
            Dim strText As String = ""
            Dim oRand As New Random
            For intI = 1 To Numcharacters
                intRand = oRand.Next(100)
                If intRand < 15 Then
                    strText &= " "
                ElseIf intRand < 20 Then
                    strText &= Mid("aeiou", oRand.Next(1, 5), 1)
                Else
                    strText &= Chr(oRand.Next(97, 122))
                End If
            Next
            Return strText
        End Function

        Public Shared Sub CopyGlobalSetting()
            BL.Server.ServerDefault()
            DL.UserAccess.CopyProgramList()
            DL.UserAccess.CopyModuleList()
            DL.UserAccess.CopyAccessLevel()
            DL.UserAccess.CopyProgramMenu()
            DL.UserAccess.CopyProgramMenuDetail()
        End Sub

        Public Shared Function GetProgramList() As DataTable
            BL.Server.ServerDefault()
            Return DL.UserAccess.GetProgramList
        End Function

        Public Shared Function GetModuleList() As DataTable
            BL.Server.ServerDefault()
            Return DL.UserAccess.GetModuleList
        End Function

        Public Shared Function GetAccessLevel() As DataTable
            BL.Server.ServerDefault()
            Return DL.UserAccess.GetAccessLevel
        End Function

        Public Shared Function GetProgramMenu() As DataTable
            BL.Server.ServerDefault()
            Return DL.UserAccess.GetProgramMenu
        End Function

        Public Shared Function GetProgramMenuDetail() As DataTable
            BL.Server.ServerDefault()
            Return DL.UserAccess.GetProgramMenuDetail
        End Function

        Public Shared Sub CopyUserList(ByVal strNewUserID As String, ByVal strLegacyUserID As String)
            Dim dtDB As New DataTable
            Dim dtAll As New DataTable
            Dim dtUserListDetail As New DataTable

            BL.Server.ServerDefault()
            dtDB = BL.Server.ServerList

            For Each drDB As DataRow In dtDB.Rows
                DL.SQL.strServer = drDB.Item("Server")
                DL.SQL.strDatabase = drDB.Item("DBName")
                DL.SQL.strSAID = drDB.Item("UserID")
                DL.SQL.strSAPassword = drDB.Item("UserPassword")
                dtUserListDetail = DL.UserAccess.GetUserListDetail(strLegacyUserID, drDB.Item("DBName"))
                dtAll.Merge(dtUserListDetail)
            Next

            If dtAll.Rows.Count > 0 Then
                Dim strUserMenu As String = ""
                BL.Server.ServerDefault()
                For Each drData As DataRow In dtAll.Rows
                    strUserMenu = DL.UserAccess.GetUserProgramMenu(strLegacyUserID, drData("ProgramID"))
                    DL.UserAccess.CopyUserListDetail(strNewUserID, drData("Sub_Div_Id"), drData("Com_Loc_Div_Id"), drData("ProgramId"), strUserMenu)
                Next
            End If
        End Sub

        Public Shared Function GetUserIDByLegacyUserForCopyUser(ByVal strLegacyUser As String) As String
            BL.Server.ServerDefault()
            Return DL.UserAccess.GetUserIDByLegacyUser(strLegacyUser)
        End Function

        Public Shared Function GetHeadID(ByVal strUserID As String) As String
            BL.Server.ServerDefault()
            Return DL.UserAccess.GetHeadID(strUserID)
        End Function

        Public Shared Function GetUserEmailList(ByVal strUserIDList As String) As String
            BL.Server.ServerDefault()
            Return DL.UserAccess.GetUserEmailList(strUserIDList)
        End Function
    End Class

End Namespace
