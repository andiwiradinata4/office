Namespace BL
    Public Class ImportMailType
        Public Shared Function ListData(ByVal bytMailTypeID As Byte) As DataTable
            BL.Server.ServerDefault() 
            Return DL.ImportMailType.ListData(bytMailTypeID)
        End Function

        Public Shared Function SaveData(ByVal bolNew as Boolean, ByVal clsData As VO.ImportMailType) As Byte
            BL.Server.ServerDefault() 
            Try
                DL.SQL.OpenConnection() 
                DL.SQL.BeginTransaction() 

                If bolNew Then 
                    clsData.MailTypeID = DL.ImportMailType.GetMaxID(clsData.MailTypeID)
                    If DL.ImportMailType.DataExists(clsData.MailTypeID) Then 
                        Err.Raise(515, "","Cannot Save. Data already exist") 
                    End If 
                End If 

                DL.ImportMailType.SaveData(bolNew, clsData) 

                DL.SQL.CommitTransaction() 
            Catch ex As Exception
                DL.SQL.RollBackTransaction() 
                Throw ex 
            Finally 
                DL.SQL.CloseConnection() 
            End Try
            Return clsData.MailTypeID
        End Function

        Public Shared Function GetDetail(ByVal bytMailTypeID As Byte) As VO.ImportMailType
            BL.Server.ServerDefault() 
            Return DL.ImportMailType.GetDetail(bytMailTypeID)
        End Function 

        Public Shared Sub DeleteData(ByVal bytMailTypeID As Byte)
            BL.Server.ServerDefault() 
            Try
                DL.SQL.OpenConnection() 
                DL.SQL.BeginTransaction() 

                'If DL.ImportMailType.XXX(bytMailTypeID) Then 
                '    Err.Raise(515,"","Cannot Delete. Data already used at XXX") 
                'Else 
                '    DL.ImportMailType.DeleteData(bytMailTypeID) 
                'End If 

                DL.SQL.CommitTransaction() 
            Catch ex As Exception
                DL.SQL.RollBackTransaction() 
                Throw ex 
            Finally 
                DL.SQL.CloseConnection() 
            End Try
        End Sub

        Public Shared Sub DeleteData_UpdateStatus(ByVal bytMailTypeID As Byte, ByVal strLogBy As String)
            BL.Server.ServerDefault() 
            Try
                DL.SQL.OpenConnection() 
                DL.SQL.BeginTransaction() 

                'If DL.ImportMailType.XXX(bytMailTypeID, strLogBy) Then 
                '    Err.Raise(515,"","Cannot Delete. Data already used at XXX") 
                'Else 
                DL.ImportMailType.DeleteData_UpdateStatus(bytMailTypeID, strLogBy)
                'End If 

                DL.SQL.CommitTransaction() 
            Catch ex As Exception
                DL.SQL.RollBackTransaction() 
                Throw ex 
            Finally 
                DL.SQL.CloseConnection() 
            End Try
        End Sub

    End Class 

End Namespace

