﻿Namespace BL
    Public Class DataTypeList
        Public Shared Function ListData(ByVal bolViewAll As Boolean) As DataTable
            BL.Server.ServerDefault()
            Return DL.DataTypeList.ListData(bolViewAll)
        End Function
    End Class
End Namespace
