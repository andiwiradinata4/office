Namespace BL

    Public Class Server

        Public Shared Function ServerList() As DataTable
            Return DL.Server.ServerList
        End Function

        Public Shared Sub ServerDefault()
            DL.SQL.strServer = VO.DefaultServer.Server
            DL.SQL.strDatabase = VO.DefaultServer.Database
            DL.SQL.strSAID = ""
            DL.SQL.strSAPassword = ""
        End Sub

        Public Shared Function ServerListForRFC(ByVal strDBMS As String) As DataTable
            BL.Server.ServerDefault()
            Return DL.Server.ServerListForRFC(strDBMS)
        End Function

        Public Shared Function CompanyIDForRFC(ByVal strDBMS As String) As DataTable
            DL.SQL.strServer = "172.18.3.12\sqlserver"
            DL.SQL.strDatabase = strDBMS
            DL.SQL.strSAID = ""
            DL.SQL.strSAPassword = ""
            Return DL.Server.CompanyIDForRFC
        End Function

        Public Shared Sub SetServer(ByVal strCompanyID As String)
            For Each dtRow As DataRow In VO.ServerList.ServerList.Rows
                If dtRow.Item("CompanyID") = strCompanyID Then
                    DL.SQL.strServer = dtRow.Item("Server")
                    DL.SQL.strDatabase = dtRow.Item("DBName")
                    DL.SQL.strSAID = dtRow.Item("UserID")
                    DL.SQL.strSAPassword = dtRow.Item("UserPassword")
                    Exit For
                End If
            Next
        End Sub

        Public Shared Sub SetServer(ByVal strServer As String, ByVal strDBName As String, ByVal strUserID As String, ByVal strUserPassword As String)
            DL.SQL.strServer = strServer
            DL.SQL.strDatabase = strDBName
            DL.SQL.strSAID = strUserID
            DL.SQL.strSAPassword = strUserPassword
        End Sub

        Public Shared Sub SetServerAndDBMS(ByVal strServer As String, ByVal strDBName As String)
            DL.SQL.strServer = strServer
            DL.SQL.strDatabase = strDBName
        End Sub

    End Class

End Namespace
