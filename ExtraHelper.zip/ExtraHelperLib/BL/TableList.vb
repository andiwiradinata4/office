﻿Namespace BL
    Public Class TableList
        Public Shared Function ListData(ByVal strServerName As String, ByVal strDBMSName As String) As DataTable
            BL.Server.SetServerAndDBMS(strServerName, strDBMSName)
            Return DL.TableList.ListData()
        End Function

        Public Shared Function ExecuteScriptF6(ByVal drvData As DataRowView, ByVal strScripts As String, ByVal strServerType As String) As DataTable
            Dim dtData As New DataTable, dtFilter As New DataTable
            Dim drFilter() As DataRow
            Dim strDBMS As String = drvData.Row.Item("DBMS")
            Dim strCompanyID As String = drvData.Row.Item("CompanyID")
            Dim strFilterExpression As String = "DBMS='" & drvData.Row.Item("DBMS") & "'"
            Dim strFilterExpressionKPA As String = "DBMS='KPA_" & drvData.Row.Item("DBMS") & "'"

            '# Combine Filter Expression for using Select Data in DataTable
            If strCompanyID.Trim <> "All Company" Then
                strFilterExpression += " AND CompanyID='" & strCompanyID.Trim & "'"
                strFilterExpressionKPA += " AND CompanyID='" & strCompanyID.Trim & "'"
            End If

            If strServerType.Trim <> "All" Then
                strFilterExpression += " AND ServerType='" & strServerType.Trim & "'"
                strFilterExpressionKPA += " AND ServerType='" & strServerType.Trim & "'"
            End If

            dtFilter = VO.DefaultServer.AllServers.Clone

            drFilter = VO.DefaultServer.AllServers.Select(strFilterExpression)
            '# Import All Selected Rows
            For Each row In drFilter
                dtFilter.ImportRow(row)
            Next

            drFilter = VO.DefaultServer.AllServers.Select(strFilterExpressionKPA)
            '# Import All Selected Rows KPA
            For Each row In drFilter
                dtFilter.ImportRow(row)
            Next

            '# Grouping DataTable
            Dim clsHelper As New DataSetHelper
            Dim dtGroup As New DataTable
            dtGroup = clsHelper.SelectGroupByInto("Group", dtFilter, "Server, DBMS", "", "Server, DBMS")

            '# Run Scripts
            For Each drServer As DataRow In dtGroup.Rows
                BL.Server.SetServerAndDBMS(drServer.Item("Server"), drServer.Item("DBMS"))
                dtData.Merge(DL.TableList.ExecuteScriptF6(strScripts))
            Next

            Return dtData
        End Function
    End Class
End Namespace

