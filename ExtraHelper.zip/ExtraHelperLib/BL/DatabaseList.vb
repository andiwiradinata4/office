﻿Namespace BL
    Public Class DatabaseList
        Public Shared Function ListData(ByVal strServerName As String) As DataTable
            BL.Server.ServerDefault()
            Return DL.DatabaseList.ListData()
        End Function
    End Class
End Namespace

