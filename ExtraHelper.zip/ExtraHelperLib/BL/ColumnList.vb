﻿Namespace BL

    Public Class ColumnList
        Public Shared Function ListData(ByVal strTableName As String, ByVal cls As VO.UserSelection) As DataTable
            BL.Server.SetServerAndDBMS(cls.Server, cls.Database)
            Return DL.ColumnList.ListData(strTableName)
        End Function

        Public Shared Function ListDataPK(ByVal strTableName As String, ByVal cls As VO.UserSelection) As DataTable
            BL.Server.SetServerAndDBMS(cls.Server, cls.Database)
            Return DL.ColumnList.ListDataPK(strTableName)
        End Function

        Public Shared Function ListDataTop1PK(ByVal strTableName As String, ByVal cls As VO.UserSelection) As DataTable
            BL.Server.SetServerAndDBMS(cls.Server, cls.Database)
            Return DL.ColumnList.ListDataTop1PK(strTableName)
        End Function

        Public Shared Function GetTop1PK(ByVal strTableName As String, ByVal cls As VO.UserSelection) As String
            BL.Server.SetServerAndDBMS(cls.Server, cls.Database)
            Return DL.ColumnList.GetTop1PK(strTableName)
        End Function

        Public Shared Function ListDataDesc(ByVal strTableName As String, ByVal cls As VO.UserSelection) As DataTable
            BL.Server.SetServerAndDBMS(cls.Server, cls.Database)
            Return DL.ColumnList.ListDataDesc(strTableName)
        End Function

        Public Shared Function ListDataScript(ByVal cls As VO.UserSelection) As DataTable
            BL.Server.SetServerAndDBMS(cls.Server, cls.Database)
            Return DL.ColumnList.ListDataScript()
        End Function

    End Class

End Namespace

