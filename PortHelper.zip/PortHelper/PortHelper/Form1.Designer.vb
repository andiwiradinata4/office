﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.tlpMain = New System.Windows.Forms.TableLayoutPanel()
        Me.pnlLeft = New DevExpress.XtraEditors.PanelControl()
        Me.pnlRight = New DevExpress.XtraEditors.PanelControl()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.cboPortName = New System.Windows.Forms.ComboBox()
        Me.txtDataBits = New System.Windows.Forms.NumericUpDown()
        Me.txtBaudRate = New System.Windows.Forms.NumericUpDown()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cboStopBits = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cboParity = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnStartTimer = New System.Windows.Forms.Button()
        Me.rtbResult = New System.Windows.Forms.RichTextBox()
        Me.btnStopTimer = New System.Windows.Forms.Button()
        Me.tmrPort = New System.Windows.Forms.Timer(Me.components)
        Me.btnReload = New System.Windows.Forms.Button()
        Me.txtInterval = New System.Windows.Forms.NumericUpDown()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.tlpMain.SuspendLayout()
        CType(Me.pnlLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlLeft.SuspendLayout()
        CType(Me.pnlRight, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlRight.SuspendLayout()
        CType(Me.txtDataBits, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtBaudRate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtInterval, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'tlpMain
        '
        Me.tlpMain.ColumnCount = 2
        Me.tlpMain.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.0!))
        Me.tlpMain.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70.0!))
        Me.tlpMain.Controls.Add(Me.pnlLeft, 0, 0)
        Me.tlpMain.Controls.Add(Me.pnlRight, 1, 0)
        Me.tlpMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpMain.Location = New System.Drawing.Point(0, 0)
        Me.tlpMain.Name = "tlpMain"
        Me.tlpMain.RowCount = 1
        Me.tlpMain.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpMain.Size = New System.Drawing.Size(760, 493)
        Me.tlpMain.TabIndex = 0
        '
        'pnlLeft
        '
        Me.pnlLeft.Controls.Add(Me.txtInterval)
        Me.pnlLeft.Controls.Add(Me.Label6)
        Me.pnlLeft.Controls.Add(Me.btnReload)
        Me.pnlLeft.Controls.Add(Me.btnStopTimer)
        Me.pnlLeft.Controls.Add(Me.btnStartTimer)
        Me.pnlLeft.Controls.Add(Me.btnClear)
        Me.pnlLeft.Controls.Add(Me.cboPortName)
        Me.pnlLeft.Controls.Add(Me.txtDataBits)
        Me.pnlLeft.Controls.Add(Me.txtBaudRate)
        Me.pnlLeft.Controls.Add(Me.Label1)
        Me.pnlLeft.Controls.Add(Me.Label2)
        Me.pnlLeft.Controls.Add(Me.cboStopBits)
        Me.pnlLeft.Controls.Add(Me.Label3)
        Me.pnlLeft.Controls.Add(Me.Label5)
        Me.pnlLeft.Controls.Add(Me.cboParity)
        Me.pnlLeft.Controls.Add(Me.Label4)
        Me.pnlLeft.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlLeft.Location = New System.Drawing.Point(3, 3)
        Me.pnlLeft.Name = "pnlLeft"
        Me.pnlLeft.Size = New System.Drawing.Size(222, 487)
        Me.pnlLeft.TabIndex = 0
        '
        'pnlRight
        '
        Me.pnlRight.Controls.Add(Me.rtbResult)
        Me.pnlRight.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlRight.Location = New System.Drawing.Point(231, 3)
        Me.pnlRight.Name = "pnlRight"
        Me.pnlRight.Size = New System.Drawing.Size(526, 487)
        Me.pnlRight.TabIndex = 1
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(11, 256)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(200, 23)
        Me.btnClear.TabIndex = 8
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'cboPortName
        '
        Me.cboPortName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPortName.Location = New System.Drawing.Point(89, 9)
        Me.cboPortName.Name = "cboPortName"
        Me.cboPortName.Size = New System.Drawing.Size(124, 21)
        Me.cboPortName.TabIndex = 0
        '
        'txtDataBits
        '
        Me.txtDataBits.Location = New System.Drawing.Point(89, 63)
        Me.txtDataBits.Maximum = New Decimal(New Integer() {99999999, 0, 0, 0})
        Me.txtDataBits.Name = "txtDataBits"
        Me.txtDataBits.Size = New System.Drawing.Size(124, 21)
        Me.txtDataBits.TabIndex = 2
        Me.txtDataBits.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtDataBits.Value = New Decimal(New Integer() {8, 0, 0, 0})
        '
        'txtBaudRate
        '
        Me.txtBaudRate.Location = New System.Drawing.Point(89, 36)
        Me.txtBaudRate.Maximum = New Decimal(New Integer() {99999999, 0, 0, 0})
        Me.txtBaudRate.Name = "txtBaudRate"
        Me.txtBaudRate.Size = New System.Drawing.Size(124, 21)
        Me.txtBaudRate.TabIndex = 1
        Me.txtBaudRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtBaudRate.Value = New Decimal(New Integer() {9600, 0, 0, 0})
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(57, 13)
        Me.Label1.TabIndex = 20
        Me.Label1.Text = "Port Name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(13, 38)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(57, 13)
        Me.Label2.TabIndex = 23
        Me.Label2.Text = "Baud Rate"
        '
        'cboStopBits
        '
        Me.cboStopBits.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboStopBits.Items.AddRange(New Object() {"1", "1.5", "2"})
        Me.cboStopBits.Location = New System.Drawing.Point(89, 117)
        Me.cboStopBits.Name = "cboStopBits"
        Me.cboStopBits.Size = New System.Drawing.Size(124, 21)
        Me.cboStopBits.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(13, 64)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(50, 13)
        Me.Label3.TabIndex = 26
        Me.Label3.Text = "Data Bits"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(13, 120)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(49, 13)
        Me.Label5.TabIndex = 29
        Me.Label5.Text = "Stop Bits"
        '
        'cboParity
        '
        Me.cboParity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboParity.Items.AddRange(New Object() {"0 - NONE", "1 - ODD", "2 - EVEN", "3 - MARK", "4 - SPACE"})
        Me.cboParity.Location = New System.Drawing.Point(89, 90)
        Me.cboParity.Name = "cboParity"
        Me.cboParity.Size = New System.Drawing.Size(124, 21)
        Me.cboParity.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(13, 93)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(35, 13)
        Me.Label4.TabIndex = 28
        Me.Label4.Text = "Parity"
        '
        'btnStartTimer
        '
        Me.btnStartTimer.Location = New System.Drawing.Point(13, 198)
        Me.btnStartTimer.Name = "btnStartTimer"
        Me.btnStartTimer.Size = New System.Drawing.Size(200, 23)
        Me.btnStartTimer.TabIndex = 6
        Me.btnStartTimer.Text = "Start Timer"
        Me.btnStartTimer.UseVisualStyleBackColor = True
        '
        'rtbResult
        '
        Me.rtbResult.Dock = System.Windows.Forms.DockStyle.Fill
        Me.rtbResult.Location = New System.Drawing.Point(2, 2)
        Me.rtbResult.Name = "rtbResult"
        Me.rtbResult.Size = New System.Drawing.Size(522, 483)
        Me.rtbResult.TabIndex = 0
        Me.rtbResult.Text = ""
        '
        'btnStopTimer
        '
        Me.btnStopTimer.Location = New System.Drawing.Point(11, 227)
        Me.btnStopTimer.Name = "btnStopTimer"
        Me.btnStopTimer.Size = New System.Drawing.Size(200, 23)
        Me.btnStopTimer.TabIndex = 7
        Me.btnStopTimer.Text = "Stop Timer"
        Me.btnStopTimer.UseVisualStyleBackColor = True
        '
        'tmrPort
        '
        '
        'btnReload
        '
        Me.btnReload.Location = New System.Drawing.Point(11, 285)
        Me.btnReload.Name = "btnReload"
        Me.btnReload.Size = New System.Drawing.Size(200, 23)
        Me.btnReload.TabIndex = 9
        Me.btnReload.Text = "Reload"
        Me.btnReload.UseVisualStyleBackColor = True
        '
        'txtInterval
        '
        Me.txtInterval.Location = New System.Drawing.Point(89, 144)
        Me.txtInterval.Maximum = New Decimal(New Integer() {99999999, 0, 0, 0})
        Me.txtInterval.Name = "txtInterval"
        Me.txtInterval.Size = New System.Drawing.Size(124, 21)
        Me.txtInterval.TabIndex = 5
        Me.txtInterval.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtInterval.Value = New Decimal(New Integer() {1000, 0, 0, 0})
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(13, 146)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(45, 13)
        Me.Label6.TabIndex = 32
        Me.Label6.Text = "Interval"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(760, 493)
        Me.Controls.Add(Me.tlpMain)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Name = "frmMain"
        Me.Text = "Main"
        Me.tlpMain.ResumeLayout(False)
        CType(Me.pnlLeft, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlLeft.ResumeLayout(False)
        Me.pnlLeft.PerformLayout()
        CType(Me.pnlRight, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlRight.ResumeLayout(False)
        CType(Me.txtDataBits, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtBaudRate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtInterval, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents tlpMain As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents pnlLeft As DevExpress.XtraEditors.PanelControl
    Friend WithEvents pnlRight As DevExpress.XtraEditors.PanelControl
    Friend WithEvents btnStartTimer As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents cboPortName As System.Windows.Forms.ComboBox
    Friend WithEvents txtDataBits As System.Windows.Forms.NumericUpDown
    Friend WithEvents txtBaudRate As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cboStopBits As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents cboParity As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents rtbResult As System.Windows.Forms.RichTextBox
    Friend WithEvents btnStopTimer As System.Windows.Forms.Button
    Friend WithEvents tmrPort As System.Windows.Forms.Timer
    Friend WithEvents btnReload As System.Windows.Forms.Button
    Friend WithEvents txtInterval As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label6 As System.Windows.Forms.Label

End Class
