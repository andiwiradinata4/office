﻿Imports System.IO.Ports
Public Class frmMain
    Private ioPort As SerialPort

    Private Sub ReadPortName()
        cboPortName.Items.Clear()
        Dim AllPortName As String() = SerialPort.GetPortNames()
        For Each portName As String In AllPortName
            cboPortName.Items.Add(portName.Trim)
        Next
        cboPortName.SelectedIndex = 0
        txtBaudRate.Value = 9600
        txtDataBits.Value = 8
        cboParity.SelectedIndex = 0
        cboStopBits.SelectedIndex = 0
    End Sub

    Private Sub SettingSerialPort()
        ioPort = New SerialPort
        Try
            With ioPort
                .DtrEnable = True
                .PortName = cboPortName.Text.Trim
                .BaudRate = txtBaudRate.Value
                .DataBits = txtDataBits.Value

                Select Case cboParity.SelectedIndex
                    Case 0 : .Parity = IO.Ports.Parity.None
                    Case 1 : .Parity = IO.Ports.Parity.Odd
                    Case 2 : .Parity = IO.Ports.Parity.Even
                    Case 3 : .Parity = IO.Ports.Parity.Mark
                    Case 4 : .Parity = IO.Ports.Parity.Space
                End Select

                Select Case cboStopBits.SelectedIndex
                    Case 0 : .StopBits = IO.Ports.StopBits.One
                    Case 1 : .StopBits = IO.Ports.StopBits.OnePointFive
                    Case 2 : .StopBits = IO.Ports.StopBits.Two
                End Select
            End With
            rtbResult.Text += "SETTING PORT " & ioPort.PortName & " ... "
            rtbResult.Text += vbCrLf
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Setting Serial Port")
            tmrPort.Stop()
        End Try
    End Sub

    Private Sub OpenIO()
        Try
            ioPort.Open()
            rtbResult.Text += "======================================" & vbCrLf
            rtbResult.Text += "OPEN PORT " & ioPort.PortName & " ... " & vbCrLf
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Open Serial Port")
            tmrPort.Stop()
        End Try
    End Sub

    Private Sub CloseIO()
        Try
            If (ioPort.IsOpen) Then
                ioPort.Close()
            End If
            rtbResult.Text += "CLOSE PORT " & ioPort.PortName & " ... " & vbCrLf
            rtbResult.Text += "======================================" & vbCrLf
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Close Serial Port")
            tmrPort.Stop()
        End Try
    End Sub

    Private Sub ReadExisting()
        Try
            rtbResult.Text += "READ PORT " & ioPort.PortName & " ... " & vbCrLf
            Dim strValue As String = ioPort.ReadExisting
            rtbResult.Text += "READ VALUE -> " & strValue
            rtbResult.Text += vbCrLf
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Read Existing")
            tmrPort.Stop()
        End Try
    End Sub

#Region "Form Handle"

    Private Sub btnStartTimer_Click(sender As Object, e As EventArgs) Handles btnStartTimer.Click
        SettingSerialPort()
        OpenIO()
        tmrPort.Interval = txtInterval.Value
        tmrPort.Start()
    End Sub

    Private Sub btnStopTimer_Click(sender As Object, e As EventArgs) Handles btnStopTimer.Click
        tmrPort.Stop()
        CloseIO()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        rtbResult.Text = ""
    End Sub

    Private Sub tmrPort_Tick(sender As Object, e As EventArgs) Handles tmrPort.Tick
        ReadExisting()
    End Sub

    Private Sub btnReload_Click(sender As Object, e As EventArgs) Handles btnReload.Click
        ReadPortName()
    End Sub

#End Region
    
End Class
