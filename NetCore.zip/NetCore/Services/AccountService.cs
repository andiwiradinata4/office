﻿
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using NetCore.Models;
using NetCore.Models.dto.Account;
using NetCore.Repositories.Interfaces;
using NetCore.Services.Interfaces;
using NetCore.usException;
using NetCore.Utilities;
using Newtonsoft.Json.Linq;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace NetCore.Services
{
    public class AccountService : IAccountService
    {
        private readonly UserManager<AppUser> _userManager;
        private readonly SignInManager<AppUser> _signInManager;
        private readonly IConfiguration _configuration;
        private readonly SymmetricSecurityKey _key;
        private readonly IAccountRepository _repo;
        public AccountService(UserManager<AppUser> userManager, SignInManager<AppUser> signInManager, IConfiguration configuration, IAccountRepository repo)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _configuration = configuration;
            _key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JWT:SigningKey"] ?? ""));
            _repo = repo;
        }

        public async Task<MessageObject<TokenDTO>> Register(RegisterDTO dto)
        {
            string errorMessage = "";
            MessageObject<TokenDTO> messageObject = new MessageObject<TokenDTO>();

            var user = new AppUser
            {
                UserName = dto.Username,
                Email = dto.Email,
                PhoneNumber = dto.PhoneNumber,
            };

            try
            {
                if (messageObject.ProcessingStatus)
                {
                    var createUser = await _userManager.CreateAsync(user, dto.Password ?? "");
                    if (createUser.Succeeded)
                    {
                        var roleResult = await _userManager.AddToRoleAsync(user, "User");
                        if (roleResult.Succeeded)
                        {
                            messageObject.Data = CreateJWTToken(user);

                            /// Log Success
                            return messageObject;
                        }
                        else
                        {
                            foreach (var error in roleResult.Errors)
                            {
                                errorMessage += error.Description + " | ";
                            }
                            if (errorMessage.Length > 0) errorMessage = errorMessage.Substring(0, errorMessage.Length - 3);
                            messageObject.AddMessage(new Message(MessageType.Error, "Invalid Role", errorMessage));
                        }
                    }
                    else
                    {
                        foreach (var error in createUser.Errors)
                        {
                            errorMessage += error.Description + " | ";
                        }
                        if (errorMessage.Length > 0) errorMessage = errorMessage.Substring(0, errorMessage.Length - 3);
                        messageObject.AddMessage(new Message(MessageType.Error, "Invalid User", errorMessage));
                        /// Log Error
                    }
                }
            }
            catch (Exception ex)
            {
                /// Log Error
                messageObject.AddException(ex);
            }
            return messageObject;
        }

        public async Task<MessageObject<TokenDTO>> Login(LoginDTO dto)
        {
            MessageObject<TokenDTO> messageObject = new MessageObject<TokenDTO>();
            try
            {
                var user = await _userManager.Users.FirstOrDefaultAsync(x => x.UserName == dto.UserName.ToLower());
                if (user == null)
                {
                    messageObject.AddMessage(new Message(MessageType.Error, "Unauthorized", "Invalid username.", "Username"));
                    return messageObject;
                }

                var result = await _signInManager.CheckPasswordSignInAsync(user, dto.Password, false);
                if (!result.Succeeded)
                {
                    messageObject.AddMessage(new Message(MessageType.Error, "Unauthorized", "Password Incorrect", "Password"));
                    return messageObject;
                }

                if (messageObject.ProcessingStatus)
                {
                    var token = CreateJWTToken(user);
                    var resultSetAuthentication = await _userManager.SetAuthenticationTokenAsync(user, token.Issuer, token.UserName, token.AccessToken);
                    if (resultSetAuthentication.Succeeded)
                    {
                        messageObject.Data = token;
                    }
                    else
                    {
                        messageObject.AddMessage(new Message(MessageType.Error, "Unauthorized", resultSetAuthentication.Errors.First().Description));
                    }
                }
            }
            catch (Exception ex)
            {
                /// Log Error
                messageObject.AddException(ex);
            }
            return messageObject;

        }

        public async Task<MessageObject<TokenDTO>> RefreshToken(string refreshToken)
        {
            MessageObject<TokenDTO> messageObject = new MessageObject<TokenDTO>();
            try
            {
                var token = _repo.GetToken(refreshToken);
                if (token == null)
                {
                    messageObject.AddMessage(new Message(MessageType.Error, "Unauthorized", "Invalid Refresh Token."));
                    return messageObject;
                }

                var user = await _userManager.FindByIdAsync(token.UserID);
                if (user == null)
                {
                    messageObject.AddMessage(new Message(MessageType.Error, "Unauthorized", "User is not valid."));
                    return messageObject;
                }

                var newToken = CreateJWTToken(user);
                var resultSetAuthentication = await _userManager.SetAuthenticationTokenAsync(user, newToken.Issuer, newToken.UserName, newToken.AccessToken);
                if (resultSetAuthentication.Succeeded)
                {
                    messageObject.Data = newToken;
                }
                else
                {
                    messageObject.AddMessage(new Message(MessageType.Error, "Unauthorized", resultSetAuthentication.Errors.First().Description));
                }
            }
            catch (Exception ex)
            {
                /// Log Error
                messageObject.AddException(ex);
            }
            return messageObject;

        }

        public async Task<MessageObject<AppUser>> GetDetailUser(string userId)
        {
            MessageObject<AppUser> messageObject = new MessageObject<AppUser>();
            var user = await _userManager.FindByIdAsync(userId);
            if (user == null) messageObject.AddMessage(new Message(MessageType.Error, "Invalid User", "User not found."));
            if (messageObject.ProcessingStatus) messageObject.Data = user!;
            return messageObject;
        }

        public async Task<MessageObject<VerifyConfirmEmailDTO>> EmailConfirmationToken(string userId)
        {
            MessageObject<VerifyConfirmEmailDTO> messageObject = new MessageObject<VerifyConfirmEmailDTO>();
            var tokenType = "EMAIL_CONFIRMATION";
            var user = await _userManager.FindByIdAsync(userId);
            if (user == null)
            {
                messageObject.AddMessage(new Message(MessageType.Error, "Invalid User", "User not found."));
                return messageObject;
            }

            if (messageObject.ProcessingStatus)
            {
                var token = await _userManager.GenerateEmailConfirmationTokenAsync(user!);
                var code = GenerateCode(user, tokenType, token);
                messageObject.Data = new VerifyConfirmEmailDTO { Code = code, Token = token };
            }

            return messageObject;
        }

        public async Task<MessageObject<bool>> VerifyEmailConfirmationToken(string userId, VerifyConfirmEmailDTO dto)
        {
            MessageObject<bool> messageObject = new MessageObject<bool>();
            var tokenType = "EMAIL_CONFIRMATION";
            var user = await _userManager.FindByIdAsync(userId);
            if (user == null)
            {
                messageObject.AddMessage(new Message(MessageType.Error, "Invalid User", "User not found."));
                return messageObject;
            }


            var token = GetTokenAsync(dto.Token);
            if (token == null || token.TokenType != tokenType)
            {
                messageObject.AddMessage(new Message(MessageType.Error, "Invalid Token", "Token is not valid.", "Token"));
                return messageObject;
            }

            if (token.Code != dto.Code)
            {
                messageObject.AddMessage(new Message(MessageType.Error, "Invalid Code", "Code is not valid.", "Code"));
                return messageObject;
            }

            var result = await _userManager.ConfirmEmailAsync(user, token.TokenValue);
            if (result.Succeeded)
            {
                GenerateCode(user, tokenType, "SUCCESS");
                messageObject.Data = true;
            }
            else
            {
                messageObject.AddMessage(new Message(MessageType.Error, "Invalid Email Confirmation", result.Errors.First().Description));
            }
            return messageObject;
        }

        public async Task<MessageObject<VerifyConfirmEmailDTO>> ChangeEmailToken(string userId, string newEmail)
        {
            MessageObject<VerifyConfirmEmailDTO> messageObject = new MessageObject<VerifyConfirmEmailDTO>();
            var tokenType = "CHANGE_EMAIL";
            var user = await _userManager.FindByIdAsync(userId);
            if (user == null)
            {
                messageObject.AddMessage(new Message(MessageType.Error, "Invalid User", "User not found."));
                return messageObject;
            }

            var token = await _userManager.GenerateChangeEmailTokenAsync(user, newEmail);
            var code = GenerateCode(user, tokenType, token);
            messageObject.Data = new VerifyConfirmEmailDTO { Code = code, Token = token };
            return messageObject;
        }

        public Task<MessageObject<bool>> ChangeEmail(string userId, ChangeEmailDTO dto)
        {
            throw new NotImplementedException();
        }

        public TokenDTO CreateJWTToken(AppUser user)
        {
            var claims = new List<Claim> {
                new Claim(JwtRegisteredClaimNames.Sub, user.Id ?? ""),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(JwtRegisteredClaimNames.Name, user.UserName ?? ""),
                new Claim(JwtRegisteredClaimNames.Email, user.Email ?? ""),
                //new Claim(JwtRegisteredClaimNames.GivenName, user.UserName ?? "")
            };

            var creds = new SigningCredentials(_key, SecurityAlgorithms.HmacSha512Signature);

            //var token = new JwtSecurityToken
            //    (
            //        issuer: _configuration["JWT:Issuer"], 
            //        audience: _configuration["JWT:Audience"],
            //        claims: claims,
            //        expires: DateTime.Now.AddMinutes(15000),
            //        signingCredentials : creds
            //    );

            //var tokenHandler = new JwtSecurityTokenHandler();

            //var resultToken = tokenHandler.WriteToken(token);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims),
                Expires = DateTime.Now.AddMinutes(15000),
                SigningCredentials = creds,
                Issuer = _configuration["JWT:Issuer"],
                Audience = _configuration["JWT:Audience"]
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDescriptor);
            var resultToken = tokenHandler.WriteToken(token);
            var refreshToken = GenerateRefreshToken();

            TokenDTO usToken = new()
            {
                UserName = user.UserName ?? "",
                Email = user.Email ?? "",
                AccessToken = resultToken,
                ValidFrom = token.ValidFrom,
                ValidTo = token.ValidTo,
                RefreshToken = refreshToken,
                Issuer = _configuration["JWT:Issuer"] ?? "",
                Audience = _configuration["JWT:Audience"] ?? ""
            };

            if (user.Id == null) throw new Exception("User ID not Valid!");

            bool bolRefresToken = _repo.SaveToken(new Token()
            {
                UserID = user.Id,
                TokenType = "REFRESH_TOKEN",
                TokenValue = refreshToken,
                ValidFrom = DateTime.Today,
                ValidTo = DateTime.Today.AddYears(100),
            });

            if (!bolRefresToken) throw new Exception("Error when generate refresh token!");

            return usToken;
        }

        private static string GenerateRefreshToken()
        {
            var randomNumber = new byte[64];
            using var rng = RandomNumberGenerator.Create();
            rng.GetBytes(randomNumber);
            return Convert.ToBase64String(randomNumber);
        }

        public Token? GetTokenAsync(string token)
        {
            return _repo.GetToken(token);
        }

        public string GenerateCode(AppUser user, string tokenType, string token)
        {
            string code = "";
            Random rdm = new Random();
            for (int i = 0; i < 6; i++)
            {
                code += rdm.Next(0, 9).ToString();
            }

            bool bolSuccess = _repo.SaveToken(new Token()
            {
                UserID = user.Id,
                TokenType = tokenType,
                TokenValue = token,
                Code = code,
                ValidFrom = DateTime.Today,
                ValidTo = DateTime.Today.AddYears(100),
            });

            if (!bolSuccess) throw new Exception("Error Save Token.");
            return code;
        }

    }
}