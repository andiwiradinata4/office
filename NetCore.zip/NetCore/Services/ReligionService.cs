﻿using NetCore.Models;
using NetCore.Models.dto.Base;
using NetCore.Repositories.Interfaces;
using NetCore.Services.Interfaces;

namespace NetCore.Services
{
    public class ReligionService : IReligionService
    {
        private readonly IReligionRepository _repo;

        public ReligionService(IReligionRepository repo)
        {
            _repo = repo;
        }

        public async Task<List<Religion>> GetAllAsync(QueryObject query)
        {
            return await _repo.GetAllAsync(query);
        }

        public async Task<Religion> GetByIDAsync(dynamic id)
        {
            return await _repo.GetByIDAsync(id);
        }

        public async Task<Religion> DeleteAsync(dynamic id)
        {
            return await _repo.DeleteAsync(id);
        }

        public async Task<Religion> UpdateAsync(dynamic id, Religion data, string userId)
        {
            return await _repo.UpdateAsync(id, data);
        }

        public async Task<Religion> CreateAsync(Religion data, string userId)
        {
            data.ID = await _repo.GetMaxID();
            return await _repo.CreateAsync(data);
        }

        //public async Task<Religion> Create(Religion entity)
        //{
        //    entity.ID = await _repo.GetMaxID();
        //    return await _repo.Create(entity);
        //}
    }
}
