﻿using NetCore.Models;
using NetCore.Models.dto.Base;
using NetCore.Repositories.Interfaces;
using NetCore.Services.Interfaces;

namespace NetCore.Services
{
    public class GenderService : BaseService<Gender>, IGenderService
    {
        private readonly IGenderRepository _repo;

        public GenderService(IGenderRepository repo) : base(repo)
        {
            _repo = repo;
        }

        //public async Task<List<Gender>> GetAllAsync(QueryObject query)
        //{
        //    return await _repo.GetAllAsync(query);
        //}

        //public async Task<Gender> GetByIDAsync(dynamic Id)
        //{
        //    return await _repo.GetByIDAsync(Id);
        //}

        //public async Task<Gender> DeleteAsync(dynamic Id)
        //{
        //    return await _repo.DeleteAsync(Id);
        //}

        //public async Task<Gender> CreateAsync(Gender data, string userId)
        //{
        //    return await _repo.CreateAsync(data);
        //}

        //public async Task<Gender> UpdateAsync(dynamic Id, Gender data, string userId)
        //{
        //    return await _repo.UpdateAsync(Id, data);
        //}

        //public async Task<Gender> Create(Gender entity)
        //{
        //    entity.Id = await _repo.GetMaxId();
        //    return await _repo.Create(entity);
        //}
    }
}
