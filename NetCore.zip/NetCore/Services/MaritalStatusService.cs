﻿using NetCore.Models;
using NetCore.Models.dto.Base;
using NetCore.Repositories.Interfaces;
using NetCore.Services.Interfaces;

namespace NetCore.Services
{
    public class MaritalStatusService : BaseService<MaritalStatus>, IMaritalStatusService
    {
        private readonly IMaritalStatusRepository _repo;

        public MaritalStatusService(IMaritalStatusRepository repo) : base(repo)
        {
            _repo = repo;
        }

        //public async Task<List<MaritalStatus>> GetAllAsync(QueryObject query)
        //{
        //    return await _repo.GetAllAsync(query);
        //}

        //public async Task<MaritalStatus> GetByIDAsync(dynamic id)
        //{
        //    return await _repo.GetByIDAsync(id);
        //}

        //public async Task<MaritalStatus> DeleteAsync(dynamic id)
        //{
        //    return await _repo.DeleteAsync(id);
        //}

        //public async Task<MaritalStatus> CreateAsync(MaritalStatus data, string userId)
        //{
        //    data.ID = await _repo.GetMaxID();
        //    return await _repo.CreateAsync(data);
        //}

        //public async Task<MaritalStatus> UpdateAsync(dynamic id, MaritalStatus data, string userId)
        //{
        //    return await _repo.UpdateAsync(id, data);
        //}

        //public async Task<MaritalStatus> Create(MaritalStatus entity)
        //{
        //    entity.ID = await _repo.GetMaxID();
        //    return await _repo.Create(entity);
        //}
    }
}
