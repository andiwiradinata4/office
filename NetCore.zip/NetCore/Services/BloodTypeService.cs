﻿using NetCore.Models;
using NetCore.Models.dto.Base;
using NetCore.Repositories.Interfaces;
using NetCore.Services.Interfaces;

namespace NetCore.Services
{
    public class BloodTypeService : IBloodTypeService
    {
        private readonly IBloodTypeRepository _repo;

        public BloodTypeService(IBloodTypeRepository repo) 
        {
            _repo = repo;
        }

        public async Task<List<BloodType>> GetAllAsync(QueryObject query)
        {
            return await _repo.GetAllAsync(query);
        }
        
        public async Task<BloodType> GetByIDAsync(dynamic id)
        {
            return await _repo.GetByIDAsync(id);
        }

        public async Task<BloodType> DeleteAsync(dynamic id)
        {
            return await _repo.DeleteAsync(id);
        }

        public async Task<BloodType> CreateAsync(BloodType data, string userId)
        {
            data.ID = await _repo.GetMaxID();
            return await _repo.CreateAsync(data);
        }

        public async Task<BloodType> UpdateAsync(dynamic id, BloodType data, string userId)
        {
            return await _repo.UpdateAsync(id, data);
        }

        public async Task<object> GetAllWithJoinAsync()
        {
            return await _repo.GetAllWithJoinAsync();
        }

        //public async Task<BloodType> CreateAsync(BloodType entity)
        //{
        //    entity.ID = await _repo.GetMaxID();
        //    return await _repo.CreateAsync(entity);
        //}
    }
}
