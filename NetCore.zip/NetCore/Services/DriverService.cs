﻿using NetCore.Models;
using NetCore.Models.dto.Base;
using NetCore.Repositories.Interfaces;
using NetCore.Services.Interfaces;
using NetCore.usDBContext;

namespace NetCore.Services
{
    public class DriverService : BaseService<Driver>, IDriverService
    {
        private readonly IDriverRepository _repo;
        private readonly AppDBContext _context;

        //using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
        //{}

        // https://dzone.com/articles/upload-single-and-multiple-files-using-the-net-cor -> Link for upload file

        public DriverService(IDriverRepository repo, AppDBContext context) : base(repo)
        {
            _repo = repo;
            _context = context;
        }

        //public async Task<List<Driver>> GetAllAsync(QueryObject query)
        //{
        //    return await _repo.GetAllAsync(query);
        //}

        //public async Task<Driver> GetByIDAsync(dynamic id)
        //{
        //    return await _repo.GetByIDAsync(id);
        //}

        //public async Task<Driver> DeleteAsync(dynamic id)
        //{
        //    return await _repo.DeleteAsync(id);
        //}

        //public async Task<Driver> CreateAsync(Driver entity, string userId)
        //{
        //    using (var transaction = await _context.Database.BeginTransactionAsync())
        //    {
        //        try
        //        {
        //            string initial = await _repo.GetComLocInitialAsync(entity.CreatedFromComLocID) + "-";
        //            int max = await _repo.GetMaxID(initial);
        //            entity.ID = initial + max.ToString("D4");
        //            entity.CreatedBy = userId;
        //            entity.LogBy = userId;

        //            entity.DriverStatuses = new List<DriverStatus>();
        //            var data = await _repo.CreateAsync(entity, true);

        //            /// Add Images
        //            if (entity.DriverImages != null && entity.DriverImages.Count > 0) await _repo.CreateImageAsync(entity.DriverImages);

        //            /// Add Status
        //            await CreateStatusAsync(new DriverStatus()
        //            {
        //                DriverID = entity.ID,
        //                Status = "NEW",
        //                StatusBy = userId,
        //                Remarks = entity.Remarks
        //            });

        //            await _context.SaveChangesAsync();
        //            await transaction.CommitAsync();
        //            return data;
        //        }
        //        catch (Exception)
        //        {
        //            await transaction.RollbackAsync();
        //            throw;
        //        }
        //    }
        //}

        //public async Task<Driver> UpdateAsync(dynamic id, Driver entity, string userId)
        //{
        //    using (var transaction = await _context.Database.BeginTransactionAsync())
        //    {
        //        try
        //        {
        //            entity.DriverStatuses = new List<DriverStatus>();
        //            entity.LogBy = userId;
        //            var data = await _repo.UpdateAsync(id, entity, true);

        //            /// Add Images
        //            await _repo.DeleteImageAsync(id);
        //            foreach (var image in entity.DriverImages ?? new List<DriverImage>()) image.DriverID = data.ID;
        //            if (entity.DriverImages != null && entity.DriverImages.Count > 0) await _repo.CreateImageAsync(entity.DriverImages);

        //            await CreateStatusAsync(new DriverStatus()
        //            {
        //                DriverID = entity.ID,
        //                Status = "EDIT",
        //                StatusBy = userId,
        //                Remarks = entity.Remarks
        //            });

        //            await _context.SaveChangesAsync();
        //            await transaction.CommitAsync();
        //            return data;
        //        }
        //        catch (Exception)
        //        {
        //            await transaction.RollbackAsync();
        //            throw;
        //        }
        //    }
        //}

        //private async Task<bool> CreateStatusAsync(DriverStatus status)
        //{
        //    string initial = status.DriverID + "-";
        //    int max = await _repo.GetMaxIDStatusAsync(initial);
        //    status.ID = initial + max.ToString("D4");
        //    return await _repo.CreateStatusAsync(status);
        //}
    }
}
