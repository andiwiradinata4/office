﻿using NetCore.Models;
using NetCore.Models.dto.Base;
using NetCore.Repositories.Interfaces;
using NetCore.Services.Interfaces;

namespace NetCore.Services
{
    public class DriverService : IDriverService
    {
        private readonly IDriverRepository _repo;

        public DriverService(IDriverRepository repo)
        {
            _repo = repo;
        }

        public async Task<List<Driver>> GetAllAsync(QueryObject query)
        {
            return await _repo.GetAllAsync(query);
        }

        public async Task<Driver> GetByIDAsync(dynamic id)
        {
            return await _repo.GetByIDAsync(id);
        }

        public async Task<Driver> DeleteAsync(dynamic id)
        {
            return await _repo.DeleteAsync(id);
        }

        public async Task<Driver> CreateAsync(Driver entity, string userId)
        {
            string initial = "KM2" + "-";
            int max = await _repo.GetMaxID(initial);
            entity.ID = initial + max.ToString("D4");
            entity.CreatedBy = userId;
            entity.LogBy = userId;
            return await _repo.CreateAsync(entity);
        }

        public async Task<Driver> UpdateAsync(dynamic id, Driver entity, string userId)
        {
            return await _repo.UpdateAsync(id, entity);
        }
    }
}
