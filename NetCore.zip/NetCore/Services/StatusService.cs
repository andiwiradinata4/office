﻿using NetCore.Models;
using NetCore.Models.dto.Base;
using NetCore.Repositories.Interfaces;
using NetCore.Services.Interfaces;
using NetCore.usDBContext;

namespace NetCore.Services
{
    public class StatusService : BaseService<AppDBContext, Status>, IStatusService
    {
        private readonly IBaseRepository<AppDBContext, Status> _baseRepo;
        private readonly IStatusRepository _repo;
        public StatusService(IStatusRepository repo, IBaseRepository<AppDBContext, Status> baseRepo) : base(repo)
        {
            _repo = repo;
            _baseRepo = baseRepo;
        }

        //public async Task<List<Status>> GetAllAsync(QueryObject query)
        //{
        //    return await _repo.GetAllAsync(query);
        //}

        //public async Task<Status> GetByIDAsync(dynamic id)
        //{
        //    return await _repo.GetByIDAsync(id);
        //}

        //public async Task<Status> CreateAsync(Status data, string userId)
        //{
        //    data.ID = await _repo.GetMaxID();
        //    return await _repo.CreateAsync(data);
        //}

        //public async Task<Status> UpdateAsync(dynamic id, Status data, string userId)
        //{
        //    return await _repo.UpdateAsync(id, data);
        //}

        //public async Task<Status> DeleteAsync(dynamic id)
        //{
        //    return await _repo.DeleteAsync(id);
        //}

        //public async Task<Status> Create(Status entity)
        //{
        //    entity.ID = await _repo.GetMaxID();
        //    return await _repo.Create(entity);
        //}
    }
}
