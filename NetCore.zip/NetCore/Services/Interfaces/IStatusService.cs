﻿using Microsoft.AspNetCore.Mvc;
using NetCore.Models;
using NetCore.usDBContext;

namespace NetCore.Services.Interfaces
{
    public interface IStatusService: IBaseService<AppDBContext, Status>
    {
        //Task<Status> CreateAsync(Status data);
        //Task<Status> UpdateAsync(int id, Status data);
    }
}
