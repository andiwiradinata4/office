﻿using Microsoft.AspNetCore.Mvc;
using NetCore.Models;

namespace NetCore.Services.Interfaces
{
    public interface IStatusService: IBaseService<Status>
    {
        Task<Status> CreateAsync(Status data);
        Task<Status> UpdateAsync(int id, Status data);
    }
}
