﻿using Microsoft.AspNetCore.OData.Query;
using Microsoft.EntityFrameworkCore;
using NetCore.Models;
using NetCore.Models.dto.Base;
using NetCore.Models.Interface;
using NetCore.Utilities;

namespace NetCore.Services.Interfaces
{
    public interface IBaseService<TDbContext, T> where TDbContext: DbContext where T: IEntityStandard
    {
        ICollection<T> GetAll();
        object GetAll(QueryObject query);
        Task<List<T>> GetAllAsync(QueryObject query);
        IQueryable GetByODataQuery(ODataQueryOptions<T> queryOptions);
        T? GetById(string Id);
        Task<T?> GetByIDAsync(string Id);
        bool Exists(string id);
        bool ExistsInDb(Func<T, bool> predicate);
        MessageObject<T> Create(T entity);
        Task<MessageObject<T>> CreateAsync(T entity);
        MessageObject<T> Update(string id, T entity);
        Task<MessageObject<T>> UpdateAsync(string id, T entity);
        MessageObject<T> Disable(string id);
        MessageObject<T> Disable(string id, T entity);
        MessageObject<T> Delete(string id);
        MessageObject<T> Delete(T entity);
        object GetColumnSet();

        //Task<List<T>> GetAllAsync(QueryObject query);
        //Task<T> GetByIDAsync(dynamic Id);
        //Task<T> DeleteAsync(dynamic Id);
        //Task<T> CreateAsync(T entity, string userId);
        //Task<T> UpdateAsync(dynamic Id, T entity, string userId);
    }
}