﻿using NetCore.Models.dto.Base;

namespace NetCore.Services.Interfaces
{
    public interface IBaseService<T>
    {
        Task<List<T>> GetAllAsync(QueryObject query);
        Task<T> GetByIDAsync(dynamic Id);
        Task<T> DeleteAsync(dynamic Id);
        Task<T> CreateAsync(T entity, string userId);
        Task<T> UpdateAsync(dynamic Id, T entity, string userId);
    }
}