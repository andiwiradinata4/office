﻿using NetCore.Models;

namespace NetCore.Services.Interfaces
{
    public interface IReligionService : IBaseService<Religion>
    {
        Task<Religion> CreateAsync(Religion data);
        Task<Religion> UpdateAsync(int id, Religion data);
    }
}
