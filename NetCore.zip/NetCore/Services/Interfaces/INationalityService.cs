﻿using NetCore.Models;

namespace NetCore.Services.Interfaces
{
    public interface INationalityService : IBaseService<Nationality>
    {
        //    Task<Nationality> CreateAsync(Nationality data);
        //    Task<Nationality> UpdateAsync(int id, Nationality data);
    }
}