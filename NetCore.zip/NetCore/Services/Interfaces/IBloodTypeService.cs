﻿using NetCore.Models;

namespace NetCore.Services.Interfaces
{
    public interface IBloodTypeService : IBaseService<BloodType>
    {
        Task<object> GetAllWithJoinAsync();
        //Task<BloodType> CreateAsync(BloodType data);
        //Task<BloodType> UpdateAsync(int id, BloodType data);
    }
}