﻿using NetCore.Models;

namespace NetCore.Services.Interfaces
{
    public interface IBloodTypeService : IBaseService<BloodType>
    {
        Task<List<BloodType>> GetAllWithIncludes(string[] includes);
        Task<BloodType> CreateAsync(BloodType data);
        Task<BloodType> UpdateAsync(int id, BloodType data);
    }
}