﻿using NetCore.Models;

namespace NetCore.Services.Interfaces
{
    public interface IDriverService : IBaseService<Driver>
    {
    }
}
