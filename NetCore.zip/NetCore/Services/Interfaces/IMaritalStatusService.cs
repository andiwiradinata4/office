﻿using NetCore.Models;

namespace NetCore.Services.Interfaces
{
    public interface IMaritalStatusService : IBaseService<MaritalStatus>
    {
        //Task<MaritalStatus> CreateAsync(MaritalStatus data);
        //Task<MaritalStatus> UpdateAsync(int id, MaritalStatus data);
    }
}
