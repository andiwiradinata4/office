﻿namespace NetCore.Utilities
{
    public enum MessageType
    {
        Error,
        Warning,
        Information,
        Confirmation
    }
}
