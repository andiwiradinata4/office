﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Options;
using System.Security.Claims;
using System.Text.Encodings.Web;

namespace NetCore.Utils
{
    public class ApiKeyAuthenticationHandler : AuthenticationHandler<ApiKeyAuthenticationOptions>
    {
        private readonly IConfiguration _configuration;
        public ApiKeyAuthenticationHandler(
            IOptionsMonitor<ApiKeyAuthenticationOptions> options,
            ILoggerFactory logger,
            UrlEncoder encoder,
            ISystemClock clock,
            IConfiguration configuration) : base(options, logger, encoder, clock)
        {
            _configuration = configuration;
        }

        protected override Task<AuthenticateResult> HandleAuthenticateAsync()
        {
            if (!Request.Headers.TryGetValue(Options.ApiKeyHeaderName, out var apiKeyHeaderValues)) return Task.FromResult(AuthenticateResult.NoResult());

            var provideApiKey = apiKeyHeaderValues.FirstOrDefault();
            var configurationApiKey = _configuration["APIKey:Value"];
            if (provideApiKey == null || !provideApiKey.Equals(configurationApiKey)) return Task.FromResult(AuthenticateResult.Fail("Invalid API Key Provided"));

            var claims = new[] { new Claim(ClaimTypes.Name, _configuration["APIKey:Name"] ?? "") };
            var identity = new ClaimsIdentity(claims, Options.Scheme);
            var identities = new[] { identity };
            var principal = new ClaimsPrincipal(identities);
            var ticket = new AuthenticationTicket(principal, Options.Scheme);

            return Task.FromResult(AuthenticateResult.Success(ticket));
        }
    }
}
