﻿using Microsoft.EntityFrameworkCore;
using NetCore.Utils.Interface;

namespace NetCore.Utils
{
    public class Logger : ILogger<DbContext>
    {

    }
}
