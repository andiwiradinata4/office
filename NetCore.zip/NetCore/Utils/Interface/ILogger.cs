﻿using Microsoft.EntityFrameworkCore;

namespace NetCore.Utils.Interface
{
    public interface ILogger<TDbContext> where TDbContext: DbContext
    {
        void SetLogInfo(string userName, string source = null, string request = null, string issueTypeCode = "undefined", params object[] objs);

        void Log(LogLevel level, Exception ex, string message, string source = null, string request = null, string issueTypeCode = "undefined", params object[] objs);

        void LogDebug(Exception ex, string message, string source = null, string request = null, string issueTypeCode = "undefined", params object[] objs);

        void LogInformation(string message, string source = null, string request = null, string issueTypeCode = "undefined", params object[] objs);

        void LogInformation(Exception ex, string message, string source = null, string request = null, string issueTypeCode = "undefined", params object[] objs);

        void LogError(Exception ex, string message, string source = null, string request = null, string issueTypeCode = "undefined", params object[] objs);

        void Log(Exception ex, string source = null, string request = null, string issueTypeCode = "undefined", params object[] objs);
    }
}
