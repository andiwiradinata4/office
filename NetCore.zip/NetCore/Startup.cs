﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json;
using System.Security.Principal;
using System.Text;
using NetCore.usDBContext;
using Microsoft.EntityFrameworkCore;
using NetCore.Repositories.Interfaces;
using NetCore.Repositories;
using NetCore.Services.Interfaces;
using NetCore.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Rewrite;

namespace NetCore
{
    public class Startup
    {
        public IConfiguration Configuration { get; }
        public Startup(IWebHostEnvironment env)
        {
            Configuration = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                .AddEnvironmentVariables()
                .Build();
        }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            .AddJwtBearer(option =>
            {
                option.ClaimsIssuer = "OAuth2";
                option.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = "OAuth2",
                    ValidAudience = "all",
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration[key: "JWT:SigningKey"] ?? "")),
                    ClockSkew = TimeSpan.Zero
                };
            }
            );

            // Inject IPrincipal
            services.AddHttpContextAccessor();
#pragma warning disable CS8602 // Dereference of a possibly null reference.
            services.AddScoped<IPrincipal>(provider => provider.GetService<IHttpContextAccessor>().HttpContext.User);
#pragma warning restore CS8602 // Dereference of a possibly null reference.
            services.AddMvc(options =>
            {
                //options.Filters.Add(new ApiLoggingInfoFilter(services.BuildServiceProvider().CreateScope().ServiceProvider));
                //options.Filters.Add(new ApiExceptionFilter());
            });

            //services.AddHostedService<ActionExecutionBackgroundService>();
            //services.AddE1Authorization<Startup>(Configuration);
            //services.AddOAuthEndPoint(Configuration);
            //services.AddHelperServices(Configuration);
            services.AddDbContext<AppDBContext>(options =>
            {
                options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection"));
            });

            services.AddControllers().AddNewtonsoftJson(options =>
            {
                options.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
                options.SerializerSettings.NullValueHandling = NullValueHandling.Ignore;
                options.SerializerSettings.DateTimeZoneHandling = DateTimeZoneHandling.RoundtripKind;
                //avoid camel case names by default
                options.SerializerSettings.ContractResolver = new DefaultContractResolver();
            });
            services.AddControllers();
            //services.AddLocalServices();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "TemplateProjectCore", Version = "v1" });
            });

            //services.AddHubConnection(Configuration);
            RegisterDIServices(services);
            //services.AddIIIIIIIIServices();

            //AddIIIIIIIIServices(services);
            //AppDomain.CurrentDomain.GetAssemblies().SelectMany(s =>
            //{
            //    try { return s.GetTypes(); }
            //    catch (Exception) { return Type.EmptyTypes; }
            //})
            //.Where(s => typeof(IBaseRepository<,>).IsAssignableFrom(s))
            //.Where(s => !s.IsAbstract)
            //.Where(s => s.IsClass)
            //.Select(s =>
            //{
            //    services.AddScoped(s);
            //    return services.AddScoped(sp => sp.CreateScope().ServiceProvider.GetService(s));
            //})
            //.ToList();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                // code to be executed in SIT environment 

            }
            else if (env.IsEnvironment("SIT"))
            {
                // code to be executed in SIT environment 

            }
            else if (env.IsEnvironment("QA"))
            {
                // code to be executed in QA environment 

            }
            else if (env.IsEnvironment("UAT"))
            {
                // code to be executed in UAT environment 

            }
            else if (env.IsProduction())
            {
                // code to be executed in Production environment 

            }
            else
            {

            }

            // code to be executed in development environment 
            app.UseDeveloperExceptionPage();
            app.UseSwagger();
            app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "TemplateProjectCore"));

            //app.UseRewriter(new RewriteOptions().Add(RewriteRouteRule.ReWriteRequests));

            app.UseHttpsRedirection();

            app.UseStaticFiles();
            app.UseRouting();

            app.UseCors(x => x.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin());
            app.UseAuthentication();
            //app.UseMiddleware<MessageHandlerInterceptor>();
            app.UseAuthorization();
            //app.UseE1Authorization();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapControllerRoute(
                    name: "DefaultApi",
                    pattern: "api/{controller}/{id}");
            });
            //app.UseDataContextModel();
            //app.UseHelperUtilities();
            //app.UseHelperServices();

            // Reponse a message when solution run in debug. 
            app.Run(async (context) =>
            {
                await context.Response.WriteAsync("WebApi Page");
            });

            //LocalDbContext.ValidateDatabaseModel = true;
        }

        

        public void RegisterDIServices(IServiceCollection services)
        {
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            // #region "Custom Service"
            services.AddScoped(typeof(IBaseService<,>), typeof(BaseService<,>));
            services.AddScoped(typeof(IStatusService), typeof(StatusService));
            // #endregion 


            // #region "Custom Repository"
            services.AddScoped(typeof(IBaseRepository<,>), typeof(BaseRepository<,>));
            services.AddScoped(typeof(IStatusRepository), typeof(StatusRepository));

            // #endregion 
        }

        //public static void AddIIIIIIIIServices(this IServiceCollection services)
        //{
        //    AppDomain.CurrentDomain.GetAssemblies()
        //        .SelectMany(s =>
        //        {
        //            try { return s.GetTypes(); }
        //            catch (Exception) { return Type.EmptyTypes; }
        //        })
        //        .Where(s => typeof(IBaseRepository<,>).IsAssignableFrom(s))
        //        .Where(s => !s.IsAbstract)
        //        .Where(s => s.IsClass)
        //        .Select(s =>
        //        {
        //            services.AddScoped(s);
        //            return services.AddScoped(sp => sp.CreateScope().ServiceProvider.GetService(s));
        //        })
        //        .ToList();
        //}
    }
}


