﻿using Microsoft.EntityFrameworkCore;
using NetCore.Models;
using NetCore.Repositories.Interfaces;
using NetCore.Repositories.Shared;
using NetCore.usDBContext;
using NetCore.usException;
using System.Net.NetworkInformation;

namespace NetCore.Repositories
{
    public class DriverRepository : BaseRepository<Driver>, IDriverRepository
    {
        private readonly AppDBContext _context;
        private readonly CompanyStructureRepository _csRepo;

        public DriverRepository(AppDBContext context) : base(context)
        {
            _context = context;
            _csRepo = new CompanyStructureRepository(context);
        }

        public async Task<string> GetComLocInitialAsync(int ComLocID)
        {
            return await _csRepo.GetComLocInitial(ComLocID);
        }

        public async Task<int> GetMaxIDStatusAsync(string initial)
        {
            int maxId = 0;
            var allData = await _context.DriverStatuses.ToListAsync();
            if (allData.Count > 0)
            {
                var ids = _context.DriverStatuses.Where((e => EF.Property<string>(e, "ID").StartsWith(initial))).Select(e => EF.Property<string>(e, "ID"));
                int.TryParse(ids.Any() ? ids.Max() != null ? ids.Max()?.Substring(initial.Length) : "0" : "0", out maxId);
            }
            return maxId + 1;
        }

        public async Task<bool> CreateStatusAsync(DriverStatus data, bool useTransaction = false)
        {
            var result = await _context.DriverStatuses.AddAsync(data);
            if (!useTransaction) await _context.SaveChangesAsync();
            if (result == null) throw new AppException("Data not found");
            return true;
        }

        public async Task<bool> CreateImageAsync(DriverImage data, bool useTransaction = false)
        {
            var result = await _context.DriverImages.AddAsync(data);
            if (!useTransaction) await _context.SaveChangesAsync();
            if (result == null) throw new AppException("Data not found");
            return true;
        }

        public async Task<bool> CreateImageAsync(List<DriverImage> data, bool useTransaction = false)
        {
            await _context.DriverImages.AddRangeAsync(data);
            if (!useTransaction) await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteImageAsync(string driverID, bool useTransaction = false)
        {
            var allImages = await _context.DriverImages.Where(e => e.DriverID == driverID).ToListAsync();
            _context.DriverImages.RemoveRange(allImages);
            if (!useTransaction) await _context.SaveChangesAsync();
            return true;
        }
    }
}
