﻿using NetCore.Models;
using NetCore.Repositories.Interfaces;
using NetCore.usDBContext;

namespace NetCore.Repositories
{
    public class DriverRepository : BaseRepository<Driver>, IDriverRepository
    {
        private readonly AppDBContext _context;

        public DriverRepository(AppDBContext context) : base(context)
        {
            _context = context;
        }

        
    }
}
