﻿using NetCore.Models;

namespace NetCore.Repositories.Interfaces
{
    public interface INationalityRepository : IBaseRepository<Nationality>
    {
        Task<Nationality> CreateAsync(Nationality data);
        Task<Nationality> UpdateAsync(int id, Nationality data);
    }
}
