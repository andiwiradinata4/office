﻿using NetCore.Models;

namespace NetCore.Repositories.Interfaces
{
    public interface IMaritalStatusRepository : IBaseRepository<MaritalStatus>
    {
        //Task<MaritalStatus> CreateAsync(MaritalStatus data);
        //Task<MaritalStatus> UpdateAsync(int id, MaritalStatus data);
    }
}
