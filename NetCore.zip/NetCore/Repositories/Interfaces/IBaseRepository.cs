﻿using NetCore.Models.dto.Base;

namespace NetCore.Repositories.Interfaces
{
    public interface IBaseRepository<T>
        where T : class
    {
        Task<List<T>> GetAllAsync(QueryObject query);
        Task<T> GetByIDAsync(dynamic id);
        Task<int> GetMaxID();
        Task<int> GetMaxID(string initial);
        Task<T> DeleteAsync(dynamic id);
        Task<T> CreateAsync(T entity);
        Task<T> UpdateAsync(dynamic id, T entity);
    }
}