﻿using NetCore.Models;
using NetCore.usDBContext;

namespace NetCore.Repositories.Interfaces
{
    public interface IStatusRepository: IBaseRepository<AppDBContext, Status>
    {
        //Task<Status> CreateAsync(Status data);
        //Task<Status> UpdateAsync(int id, Status data);
    }
}