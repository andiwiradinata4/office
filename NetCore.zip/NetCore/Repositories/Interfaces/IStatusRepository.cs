﻿using NetCore.Models;

namespace NetCore.Repositories.Interfaces
{
    public interface IStatusRepository: IBaseRepository<Status>
    {
        //Task<Status> CreateAsync(Status data);
        //Task<Status> UpdateAsync(int id, Status data);
    }
}