﻿using NetCore.Models;

namespace NetCore.Repositories.Interfaces
{
    public interface IGenderRepository : IBaseRepository<Gender>
    {
        Task<Gender> CreateAsync(Gender data);
        Task<Gender> UpdateAsync(int id, Gender data);
    }
}
