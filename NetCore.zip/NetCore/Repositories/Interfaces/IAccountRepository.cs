﻿using NetCore.Models;
using NetCore.Models.dto.Account;
using NetCore.usDBContext;

namespace NetCore.Repositories.Interfaces
{
    public interface IAccountRepository
    {
        Token? GetToken(string token);
        Task<Token?> GetTokenByUserIDAsync(string userID);
        bool SaveToken(Token token);
        bool ChangeEmail(ChangeEmailDTO dto);
        void SaveChanges();
    }
}
