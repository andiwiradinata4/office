﻿using NetCore.Models;
using NetCore.Models.dto.Account;

namespace NetCore.Repositories.Interfaces
{
    public interface IAccountRepository
    {
        Token? GetToken(string token);
        Task<Token?> GetTokenByUserIDAsync(string userID);
        bool SaveToken(Token token);
        bool ChangeEmail(ChangeEmailDTO dto);
    }
}
