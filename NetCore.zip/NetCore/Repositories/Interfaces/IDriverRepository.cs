﻿using NetCore.Models;

namespace NetCore.Repositories.Interfaces
{
    public interface IDriverRepository : IBaseRepository<Driver>
    {
        Task<string> GetComLocInitialAsync(int ComLocID);
        Task<int> GetMaxIDStatusAsync(string initial);
        Task<bool> CreateStatusAsync(DriverStatus data, bool useTransaction = false);
        Task<bool> CreateImageAsync(DriverImage data, bool useTransaction = false);
        Task<bool> CreateImageAsync(List<DriverImage> data, bool useTransaction = false);
        Task<bool> DeleteImageAsync(string driverID, bool useTransaction = false);
    }
}
