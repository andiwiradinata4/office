﻿using NetCore.Models;

namespace NetCore.Repositories.Interfaces
{
    public interface IDriverRepository : IBaseRepository<Driver>
    {
    }
}
