﻿using NetCore.Models;

namespace NetCore.Repositories.Interfaces
{
    public interface IReligionRepository : IBaseRepository<Religion>
    {
        Task<Religion> CreateAsync(Religion data);
        Task<Religion> UpdateAsync(int id, Religion data);
    }
}