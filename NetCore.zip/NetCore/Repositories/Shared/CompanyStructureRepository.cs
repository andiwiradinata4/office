﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using NetCore.usDBContext;
using NetCore.usException;

namespace NetCore.Repositories.Shared
{
    public class CompanyStructureRepository
    {
        private readonly AppDBContext _context;

        public CompanyStructureRepository(AppDBContext context)
        {
            _context = context;
        }

        public async Task<string> GetComLocInitial(int ComLocID)
        {
            var allInitial = await _context.Database.SqlQuery<string>($"SELECT TOP 1 ComLocInitial FROM QMS_vwCompanyStructure WHERE ComLocID={ComLocID}").ToListAsync();
            if(allInitial.Any())
            {
                var initial = allInitial.First();
                if(initial == null || initial == string.Empty) throw new AppException("ComLoc Initial Not Found. Please Map this ComLoc Initial First.");
                return initial;
            }
            throw new AppException("ComLoc Initial Not Found. Please Map this ComLoc Initial First.");
        }
    }
}
