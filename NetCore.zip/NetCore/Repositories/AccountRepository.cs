﻿using Microsoft.EntityFrameworkCore;
using NetCore.Models;
using NetCore.Models.dto.Account;
using NetCore.Repositories.Interfaces;
using NetCore.usDBContext;

namespace NetCore.Repositories
{
    public class AccountRepository : IAccountRepository
    {
        private readonly AppDBContext _context;

        public AccountRepository(AppDBContext context)
        {
            _context = context;
        }

        public Token? GetToken(string refreshToken)
        {
            return _context.Tokens.FirstOrDefault(d => d.TokenValue == refreshToken);
        }

        public async Task<Token?> GetTokenByUserIDAsync(string userID)
        {
            return await _context.Tokens.FirstOrDefaultAsync(d => d.UserID == userID);
        }

        public bool SaveToken(Token token)
        {
            var dataExists = _context.Tokens.FirstOrDefault(t => t.UserID == token.UserID && t.TokenType == token.TokenType);
            if (dataExists != null) _context.Tokens.Remove(dataExists);

            _context.Tokens.Add(token);
            _context.SaveChanges();
            return true;
        }

        public bool ChangeEmail(ChangeEmailDTO dto)
        {
            throw new NotImplementedException();
        }

        public void SaveChanges()
        {
            _context.SaveChanges();
        }
    }
}
