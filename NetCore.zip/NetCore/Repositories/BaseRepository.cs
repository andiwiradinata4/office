﻿using Microsoft.EntityFrameworkCore;
using NetCore.Models.dto.Base;
using NetCore.Repositories.Interfaces;
using NetCore.Repositories.Shared;
using NetCore.usDBContext;
using NetCore.usException;
using System.Linq;
using System.Linq.Dynamic.Core;

namespace NetCore.Repositories
{
    public class BaseRepository<T> : IBaseRepository<T> where T : class
    {
        private readonly AppDBContext _context;
        private readonly FKValidatorRepository _FKValidatorRepository;
        private readonly DbSet<T> _dbSet;
        public BaseRepository(AppDBContext context)
        {
            _context = context;
            _FKValidatorRepository = new FKValidatorRepository(context);
            _dbSet = _context.Set<T>();
        }

        public virtual async Task<List<T>> GetAllAsync(QueryObject query)
        {
            //IQueryable<T> _query = _dbSet;

            //// Apply Filtering
            //if (!string.IsNullOrEmpty(query.Filter))
            //{
            //    foreach (var filter in query.Filter.Split(",", StringSplitOptions.RemoveEmptyEntries))
            //    {
            //        string[] KeyAndValue = filter.Split("=", StringSplitOptions.RemoveEmptyEntries);
            //        if (KeyAndValue.Length > 0) _query = _query.Where(e => EF.Property<string>(e, KeyAndValue.First()).Contains(KeyAndValue.Last()));

            //    }
            //}

            //// Apply Includes
            //if (!string.IsNullOrEmpty(query.Includes))
            //{
            //    foreach (var include in query.Includes.Split(",", StringSplitOptions.RemoveEmptyEntries))
            //    {
            //        _query = _query.Include(include);
            //    }
            //}

            //// Apply Sorting
            ////if (!string.IsNullOrEmpty(query.SortBy))
            ////{
            ////    _query = _query.OrderBy(e => EF.Property<object>(e, query.SortBy));
            ////}

            //// Apply Pagination
            //_query = _query.Skip((query.Page - 1) * query.PageSize).Take(query.PageSize);

            //return await _query.ToListAsync();
            ////return await _context.SetWithIncludes<T>(includes).ToListAsync();
            ////return await _context.Set<T>().ToListAsync();

            //var results = await _context.Queries<T>(query).ToListAsync();
            //if (results != null)
            //{
            //    var resultsDynamic = results.ToDynamicList();
            //    if (!string.IsNullOrEmpty(query.Columns)) return results.Select<T>(query.Columns).ToDynamicList();
            //}

            return await _context.SetQuery<T>(query).ToListAsync();
        }

        public virtual async Task<T> GetByIDAsync(dynamic id)
        {
            //int intID = 0;
            //int.TryParse(id.ToString(), out intID);
            //var idValue = (intID <= 0) ? id : intID;

            if (int.TryParse(id, out int newID)) return await _context.Set<T>().FindAsync(newID) ?? throw new AppException("Data Not Found");

            return await _context.Set<T>().FindAsync(id) ?? throw new AppException("Data Not Found");

            //if (id is Int16 || id is Int32 || id is Int64 || id is Int128 || id is int || id is long || id is double)
            //{
            //    var idValue = id;
            //    var data = await _context.Set<T>().FindAsync(idValue);
            //    return data ?? throw new AppException("Data Not Found");
            //}
            //else
            //{
            //    var data = await _context.Set<T>().FindAsync(id);
            //    return data ?? throw new AppException("Data Not Found");
            //}

            //return data ?? throw new AppException("Data Not Found");
        }

        public virtual async Task<int> GetMaxID()
        {
            var ids = await _context.Set<T>().Select(e => EF.Property<int>(e, "ID")).ToListAsync();
            return ids.Any() ? ids.Max() + 1 : 1;
        }

        public virtual async Task<int> GetMaxID(string initial)
        {
            int maxId = 0;
            var allData = await _context.Set<T>().ToListAsync();
            if (allData.Count > 0)
            {
                var ids = _context.Set<T>().Where((e => EF.Property<string>(e, "ID").StartsWith(initial))).Select(e => EF.Property<string>(e, "ID"));
                int.TryParse(ids.Any() ? ids.Max() != null ? ids.Max()?.Substring(initial.Length) : "0" : "0", out maxId);
            }
            return maxId + 1;
        }

        public virtual async Task<T> DeleteAsync(dynamic id, bool useTransaction = false)
        {
            int intID = 0;
            int.TryParse(id.ToString(), out intID);
            var idValue = (intID <= 0) ? id : intID;
            var data = await _context.Set<T>().FindAsync(idValue) ?? throw new AppException("Data not found");
            _context.Set<T>().Remove(data);
            if (!useTransaction) await _context.SaveChangesAsync();
            return data;
        }

        public virtual async Task<T> CreateAsync(T entity, bool useTransaction = false)
        {
            await _FKValidatorRepository.ValidateFKAsync(entity);
            await _context.Set<T>().AddAsync(entity);
            if (!useTransaction) await _context.SaveChangesAsync();
            return entity;
        }

        public virtual async Task<T> UpdateAsync(dynamic id, T entity, bool useTransaction = false)
        {
            await _FKValidatorRepository.ValidateFKAsync(entity);

            int intID = 0;
            int.TryParse(id.ToString(), out intID);
            var idValue = (intID <= 0) ? id : intID;
            var dataExists = await _context.Set<T>().FindAsync(idValue);

            if (dataExists == null) throw new AppException("Data Not Found");

            var propertiesEntity = entity.GetType().GetProperties();
            //foreach (var propertyEntity in propertiesEntity)
            //{
            //    if (propertyEntity.Name == "ID") propertyEntity.SetValue(entity, idValue);
            //}

            var propertiesExists = typeof(T).GetProperties();
            foreach (var propertyExists in propertiesExists)
            {
                var propertyExistsName = propertyExists.Name;
                var propertyExistsValue = propertyExists.GetValue(dataExists);
                foreach (var propertyEntity in propertiesEntity)
                {
                    if (propertyExistsName == "LogInc" && propertyEntity.Name == "LogInc") propertyEntity.SetValue(entity, propertyExistsValue + 1);
                    if (propertyExistsName == propertyEntity.Name && NeedReplace(propertyEntity.Name)) propertyEntity.SetValue(entity, propertyExistsValue);
                }
            }

            _context.Entry(dataExists).CurrentValues.SetValues(entity);
            if (!useTransaction) await _context.SaveChangesAsync();
            return entity;
        }

        private bool NeedReplace(string propertyName)
        {
            if (propertyName == "ID") return true;
            if (propertyName == "CreatedBy") return true;
            if (propertyName == "CreatedDate") return true;
            return false;
        }
    }
}