﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using NetCore.Models;
using NetCore.Models.Interface;
using NetCore.Repositories.Interfaces;
using NetCore.Utilities;
using NetCore.Utils;
using System.Collections.ObjectModel;
using System.Security.Principal;

namespace NetCore.Repositories
{
    public class BaseRepository<TDbContext, T> : BaseSelectRepository<TDbContext, T>, IBaseRepository<TDbContext, T>, IBaseSelectRepository<TDbContext, T> where TDbContext : DbContext where T : BaseEntity, IEntityStandard
    {

        //private readonly AppDBContext _context;
        //private readonly FKValidatorRepository _FKValidatorRepository;
        //private readonly DbSet<T> _dbSet;
        //public BaseRepository(AppDBContext context)
        //{
        //    _context = context;
        //    _FKValidatorRepository = new FKValidatorRepository(context);
        //    _dbSet = _context.Set<T>();
        //}

        //public virtual async Task<List<T>> GetAllAsync(QueryObject query)
        //{
        //    //IQueryable<T> _query = _dbSet;

        //    //// Apply Filtering
        //    //if (!string.IsNullOrEmpty(query.Filter))
        //    //{
        //    //    foreach (var filter in query.Filter.Split(",", StringSplitOptions.RemoveEmptyEntries))
        //    //    {
        //    //        string[] KeyAndValue = filter.Split("=", StringSplitOptions.RemoveEmptyEntries);
        //    //        if (KeyAndValue.Length > 0) _query = _query.Where(e => EF.Property<string>(e, KeyAndValue.First()).Contains(KeyAndValue.Last()));

        //    //    }
        //    //}

        //    //// Apply Includes
        //    //if (!string.IsNullOrEmpty(query.Includes))
        //    //{
        //    //    foreach (var include in query.Includes.Split(",", StringSplitOptions.RemoveEmptyEntries))
        //    //    {
        //    //        _query = _query.Include(include);
        //    //    }
        //    //}

        //    //// Apply Sorting
        //    ////if (!string.IsNullOrEmpty(query.SortBy))
        //    ////{
        //    ////    _query = _query.OrderBy(e => EF.Property<object>(e, query.SortBy));
        //    ////}

        //    //// Apply Pagination
        //    //_query = _query.Skip((query.Page - 1) * query.PageSize).Take(query.PageSize);

        //    //return await _query.ToListAsync();
        //    ////return await _context.SetWithIncludes<T>(includes).ToListAsync();
        //    ////return await _context.Set<T>().ToListAsync();

        //    //var results = await _context.Queries<T>(query).ToListAsync();
        //    //if (results != null)
        //    //{
        //    //    var resultsDynamic = results.ToDynamicList();
        //    //    if (!string.IsNullOrEmpty(query.Columns)) return results.Select<T>(query.Columns).ToDynamicList();
        //    //}

        //    return await _context.SetQuery<T>(query).ToListAsync();
        //}

        //public virtual async Task<T> GetByIDAsync(dynamic id)
        //{
        //    //int intID = 0;
        //    //int.TryParse(id.ToString(), out intID);
        //    //var idValue = (intID <= 0) ? id : intID;

        //    if (int.TryParse(id, out int newID)) return await _context.Set<T>().FindAsync(newID) ?? throw new AppException("Data Not Found");

        //    return await _context.Set<T>().FindAsync(id) ?? throw new AppException("Data Not Found");

        //    //if (id is Int16 || id is Int32 || id is Int64 || id is Int128 || id is int || id is long || id is double)
        //    //{
        //    //    var idValue = id;
        //    //    var data = await _context.Set<T>().FindAsync(idValue);
        //    //    return data ?? throw new AppException("Data Not Found");
        //    //}
        //    //else
        //    //{
        //    //    var data = await _context.Set<T>().FindAsync(id);
        //    //    return data ?? throw new AppException("Data Not Found");
        //    //}

        //    //return data ?? throw new AppException("Data Not Found");
        //}

        //public virtual async Task<int> GetMaxID()
        //{
        //    var ids = await _context.Set<T>().Select(e => EF.Property<int>(e, "ID")).ToListAsync();
        //    return ids.Any() ? ids.Max() + 1 : 1;
        //}

        //public virtual async Task<int> GetMaxID(string initial)
        //{
        //    int maxId = 0;
        //    var allData = await _context.Set<T>().ToListAsync();
        //    if (allData.Count > 0)
        //    {
        //        var ids = _context.Set<T>().Where((e => EF.Property<string>(e, "ID").StartsWith(initial))).Select(e => EF.Property<string>(e, "ID"));
        //        int.TryParse(ids.Any() ? ids.Max() != null ? ids.Max()?.Substring(initial.Length) : "0" : "0", out maxId);
        //    }
        //    return maxId + 1;
        //}

        //public virtual async Task<T> DeleteAsync(dynamic id, bool useTransaction = false)
        //{
        //    int intID = 0;
        //    int.TryParse(id.ToString(), out intID);
        //    var idValue = (intID <= 0) ? id : intID;
        //    var data = await _context.Set<T>().FindAsync(idValue) ?? throw new AppException("Data not found");
        //    _context.Set<T>().Remove(data);
        //    if (!useTransaction) await _context.SaveChangesAsync();
        //    return data;
        //}

        //public virtual async Task<T> CreateAsync(T entity, bool useTransaction = false)
        //{
        //    await _FKValidatorRepository.ValidateFKAsync(entity);
        //    await _context.Set<T>().AddAsync(entity);
        //    if (!useTransaction) await _context.SaveChangesAsync();
        //    return entity;
        //}

        //public virtual async Task<T> UpdateAsync(dynamic id, T entity, bool useTransaction = false)
        //{
        //    await _FKValidatorRepository.ValidateFKAsync(entity);

        //    int intID = 0;
        //    int.TryParse(id.ToString(), out intID);
        //    var idValue = (intID <= 0) ? id : intID;
        //    var dataExists = await _context.Set<T>().FindAsync(idValue);

        //    if (dataExists == null) throw new AppException("Data Not Found");

        //    var propertiesEntity = entity.GetType().GetProperties();
        //    //foreach (var propertyEntity in propertiesEntity)
        //    //{
        //    //    if (propertyEntity.Name == "ID") propertyEntity.SetValue(entity, idValue);
        //    //}

        //    var propertiesExists = typeof(T).GetProperties();
        //    foreach (var propertyExists in propertiesExists)
        //    {
        //        var propertyExistsName = propertyExists.Name;
        //        var propertyExistsValue = propertyExists.GetValue(dataExists);
        //        foreach (var propertyEntity in propertiesEntity)
        //        {
        //            if (propertyExistsName == "LogInc" && propertyEntity.Name == "LogInc") propertyEntity.SetValue(entity, propertyExistsValue + 1);
        //            if (propertyExistsName == propertyEntity.Name && NeedReplace(propertyEntity.Name)) propertyEntity.SetValue(entity, propertyExistsValue);
        //        }
        //    }

        //    _context.Entry(dataExists).CurrentValues.SetValues(entity);
        //    if (!useTransaction) await _context.SaveChangesAsync();
        //    return entity;
        //}

        //private bool NeedReplace(string propertyName)
        //{
        //    if (propertyName == "ID") return true;
        //    if (propertyName == "CreatedBy") return true;
        //    if (propertyName == "CreatedDate") return true;
        //    return false;
        //}

        protected string logSource;
        protected readonly IPrincipal pctx;

        public BaseRepository(TDbContext context, IPrincipal pctx)
            : base(context)
        {
            this.pctx = pctx;
            logSource = "BaseRepository<" + typeof(T).Name + ">";
        }

        public virtual T Create(T entity, bool useTransaction = false)
        {
            try
            {
                if (entity != null)
                {
                    SetInsertProperties(entity);
                    dbSet.Add(entity);

                    /// Log Success

                    if (!useTransaction) context.SaveChanges();
                }
                else
                {
                    throw new Exception("Entity not allow null");
                }
            }
            catch
            {
                /// Log Error
                throw;
            }
            return entity!;
        }

        public virtual void Create(ICollection<T> entities, bool useTransaction = false)
        {
            try
            {
                if (entities == null || entities.Count <= 0) return;

                entities.ToList().ForEach(delegate (T p)
                {
                    SetInsertProperties(p);
                });
                dbSet.AddRange(entities);

                /// Log Success

                if (!useTransaction) context.SaveChanges();
            }
            catch
            {
                /// Log Error
                throw;
            }
        }

        public virtual async Task<T> CreateAsync(T entity, bool useTransaction = false)
        {
            try
            {
                if (entity != null)
                {
                    SetInsertProperties(entity);
                    await dbSet.AddAsync(entity);

                    /// Log Success

                    if (!useTransaction) context.SaveChanges();
                }
                else
                {
                    throw new Exception("Entity not allow null");
                }
            }
            catch
            {
                /// Log Error
                throw;
            }
            return entity!;
        }

        public virtual async void CreateAsync(ICollection<T> entities, bool useTransaction = false)
        {
            try
            {
                if (entities == null || entities.Count <= 0) return;

                entities.ToList().ForEach(delegate (T p)
                {
                    SetInsertProperties(p);
                });

                await dbSet.AddRangeAsync(entities);

                /// Log Success

                if (!useTransaction) context.SaveChanges();
            }
            catch
            {
                /// Log Error
                throw;
            }
        }

        public T Update(string id, T entity, bool useTransaction = false)
        {
            try
            {
                var exists = base.GetById(id);
                if (exists == null) throw new Exception("Data not found");
                //if (exists.RowVersion != entity.RowVersion) throw new Exception("Invalid Row Version");
                entity = Update(entity, useTransaction);
            }
            catch
            {
                throw;
            }
            return entity;
        }

        public T Update(T entity, bool useTransaction = false)
        {
            var exists = base.GetById(entity.Id);
            try
            {
                if (exists == null) throw new Exception("Data not found");
                //if (exists.RowVersion != entity.RowVersion) throw new Exception("Invalid Row Version");
                SetUpdateProperties(entity);
                SetAutoMapperUpdate(entity);

                //context.Entry(exists).CurrentValues.SetValues(entity);

                /// Log Success

                if (!useTransaction) context.SaveChanges();
            }
            catch
            {
                /// Log Error
                throw;
            }
            return exists;
        }

        public virtual void Update(ICollection<T> entities, bool useTransaction = false)
        {
            foreach (T entity in entities) Update(entity, useTransaction);
        }

        public virtual async Task<T> UpdateAsync(string id, T entity, bool useTransaction = false)
        {
            try
            {
                var exists = await base.GetByIDAsync(id);
                if (exists == null) throw new Exception("Data not found");
                //if (exists.RowVersion != entity.RowVersion) throw new Exception("Invalid Row Version");
                entity = await UpdateAsync(entity, useTransaction);
            }
            catch
            {
                throw;
            }
            return entity;
        }

        public virtual async Task<T> UpdateAsync(T entity, bool useTransaction = false)
        {
            try
            {
                var exists = await base.GetByIDAsync(entity.Id);
                if (exists == null) throw new Exception("Data not found");
                //if (exists.RowVersion != entity.RowVersion) throw new Exception("Invalid Row Version");

                SetUpdateProperties(entity);

                /// Log Success

                if (!useTransaction) context.SaveChanges();
            }
            catch
            {
                /// Log Error
                throw;
            }
            return entity;
        }

        public virtual async void UpdateAsync(ICollection<T> entities, bool useTransaction = false)
        {
            foreach (T entity in entities) await UpdateAsync(entity, useTransaction);
        }

        public virtual T Delete(string id, bool useTransaction = false)
        {
            var entity = GetById(id);
            if (entity == null) throw new Exception("Entity not allow null");
            Delete(entity, useTransaction);
            return entity;
        }

        public virtual T Delete(T entity, bool useTransaction = false)
        {
            try
            {
                if (entity != null)
                {
                    context.Entry(entity).State = EntityState.Deleted;
                    dbSet.Remove(entity);

                    /// Log Success

                    if (!useTransaction) context.SaveChanges();
                }
                else
                {
                    throw new Exception("Entity not allow null");
                }
            }
            catch
            {
                /// Log Error
                throw;
            }
            return entity!;
        }

        public virtual void Delete(ICollection<T> entities, bool useTransaction = false)
        {
            try
            {
                if (entities == null || entities.Count <= 0) return;

                dbSet.RemoveRange(entities);
                context.Entry(entities).State = EntityState.Deleted;

                /// Log Success
                if (!useTransaction) context.SaveChanges();
            }
            catch
            {
                /// Log Error
                throw;
            }
        }

        public virtual T Disable(string id, bool useTransaction = false)
        {
            try
            {
                var entity = base.GetById(id);
                if (entity == null) throw new Exception($"Entity not found with Id {id}");
                entity = Disable(entity, useTransaction);
                return entity;
            }
            catch
            {
                throw;
            }
        }

        public virtual T Disable(T entity, bool useTransaction = false)
        {
            try
            {
                entity.Disabled = true;
                entity = Update(entity, useTransaction);
            }
            catch
            {
                throw;
            }
            return entity;
        }

        public virtual void Disable(ICollection<T> entities, bool useTransaction = false)
        {
            try
            {
                foreach (T entity in entities) Update(entity, useTransaction);
            }
            catch
            {
                throw;
            }
        }

        protected virtual void SetInsertProperties(T entity)
        {
            Helper.setPostData(entity, pctx);
        }

        protected virtual void SetUpdateProperties(T entity)
        {
            Helper.setPutData(entity, pctx);
        }

        public T SetAutoMapperUpdate(T entity)
        {
            T? destination = base.GetById(entity.Id);
            MapperConfiguration configurationProvider = new MapperConfiguration(delegate (IMapperConfigurationExpression cfg)
            {
                cfg.CreateMap<T, T>().ForMember((T des) => des.Id, delegate (IMemberConfigurationExpression<T, T, string> opt)
                {
                    opt.Ignore();
                }).ForMember((T des) => des.RowVersion, delegate (IMemberConfigurationExpression<T, T, byte[]> opt)
                {
                    opt.Ignore();
                }).ForMember((T des) => des.CreatedBy, delegate (IMemberConfigurationExpression<T, T, string> opt)
                {
                    opt.Ignore();
                }).ForMember((T des) => des.CreatedByUserDisplayName, delegate (IMemberConfigurationExpression<T, T, string> opt)
                {
                    opt.Ignore();
                }).ForMember((T des) => des.CreatedDate, delegate (IMemberConfigurationExpression<T, T, DateTime> opt)
                {
                    opt.Ignore();
                }).ForMember((T des) => des.CreatedDateUTC, delegate (IMemberConfigurationExpression<T, T, DateTime> opt)
                {
                    opt.Ignore();
                });

                //cfg.ForAllPropertyMaps((PropertyMap map) => FilterICollectionAndBaseEntityMembersForCascadeOff(map), delegate (PropertyMap map, IMemberConfigurationExpression options)
                //{
                //    options.Ignore();
                //});
            });
            IMapper mapper = new Mapper(configurationProvider);
            entity.LogInc = destination!.LogInc + 1;
            return mapper.Map(entity, destination);
        }

        public virtual void SaveChanges()
        {
            context.SaveChanges();
        }

        public virtual void Dispose()
        {
            context.Dispose();
        }

        TDbContext IBaseRepository<TDbContext, T>.GetDbContext()
        {
            //List<ICollection<T>> data2;
            //ICollection<List<T>> data3;
            //data3.First().RemoveAt(0);

            //List<T> data;
            //data.Count();
            //var data = context.Set<T>().ToList();
            return context;
        }
    }
}