﻿using Microsoft.EntityFrameworkCore;
using NetCore.Models;
using NetCore.Repositories.Interfaces;
using NetCore.usDBContext;

namespace NetCore.Repositories
{
    public class BloodTypeRepository : BaseRepository<BloodType>, IBloodTypeRepository
    {
        private readonly AppDBContext _context;

        public BloodTypeRepository(AppDBContext context) : base(context)
        {
            _context = context;
        }

        public async Task<object> GetAllWithJoinAsync()
        {
            var queries = from bloodType in _context.BloodTypes
                          join status in _context.Status on bloodType.StatusID equals status.ID
                          where bloodType.ID == 1
                          select new
                          {
                              bloodType.ID,
                              bloodType.Description,
                              bloodType.StatusID,
                              StatusName = status.Description
                          };
            var queriesMethod =
                _context.BloodTypes.Include(s => s.Status)
                .Where(b => b.ID == 1)
                .Select(b => new { b.ID, b.Description, b.StatusID, StatusName = b.Status == null ? "" : b.Status.Description });

            if (queries == null) return new List<BloodType>();
            return await queries.ToListAsync();
        }

        //public async Task<BloodType> CreateAsync(BloodType data)
        //{
        //    await new ReferencesRepository(_context).IsExistsStatusID(data.StatusID);
        //    await _context.BloodTypes.AddAsync(data);
        //    await _context.SaveChangesAsync();
        //    return data;
        //}

        //public async Task<BloodType> UpdateAsync(int id, BloodType data)
        //{
        //    await new ReferencesRepository(_context).IsExistsStatusID(data.StatusID);
        //    var dataExists = await _context.BloodTypes.FirstOrDefaultAsync(a => a.ID == id);
        //    if (dataExists == null) throw new AppException("Data Not Found");
        //    dataExists.Description = data.Description;
        //    dataExists.StatusID = data.StatusID;
        //    dataExists.Remarks = data.Remarks;
        //    await _context.SaveChangesAsync();
        //    return data;
        //}
    }
}