﻿using Microsoft.EntityFrameworkCore;
using NetCore.Models;
using NetCore.Repositories.Interfaces;
using NetCore.usDBContext;

namespace NetCore.Repositories
{
    public class BloodTypeRepository : BaseRepository<BloodType>, IBloodTypeRepository
    {
        private readonly AppDBContext _context;

        public BloodTypeRepository(AppDBContext context) : base(context)
        {
            _context = context;
        }

        public async Task<object> GetAllWithJoinAsync()
        {
            var queries = from bloodType in _context.BloodTypes
                          join status in _context.Status on bloodType.StatusID equals status.Id
                          //where bloodType.Id == 1
                          select new
                          {
                              bloodType.Id,
                              bloodType.Description,
                              bloodType.StatusID,
                              StatusName = status.Description
                          };
            
            var queriesMethod =
                _context.BloodTypes.Include(s => s.Status)
                //.Where(b => b.Id == 1)
                .Select(b => new { b.Id, b.Description, b.StatusID, StatusName = b.Status == null ? "" : b.Status.Description });

            if (queries == null) return new List<BloodType>();
            return await queries.ToListAsync();
        }

        //public async Task<BloodType> CreateAsync(BloodType data)
        //{
        //    await new ReferencesRepository(_context).IsExistsStatusId(data.StatusId);
        //    await _context.BloodTypes.AddAsync(data);
        //    await _context.SaveChangesAsync();
        //    return data;
        //}

        //public async Task<BloodType> UpdateAsync(int Id, BloodType data)
        //{
        //    await new ReferencesRepository(_context).IsExistsStatusId(data.StatusId);
        //    var dataExists = await _context.BloodTypes.FirstOrDefaultAsync(a => a.Id == Id);
        //    if (dataExists == null) throw new AppException("Data Not Found");
        //    dataExists.Description = data.Description;
        //    dataExists.StatusId = data.StatusId;
        //    dataExists.Remarks = data.Remarks;
        //    await _context.SaveChangesAsync();
        //    return data;
        //}
    }
}