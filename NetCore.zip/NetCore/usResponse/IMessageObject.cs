﻿namespace NetCore.usResponse
{
    public interface IMessageObject
    {
    }
}
