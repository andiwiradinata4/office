﻿using Newtonsoft.Json;

namespace NetCore.usResponse
{
    public class Message
    {
        [JsonConverter(typeof(Newtonsoft.Json.Converters.StringEnumConverter))]
        public MessageType Type { get; }

        public string Code { get; }

        public string Description { get; }

        public string Field { get; } = string.Empty;


        public Message(MessageType type, string code, string description, string field = "")
        {
            Type = type;
            Code = code;
            Description = description;
            Field = field;
        }
    }
}
