﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace NetCore.Migrations
{
    /// <inheritdoc />
    public partial class UpdateRelationshipofDriverswithGender : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_LR_mstDriver_LR_mstGender_GenderID",
                schema: "dbo",
                table: "LR_mstDriver");

            migrationBuilder.DeleteData(
                schema: "dbo",
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "ad031c38-fae0-448e-85c1-6404c1747a71");

            migrationBuilder.DeleteData(
                schema: "dbo",
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "fd7a6885-4333-4984-8e38-77b79aa9e260");

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "e38560fc-57b0-40e8-b1ba-b59321343d42", null, "Admin", "ADMIN" },
                    { "f84c29df-310a-4395-9645-7c9064abb2e0", null, "User", "USER" }
                });

            migrationBuilder.AddForeignKey(
                name: "FK_LR_mstDriver_LR_mstGender_GenderID",
                schema: "dbo",
                table: "LR_mstDriver",
                column: "GenderID",
                principalSchema: "dbo",
                principalTable: "LR_mstGender",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_LR_mstDriver_LR_mstGender_GenderID",
                schema: "dbo",
                table: "LR_mstDriver");

            migrationBuilder.DeleteData(
                schema: "dbo",
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "e38560fc-57b0-40e8-b1ba-b59321343d42");

            migrationBuilder.DeleteData(
                schema: "dbo",
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "f84c29df-310a-4395-9645-7c9064abb2e0");

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "ad031c38-fae0-448e-85c1-6404c1747a71", null, "User", "USER" },
                    { "fd7a6885-4333-4984-8e38-77b79aa9e260", null, "Admin", "ADMIN" }
                });

            migrationBuilder.AddForeignKey(
                name: "FK_LR_mstDriver_LR_mstGender_GenderID",
                schema: "dbo",
                table: "LR_mstDriver",
                column: "GenderID",
                principalSchema: "dbo",
                principalTable: "LR_mstGender",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
