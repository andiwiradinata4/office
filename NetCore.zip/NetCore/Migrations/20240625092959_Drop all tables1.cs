﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace NetCore.Migrations
{
    /// <inheritdoc />
    public partial class Dropalltables1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "LR_mstDriverStatus",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "LR_mstToken",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "LR_mstDriver",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "LR_mstBloodType",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "LR_mstGender",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "LR_mstMaritalStatus",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "LR_mstNationality",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "LR_mstReligion",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "LR_mstStatus",
                schema: "dbo");

            migrationBuilder.DeleteData(
                schema: "dbo",
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "0f836a01-c356-4cfd-8f9f-b212f3bd3954");

            migrationBuilder.DeleteData(
                schema: "dbo",
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "2052c469-5e65-459e-9acf-65970916a71a");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "LR_mstStatus",
                schema: "dbo",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    LogBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LogDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LogInc = table.Column<int>(type: "int", nullable: false),
                    Remarks = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LR_mstStatus", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "LR_mstToken",
                schema: "dbo",
                columns: table => new
                {
                    ID = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Code = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TokenType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TokenValue = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    UserID = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ValidFrom = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ValidTo = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LR_mstToken", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "LR_mstBloodType",
                schema: "dbo",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false),
                    StatusID = table.Column<int>(type: "int", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LogBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LogDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LogInc = table.Column<int>(type: "int", nullable: false),
                    Remarks = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LR_mstBloodType", x => x.ID);
                    table.ForeignKey(
                        name: "FK_LR_mstBloodType_LR_mstStatus_StatusID",
                        column: x => x.StatusID,
                        principalSchema: "dbo",
                        principalTable: "LR_mstStatus",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "LR_mstGender",
                schema: "dbo",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false),
                    StatusID = table.Column<int>(type: "int", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LogBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LogDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LogInc = table.Column<int>(type: "int", nullable: false),
                    Remarks = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LR_mstGender", x => x.ID);
                    table.ForeignKey(
                        name: "FK_LR_mstGender_LR_mstStatus_StatusID",
                        column: x => x.StatusID,
                        principalSchema: "dbo",
                        principalTable: "LR_mstStatus",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "LR_mstMaritalStatus",
                schema: "dbo",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false),
                    StatusID = table.Column<int>(type: "int", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LogBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LogDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LogInc = table.Column<int>(type: "int", nullable: false),
                    Remarks = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LR_mstMaritalStatus", x => x.ID);
                    table.ForeignKey(
                        name: "FK_LR_mstMaritalStatus_LR_mstStatus_StatusID",
                        column: x => x.StatusID,
                        principalSchema: "dbo",
                        principalTable: "LR_mstStatus",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "LR_mstNationality",
                schema: "dbo",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false),
                    StatusID = table.Column<int>(type: "int", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LogBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LogDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LogInc = table.Column<int>(type: "int", nullable: false),
                    Remarks = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LR_mstNationality", x => x.ID);
                    table.ForeignKey(
                        name: "FK_LR_mstNationality_LR_mstStatus_StatusID",
                        column: x => x.StatusID,
                        principalSchema: "dbo",
                        principalTable: "LR_mstStatus",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "LR_mstReligion",
                schema: "dbo",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false),
                    StatusID = table.Column<int>(type: "int", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LogBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LogDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LogInc = table.Column<int>(type: "int", nullable: false),
                    Remarks = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LR_mstReligion", x => x.ID);
                    table.ForeignKey(
                        name: "FK_LR_mstReligion_LR_mstStatus_StatusID",
                        column: x => x.StatusID,
                        principalSchema: "dbo",
                        principalTable: "LR_mstStatus",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "LR_mstDriver",
                schema: "dbo",
                columns: table => new
                {
                    ID = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    BloodTypeID = table.Column<int>(type: "int", nullable: false),
                    GenderID = table.Column<int>(type: "int", nullable: false),
                    MaritalStatusID = table.Column<int>(type: "int", nullable: false),
                    NationalityID = table.Column<int>(type: "int", nullable: false),
                    ReligionID = table.Column<int>(type: "int", nullable: false),
                    StatusID = table.Column<int>(type: "int", nullable: false),
                    AddressOfDrivingLicense = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    AddressOfIdentityCard = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatedFromComLocID = table.Column<int>(type: "int", nullable: false),
                    DateOfBirth = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DrivingLicenseNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DrivingLicenseTypeID = table.Column<int>(type: "int", nullable: false),
                    FullName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Height = table.Column<int>(type: "int", nullable: false),
                    IdentityCardNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    InternalRemarks = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LastUpdatedFromComLocID = table.Column<int>(type: "int", nullable: false),
                    LogBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LogDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LogInc = table.Column<int>(type: "int", nullable: false),
                    OccupationsIDOfDrivingLicense = table.Column<int>(type: "int", nullable: false),
                    OccupationsIDOfIdentityCard = table.Column<int>(type: "int", nullable: false),
                    OccupationsOthersOfDrivingLicense = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    OccupationsOthersOfIdentityCard = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PlaceOfBirth = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ReferencesID = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Remarks = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ValidThruOfDrivingLicense = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ValidThruOfIdentityCard = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LR_mstDriver", x => x.ID);
                    table.ForeignKey(
                        name: "FK_LR_mstDriver_LR_mstBloodType_BloodTypeID",
                        column: x => x.BloodTypeID,
                        principalSchema: "dbo",
                        principalTable: "LR_mstBloodType",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_LR_mstDriver_LR_mstGender_GenderID",
                        column: x => x.GenderID,
                        principalSchema: "dbo",
                        principalTable: "LR_mstGender",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_LR_mstDriver_LR_mstMaritalStatus_MaritalStatusID",
                        column: x => x.MaritalStatusID,
                        principalSchema: "dbo",
                        principalTable: "LR_mstMaritalStatus",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_LR_mstDriver_LR_mstNationality_NationalityID",
                        column: x => x.NationalityID,
                        principalSchema: "dbo",
                        principalTable: "LR_mstNationality",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_LR_mstDriver_LR_mstReligion_ReligionID",
                        column: x => x.ReligionID,
                        principalSchema: "dbo",
                        principalTable: "LR_mstReligion",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_LR_mstDriver_LR_mstStatus_StatusID",
                        column: x => x.StatusID,
                        principalSchema: "dbo",
                        principalTable: "LR_mstStatus",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "LR_mstDriverStatus",
                schema: "dbo",
                columns: table => new
                {
                    ID = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    DriverID = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Remarks = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Status = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StatusBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StatusDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LR_mstDriverStatus", x => x.ID);
                    table.ForeignKey(
                        name: "FK_LR_mstDriverStatus_LR_mstDriver_DriverID",
                        column: x => x.DriverID,
                        principalSchema: "dbo",
                        principalTable: "LR_mstDriver",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "0f836a01-c356-4cfd-8f9f-b212f3bd3954", null, "Admin", "ADMIN" },
                    { "2052c469-5e65-459e-9acf-65970916a71a", null, "User", "USER" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_LR_mstBloodType_StatusID",
                schema: "dbo",
                table: "LR_mstBloodType",
                column: "StatusID");

            migrationBuilder.CreateIndex(
                name: "IX_LR_mstDriver_BloodTypeID",
                schema: "dbo",
                table: "LR_mstDriver",
                column: "BloodTypeID");

            migrationBuilder.CreateIndex(
                name: "IX_LR_mstDriver_GenderID",
                schema: "dbo",
                table: "LR_mstDriver",
                column: "GenderID");

            migrationBuilder.CreateIndex(
                name: "IX_LR_mstDriver_MaritalStatusID",
                schema: "dbo",
                table: "LR_mstDriver",
                column: "MaritalStatusID");

            migrationBuilder.CreateIndex(
                name: "IX_LR_mstDriver_NationalityID",
                schema: "dbo",
                table: "LR_mstDriver",
                column: "NationalityID");

            migrationBuilder.CreateIndex(
                name: "IX_LR_mstDriver_ReligionID",
                schema: "dbo",
                table: "LR_mstDriver",
                column: "ReligionID");

            migrationBuilder.CreateIndex(
                name: "IX_LR_mstDriver_StatusID",
                schema: "dbo",
                table: "LR_mstDriver",
                column: "StatusID");

            migrationBuilder.CreateIndex(
                name: "IX_LR_mstDriverStatus_DriverID",
                schema: "dbo",
                table: "LR_mstDriverStatus",
                column: "DriverID");

            migrationBuilder.CreateIndex(
                name: "IX_LR_mstGender_StatusID",
                schema: "dbo",
                table: "LR_mstGender",
                column: "StatusID");

            migrationBuilder.CreateIndex(
                name: "IX_LR_mstMaritalStatus_StatusID",
                schema: "dbo",
                table: "LR_mstMaritalStatus",
                column: "StatusID");

            migrationBuilder.CreateIndex(
                name: "IX_LR_mstNationality_StatusID",
                schema: "dbo",
                table: "LR_mstNationality",
                column: "StatusID");

            migrationBuilder.CreateIndex(
                name: "IX_LR_mstReligion_StatusID",
                schema: "dbo",
                table: "LR_mstReligion",
                column: "StatusID");
        }
    }
}
