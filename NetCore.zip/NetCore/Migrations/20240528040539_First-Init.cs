﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NetCore.Migrations
{
    /// <inheritdoc />
    public partial class FirstInit : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "dbo");

            migrationBuilder.CreateTable(
                name: "LR_mstStatus",
                schema: "dbo",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    LogBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LogDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LogInc = table.Column<int>(type: "int", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Remarks = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LR_mstStatus", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "LR_mstBloodType",
                schema: "dbo",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StatusID = table.Column<int>(type: "int", nullable: false),
                    LogBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LogDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LogInc = table.Column<int>(type: "int", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Remarks = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LR_mstBloodType", x => x.ID);
                    table.ForeignKey(
                        name: "FK_LR_mstBloodType_LR_mstStatus_StatusID",
                        column: x => x.StatusID,
                        principalSchema: "dbo",
                        principalTable: "LR_mstStatus",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "LR_mstGender",
                schema: "dbo",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StatusID = table.Column<int>(type: "int", nullable: false),
                    LogBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LogDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LogInc = table.Column<int>(type: "int", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Remarks = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LR_mstGender", x => x.ID);
                    table.ForeignKey(
                        name: "FK_LR_mstGender_LR_mstStatus_StatusID",
                        column: x => x.StatusID,
                        principalSchema: "dbo",
                        principalTable: "LR_mstStatus",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "LR_mstMaritalStatus",
                schema: "dbo",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StatusID = table.Column<int>(type: "int", nullable: false),
                    LogBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LogDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LogInc = table.Column<int>(type: "int", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Remarks = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LR_mstMaritalStatus", x => x.ID);
                    table.ForeignKey(
                        name: "FK_LR_mstMaritalStatus_LR_mstStatus_StatusID",
                        column: x => x.StatusID,
                        principalSchema: "dbo",
                        principalTable: "LR_mstStatus",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "LR_mstNationality",
                schema: "dbo",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StatusID = table.Column<int>(type: "int", nullable: false),
                    LogBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LogDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LogInc = table.Column<int>(type: "int", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Remarks = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LR_mstNationality", x => x.ID);
                    table.ForeignKey(
                        name: "FK_LR_mstNationality_LR_mstStatus_StatusID",
                        column: x => x.StatusID,
                        principalSchema: "dbo",
                        principalTable: "LR_mstStatus",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "LR_mstReligion",
                schema: "dbo",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StatusID = table.Column<int>(type: "int", nullable: false),
                    LogBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LogDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LogInc = table.Column<int>(type: "int", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Remarks = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LR_mstReligion", x => x.ID);
                    table.ForeignKey(
                        name: "FK_LR_mstReligion_LR_mstStatus_StatusID",
                        column: x => x.StatusID,
                        principalSchema: "dbo",
                        principalTable: "LR_mstStatus",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "LR_mstDriver",
                schema: "dbo",
                columns: table => new
                {
                    ID = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    IdentityCardNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DrivingLicenseNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FullName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PlaceOfBirth = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DateOfBirth = table.Column<DateTime>(type: "datetime2", nullable: false),
                    GenderID = table.Column<int>(type: "int", nullable: false),
                    BloodTypeID = table.Column<int>(type: "int", nullable: false),
                    AddressOfIdentityCard = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    AddressOfDrivingLicense = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ReligionID = table.Column<int>(type: "int", nullable: false),
                    MaritalStatusID = table.Column<int>(type: "int", nullable: false),
                    NationalityID = table.Column<int>(type: "int", nullable: false),
                    OccupationsIDOfIdentityCard = table.Column<int>(type: "int", nullable: false),
                    OccupationsOthersOfIdentityCard = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    OccupationsIDOfDrivingLicense = table.Column<int>(type: "int", nullable: false),
                    OccupationsOthersOfDrivingLicense = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ValidThruOfIdentityCard = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ValidThruOfDrivingLicense = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DrivingLicenseTypeID = table.Column<int>(type: "int", nullable: false),
                    Height = table.Column<int>(type: "int", nullable: false),
                    StatusID = table.Column<int>(type: "int", nullable: false),
                    CreatedFromComLocID = table.Column<int>(type: "int", nullable: false),
                    LastUpdatedFromComLocID = table.Column<int>(type: "int", nullable: false),
                    ReferencesID = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    InternalRemarks = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LogBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LogDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LogInc = table.Column<int>(type: "int", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Remarks = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LR_mstDriver", x => x.ID);
                    table.ForeignKey(
                        name: "FK_LR_mstDriver_LR_mstBloodType_BloodTypeID",
                        column: x => x.BloodTypeID,
                        principalSchema: "dbo",
                        principalTable: "LR_mstBloodType",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_LR_mstDriver_LR_mstGender_GenderID",
                        column: x => x.GenderID,
                        principalSchema: "dbo",
                        principalTable: "LR_mstGender",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_LR_mstDriver_LR_mstMaritalStatus_MaritalStatusID",
                        column: x => x.MaritalStatusID,
                        principalSchema: "dbo",
                        principalTable: "LR_mstMaritalStatus",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_LR_mstDriver_LR_mstNationality_NationalityID",
                        column: x => x.NationalityID,
                        principalSchema: "dbo",
                        principalTable: "LR_mstNationality",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_LR_mstDriver_LR_mstReligion_ReligionID",
                        column: x => x.ReligionID,
                        principalSchema: "dbo",
                        principalTable: "LR_mstReligion",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_LR_mstDriver_LR_mstStatus_StatusID",
                        column: x => x.StatusID,
                        principalSchema: "dbo",
                        principalTable: "LR_mstStatus",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_LR_mstBloodType_StatusID",
                schema: "dbo",
                table: "LR_mstBloodType",
                column: "StatusID");

            migrationBuilder.CreateIndex(
                name: "IX_LR_mstDriver_BloodTypeID",
                schema: "dbo",
                table: "LR_mstDriver",
                column: "BloodTypeID");

            migrationBuilder.CreateIndex(
                name: "IX_LR_mstDriver_GenderID",
                schema: "dbo",
                table: "LR_mstDriver",
                column: "GenderID");

            migrationBuilder.CreateIndex(
                name: "IX_LR_mstDriver_MaritalStatusID",
                schema: "dbo",
                table: "LR_mstDriver",
                column: "MaritalStatusID");

            migrationBuilder.CreateIndex(
                name: "IX_LR_mstDriver_NationalityID",
                schema: "dbo",
                table: "LR_mstDriver",
                column: "NationalityID");

            migrationBuilder.CreateIndex(
                name: "IX_LR_mstDriver_ReligionID",
                schema: "dbo",
                table: "LR_mstDriver",
                column: "ReligionID");

            migrationBuilder.CreateIndex(
                name: "IX_LR_mstDriver_StatusID",
                schema: "dbo",
                table: "LR_mstDriver",
                column: "StatusID");

            migrationBuilder.CreateIndex(
                name: "IX_LR_mstGender_StatusID",
                schema: "dbo",
                table: "LR_mstGender",
                column: "StatusID");

            migrationBuilder.CreateIndex(
                name: "IX_LR_mstMaritalStatus_StatusID",
                schema: "dbo",
                table: "LR_mstMaritalStatus",
                column: "StatusID");

            migrationBuilder.CreateIndex(
                name: "IX_LR_mstNationality_StatusID",
                schema: "dbo",
                table: "LR_mstNationality",
                column: "StatusID");

            migrationBuilder.CreateIndex(
                name: "IX_LR_mstReligion_StatusID",
                schema: "dbo",
                table: "LR_mstReligion",
                column: "StatusID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "LR_mstDriver",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "LR_mstBloodType",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "LR_mstGender",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "LR_mstMaritalStatus",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "LR_mstNationality",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "LR_mstReligion",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "LR_mstStatus",
                schema: "dbo");
        }
    }
}
