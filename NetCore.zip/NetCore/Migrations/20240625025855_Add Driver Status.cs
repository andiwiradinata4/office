﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace NetCore.Migrations
{
    /// <inheritdoc />
    public partial class AddDriverStatus : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                schema: "dbo",
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "267c9dde-1fd2-49ab-952f-dffb040d0319");

            migrationBuilder.DeleteData(
                schema: "dbo",
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "3b975f44-d368-4ed5-a704-335460c82f0b");

            migrationBuilder.CreateTable(
                name: "LR_mstDriverStatus",
                schema: "dbo",
                columns: table => new
                {
                    ID = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    DriverID = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Status = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StatusBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StatusDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Remarks = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LR_mstDriverStatus", x => x.ID);
                    table.ForeignKey(
                        name: "FK_LR_mstDriverStatus_LR_mstDriver_DriverID",
                        column: x => x.DriverID,
                        principalSchema: "dbo",
                        principalTable: "LR_mstDriver",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "ad031c38-fae0-448e-85c1-6404c1747a71", null, "User", "USER" },
                    { "fd7a6885-4333-4984-8e38-77b79aa9e260", null, "Admin", "ADMIN" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_LR_mstDriverStatus_DriverID",
                schema: "dbo",
                table: "LR_mstDriverStatus",
                column: "DriverID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "LR_mstDriverStatus",
                schema: "dbo");

            migrationBuilder.DeleteData(
                schema: "dbo",
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "ad031c38-fae0-448e-85c1-6404c1747a71");

            migrationBuilder.DeleteData(
                schema: "dbo",
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "fd7a6885-4333-4984-8e38-77b79aa9e260");

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "267c9dde-1fd2-49ab-952f-dffb040d0319", null, "User", "USER" },
                    { "3b975f44-d368-4ed5-a704-335460c82f0b", null, "Admin", "ADMIN" }
                });
        }
    }
}
