﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace NetCore.Migrations
{
    /// <inheritdoc />
    public partial class UpdateVariableStatus : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                schema: "dbo",
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "4ea9515b-c521-4a78-80dd-6b1ef9706452");

            migrationBuilder.DeleteData(
                schema: "dbo",
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "60256bb8-b4a8-4eb4-a965-e2d4dfe49a25");

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "267c9dde-1fd2-49ab-952f-dffb040d0319", null, "User", "USER" },
                    { "3b975f44-d368-4ed5-a704-335460c82f0b", null, "Admin", "ADMIN" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                schema: "dbo",
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "267c9dde-1fd2-49ab-952f-dffb040d0319");

            migrationBuilder.DeleteData(
                schema: "dbo",
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "3b975f44-d368-4ed5-a704-335460c82f0b");

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "4ea9515b-c521-4a78-80dd-6b1ef9706452", null, "User", "USER" },
                    { "60256bb8-b4a8-4eb4-a965-e2d4dfe49a25", null, "Admin", "ADMIN" }
                });
        }
    }
}
