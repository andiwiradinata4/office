﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace NetCore.Migrations
{
    /// <inheritdoc />
    public partial class Dropalltables : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                schema: "dbo",
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "e38560fc-57b0-40e8-b1ba-b59321343d42");

            migrationBuilder.DeleteData(
                schema: "dbo",
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "f84c29df-310a-4395-9645-7c9064abb2e0");

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "0f836a01-c356-4cfd-8f9f-b212f3bd3954", null, "Admin", "ADMIN" },
                    { "2052c469-5e65-459e-9acf-65970916a71a", null, "User", "USER" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                schema: "dbo",
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "0f836a01-c356-4cfd-8f9f-b212f3bd3954");

            migrationBuilder.DeleteData(
                schema: "dbo",
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "2052c469-5e65-459e-9acf-65970916a71a");

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "e38560fc-57b0-40e8-b1ba-b59321343d42", null, "Admin", "ADMIN" },
                    { "f84c29df-310a-4395-9645-7c9064abb2e0", null, "User", "USER" }
                });
        }
    }
}
