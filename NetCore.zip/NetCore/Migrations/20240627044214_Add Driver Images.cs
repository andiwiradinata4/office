﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace NetCore.Migrations
{
    /// <inheritdoc />
    public partial class AddDriverImages : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                schema: "dbo",
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "199c868b-29b6-4236-83f7-bcd3077814a6");

            migrationBuilder.DeleteData(
                schema: "dbo",
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "34ddca38-26a1-445c-9364-ba2892ea0c0d");

            migrationBuilder.CreateTable(
                name: "LR_mstDriverImage",
                schema: "dbo",
                columns: table => new
                {
                    ID = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    DriverID = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ImagePath = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ImageTypeID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LR_mstDriverImage", x => x.ID);
                    table.ForeignKey(
                        name: "FK_LR_mstDriverImage_LR_mstDriver_DriverID",
                        column: x => x.DriverID,
                        principalSchema: "dbo",
                        principalTable: "LR_mstDriver",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "3a0ed81c-7271-4967-8339-44d5919544aa", null, "Admin", "ADMIN" },
                    { "96f71ac1-c5dd-4ab3-85a7-28c0aa19516e", null, "User", "USER" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_LR_mstDriverImage_DriverID",
                schema: "dbo",
                table: "LR_mstDriverImage",
                column: "DriverID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "LR_mstDriverImage",
                schema: "dbo");

            migrationBuilder.DeleteData(
                schema: "dbo",
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "3a0ed81c-7271-4967-8339-44d5919544aa");

            migrationBuilder.DeleteData(
                schema: "dbo",
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "96f71ac1-c5dd-4ab3-85a7-28c0aa19516e");

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "199c868b-29b6-4236-83f7-bcd3077814a6", null, "Admin", "ADMIN" },
                    { "34ddca38-26a1-445c-9364-ba2892ea0c0d", null, "User", "USER" }
                });
        }
    }
}
