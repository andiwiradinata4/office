﻿using Microsoft.AspNetCore.Mvc;
using NetCore.Models;
using NetCore.Services.Interfaces;

namespace NetCore.Controllers.v1
{
    [Route("api/v1/religion")]
    [ApiController]
    public class ReligionController : BaseController<Religion>
    {
        private readonly IReligionService _svc;
        public ReligionController(IReligionService svc) : base(svc)
        {
            _svc = svc;
        }

        //public override Religion MapDTOToEntity(ReligionDTO dto)
        //{
        //    return dto.FromDto();
        //}

        //public override Religion MapCreateDTOToEntity(ReligionDTO dto)
        //{
        //    return dto.FromCreateOrUpdateDto();
        //}

        //public override Religion MapUpdateDTOToEntity(ReligionDTO dto)
        //{
        //    return dto.FromCreateOrUpdateDto();
        //}

        //[HttpPost]
        //public async Task<IActionResult> Create([FromBody] BaseMasterCreateOrUpdateDto Requestdto)
        //{
        //    try
        //    {
        //        if (!ModelState.IsValid) return BadRequest(ModelState);
        //        Religion model = Requestdto.FromCreateOrUpdateReligionDto();
        //        model = await _svc.CreateAsync(model);
        //        return CreatedAtAction(nameof(GetByID), new { id = model.ID }, model.ToDto());
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(ex.Message);
        //    }
        //}

        //[HttpPut("{id}")]
        //public async Task<IActionResult> Update([FromRoute] int id, [FromBody] BaseMasterCreateOrUpdateDto Requestdto)
        //{
        //    try
        //    {
        //        if (!ModelState.IsValid) return BadRequest(ModelState);
        //        Religion data = Requestdto.FromCreateOrUpdateReligionDto();
        //        data = await _svc.UpdateAsync(id, data);
        //        return Ok(new AppResponse(true, "Save Data Success", new { id }));
        //    }
        //    catch (AppException ex)
        //    {
        //        return BadRequest(new AppResponse(false, ex.Message, null));
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(new AppResponse(false, ex, null));
        //    }
        //}
    }
}
