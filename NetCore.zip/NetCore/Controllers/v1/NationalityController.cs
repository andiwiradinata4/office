﻿using Microsoft.AspNetCore.Mvc;
using NetCore.Models;
using NetCore.Services.Interfaces;
using NetCore.usDBContext;

namespace NetCore.Controllers.v1
{
    [Route("api/v1/nationality")]
    public class NationalityController : BaseController<AppDBContext, Nationality>
    {
        public NationalityController(IBaseService<AppDBContext, Nationality> svc) : base(svc)
        {
            
        }

        //public override Nationality MapDTOToEntity(NationalityDTO dto)
        //{
        //    return dto.FromDto();
        //}

        //public override Nationality MapCreateDTOToEntity(NationalityDTO dto)
        //{
        //    return dto.FromCreateOrUpdateDto();
        //}

        //public override Nationality MapUpdateDTOToEntity(NationalityDTO dto)
        //{
        //    return dto.FromCreateOrUpdateDto();
        //}

        //[HttpPost]
        //public async Task<IActionResult> Create([FromBody] BaseMasterCreateOrUpdateDto Requestdto)
        //{
        //    try
        //    {
        //        if (!ModelState.IsValid) return BadRequest(ModelState);
        //        Nationality model = Requestdto.FromCreateOrUpdateNationalityDto();
        //        model = await _svc.CreateAsync(model);
        //        return CreatedAtAction(nameof(GetByID), new { id = model.ID }, model.ToDto());
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(ex.Message);
        //    }
        //}

        //[HttpPut("{id}")]
        //public async Task<IActionResult> Update([FromRoute] int id, [FromBody] BaseMasterCreateOrUpdateDto Requestdto)
        //{
        //    try
        //    {
        //        if (!ModelState.IsValid) return BadRequest(ModelState);
        //        Nationality data = Requestdto.FromCreateOrUpdateNationalityDto();
        //        data = await _svc.UpdateAsync(id, data);
        //        return Ok(new AppResponse(true, "Save Data Success", new { id }));
        //    }
        //    catch (AppException ex)
        //    {
        //        return BadRequest(new AppResponse(false, ex.Message, null));
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(new AppResponse(false, ex.InnerException, null));
        //    }
        //}
    }
}
