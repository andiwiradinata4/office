﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NetCore.Models;
using NetCore.Services.Interfaces;

namespace NetCore.Controllers.v1
{
    [Route("api/v1/driver")]
    [ApiController]
    public class DriverController : BaseController<Driver>
    {
        private readonly IDriverService _svc;

        public DriverController(IDriverService svc) : base(svc)
        {
            _svc = svc;
        }
    }
}
