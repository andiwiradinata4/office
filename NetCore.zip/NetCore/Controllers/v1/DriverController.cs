﻿using Microsoft.AspNetCore.Mvc;
using NetCore.Models;
using NetCore.Services.Interfaces;
using NetCore.usException;
using NetCore.usResponse;

namespace NetCore.Controllers.v1
{
    [Route("api/v1/driver")]
    [ApiController]
    public class DriverController : BaseController<Driver>
    {
        private readonly IDriverService _svc;
        private readonly IWebHostEnvironment _env;

        public DriverController(IDriverService svc, IWebHostEnvironment env) : base(svc)
        {
            _svc = svc;
            _env = env;

            string uploadPath = Path.Combine(_env.ContentRootPath, "Uploads");
            if (!Directory.Exists(uploadPath)) Directory.CreateDirectory(uploadPath);
        }

        //[HttpPost("upload-file")]
        //public async Task<IActionResult> UploadFile(IFormFile file)
        //{
        //    try
        //    {
        //        if (file == null || file.Length == 0) throw new Exception("No file uploaded.");
        //        string newFileName = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName);
        //        var filePath = Path.Combine(_env.ContentRootPath, "Uploads", newFileName);
        //        using (var stream = new FileStream(filePath, FileMode.Create))
        //        {
        //            await file.CopyToAsync(stream);
        //        }
        //        return Ok(new AppResponse(true, $"Upload file success. {filePath}", null));
        //    }
        //    catch (AppException ex)
        //    {
        //        return BadRequest(new AppResponse(false, ex.Message, null));
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(new AppResponse(false, ex, null));
        //    }
        //}

        //[HttpPost("upload-file-multiple")]
        //public async Task<IActionResult> UploadFile(List<IFormFile> files)
        //{
        //    try
        //    {
        //        if (files == null || files.Count == 0) throw new Exception("No file uploaded.");
        //        List<string> filePaths = new();
        //        foreach (var file in files)
        //        {
        //            if (file == null || file.Length == 0) throw new Exception("No file uploaded.");
        //            var filePath = Path.Combine(_env.ContentRootPath, "Uploads", file.FileName);
        //            using (var stream = new FileStream(filePath, FileMode.Create))
        //            {
        //                await file.CopyToAsync(stream);
        //            }
        //        }
        //        return Ok(new AppResponse(true, $"Upload file success. {filePaths}", null));
        //    }
        //    catch (AppException ex)
        //    {
        //        return BadRequest(new AppResponse(false, ex.Message, null));
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(new AppResponse(false, ex, null));
        //    }
        //}

        //[HttpGet("download-file/{id}")]
        //public async Task<IActionResult> DownloadFile([FromRoute] Guid id)
        //{
        //    var files = Directory.GetFiles(Path.Combine(_env.ContentRootPath, "Uploads"));
        //    foreach (var file in files)
        //    {
        //        var fileName = Path.GetFileNameWithoutExtension(file);
        //        if (fileName.Equals(id.ToString(), StringComparison.OrdinalIgnoreCase))
        //        {
        //            var fileBytes = await System.IO.File.ReadAllBytesAsync(file);
        //            var fileExtension = Path.GetExtension(file);
        //            return File(fileBytes, "application/octet-stream", "Image" + fileExtension);
        //        }
        //    }
        //    return BadRequest(new AppResponse(false, "File not found", null));
        //}

        //[HttpGet("view-file/{id}")]
        //public IActionResult ViewFile([FromRoute] Guid id)
        //{
        //    var files = Directory.GetFiles(Path.Combine(_env.ContentRootPath, "Uploads"));
        //    foreach (var file in files)
        //    {
        //        var fileName = Path.GetFileNameWithoutExtension(file);
        //        if (fileName.Equals(id.ToString(), StringComparison.OrdinalIgnoreCase))
        //        {
        //            var fileStream = new FileStream(file, FileMode.Open, FileAccess.Read);
        //            var fileExtension = Path.GetExtension(file);
        //            return File(fileStream, "application/octet-stream", "Image" + fileExtension);
        //        }
        //    }
        //    return BadRequest(new AppResponse(false, "File not found", null));
        //}
    }
}
