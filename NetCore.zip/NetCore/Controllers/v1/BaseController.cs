﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using NetCore.Models;
using NetCore.Models.dto.Base;
using NetCore.Models.Interface;
using NetCore.Services.Interfaces;
using NetCore.usException;
using NetCore.Utilities;
using System.Runtime.CompilerServices;
using System.Security.Claims;

namespace NetCore.Controllers.v1
{
    [ApiController]
    [Route("api/[controller]")]
    public abstract class BaseController<TDbContext, T> : BaseSelectController<TDbContext, T> where TDbContext : DbContext where T : BaseEntity, IEntityStandard
    {
        //private readonly IBaseService<T> _svc;

        //public BaseController(IBaseService<T> svc)
        //{
        //    _svc = svc;
        //}

        //[HttpGet]
        //[Authorize]
        //public virtual async Task<IActionResult> GetAll()
        //{
        //    try
        //    {
        //        return Ok(new MessageObject(true,
        //                                  "Get All Data Success",
        //                                  await _svc.GetAllAsync(new QueryObject())));
        //    }
        //    catch (AppException ex)
        //    {
        //        return BadRequest(new MessageObject(false, ex.Message, null));
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(new MessageObject(false, ex, null));
        //    }
        //}

        //[HttpPost]
        //[Authorize]
        //public virtual async Task<IActionResult> GetAll([FromBody] QueryObject query)
        //{
        //    try
        //    {
        //        return Ok(new MessageObject(true,
        //                                  "Get All Data Success",
        //                                  await _svc.GetAllAsync(query)));
        //    }
        //    catch (AppException ex)
        //    {
        //        return BadRequest(new MessageObject(false, ex.Message, null));
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(new MessageObject(false, ex, null));
        //    }
        //}

        //[HttpPost("detail/{id}")]
        //[Authorize]
        //public virtual async Task<IActionResult> GetByID([FromBody] QueryObject query, [FromRoute] string id)
        //{
        //    try
        //    {
        //        return Ok(new MessageObject(true,
        //                                  "Get Data Success",
        //                                  await _svc.GetByIDAsync(id)));
        //    }
        //    catch (AppException ex)
        //    {
        //        return BadRequest(new MessageObject(false, ex.Message, null));
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(new MessageObject(false, ex, null));
        //    }
        //}

        //[HttpGet("detail/{id}")]
        //[Authorize]
        //public virtual async Task<IActionResult> GetByID([FromRoute] string id)
        //{
        //    try
        //    {
        //        return Ok(new MessageObject(true,
        //                                  "Get Data Success",
        //                                  await _svc.GetByIDAsync(id)));
        //    }
        //    catch (AppException ex)
        //    {
        //        return BadRequest(new MessageObject(false, ex.Message, null));
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(new MessageObject(false, ex, null));
        //    }
        //}

        //[HttpPost("create")]
        //[Authorize]
        //public virtual async Task<IActionResult> Create([FromBody] T entity)
        //{
        //    try
        //    {
        //        if (!ModelState.IsValid) return BadRequest(ModelState);

        //        string userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "";

        //        //var entity = MapCreateDTOToEntity(dto);
        //        return Ok(new MessageObject(true,
        //                                  "Create Data Success",
        //                                  await _svc.CreateAsync(entity, userId)));
        //    }
        //    catch (AppException ex)
        //    {
        //        return BadRequest(new MessageObject(false, ex.Message, null));
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(new MessageObject(false, ex, null));
        //    }
        //}

        //[HttpPut("{id}")]
        //[Authorize]
        //public virtual async Task<IActionResult> Update([FromRoute] string id, [FromBody] T dto)
        //{
        //    try
        //    {
        //        if (!ModelState.IsValid) return BadRequest(ModelState);

        //        string userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "";

        //        //var entity = MapUpdateDTOToEntity(dto);
        //        var data = await _svc.UpdateAsync(id, dto, userId);
        //        return Ok(new MessageObject(true,
        //                                  "Update Data Success",
        //                                  new { id }));
        //    }
        //    catch (AppException ex)
        //    {
        //        return BadRequest(new MessageObject(false, ex.Message, null));
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(new MessageObject(false, ex, null));
        //    }
        //}

        //[HttpDelete("{id}")]
        //[Authorize]
        //public virtual async Task<IActionResult> Delete([FromRoute] string id)
        //{
        //    try
        //    {
        //        if (!ModelState.IsValid) return BadRequest(ModelState);
        //        var data = await _svc.DeleteAsync(id);
        //        return Ok(new MessageObject(true,
        //                                  "Delete Data Success",
        //                                  null));
        //    }
        //    catch (AppException ex)
        //    {
        //        return BadRequest(new MessageObject(false, ex.Message, null));
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(new MessageObject(false, ex, null));
        //    }
        //}

        //public virtual T MapDTOToEntity(TDTO dto)
        //{
        //    throw new AppException($"Method MapDTOToEntity needs to be implemented in the derived class.");
        //}

        //public abstract T MapCreateDTOToEntity(TDTO dto);
        //{
        //    throw new AppException($"Method MapCreateDTOToEntity needs to be implemented in the derived class.");
        //}
        //public virtual T MapUpdateDTOToEntity(TDTO dto)
        //{
        //    throw new AppException($"Method MapUpdateDTOToEntity needs to be implemented in the derived class.");
        //}

        public BaseController()
        {
        }

        public BaseController(IBaseService<TDbContext, T> svc) : base(svc) { }

        [HttpPost]
        public virtual IActionResult Create(T obj)
        {
            if (!base.ModelState.IsValid)
            {
                return BadRequest(base.ModelState);
            }

            MessageObject<T> messageObject = svc.Create(obj);
            if (messageObject.ProcessingStatus)
            {
                return Ok(messageObject);
            }

            return BadRequest(messageObject);
        }

        [HttpPut("{id}")]
        public virtual IActionResult Update([FromRoute] string id, [FromBody] T obj)
        {
            if (!base.ModelState.IsValid)
            {
                return BadRequest(base.ModelState);
            }

            if (id != obj.Id)
            {
                DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(31, 2);
                defaultInterpolatedStringHandler.AppendLiteral("Route Id ");
                defaultInterpolatedStringHandler.AppendFormatted(id);
                defaultInterpolatedStringHandler.AppendLiteral(" not equal to Body Id ");
                defaultInterpolatedStringHandler.AppendFormatted(obj.Id);
                return BadRequest(defaultInterpolatedStringHandler.ToStringAndClear());
            }

            if (obj == null || obj.RowVersion == null)
            {
                DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(39, 1);
                defaultInterpolatedStringHandler.AppendLiteral("RowVersion of Body Id ");
                defaultInterpolatedStringHandler.AppendFormatted(id);
                defaultInterpolatedStringHandler.AppendLiteral(" cannot be null. ");
                return BadRequest(defaultInterpolatedStringHandler.ToStringAndClear());
            }

            T? data = svc.GetById(obj.Id);
            if (data == null)
            {
                DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(39, 1);
                defaultInterpolatedStringHandler.AppendLiteral("Data ");
                defaultInterpolatedStringHandler.AppendFormatted(id);
                defaultInterpolatedStringHandler.AppendLiteral(" not found. ");
                return BadRequest(defaultInterpolatedStringHandler.ToStringAndClear());
            }

            if (Convert.ToBase64String(data.RowVersion) != Convert.ToBase64String(obj.RowVersion))
            {
                MessageObject<T> messageObject = new MessageObject<T>();
                messageObject.AddMessage(MessageType.Error, "RowVersion Conflict", "The record has been changed by another user since you started editing it. Please try again.", "RowVersion");
                return Conflict(messageObject);
            }

            try
            {
                MessageObject<T> messageObject2 = svc.Update(id, obj);
                if (messageObject2.ProcessingStatus)
                {
                    return Ok(messageObject2);
                }

                return BadRequest(messageObject2);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!svc.Exists(id))
                {
                    return NotFound();
                }
                throw;
            }
        }

        [HttpPut("{id}/disable")]
        public virtual IActionResult Disable([FromRoute] string id, [FromBody] T obj)
        {
            if (!base.ModelState.IsValid)
            {
                return BadRequest(base.ModelState);
            }

            if (id != obj.Id)
            {
                DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(31, 2);
                defaultInterpolatedStringHandler.AppendLiteral("Route Id ");
                defaultInterpolatedStringHandler.AppendFormatted(id);
                defaultInterpolatedStringHandler.AppendLiteral(" not equal to Body Id ");
                defaultInterpolatedStringHandler.AppendFormatted(obj.Id);
                return BadRequest(defaultInterpolatedStringHandler.ToStringAndClear());
            }

            if (obj == null || obj.RowVersion == null)
            {
                DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(39, 1);
                defaultInterpolatedStringHandler.AppendLiteral("RowVersion of Body Id ");
                defaultInterpolatedStringHandler.AppendFormatted(id);
                defaultInterpolatedStringHandler.AppendLiteral(" cannot be null. ");
                return BadRequest(defaultInterpolatedStringHandler.ToStringAndClear());
            }

            T? data = svc.GetById(obj.Id);
            if (data == null)
            {
                DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(39, 1);
                defaultInterpolatedStringHandler.AppendLiteral("Data ");
                defaultInterpolatedStringHandler.AppendFormatted(id);
                defaultInterpolatedStringHandler.AppendLiteral(" not found. ");
                return BadRequest(defaultInterpolatedStringHandler.ToStringAndClear());
            }

            if (Convert.ToBase64String(data.RowVersion) != Convert.ToBase64String(obj.RowVersion))
            {
                MessageObject<T> messageObject = new MessageObject<T>();
                messageObject.AddMessage(MessageType.Error, "RowVersion Conflict", "The record has been changed by another user since you started editing it. Please try again.", "RowVersion");
                return Conflict(messageObject);
            }

            try
            {
                MessageObject<T> messageObject2 = svc.Disable(id, obj);
                if (messageObject2.ProcessingStatus)
                {
                    return Ok(messageObject2);
                }

                return BadRequest(messageObject2);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!svc.Exists(id))
                {
                    return NotFound();
                }
                throw;
            }
        }

        [HttpDelete("{id}")]
        public virtual IActionResult Delete(string id)
        {
            T? data = svc.GetById(id);
            if (data == null)
            {
                return NotFound();
            }

            MessageObject<T> messageObject = svc.Delete(data);
            if (messageObject.ProcessingStatus)
            {
                return Ok(messageObject);
            }

            return BadRequest(messageObject);
        }
    }
}