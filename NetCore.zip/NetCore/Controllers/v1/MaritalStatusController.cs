﻿using Microsoft.AspNetCore.Mvc;
using NetCore.Models;
using NetCore.Services.Interfaces;
using NetCore.usDBContext;

namespace NetCore.Controllers.v1
{
    [Route("api/v1/marital-status")]
    [ApiController]
    public class MaritalStatusController : BaseController<AppDBContext, MaritalStatus>
    {
        public MaritalStatusController(IBaseService<AppDBContext, MaritalStatus> svc) : base(svc)
        {
        }

        //public override MaritalStatus MapDTOToEntity(MaritalStatusDTO dto)
        //{
        //    return dto.FromDto();
        //}

        //public override MaritalStatus MapCreateDTOToEntity(MaritalStatusDTO dto)
        //{
        //    return dto.FromCreateOrUpdateDto();
        //}

        //public override MaritalStatus MapUpdateDTOToEntity(MaritalStatusDTO dto)
        //{
        //    return dto.FromCreateOrUpdateDto();
        //}

        //[HttpPost]
        //public async Task<IActionResult> Create([FromBody] BaseMasterCreateOrUpdateDto Requestdto)
        //{
        //    try
        //    {
        //        if (!ModelState.IsValid) return BadRequest(ModelState);
        //        MaritalStatus model = Requestdto.FromCreateOrUpdateMaritalStatusDto();
        //        model = await _svc.CreateAsync(model);
        //        return CreatedAtAction(nameof(GetByID), new { id = model.ID }, model.ToDto());
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(ex.Message);
        //    }
        //}

        //[HttpPut("{id}")]
        //public async Task<IActionResult> Update([FromRoute] int id, [FromBody] BaseMasterCreateOrUpdateDto Requestdto)
        //{
        //    try
        //    {
        //        if (!ModelState.IsValid) return BadRequest(ModelState);
        //        MaritalStatus data = Requestdto.FromCreateOrUpdateMaritalStatusDto();
        //        data = await _svc.UpdateAsync(id, data);
        //        return Ok(new AppResponse(true, "Save Data Success", new { id }));
        //    }
        //    catch (AppException ex)
        //    {
        //        return BadRequest(new AppResponse(false, ex.Message, null));
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(new AppResponse(false, ex, null));
        //    }
        //}
    }
}
