﻿using Microsoft.AspNetCore.Mvc;
using NetCore.Models.dto.Status;
using NetCore.Models;
using NetCore.Models.Mappers;
using NetCore.Services.Interfaces;
using NetCore.usResponse;
using NetCore.usException;

namespace NetCore.Controllers
{
    [Route("api/status")]
    [ApiController]
    public class StatusController : BaseController<Status>
    {

        private readonly IStatusService _svc;

        public StatusController(IStatusService svc) : base(svc)
        {
            _svc = svc;
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateOrUpdateDto RequestDto)
        {
            try
            {
                if (!ModelState.IsValid) return BadRequest(ModelState);
                Status model = RequestDto.FromCreateOrUpdateStatusDto();
                var data = await _svc.CreateAsync(model);
                return Created("", new AppResponse(true, "Save Data Success", new { data.ToDto().ID }));
            }
            catch (AppException ex)
            {
                return BadRequest(new AppResponse(false, ex.Message, null));
            }
            catch (Exception ex)
            {
                return BadRequest(new AppResponse(false, ex.InnerException, null));
            }
        }

        [HttpPut]
        [Route("{id}")]
        public async Task<IActionResult> Update([FromRoute] byte id, [FromBody] CreateOrUpdateDto RequestDto)
        {
            try
            {
                if (!ModelState.IsValid) return BadRequest(ModelState);
                Status dataFromDto = RequestDto.FromCreateOrUpdateStatusDto();
                var data = await _svc.UpdateAsync(id, dataFromDto);
                if (data == null) return NotFound();
                return Ok(new AppResponse(true, "Save Data Success", new { id }));
            }
            catch (AppException ex)
            {
                return BadRequest(new AppResponse(false, ex.Message, null));
            }
            catch (Exception ex)
            {
                return BadRequest(new AppResponse(false, ex.InnerException, null));
            }
        }
    }
}
