﻿using Microsoft.AspNetCore.Mvc;
using NetCore.Models;
using NetCore.Services.Interfaces;

namespace NetCore.Controllers
{
    [Route("api/status")]
    [ApiController]
    public class StatusController : BaseController<Status>
    {

        private readonly IStatusService _svc;

        public StatusController(IStatusService svc) : base(svc)
        {
            _svc = svc;
        }

        //public override Status MapDTOToEntity(StatusDTO dto)
        //{
        //    return dto.FromDto();
        //}

        //public override Status MapCreateDTOToEntity(StatusDTO dto)
        //{
        //    return dto.FromCreateOrUpdateStatusDto();
        //}

        //public override Status MapUpdateDTOToEntity(StatusDTO dto)
        //{
        //    return dto.FromCreateOrUpdateStatusDto();
        //}

        //[HttpPost]
        //public async Task<IActionResult> Create([FromBody] CreateOrUpdateDto RequestDto)
        //{
        //    try
        //    {
        //        if (!ModelState.IsValid) return BadRequest(ModelState);
        //        Status model = RequestDto.FromCreateOrUpdateStatusDto();
        //        var data = await _svc.CreateAsync(model);
        //        return Created("", new AppResponse(true, "Save Data Success", new { data.ToDto().ID }));
        //    }
        //    catch (AppException ex)
        //    {
        //        return BadRequest(new AppResponse(false, ex.Message, null));
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(new AppResponse(false, ex, null));
        //    }
        //}

        //[HttpPut]
        //[Route("{id}")]
        //public async Task<IActionResult> Update([FromRoute] byte id, [FromBody] CreateOrUpdateDto RequestDto)
        //{
        //    try
        //    {
        //        if (!ModelState.IsValid) return BadRequest(ModelState);
        //        Status dataFromDto = RequestDto.FromCreateOrUpdateStatusDto();
        //        var data = await _svc.UpdateAsync(id, dataFromDto);
        //        if (data == null) return NotFound();
        //        return Ok(new AppResponse(true, "Save Data Success", new { id }));
        //    }
        //    catch (AppException ex)
        //    {
        //        return BadRequest(new AppResponse(false, ex.Message, null));
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(new AppResponse(false, ex, null));
        //    }
        //}
    }
}
