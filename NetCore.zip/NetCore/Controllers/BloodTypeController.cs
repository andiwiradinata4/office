﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NetCore.Controllers.v1;
using NetCore.Models;
using NetCore.Services.Interfaces;
using NetCore.usResponse;

namespace NetCore.Controllers
{
    [ApiController]
    [Route("api/v1/blood-type")]
    [ApiVersion("1.0")]
    public class BloodTypeController : BaseController<BloodType>
    {
        private readonly IBloodTypeService _svc;
        public BloodTypeController(IBloodTypeService svc) : base(svc)
        {
            _svc = svc;
        }

        [HttpGet("with-join")]
        [Authorize]
        public async Task<IActionResult> GetAllWithJoin()
        {
            try
            {
                return Ok(new AppResponse(true, "Get Data Success", await _svc.GetAllWithJoinAsync()));
            }
            catch (Exception ex)
            {
                return BadRequest(new AppResponse(false, ex.Message, null));
            }
        }

        //public override BloodType MapDTOToEntity(BloodTypeDTO dto)
        //{
        //    return dto.FromDto();
        //}

        //public override BloodType MapCreateDTOToEntity(BloodTypeDTO dto)
        //{
        //    return new BloodType();
        //    return dto.FromCreateOrUpdateDto();
        //}

        //public override BloodType MapUpdateDTOToEntity(BloodTypeDTO dto)
        //{
        //    return dto.FromCreateOrUpdateDto();
        //}

        //using (var sqlTrans = _context.Database.BeginTransaction())
        //{
        //    sqlTrans.Commit();
        //    sqlTrans.Rollback();
        //}

    }
}
