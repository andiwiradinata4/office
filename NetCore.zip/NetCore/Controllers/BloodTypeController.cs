﻿using Microsoft.AspNetCore.Mvc;
using NetCore.Models;
using NetCore.Models.dto.Base;
using NetCore.Models.Mappers;
using NetCore.Services.Interfaces;
using NetCore.usException;
using NetCore.usResponse;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace NetCore.Controllers
{
    [Route("api/blood-type")]
    [ApiController]
    public class BloodTypeController : BaseController<BloodType>
    {
        private readonly IBloodTypeService _svc;
        public BloodTypeController(IBloodTypeService svc) : base(svc)
        {
            _svc = svc;
        }

        //using (var sqlTrans = _context.Database.BeginTransaction())
        //{
        //    sqlTrans.Commit();
        //    sqlTrans.Rollback();
        //}

        [HttpGet("include")]
        public async Task<IActionResult> GetAllWithIncludes([FromQuery] string[] includes)
        {
            try
            {
                var data = await _svc.GetAllAsync(includes);
                return Ok(new AppResponse(true, "Get All Data Success", await _svc.GetAllAsync(includes)));
            }
            catch (AppException ex)
            {
                return BadRequest(new AppResponse(false, ex.Message, null));
            }
            catch (Exception ex)
            {
                return BadRequest(new AppResponse(false, ex.InnerException, null));
            }
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] BaseMasterCreateOrUpdateDto Requestdto)
        {
            try
            {
                if (!ModelState.IsValid) return BadRequest(ModelState);
                BloodType data = Requestdto.FromCreateOrUpdateBloodTypeDto();
                data = await _svc.CreateAsync(data);
                return Created("", new AppResponse(true, "Save Data Success", new { data.ToDto().ID }));
            }
            catch (AppException ex)
            {
                return BadRequest(new AppResponse(false, ex.Message, null));
            }
            catch (Exception ex)
            {
                return BadRequest(new AppResponse(false, ex.InnerException, null));
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update([FromRoute] int id, [FromBody] BaseMasterCreateOrUpdateDto Requestdto)
        {
            try
            {
                if (!ModelState.IsValid) return BadRequest(ModelState);
                BloodType data = Requestdto.FromCreateOrUpdateBloodTypeDto();
                data = await _svc.UpdateAsync(id, data);
                return Ok(new AppResponse(true, "Save Data Success", new { id }));
            }
            catch (AppException ex)
            {
                return BadRequest(new AppResponse(false, ex.Message, null));
            }
            catch (Exception ex)
            {
                return BadRequest(new AppResponse(false, ex.InnerException, null));
            }
        }
    }
}
