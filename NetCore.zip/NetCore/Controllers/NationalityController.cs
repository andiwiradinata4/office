﻿using Microsoft.AspNetCore.Mvc;
using NetCore.Controllers.v1;
using NetCore.Models;
using NetCore.Services.Interfaces;

namespace NetCore.Controllers
{
    [Route("api/nationality")]
    public class NationalityController : BaseController<Nationality>
    {
        private readonly INationalityService _svc;
        public NationalityController(INationalityService svc) : base(svc)
        {
            _svc = svc;
        }

        //public override Nationality MapDTOToEntity(NationalityDTO dto)
        //{
        //    return dto.FromDto();
        //}

        //public override Nationality MapCreateDTOToEntity(NationalityDTO dto)
        //{
        //    return dto.FromCreateOrUpdateDto();
        //}

        //public override Nationality MapUpdateDTOToEntity(NationalityDTO dto)
        //{
        //    return dto.FromCreateOrUpdateDto();
        //}

        //[HttpPost]
        //public async Task<IActionResult> Create([FromBody] BaseMasterCreateOrUpdateDto Requestdto)
        //{
        //    try
        //    {
        //        if (!ModelState.IsValid) return BadRequest(ModelState);
        //        Nationality model = Requestdto.FromCreateOrUpdateNationalityDto();
        //        model = await _svc.CreateAsync(model);
        //        return CreatedAtAction(nameof(GetByID), new { id = model.ID }, model.ToDto());
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(ex.Message);
        //    }
        //}

        //[HttpPut("{id}")]
        //public async Task<IActionResult> Update([FromRoute] int id, [FromBody] BaseMasterCreateOrUpdateDto Requestdto)
        //{
        //    try
        //    {
        //        if (!ModelState.IsValid) return BadRequest(ModelState);
        //        Nationality data = Requestdto.FromCreateOrUpdateNationalityDto();
        //        data = await _svc.UpdateAsync(id, data);
        //        return Ok(new AppResponse(true, "Save Data Success", new { id }));
        //    }
        //    catch (AppException ex)
        //    {
        //        return BadRequest(new AppResponse(false, ex.Message, null));
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(new AppResponse(false, ex.InnerException, null));
        //    }
        //}
    }
}
