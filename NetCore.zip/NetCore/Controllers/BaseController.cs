﻿using Microsoft.AspNetCore.Mvc;
using NetCore.Services.Interfaces;
using NetCore.usException;
using NetCore.usResponse;

namespace NetCore.Controllers
{
    public abstract class BaseController<T> : ControllerBase
        where T : class
    {
        private readonly IBaseService<T> _svc;

        public BaseController(IBaseService<T> svc)
        {
            _svc = svc;
        }

        [HttpGet]
        public virtual async Task<IActionResult> GetAll([FromQuery] string[] includes)
        {
            try
            {
                return Ok(new AppResponse(true,
                                          "Get All Data Success",
                                          await _svc.GetAllAsync(includes)));
            }
            catch (AppException ex)
            {
                return BadRequest(new AppResponse(false, ex.Message, null));
            }
            catch (Exception ex)
            {
                return BadRequest(new AppResponse(false, ex, null));
            }
        }

        [HttpGet("{id}")]
        public virtual async Task<IActionResult> GetByID([FromRoute] string id)
        {
            try
            {
                return Ok(new AppResponse(true,
                                          "Get Data Success",
                                          await _svc.GetByIDAsync(id)));
            }
            catch (AppException ex)
            {
                return BadRequest(new AppResponse(false, ex.Message, null));
            }
            catch (Exception ex)
            {
                return BadRequest(new AppResponse(false, ex, null));
            }
        }

        [HttpPost]
        public virtual async Task<IActionResult> Create([FromBody] T entity)
        {
            try
            {
                if (!ModelState.IsValid) return BadRequest(ModelState);
                //var entity = MapCreateDTOToEntity(dto);
                return Ok(new AppResponse(true,
                                          "Create Data Success",
                                          await _svc.CreateAsync(entity)));
            }
            catch (AppException ex)
            {
                return BadRequest(new AppResponse(false, ex.Message, null));
            }
            catch (Exception ex)
            {
                return BadRequest(new AppResponse(false, ex, null));
            }
        }

        [HttpPut("{id}")]
        public virtual async Task<IActionResult> Update([FromRoute] string id, [FromBody] T dto)
        {
            try
            {
                if (!ModelState.IsValid) return BadRequest(ModelState);
                //var entity = MapUpdateDTOToEntity(dto);
                var data = await _svc.UpdateAsync(id, dto);
                return Ok(new AppResponse(true,
                                          "Update Data Success",
                                          new { id }));
            }
            catch (AppException ex)
            {
                return BadRequest(new AppResponse(false, ex.Message, null));
            }
            catch (Exception ex)
            {
                return BadRequest(new AppResponse(false, ex, null));
            }
        }

        [HttpDelete("{id}")]
        public virtual async Task<IActionResult> Delete([FromRoute] string id)
        {
            try
            {
                if (!ModelState.IsValid) return BadRequest(ModelState);
                var data = await _svc.DeleteAsync(id);
                return Ok(new AppResponse(true,
                                          "Delete Data Success",
                                          null));
            }
            catch (AppException ex)
            {
                return BadRequest(new AppResponse(false, ex.Message, null));
            }
            catch (Exception ex)
            {
                return BadRequest(new AppResponse(false, ex, null));
            }
        }

        //public virtual T MapDTOToEntity(TDTO dto)
        //{
        //    throw new AppException($"Method MapDTOToEntity needs to be implemented in the derived class.");
        //}

        //public abstract T MapCreateDTOToEntity(TDTO dto);
        //{
        //    throw new AppException($"Method MapCreateDTOToEntity needs to be implemented in the derived class.");
        //}
        //public virtual T MapUpdateDTOToEntity(TDTO dto)
        //{
        //    throw new AppException($"Method MapUpdateDTOToEntity needs to be implemented in the derived class.");
        //}

    }
}