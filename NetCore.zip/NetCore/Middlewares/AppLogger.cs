﻿using NetCore.Models;
using NetCore.Services.Interfaces;
using NetCore.usDBContext;

namespace NetCore.Middlewares
{
    public class AppLogger
    {
        private readonly RequestDelegate _next;
        private readonly IBaseService<AppDBContext, AppLog> _svc;
        public AppLogger(RequestDelegate next, IBaseService<AppDBContext, AppLog> svc)
        {
            _next = next;
            _svc = svc;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                if (context != null)
                {
                    await _svc.CreateAsync(new AppLog()
                    {
                        Method = context.Request.Method,
                        Body = context.Request.Body.ToString(),
                        Header = context.Request.Headers.ToString(),
                        LogType = "REQUEST"
                    });
                }
            }
            catch (Exception) { }
            await _next(context);
        }
    }
}
