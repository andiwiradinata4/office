﻿using NetCore.Models;
using NetCore.Models.Shared;
using NetCore.Services.Interfaces;
using NetCore.usDBContext;

namespace NetCore.Middlewares
{
    public class FilterComLoc
    {
        private readonly RequestDelegate _next;

        public FilterComLoc(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                if (context != null && context.User != null)
                {
                    ComLoc.ProgramId = context.Request.Headers["ProgramId"];
                    ComLoc.CompanyId = context.Request.Headers["CompanyId"];

                    //await _svc.CreateAsync(new AppLog()
                    //{
                    //    Method = context.Request.Method,
                    //    Body = context.Request.Body.ToString(),
                    //    Header = context.Request.Headers.ToString(),
                    //    LogType = "REQUEST"
                    //});

                }
            }
            catch (Exception) {  }
            await _next(context);
        }
    }
}
