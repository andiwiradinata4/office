﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace NetCore.Models.dto.MaritalStatus
{
    public class UpdateMaritalStatusDTO
    {
        [Required]
        public string Description { get; set; } = String.Empty;
        [Required]
        [ForeignKey("Status")]
        public int StatusID { get; set; }
        public string Remarks { get; set; } = string.Empty;
    }
}
