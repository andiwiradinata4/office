﻿using NetCore.Models.dto.Base;
using NetCore.Models.dto.Status;
using System.ComponentModel.DataAnnotations.Schema;

namespace NetCore.Models.dto.MaritalStatus
{
    public class MaritalStatusDTO: BaseDTO
    {
        public int ID { get; set; }
        public string Description { get; set; } = String.Empty;
        [ForeignKey("Status")]
        public int StatusID { get; set; }
        public StatusDTO? Status { get; set; }
        public List<Driver> Drivers { get; set; } = new List<Driver>();
    }
}
