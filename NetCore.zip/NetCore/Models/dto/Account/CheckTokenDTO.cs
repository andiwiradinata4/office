﻿using System.ComponentModel.DataAnnotations;

namespace NetCore.Models.dto.Account
{
    public class CheckTokenDTO
    {
        [Required]
        public string Token { get; set; } = String.Empty;
    }
}
