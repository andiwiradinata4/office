﻿using System.ComponentModel.DataAnnotations;

namespace NetCore.Models.dto.Account
{
    public class ChangePhoneNumberTokenDTO
    {
        [Required]
        public string NewPhoneNumber { get; set; } = string.Empty;
    }
}
