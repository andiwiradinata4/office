﻿using System.ComponentModel.DataAnnotations;

namespace NetCore.Models.dto.Account
{
    public class ConfirmEmailDTO
    {
        [Required]
        public string Code { get; set; } = string.Empty;
    }
}
