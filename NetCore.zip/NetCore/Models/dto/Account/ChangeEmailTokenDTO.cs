﻿using System.ComponentModel.DataAnnotations;

namespace NetCore.Models.dto.Account
{
    public class ChangeEmailTokenDTO
    {
        [Required]
        [EmailAddress]
        public string NewEmail { get; set; } = string.Empty;
    }
}
