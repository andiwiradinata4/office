﻿using System.ComponentModel.DataAnnotations;

namespace NetCore.Models.dto.Account
{
    public class PhoneNumberConfirmationTokenDTO
    {
        [Required]
        public string PhoneNumber { get; set; } = string.Empty;
    }
}
