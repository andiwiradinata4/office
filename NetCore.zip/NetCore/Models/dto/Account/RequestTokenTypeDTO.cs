﻿using System.ComponentModel.DataAnnotations;

namespace NetCore.Models.dto.Account
{
    public class RequestTokenTypeDTO
    {
        [Required]
        public string TokenType { get; set; } = string.Empty;
    }
}
