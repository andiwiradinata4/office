﻿namespace NetCore.Models.dto.Base
{
    public class BaseDto
    {
        public string LogBy { get; set; } = string.Empty;
        public DateTime LogDate { get; set; }
        public int LogInc { get; set; }
        public string CreatedBy { get; set; } = string.Empty;
        public DateTime CreatedDate { get; set; }
    }
}
