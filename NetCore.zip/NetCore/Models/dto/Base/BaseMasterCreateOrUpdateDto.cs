﻿using System.ComponentModel.DataAnnotations;

namespace NetCore.Models.dto.Base
{
    public class BaseMasterCreateOrUpdateDto
    {
        [Required]
        public string Description { get; set; } = string.Empty;
        [Required]
        public byte StatusID { get; set; }
        public string Remarks { get; set; } = string.Empty;
    }
}