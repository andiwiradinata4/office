﻿namespace NetCore.Models.dto.Base
{
    public class DataDTO
    {
        public int? TotalCount { get; set; }
        public object? Results { get; set; }
    }
}
