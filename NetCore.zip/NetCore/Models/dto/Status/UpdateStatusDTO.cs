﻿using System.ComponentModel.DataAnnotations;

namespace NetCore.Models.dto.Status
{
    public class UpdateStatusDTO
    {
        [Required]
        public string Description { get; set; } = string.Empty;
        [Required]
        public bool IsActive { get; set; }
        public string Remarks { get; set; } = string.Empty;
    }
}
