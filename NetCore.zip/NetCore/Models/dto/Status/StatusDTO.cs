﻿using NetCore.Models.dto.Base;
using NetCore.Models.dto.BloodType;
using NetCore.Models.dto.Gender;
using NetCore.Models.dto.MaritalStatus;
using NetCore.Models.dto.Nationality;
using NetCore.Models.dto.Religion;
using System.ComponentModel.DataAnnotations;

namespace NetCore.Models.dto.Status
{
    public class StatusDTO : BaseDTO
    {
        public int ID { get; set; }
        [Required]
        public string Description { get; set; } = string.Empty;
        public bool IsActive { get; set; }
        public List<BloodTypeDTO> BloodTypes { get; set; } = new List<BloodTypeDTO>();
        public List<GenderDTO> Genders { get; set; } = new List<GenderDTO>();
        public List<MaritalStatusDTO> MaritalStatus { get; set; } = new List<MaritalStatusDTO>();
        public List<NationalityDTO> Nationality { get; set; } = new List<NationalityDTO>();
        public List<ReligionDTO> Religions { get; set; } = new List<ReligionDTO>();
        //public List<DriverDTO> Drivers { get; set; } = new List<DriverDTO>();
    }
}
