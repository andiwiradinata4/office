﻿using NetCore.Models.dto.Base;
using NetCore.Models.dto.Status;

namespace NetCore.Models.dto.Gender
{
    public class GenderDTO: BaseDTO
    {
        public int ID { get; set; }
        public string Description { get; set; } = String.Empty;
        public int StatusID { get; set; }
        public StatusDTO? Status { get; set; }
        public List<Driver> Drivers { get; set; } = new List<Driver>();
    }
}
