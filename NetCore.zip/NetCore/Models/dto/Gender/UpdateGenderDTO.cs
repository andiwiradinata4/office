﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace NetCore.Models.dto.Gender
{
    public class UpdateGenderDTO
    {
        [Required]
        public string Description { get; set; } = String.Empty;
        [Required]
        [ForeignKey("Status")]
        public int StatusID { get; set; }
        public string Remarks { get; set; } = string.Empty;
    }
}
