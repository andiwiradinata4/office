﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace NetCore.Models.dto.Nationality
{
    public class CreateNationalityDTO
    {
        [Required]
        public string Description { get; set; } = String.Empty;
        [Required]
        [ForeignKey("Status")]
        public int StatusID { get; set; }
        public string Remarks { get; set; } = string.Empty;
    }
}
