﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NetCore.Models.dto.BloodType
{
    public class CreateBloodTypeDTO
    {
        [Required]
        public string Description { get; set; } = String.Empty;
        [Required]
        [ForeignKey("Status")]
        public int StatusID { get; set; }
        public string Remarks { get; set; } = string.Empty;
    }
}
