﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NetCore.Models.dto.BloodType
{
    public class UpdateBloodTypeDTO
    {
        [Required]
        public string Description { get; set; } = String.Empty;
        [Required]
        [ForeignKey("Status")]
        public int StatusID { get; set; }
        public string Remarks { get; set; } = string.Empty;
    }
}
