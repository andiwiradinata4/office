﻿using NetCore.Models.Interface;

namespace NetCore.Models
{
    public class BaseEntity: BaseEntityCustom, IEntityStandard, IBaseEntityStandard
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
    }
}