﻿namespace NetCore.Models
{
    public class ColumnSet
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public int? Size { get; set; }
    }
}
