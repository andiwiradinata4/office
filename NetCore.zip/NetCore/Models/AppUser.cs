﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations.Schema;

namespace NetCore.Models
{
    [Table("LR_mstUser")]
    public class AppUser: IdentityUser
    {
        //public int ID { get; set; }
        //public string Email { get; set; } = System.String.Empty;
        //public string UserName { get; set; } = System.String.Empty;
    }
}
