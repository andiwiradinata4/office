﻿using System.ComponentModel.DataAnnotations.Schema;

namespace NetCore.Models
{
    [Table("LR_sysAppLog")]
    public class AppLog : BaseEntity
    {
        public string Session { get; set; } = string.Empty;
        public string Method { get; set; } = string.Empty;
        public string Header { get; set; } = string.Empty;
        public string Body { get; set; } = string.Empty;
        public string LogType { get; set; } = string.Empty;
    }
}
