﻿using NetCore.Models.dto.MaritalStatus;

namespace NetCore.Models.Mappers
{
    public static class MaritalStatusMappers
    {
        public static MaritalStatusDTO ToDto(this MaritalStatus entity)
        {
            return new MaritalStatusDTO
            {
                ID = entity.ID,
                Description = entity.Description,
                StatusID = entity.StatusID,
                Status = entity.Status.ToDto(),
                Remarks = entity.Remarks,
                CreatedBy = entity.CreatedBy,
                CreatedDate = entity.CreatedDate,
                LogBy = entity.LogBy,
                LogDate = entity.LogDate,
                LogInc = entity.LogInc
            };
        }

        public static MaritalStatus FromDto(this MaritalStatusDTO dto)
        {
            return new MaritalStatus
            {
                ID = dto.ID,
                Description = dto.Description,
                StatusID = dto.StatusID,
                Status = dto.Status.FromDto(),
                Remarks = dto.Remarks,
                CreatedBy = dto.CreatedBy,
                CreatedDate = dto.CreatedDate,
                LogBy = dto.LogBy,
                LogDate = dto.LogDate,
                LogInc = dto.LogInc
            };
        }

        public static MaritalStatus FromCreateOrUpdateDto(this MaritalStatusDTO dto)
        {
            return new MaritalStatus
            {
                Description = dto.Description,
                StatusID = dto.StatusID,
                Remarks = dto.Remarks
            };
        }
    }
}
