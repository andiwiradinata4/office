﻿using NetCore.Models.dto.Base;

namespace NetCore.Models.Mappers
{
    public static class MaritalStatusMappers
    {
        public static MaritalStatus ToDto(this MaritalStatus entity)
        {
            return new MaritalStatus
            {
                ID = entity.ID,
                Description = entity.Description,
                StatusID = entity.StatusID,
                Remarks = entity.Remarks,
                CreatedBy = entity.CreatedBy,
                CreatedDate = entity.CreatedDate,
                LogBy = entity.LogBy,
                LogDate = entity.LogDate,
                LogInc = entity.LogInc
            };
        }

        public static MaritalStatus FromCreateOrUpdateMaritalStatusDto(this BaseMasterCreateOrUpdateDto dto)
        {
            return new MaritalStatus
            {
                Description = dto.Description,
                StatusID = dto.StatusID,
                Remarks = dto.Remarks
            };
        }
    }
}
