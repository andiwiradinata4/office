﻿using NetCore.Models.dto.Gender;

namespace NetCore.Models.Mappers
{
    public static class GenderMappers
    {
        public static GenderDTO ToDto(this Gender entity)
        {
            return new GenderDTO
            {
                ID = entity.ID,
                Description = entity.Description,
                StatusID = entity.StatusID,
                Status = entity.Status.ToDto(),
                Remarks = entity.Remarks,
                CreatedBy = entity.CreatedBy,
                CreatedDate = entity.CreatedDate,
                LogBy = entity.LogBy,
                LogDate = entity.LogDate,
                LogInc = entity.LogInc
            };
        }

        public static Gender FromDto(this GenderDTO dto)
        {
            return new Gender
            {
                ID = dto.ID,
                Description = dto.Description,
                StatusID = dto.StatusID,
                Status = dto.Status.FromDto(),
                Remarks = dto.Remarks,
                CreatedBy = dto.CreatedBy,
                CreatedDate = dto.CreatedDate,
                LogBy = dto.LogBy,
                LogDate = dto.LogDate,
                LogInc = dto.LogInc
            };
        }

        public static Gender FromCreateOrUpdateDto(this GenderDTO dto)
        {
            return new Gender
            {
                Description = dto.Description,
                StatusID = dto.StatusID,
                Remarks = dto.Remarks
            };
        }
    }
}
