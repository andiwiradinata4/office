﻿using NetCore.Models.dto.Base;

namespace NetCore.Models.Mappers
{
    public static class ReligionMappers
    {
        public static Religion ToDto(this Religion entity)
        {
            return new Religion
            {
                ID = entity.ID,
                Description = entity.Description,
                StatusID = entity.StatusID,
                Remarks = entity.Remarks,
                CreatedBy = entity.CreatedBy,
                CreatedDate = entity.CreatedDate,
                LogBy = entity.LogBy,
                LogDate = entity.LogDate,
                LogInc = entity.LogInc
            };
        }

        public static Religion FromCreateOrUpdateReligionDto(this BaseMasterCreateOrUpdateDto dto)
        {
            return new Religion
            {
                Description = dto.Description,
                StatusID = dto.StatusID,
                Remarks = dto.Remarks
            };
        }
    }
}
