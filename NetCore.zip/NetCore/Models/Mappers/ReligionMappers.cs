﻿using NetCore.Models.dto.Base;
using NetCore.Models.dto.Religion;

namespace NetCore.Models.Mappers
{
    public static class ReligionMappers
    {
        public static ReligionDTO ToDto(this Religion entity)
        {
            return new ReligionDTO
            {
                ID = entity.ID,
                Description = entity.Description,
                StatusID = entity.StatusID,
                Status = entity.Status.ToDto(),
                Remarks = entity.Remarks,
                CreatedBy = entity.CreatedBy,
                CreatedDate = entity.CreatedDate,
                LogBy = entity.LogBy,
                LogDate = entity.LogDate,
                LogInc = entity.LogInc
            };
        }

        public static Religion FromDto(this ReligionDTO dto)
        {
            return new Religion
            {
                ID = dto.ID,
                Description = dto.Description,
                StatusID = dto.StatusID,
                Status = dto.Status.FromDto(),
                Remarks = dto.Remarks,
                CreatedBy = dto.CreatedBy,
                CreatedDate = dto.CreatedDate,
                LogBy = dto.LogBy,
                LogDate = dto.LogDate,
                LogInc = dto.LogInc
            };
        }

        public static Religion FromCreateOrUpdateDto(this ReligionDTO dto)
        {
            return new Religion
            {
                Description = dto.Description,
                StatusID = dto.StatusID,
                Remarks = dto.Remarks
            };
        }
    }
}
