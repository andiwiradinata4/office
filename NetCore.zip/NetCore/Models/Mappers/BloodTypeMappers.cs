﻿using NetCore.Models.dto.Base;

namespace NetCore.Models.Mappers
{
    public static class BloodTypeMappers
    {
        public static BloodType ToDto(this BloodType entity)
        {
            return new BloodType
            {
                ID = entity.ID,
                Description = entity.Description,
                StatusID = entity.StatusID,
                Remarks = entity.Remarks,
                CreatedBy = entity.CreatedBy,
                CreatedDate = entity.CreatedDate,
                LogBy = entity.LogBy,
                LogDate = entity.LogDate,
                LogInc = entity.LogInc
            };
        }

        public static BloodType FromCreateOrUpdateBloodTypeDto(this BaseMasterCreateOrUpdateDto dto)
        {
            return new BloodType
            {
                Description = dto.Description,
                StatusID = dto.StatusID,
                Remarks = dto.Remarks
            };
        }
    }
}
