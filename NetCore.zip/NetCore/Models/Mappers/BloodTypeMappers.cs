﻿using NetCore.Models.dto.Base;
using NetCore.Models.dto.BloodType;

namespace NetCore.Models.Mappers
{
    public static class BloodTypeMappers
    {
        public static BloodTypeDTO ToDto(this BloodType entity)
        {
            return new BloodTypeDTO
            {
                ID = entity.ID,
                Description = entity.Description,
                StatusID = entity.StatusID,
                Status = entity.Status.ToDto(),
                Remarks = entity.Remarks,
                CreatedBy = entity.CreatedBy,
                CreatedDate = entity.CreatedDate,
                LogBy = entity.LogBy,
                LogDate = entity.LogDate,
                LogInc = entity.LogInc
            };
        }

        public static BloodType FromDto(this BloodTypeDTO dto)
        {
            return new BloodType
            {
                ID = dto.ID,
                Description = dto.Description,
                StatusID = dto.StatusID,
                Status = dto.Status.FromDto(),
                Remarks = dto.Remarks,
                CreatedBy = dto.CreatedBy,
                CreatedDate = dto.CreatedDate,
                LogBy = dto.LogBy,
                LogDate = dto.LogDate,
                LogInc = dto.LogInc
            };
        }

        public static BloodType FromCreateOrUpdateDto(this BloodTypeDTO dto)
        {
            return new BloodType
            {
                Description = dto.Description,
                StatusID = dto.StatusID,
                Remarks = dto.Remarks
            };
        }
    }
}
