﻿using NetCore.Models.dto.Nationality;

namespace NetCore.Models.Mappers
{
    public static class NationalityMappers
    {
        public static NationalityDTO ToDto(this Nationality entity)
        {
            return new NationalityDTO
            {
                ID = entity.ID,
                Description = entity.Description,
                StatusID = entity.StatusID,
                Status = entity.Status.ToDto(),
                Remarks = entity.Remarks,
                CreatedBy = entity.CreatedBy,
                CreatedDate = entity.CreatedDate,
                LogBy = entity.LogBy,
                LogDate = entity.LogDate,
                LogInc = entity.LogInc
            };
        }

        public static Nationality FromDto(this NationalityDTO dto)
        {
            return new Nationality
            {
                ID = dto.ID,
                Description = dto.Description,
                StatusID = dto.StatusID,
                Status = dto.Status.FromDto(),
                Remarks = dto.Remarks,
                CreatedBy = dto.CreatedBy,
                CreatedDate = dto.CreatedDate,
                LogBy = dto.LogBy,
                LogDate = dto.LogDate,
                LogInc = dto.LogInc
            };
        }

        public static Nationality FromCreateOrUpdateDto(this NationalityDTO dto)
        {
            return new Nationality
            {
                Description = dto.Description,
                StatusID = dto.StatusID,
                Remarks = dto.Remarks
            };
        }
    }
}
