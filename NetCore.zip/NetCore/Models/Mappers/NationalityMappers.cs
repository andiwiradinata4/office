﻿using NetCore.Models.dto.Base;

namespace NetCore.Models.Mappers
{
    public static class NationalityMappers
    {
        public static Nationality ToDto(this Nationality entity)
        {
            return new Nationality
            {
                ID = entity.ID,
                Description = entity.Description,
                StatusID = entity.StatusID,
                Remarks = entity.Remarks,
                CreatedBy = entity.CreatedBy,
                CreatedDate = entity.CreatedDate,
                LogBy = entity.LogBy,
                LogDate = entity.LogDate,
                LogInc = entity.LogInc
            };
        }

        public static Nationality FromCreateOrUpdateNationalityDto(this BaseMasterCreateOrUpdateDto dto)
        {
            return new Nationality
            {
                Description = dto.Description,
                StatusID = dto.StatusID,
                Remarks = dto.Remarks
            };
        }
    }
}
