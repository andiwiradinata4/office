﻿using NetCore.Models.dto.Nationality;
using NetCore.Models.dto.Status;

namespace NetCore.Models.Mappers
{
    public static class StatusMappers
    {
        public static StatusDTO ToDto(this Status entity)
        {
            return new StatusDTO
            {
                ID = entity.ID,
                Description = entity.Description,
                IsActive = entity.IsActive,
                Remarks = entity.Remarks,
                CreatedBy = entity.CreatedBy,
                CreatedDate = entity.CreatedDate,
                LogBy = entity.LogBy,
                LogDate = entity.LogDate,
                LogInc = entity.LogInc
            };
        }

        public static Status FromDto(this StatusDTO dto)
        {
            return new Status
            {
                ID = dto.ID,
                Description = dto.Description,
                IsActive = dto.IsActive,
                Remarks = dto.Remarks,
                CreatedBy = dto.CreatedBy,
                CreatedDate = dto.CreatedDate,
                LogBy = dto.LogBy,
                LogDate = dto.LogDate,
                LogInc = dto.LogInc
            };
        }

        public static Status FromCreateOrUpdateStatusDto(this StatusDTO dto)
        {
            return new Status
            {
                Description = dto.Description,
                IsActive = dto.IsActive,
                Remarks = dto.Remarks
            };
        }
    }
}
