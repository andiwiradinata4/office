﻿using NetCore.Models.dto.Status;

namespace NetCore.Models.Mappers
{
    public static class StatusMappers
    {
        public static Status ToDto(this Status entity)
        {
            return new Status
            {
                ID = entity.ID,
                Description = entity.Description,
                IsActive = entity.IsActive,
                Remarks = entity.Remarks,
                CreatedBy = entity.CreatedBy,
                CreatedDate = entity.CreatedDate,
                LogBy = entity.LogBy,
                LogDate = entity.LogDate,
                LogInc = entity.LogInc
            };
        }

        public static Status FromCreateOrUpdateStatusDto(this CreateOrUpdateDto dto)
        {
            return new Status
            {
                Description = dto.Description,
                IsActive = dto.IsActive,
                Remarks = dto.Remarks
            };
        }
    }
}
