﻿namespace NetCore.Models.Shared
{
    public static class ComLoc
    {
        public static string ProgramId { get; set; }
        public static string CompanyId { get; set; }
    }
}
