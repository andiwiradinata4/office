﻿using System.ComponentModel.DataAnnotations.Schema;

namespace NetCore.Models
{
    [Table("LR_mstDriverImage")]
    public class DriverImage : BaseEntity
    {
        public string DriverID { get; set; } = string.Empty;
        public string ImagePath { get; set; } = string.Empty;
        public int ImageTypeID { get; set; }
    }
}
