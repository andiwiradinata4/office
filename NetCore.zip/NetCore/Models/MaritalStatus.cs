﻿using System.ComponentModel.DataAnnotations.Schema;

namespace NetCore.Models
{
    [Table("LR_mstMaritalStatus")]
    public class MaritalStatus : BaseEntity
    {
        public string Description { get; set; } = String.Empty;
        public int StatusID { get; set; }
        public Status? Status { get; set; }
        //public List<Driver> Drivers { get; set; } = new List<Driver>();
    }
}
