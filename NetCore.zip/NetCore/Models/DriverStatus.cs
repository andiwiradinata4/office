﻿using System.ComponentModel.DataAnnotations.Schema;

namespace NetCore.Models
{
    [Table("LR_mstDriverStatus")]
    public class DriverStatus : BaseEntity
    {
        [ForeignKey("Driver")]
        public string DriverID { get; set; } = string.Empty;
        public Driver? Driver { get; set; }
        public string Status { get; set; } = string.Empty;
        public string StatusBy { get; set; } = string.Empty;
        public DateTime StatusDate { get; set; } = DateTime.Now;
    }
}