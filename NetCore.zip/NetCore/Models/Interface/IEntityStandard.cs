﻿namespace NetCore.Models.Interface
{
    public interface IEntityStandard
    {
        string Id { get; set; }
    }
}
