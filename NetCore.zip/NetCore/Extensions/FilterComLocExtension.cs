﻿using NetCore.Middlewares;

namespace NetCore.Extensions
{
    public static class FilterComLocExtension
    {
        public static IApplicationBuilder UsFilterComLoc(this IApplicationBuilder builder) => builder.UseMiddleware<FilterComLoc>();
    }
}
