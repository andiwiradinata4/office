﻿using Microsoft.EntityFrameworkCore;
namespace NetCore.usDBContext
{
    public static class usIQueryableExtensions
    {
        public static IQueryable<T> IncludeProperties<T>(this IQueryable<T> query, params string[] properties) where T : class
        {
            foreach (var property in properties)
            {
                string[] strings = property.Split(',');
                foreach (string str in strings)
                {
                    query = query.Include(str);
                }
            }
            return query;
        }

    }

}
