﻿using Microsoft.EntityFrameworkCore;

namespace NetCore.usDBContext
{
    public static class usCustomModelBuilderExtensions
    {
        public static void ExcludeMigration<T>(this ModelBuilder modelBuilder) where T : class
        {
            modelBuilder.Entity<T>().ToTable(nameof(T), e => e.ExcludeFromMigrations());
        }

        public static void SetToView<T>(this ModelBuilder modelBuilder, string viewName) where T : class
        {
            modelBuilder.Entity<T>(e =>
            {
                e.HasNoKey();
                e.ToView(viewName);
            });

            modelBuilder.ExcludeMigration<T>();
        }

        public static void SetRelationship(this ModelBuilder modelBuilder, DeleteBehavior deleteBehavior)
        {
            modelBuilder.Model.GetEntityTypes().SelectMany(e => e.GetForeignKeys()).ToList().ForEach(e => { e.DeleteBehavior = deleteBehavior });
            //foreach (var relationship in modelBuilder.Model.GetEntityTypes().SelectMany(e => e.GetForeignKeys())) {relationship.DeleteBehavior = deleteBehavior;}
        }
    }
}
