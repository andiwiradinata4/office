﻿using Microsoft.EntityFrameworkCore;

namespace NetCore.usDBContext
{
    public static class usCustomModelBuilderExtensions
    {
        public static void ExcludeMigration<T>(this ModelBuilder modelBuilder) where T : class
        {
            modelBuilder.Entity<T>().ToTable(nameof(T), e => e.ExcludeFromMigrations());
        }

        public static void SetToView<T>(this ModelBuilder modelBuilder, string viewName) where T : class
        {
            modelBuilder.Entity<T>(e =>
            {
                e.HasNoKey();
                e.ToView(viewName);
            });

            modelBuilder.ExcludeMigration<T>();
        }
    }
}
